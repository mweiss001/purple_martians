/* fnx.c    other functions I don't know where else to put     */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>

/* functions
   ---------
   edit_float()
   edit_int()
   getxy100()

*/

int edit_float(int x, int y)
{
extern float edit_float_retval;

extern float finitial, fxinc, fyinc, flv, fuv;  /* I used to pass these but now it dont work */
int imx = mouse_x;
int imy = mouse_y;

int quit_mode= 0, retval, ef_quit=0;
int old_mouse_x, old_mouse_y;
char msg[80];
if (mouse_b & 1) quit_mode = 1;   /* set mouse exit mode if b1 pressed on enter */
clear_keybuf();
do
   {
      sprintf(msg,"%-4.3f ",finitial);
      textout(screen, font, msg, x, y, 1);

   /*     if (key[KEY_RIGHT])
         {
            clear_keybuf();
            rest(5);
            finitial += fxinc;

         }
     if (key[KEY_LEFT])
         {
            clear_keybuf();
            rest(5);
            finitial -= fxinc;
         }
      if (key[KEY_UP])
         {
            clear_keybuf();
            rest(5);
            finitial += fyinc;

         }
     if (key[KEY_DOWN])
         {
            clear_keybuf();
            rest(5);
            finitial -= fyinc;
         }*/
if (quit_mode == 1)     /* b1 pressed on function entry  */
   {
        if (!(mouse_b & 1))      /* wait for b1 release */
         {
            clear_keybuf();
            sprintf(msg,"%f  ",finitial);
            textout(screen, font, msg, x, y, 49);
            edit_float_retval = finitial;
            retval = 1;
            ef_quit = 1;

         }
   }
if (quit_mode == 0)
   {
    if (key[KEY_ENTER])
         {
            clear_keybuf();
            sprintf(msg,"%f  ",finitial);
            textout(screen, font, msg, x, y, 49);
            edit_float_retval = finitial;
            retval = 1;
            ef_quit = 1;

         }
   }

if ((key[KEY_ESC]) || (mouse_b & 2))
         {
            clear_keybuf();
            retval = 0;
            ef_quit = 1;

         }

    if (key[KEY_INSERT]) finitial = 0;


    if (key[KEY_DEL])
       {
          x = finitial;
          finitial = x;
       }

    position_mouse(160,100);
    old_mouse_x = mouse_x;
    old_mouse_y = mouse_y;
    rest(10); /* this wait is crucial to get mouse movement */


    finitial += (mouse_x - old_mouse_x) * fxinc;

    if (key[KEY_PGDN]) finitial -= ((mouse_y - old_mouse_y) * (fyinc/10));
    else finitial -= (mouse_y - old_mouse_y) * fyinc;
    if (key[KEY_PGUP]) finitial -= ((mouse_y - old_mouse_y) * (finitial/2));
    if (finitial > fuv) finitial = fuv;
    if (finitial < flv) finitial = flv;
   } while (!ef_quit);
position_mouse(imx, imy);

return retval;
}


int edit_int( int x, int y, int initial, int inc, int lv, int uv)
{
extern int edit_int_retval;
int imx = mouse_x;
int imy = mouse_y;
int quit_mode = 0, retval, quit=0, old_mouse;
char msg[80];

if (mouse_b & 1) quit_mode = 1;   /* set mouse exit mode if b1 pressed on enter */
clear_keybuf();
do
   {
      sprintf(msg,"%d  ",initial);
      textout(screen, font, msg, x, y, 1);
      if (key[KEY_UP])
         {
            clear_keybuf();
            rest(5);
            initial += inc;

         }
     if (key[KEY_DOWN])
         {
            clear_keybuf();
            rest(5);
            initial -= inc;
         }
  if (quit_mode == 1)
   {
        if (!(mouse_b & 1))
         {
            clear_keybuf();
            sprintf(msg,"%d  ",initial);
            textout(screen, font, msg, x, y, 34);
            edit_int_retval = initial;
            retval = 1;
            quit = 1;

         }
   }
if (quit_mode == 0)
   {
    if ((key[KEY_ENTER]) || (mouse_b & 1))
         {
            clear_keybuf();
            sprintf(msg,"%d  ",initial);
            textout(screen, font, msg, x, y, 34);
            edit_int_retval = initial;
            retval = 1;
            quit = 1;

         }
   }
    if ((key[KEY_ESC]) || (mouse_b & 2))
         {
            clear_keybuf();
            retval = 0;
            quit = 1;

         }
    position_mouse(160, 100);
    old_mouse = mouse_y;
    rest(10);
    initial = initial - ((mouse_y - old_mouse) * inc);
    if (initial > uv) initial = uv;
    if (initial < lv) initial = lv;
   } while (!quit);

position_mouse(imx, imy);
return retval;
}


