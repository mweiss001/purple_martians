#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>

/* funtion prototype */
void create_mov(int);

int sort_enemy(void)
{
extern int Ei[100][10];
extern float Ef[100][10];
int swap_flag = 1;
int do_swap = 0;
int temp;
float ftemp;
int num_enem;
int a, b, c, d, x, y, z;

                  while (swap_flag)
                     {
                        do_swap = 0;
                        swap_flag = 0;
                        for (x=0;x<99;x++)
                           {
                              if ( Ei[x][0] < Ei[x+1][0] )
                                 do_swap = 1;
                              if (do_swap) /* do the swap */
                                {
                                    swap_flag = 1;
                                    do_swap = 0;
                                    for (y=0; y<10; y++)
                                       {
                                          temp = Ei[x][y];
                                          Ei[x][y] = Ei[x+1][y];
                                          Ei[x+1][y] = temp;

                                          ftemp = Ef[x][y];
                                          Ef[x][y] = Ef[x+1][y];
                                          Ef[x+1][y] = ftemp;
                                        }


                                } /* end of swap */
                           } /* end of for x */
                     } /* end of while swap flag */
num_enem = 0;
for (d=0; d<100; d++)
   if (Ei[d][0]) ++num_enem;

return num_enem; /* number of enemies */
}
int sort_mov(void)
{
extern int mov_ob[20][20];
extern int mov_obi[20][20][4];
int swap_flag = 1;
int do_swap = 0;
int temp;
int num_obj;
int a, b, c, d, x, y, z;

        num_obj = 0;
            for (d=0; d<20; d++)
               if (mov_ob[d][0]) ++num_obj;

if (num_obj > 0)
{
                  while (swap_flag)
                     {
                        do_swap = 0;
                        swap_flag = 0;
                        for (x=0;x<19;x++)
                           {
                              if ( mov_ob[x][0] < mov_ob[x+1][0] )
                                 do_swap = 1;

                              if (do_swap) /* do the swap */
                                {
                                    swap_flag = 1;
                                    do_swap = 0;
                                    for (y=0; y<19; y++)
                                       {
                                          temp = mov_ob[x][y];
                                          mov_ob[x][y] = mov_ob[x+1][y];
                                          mov_ob[x+1][y] = temp;

                                          for (z=0; z<4; z++)
                                             {
                                                temp = mov_obi[x][y][z];
                                                mov_obi[x][y][z] = mov_obi[x+1][y][z];
                                                mov_obi[x+1][y][z] = temp;
                                             }
                                       }


                                } /* end of swap */
                           } /* end of for x */
                     } /* end of while swap flag */
        }
      return num_obj;
}
void draw100(int enemy_line)
{
   /* who uses?  getxy100(), enemytest100(), edit100  */
   int c, x, y;
   extern int l[100][100];
   extern int item[500][16];

   set_mouse_range(0,0,199,199);
   for (x = 0; x < 100; x++)
      for (y=0; y < 100; y++)
         {
            c= 0;
            if ((l[x][y] > 7 ) && (l[x][y] <16)) c = 6; /*  semi solid block */
            if ((l[x][y] > 15) && (l[x][y] <256)) c = 243; /*  solid block */
            if ((l[x][y] > 23) && (l[x][y] <32)) c = 5; /* breakable block */
            rectfill(screen,(x*2),(y*2),(x*2)+1,(y*2)+1,c);
         }
   for (y=0; y < 500; y++)
      if (item[y][0])
         {
            int x1 = item[y][4]/10;
            int y1 = item[y][5]/10;
            rectfill(screen, x1, y1, x1+1, y1+1, 7);
         }
}


void block_functions(int draw_item)
{
   int bl1gry,d,x,y,x1,y1,x2,y2,x3,y3;
   extern int get100_x, get100_y;
   extern int l[100][100];
   extern int item[500][16];
   char msg[80];

   x1 = get100_x;
   y1 = get100_y;

   clear(screen);
   textout(screen, font, "BLOCK FNX"   ,205,122,240);
   textout(screen, font, "---------"   ,205,130,240);
   textout(screen, font, "mouse b1"    ,205,138,11);
   textout(screen, font, "bottom/right",205,146,11);
   textout(screen, font, "mouse b2/esc",205,156,10);
   textout(screen, font, "BACK"        ,205,164,10);
   d = getxy100(999); /* 999 = no current enemy display */
   if (d == 1) /* only if b1 pressed */
      {
      if (mouse_x < 200)   /*  got bottom_left */
         {
            x2 = get100_x;
            y2 = get100_y;
         }
      rect(screen, x1*2-1,y1*2-1,x2*2+2,y2*2+2,128);
      rect(screen, x1*2-2,y1*2-2,x2*2+3,y2*2+3,240);

      bl1gry = 999;
      rest(200); /* to prevent selecting on entry */
      do
         {
            textout(screen, font, " Block Functions Menu ", 40, 174, 246);
            bl1gry = (bottom_menu(6));   /* call the menu handler */
            if (bl1gry == 0) /* set to zero */
               {
                  for (x=x1; x < (x2+1); x++)
                    for (y=y1; y < (y2+1); y++)
                      l[x][y] = 0;
                  bl1gry=-1;
                  draw100(0);
                }
            if (bl1gry == 1) /* set frame */
               {
                  for (x=x1; x < (x2+1); x++)
                     {
                        l[x][y1] = draw_item;
                        l[x][y2] = draw_item;
                     }
                  for (y=y1; y < (y2+1); y++)
                     {
                        l[x1][y] = draw_item;
                        l[x2][y] = draw_item;
                     }
                  bl1gry=-1;
                  draw100(0);
               }
            if (bl1gry == 2) /* set block */
               {
                  for (x=x1; x < (x2+1); x++)
                    for (y=y1; y < (y2+1); y++)
                       {
                          if (l[x][y] > 255) item[l[x][y]-256][0] = 0;
                          l[x][y] = draw_item;
                       }
                  bl1gry=-1;
                  draw100(0);
               }

                     if (bl1gry == 3) /* copy */
                        {

                           textout(screen, font, "COPY TO:"   ,205,122,240);
                           textout(screen, font, "--------"   ,205,130,240);
                           textout(screen, font, "mouse b1"    ,205,138,11);
                           textout(screen, font, "COPY",205,146,11);
                           textout(screen, font, "mouse b2/esc",205,156,10);
                           textout(screen, font, "BACK"        ,205,164,10);
                           do
                              {
                                 d = getxy100(999); /* 999 = no current enemy display */
                                 if ((d == 1) && (mouse_x < 200))  /* get copy destination*/
                                    {
                                       x3 = get100_x;
                                       y3 = get100_y;
                                       for (x=0; x < (x2-x1+1); x++)
                                          for (y=0; y < (y2-y1+1); y++)
                                            l[x3+x][y3+y] = l[x1+x][y1+y];
                                       draw100(0);
                                       rect(screen, x1*2-1,y1*2-1,x2*2+2,y2*2+2,128);
                                       rect(screen, x1*2-2,y1*2-2,x2*2+3,y2*2+3,240);
                                    }
                              } while ((d != 0) && (d != 2));
                         }


                     if (bl1gry == 4) ;
                     if (bl1gry == 5) ;
                     if (bl1gry == 6) ;
                     if (mouse_b & 2) bl1gry = -1;
                  } while (bl1gry != -1);  /* quit the block menu  */
        } /* end of if d == 1 */

}
int edit100(int wx, int wy, int draw_item)        /* F1 ZOOM  100x100 Edit Level  */
{
extern int l[100][100];
extern int item[500][16];
extern int bmp_index; 
extern int get100_x, get100_y;
int b, c, d, x, y;
int e100_redraw;
      if (mouse_y<160)
         {
             /* convert mouse positions from 16x8 to 100x100*/
             x = (mouse_x/20) + wx;
             y = (mouse_y/20) + wy;
             position_mouse( (x*2), (y*2) );
         }
      else
         {
             /* convert window position */
             position_mouse( (wx*2), (wy*2) );
         }
      do
         {
            clear(screen);
            textout(screen, font, "ZOOM OUT"  ,205,122,240);
            textout(screen, font, "--------"  ,205,130,240);
            textout(screen, font, "mouse b1"    ,205,138,11);
            textout(screen, font, "BLOCK FNX"   ,205,146,11);
            textout(screen, font, "mouse b2/esc",205,156,10);
            textout(screen, font, "BACK",       205,164,10);

            d = getxy100(999); /* 999 = no current enemy display */
            if (d == 1) block_functions(draw_item);

         } while ((d != 0) && (d != 2));  /* end of display 100  */
      clear_keybuf();
      clear(screen);
      /* convert mouse positions from 100x100 to 16x8  */
      x = (mouse_x/2) ;
      if (x > 99) x = 99;
      wx = x - 8;
      if (wx < 0) wx = 0;
      if (wx > 83) wx = 83;
      y = (mouse_y/2) ;
      wy = y - 4;
      if (wy < 0) wy = 0;
      if (wy > 91) wy = 91;
      position_mouse( ((x-wx) *20), ((y-wy) *20) );
      set_mouse_range(0,0,319,199);
      return (wy*100)+wx;

   }



int getxy100(int current_enemy)
{
extern int zz[20][64];
extern int l[100][100];
extern int item[500][16];
extern int Ei[100][10];
extern float Ef[100][10];
extern int mov_ob[20][20];
extern int mov_obi[20][20][4];

extern BITMAP *memory_bitmap[512];
extern int get100_x, get100_y;

int cur_en_line=1;
int retval, quit=0, bullseye_x, bullseye_y;
int a, b, c, d, e, f, x, y;

char msg[80];

           show_mouse(NULL);
           draw100(0);
                

           do
              {


                       if (mouse_x > 199) position_mouse(199, mouse_y);

                             for (x = 0; x < 5; x++)       /* draw 5x5 */
                                for (y=0; y < 5; y++)
                                   {
                                      b = (mouse_x/2);
                                      if (b > 97) b = 97;
                                      if (b < 2) b = 2;
                                      c = (mouse_y/2);
                                      if (c > 97) c = 97;
                                      if (c < 2) c = 2;

                                      a= l[x+b-2][y+c-2];
                                      blit(memory_bitmap[a] ,screen, 0, 0, 210 +(x * 20), 10 + (y * 20), 20, 20);
                                   }
                             for (d=0; d<500; d++)
                                if (item[d][0])
                                   {
                                      int x1 = item[d][4]/20;
                                      int y1 = item[d][5]/20;

                                            int x3 = 210 + ((x1-(b-2)) * 20);
                                            int y3 = 10  + ((y1-(c-2)) * 20);
                                            a = item[d][1]; /* bmp or ans */
                                            if (a > 999) a = zz[0][a-1000]; /* ans */

                                            set_clip(screen, 210, 10, 309, 109);
                                            blit(memory_bitmap[a], screen, 0,0,x3,y3,20,20);
                                            set_clip(screen, 0, 0, 319, 199);

                                    }
                             /* map border */
                             for (d=0; d<10; d++)
                                {
                                   rect(screen, 200+d, d, 319-d, 119-d, 63+(d*16) );
                                }

                             for (d=0; d<20; d++)
                                if (mov_ob[d][0]) /* active */
                                   {
                                      int x1 = mov_ob[d][2] ; /* */
                                      int y1 = mov_ob[d][3] ; /* */
                                      int x2 = mov_ob[d][4]; /* */
                                      int y2 = mov_ob[d][5]; /* */
                                      int color = mov_ob[d][12];

                                      rect(screen, x1/10, y1/10, x2/10, y2/10, color);

                                      /* ---- put on the 5x5 screen ----*/
                                               {
                                                  extern char level_text[100][40];
                                                  int x4 = 210+x1 - ((b-2)*20);
                                                  int y4 =  10+y1 - ((c-2)*20);
                                                  int x5 = 210+x2 - ((b-2)*20);
                                                  int y5 =  10+y2 - ((c-2)*20);

                                                  int tx = (x4+x5)/2;
                                                  int ty = ((y4+y5)/2)+2;

                                                  int text_line = mov_ob[d][13]-1;
                                                  set_clip(screen, 210, 10, 309, 109);
      
                                                  for (e=0; e<10; e++)
                                                     rect(screen,x4+e,y4+e,x5-e,y5-e,color+(9-e)*16);
                                                  rectfill(screen,x4+e,y4+e,x5-e,y5-e,color);

                                                  text_mode(-1);
                                                  sprintf(msg, "lift #%d", d);
                                                  if (text_line > 1) textout_centre(screen, font, level_text[text_line], tx, ty-4, color+160);
                                                  else textout_centre(screen, font, msg, tx, ty-4, color+160);
                                                  text_mode(0);
                                                  set_clip(screen, 0, 0, 319, 199);
                                               }
                                   } /* end of if (active) */
                            for (e=0; e<100; e++)    /* enemies  100x100 */
                               if (Ei[e][0]) /* active */
                               {
                                  x = Ef[e][0] / 20; /* enemy's x */
                                  y = Ef[e][1] / 20; /* enemy's y */

                                  rectfill(screen, (x*2), (y*2), (x*2)+1, (y*2)+1, 2);

                                  /* ---- put on the 5x5 screen ----*/
                                  if ( (x > (b-3)) && (x < (b+3)) &&
                                       (y > (c-3)) && (y < (c+3)) )  /* on screen */
                                     {
                                        a = Ei[e][1];  /* act bmp */
                                        set_clip(screen, 210, 10, 309, 109);

                                        blit (memory_bitmap[a] ,screen, 0, 0,
                                        210 +((x-b+2) * 20), 10 + (y-c+2) * 20, 20, 20);

                                        set_clip(screen, 0, 0, 319, 199);
                                     }

                               }


                             /* put bullseye  */
                             if (mouse_x > 198) mouse_x = 198;
                             show_mouse(NULL);

                             x =  ((mouse_x / 2) - b);
                             y =  ((mouse_y / 2) - c);


                             if (x > 2) x = 2;
                             if (x < -2) x = -2;
                             if (y > 2) y = 2;
                             if (y < -2) y = -2;

                             bullseye_x = 250 + (x * 20);  /* 210 + 40 */
                             bullseye_y =  50 + (y * 20);  /*   2 + 40 */

                             rect(screen, bullseye_x, bullseye_y, bullseye_x + 19, bullseye_y + 19, 1);

                             sprintf(msg,"x=%-2d ",(mouse_x / 2));
                             textout(screen, font, msg, 210, 184, 255);
                             sprintf(msg,"y=%-2d ",(mouse_y / 2));
                             textout(screen, font, msg, 210, 192, 255);
                             show_mouse(screen);

                    


                         if  (mouse_b & 1)
                             {
                                while (mouse_b & 1); /* wait for release */
                                quit =1;
                                retval = 1;  /* b1 xy */
                             }
                         if  ( (mouse_b & 2) && (mouse_x < 200))
                             {
                                while (mouse_b & 2); /* wait for release */
                                quit =1;
                                retval = 2;  /* b2 xy */
                             }

                         if (key[KEY_ESC])
                             {
                                 quit = 1;
                                 retval = 0;  /* ignore xy */
                             }

                          show_mouse(screen);
                          rest(10);
                          update_animation();
                    } while (!quit);

                    set_mouse_range(0,0,319,200);
                    get100_x = (mouse_x / 2);
                    if (get100_x > 99) get100_x = 99;
                    get100_y = (mouse_y / 2);
                    return retval;
                    clear(screen);
}


void mov_menu(int current_mv)
{
extern int l[100][100];
extern int mov_ob[20][20];
extern int mov_obi[20][20][4];


char msg[80];

int num_obj;
int ms = 999; /* menu selection */
int step = 0;
int cm = current_mv;
int redraw = 1;

int a, b, c, d;

while (ms != -1)
   {
      if (redraw)
         {
            redraw = 0;
            num_obj = sort_mov();
            show_mouse(NULL);
            clear(screen);

            /* map */

            for (a=0; a<100; a++)
               for (b=0; b<100; b++)
                  if (l[a][b]) putpixel(screen, a+220, b, 96);


            if (mov_obi[cm][step][3] == 1) /* only draw if move */
               {
                  a = 220 + mov_obi[cm][step][0]/20;
                  b =       mov_obi[cm][step][1]/20;
                  c = a +   mov_ob[cm][10];
                  d = b +   mov_ob[cm][11];
      
                  if (mov_ob[cm][11] = 1) hline(screen, a, b, c, mov_ob[cm][12]);
                  else rect(screen, a, b, c, d, mov_ob[cm][12]);
               }
            textout(screen, font, "MOVEABLE OBJECTS MENU",20, 0, 7);
            sprintf(msg, "%d DEFINED   %d EMPTY", num_obj, 20-num_obj );
            textout(screen, font, msg, 20, 12, 7);

            sprintf(msg, "CURRENT OBJECT %d", cm  );
            textout(screen, font, msg, 0, 102, 240);

            sprintf(msg, "CURRENT STEP %d", step );
            textout(screen, font, msg, 0, 110, 240);

            sprintf(msg, "COLOR %d", mov_ob[cm][12]);
            textout(screen, font, msg, 0, 118, mov_ob[cm][12] );

            sprintf(msg, "TEXT LINE %d", mov_ob[cm][12]);
            textout(screen, font, msg, 0, 118, mov_ob[cm][13] );

            if (mov_ob[cm][0]) /* if active */
               {
                  extern char level_text[100][40];
                  int x1 = 220;
                  int x2 = 220 + (mov_ob[cm][10] * 20) -1;
                  int y1 = 102;
                  int y2 = 102 + (mov_ob[cm][11] * 20) -1;
                  int color = mov_ob[cm][12];
                  int text_line = mov_ob[cm][13]-1;
      
                  for (a=0; a<10; a++)
                     rect(screen, x1+a, y1+a, x2-a, y2-a, color + ((9 - a)*16) );
                  rectfill(screen, x1+a, y1+a, x2-a, y2-a, color );
                  text_mode(-1);
                  if (text_line > 1) textout_centre(screen, font, level_text[text_line], ((x1+x2)/2), ((y1+y2)/2)-2, color+128+32);
                  else
                     {
                        sprintf(msg, "lift #%d", cm);
                        textout_centre(screen, font, msg, (x1+x2)/2,((y1+y2)/2)-2 ,color+160);
                     }
               }  text_mode(0);
         } /* end of if redraw */

            sprintf(msg, "STEP: %d", step);
            textout(screen, font, msg, 0, 60, 6);
            switch (mov_obi[cm][step][3])
               {
                  case 0: textout(screen, font, "UNDEFINED", 0, 70, 6);
                  break;
                  case 1: sprintf(msg, "MOVE TO X:%d Y:%d SPEED:%d", mov_obi[cm][step][0]/20, mov_obi[cm][step][1]/20, mov_obi[cm][step][2]);
                          textout(screen, font, msg, 0, 70, 6);
                  break;
                  case 2: sprintf(msg, "WAIT TIME = %d", mov_obi[cm][step][2]);
                          textout(screen, font, msg, 0, 70, 6);
                  break;
                  case 3: sprintf(msg, "WAIT PROX = %d", mov_obi[cm][step][2]);
                          textout(screen, font, msg, 0, 70, 6);
                  break;
                  case 4: textout(screen, font, "LOOP TO STEP 0", 0, 70, 6);
                  break;
               }

      ms = (bottom_menu(10));   /* call the menu handler */
      switch (ms)
         {
            case 0: /* OBJ+  */
                    redraw = 1;
                    step = 0;
                    if (++cm > num_obj-1) cm = num_obj-1;
                    if (cm<0) cm=0;
            break;
            case 1: /* OBJ- */
                    redraw = 1;
                    step = 0;
                    if (--cm<0) cm = 0;
            break;
            case 2: /* STP+ */
                    redraw = 1;
                    if (++step>19) step = 19;
                    if (mov_obi[cm][step][3] == 0) step--;
                    if (mov_obi[cm][step][3] == 4) step = 0;
            break;
            case 3: /* STP- */
                    redraw = 1;
                    if (--step<0) step = 0;
            break;
            case 4: /* COLR */
                    redraw = 1;
                    if (++mov_ob[cm][12] > 15)
                       mov_ob[cm][12] = 7;
            break;
            case 5: /* NEW */
                    redraw = 1;
                    create_mov(num_obj);
                    cm = num_obj-1;
            break;
            case 6: /* DEL */
                      redraw = 1;
                      for (b=0; b<20; b++)
                          {
                             mov_ob[cm][b] = 0;
                             for (c=0; c<4; c++)
                                mov_obi[cm][b][c] = 0;
                          }
            case 7: /* BACK */
            break;
         }
   } /* end of while (ms=1)   */
}
void create_mov(int mov_num)
{
extern int mov_ob[20][20];
extern int mov_obi[20][20][4];
extern int get100_x;
extern int get100_y;
extern int edit_int_retval;
         
int wait = 100;
int prox = 80;
int speed = 20;
int quit = 0;
int step = 0;
int redraw = 1;
int a, b, c, d, x;
char msg[80];
int  xsize = 5; /* default x size */
int  ysize = 1; /* default y size */
int  color = 12;  /* default color  */
int  other = 0;  /* default other  */
while (!quit)
{
   /* get width and height and set color */

   if (redraw)
   {
   redraw = 0;
   clear(screen);
   textout_centre(screen, font, "------------",SCREEN_W/2,28,240);
   textout_centre(screen, font, "LIFT CREATOR",SCREEN_W/2,20,240);
   {
                       extern char level_text[100][40];
                       int x1 = 120;
                       int x2 = 120 + (xsize*20)-1;
                       int y1 = 40;
                       int y2 = 40  + (ysize*20)-1;
                       int text_line = other-1;

                       for (a=0; a<10; a++)
                          rect(screen, x1+a, y1+a, x2-a, y2-a, color+((9-a)*16) );

                       rectfill(screen, x1+a, y1+a, x2-a, y2-a, color);
                       text_mode(-1);
                       sprintf(msg, "lift #%d", d);
                       if (text_line) textout_centre(screen, font, level_text[text_line], ((x1+x2)/2), ((y1+y2)/2)-2, color+128+32);
                       else textout_centre(screen, font, msg, ((x1+x2)/2), ((y1+y2)/2)-2, color+128+32);
                       text_mode(0);
   }


   textout(screen, font, "X-SIZE:", 20,40,240);
   sprintf(msg,"%d", xsize);
   textout(screen,font,msg,76,40,11);

   textout(screen, font, "Y-SIZE:", 20,50,240);
   sprintf(msg,"%d", ysize);
   textout(screen,font,msg,76,50,11);

   textout(screen, font, "COLOR:", 20,60,color);
   sprintf(msg,"%d", color);
   textout(screen,font,msg,68,60,color);

   textout(screen, font, "TEXT#:", 20,70,240);
   sprintf(msg,"%d",other);
   textout(screen,font,msg,68,70,11);

   textout(screen, font, "--------", 20,138,11);
   textout(screen, font, "CONTINUE", 20,130,11);

   textout(screen, font, "-----", 20,158,11);
   textout(screen, font, "ABORT", 20,150,11);
   } /* end of if redraw */
   show_mouse(screen); rest(20); show_mouse(NULL);

   if ((mouse_b & 1) && (mouse_x > 20) && (mouse_x < 100) && (mouse_y > 20) && (mouse_y < 170))
      {
        redraw = 1;
        switch ((mouse_y-40)/10)
        {
              case 0: /* edit x size */
              if (edit_int(76, 40, xsize, 1, 1, 20)) xsize = edit_int_retval; break;
              case 1: /* edit y size */
              if (edit_int(76, 50, ysize, 1, 1, 20)) ysize = edit_int_retval; break;
              case 2: /* edit color */
              if (edit_int(68, 60, color, 1, 7, 15)) color = edit_int_retval; break;
              case 3: /* edit other */
              if (edit_int(68, 70, other, 1, 0, 98)) other = edit_int_retval; break;
              case 9: /* CONTINUE */ quit = 1; break;
              case 11: /* ABORT */  quit = -1; break;
        }
      }
} /* end of while (!quit) */
while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
if (quit == 1) quit = 0;
if (quit != -1)
   {
      clear(screen);
      textout(screen, font, "INITIAL POS'N", 205,122, 240);
      textout(screen, font, "B1 - CONTINUE", 210,130, 230);
      textout(screen, font, "B2|ESC - QUIT", 210,138, 230);
      d = getxy100(999);
      if (d == 1)
         {
            mov_obi[mov_num][step][0] = get100_x * 20;  /* set step 0 */
            mov_obi[mov_num][step][1] = get100_y * 20;
            mov_obi[mov_num][step][2] = speed; /* default 20 */
            mov_obi[mov_num][step][3] = 1; /* type = move */
         }
      if ((d == 0) || (d == 2)) quit = -1;
    }
if (quit != -1)
    {
       mov_ob[mov_num][10] = xsize;
       mov_ob[mov_num][11] = ysize;
       mov_ob[mov_num][12] = color;
       mov_ob[mov_num][13] = other;

       mov_ob[mov_num][0] = 1; /* active */
       mov_ob[mov_num][2] = mov_obi[mov_num][0][0];
       mov_ob[mov_num][3] = mov_obi[mov_num][0][1];
       mov_ob[mov_num][4] = mov_obi[mov_num][0][0] + (mov_ob[mov_num][10]*20)-1;
       mov_ob[mov_num][5] = mov_obi[mov_num][0][1] + (mov_ob[mov_num][11]*20)-1;
    }

      step++;
      /* loop and get steps */
      while (!quit)
          {

             clear(screen);
             textout_centre(screen, font, "MOVEABLE BLOCK CREATOR",SCREEN_W/2, 0, 7);
             
             sprintf(msg, "STEP %d ", step);
             textout(screen, font, msg, 20, 60, 7);

             sprintf(msg, "MOVE TO NEW XY (SPEED=%d)", speed);
             textout(screen, font, msg, 20, 76,  7);

             sprintf(msg, "WAIT FOR TIME  (TIME=%d)", wait);
             textout(screen, font, msg, 20, 84,  7);

             sprintf(msg, "WAIT PROXIMITY (PROX=%d)", prox);
             textout(screen, font, msg, 20, 92,  7);

             textout(screen, font, "LOOP TO STEP 0", 20, 100, 7);
             textout(screen, font, "JUMP STEP", 20, 108, 7);
             textout(screen, font, "END LEAVE", 20, 116, 7);
             textout(screen, font, "END ERASE", 20, 124, 7);

             show_mouse(screen);
             rest(20);
             show_mouse(NULL);
             if ((mouse_b & 1) && (mouse_x > 190) && (mouse_x < 220) && (mouse_y > 76) && (mouse_y < 132))
                {
                   extern int edit_int_retval;
                   int selection = (mouse_y-76)/8;

                   switch (selection)
                     {
             
                        case 0: /* edit speed */
                              if (edit_int(196, 76, speed, 1, 1, 29))
                              speed = edit_int_retval;

                        break;
                        case 1: /* edit wait */
                             if (edit_int(188, 84, wait, 10, 10, 2000))
                              wait = edit_int_retval;

                        break;
                        case 2: /* edit prox */
                            if (edit_int(188, 92, prox, 20, 40, 200))
                              prox = edit_int_retval;



                        break;

                     }
                }
             if ((mouse_b & 1) && (mouse_x > 20) && (mouse_x < 100) && (mouse_y > 76) && (mouse_y < 132))
                {
                   int selection = (mouse_y-76)/8;
                   while(mouse_b & 1); /* wait for release */
                   switch (selection)
                     {
             
                        case 0:
                                  clear(screen);
                                  textout(screen, font, "MOVE TO"  ,205,122,240);
                                  textout(screen, font, "-------"  ,205,130,240);
                                  textout(screen, font, "mouse b1"    ,205,138,11);
                                  textout(screen, font, "MOVE"   ,205,146,11);
                                  textout(screen, font, "mouse b2/esc",205,156,10);
                                  textout(screen, font, "BACK",       205,164,10);
                                  d = getxy100(999);
                                  if (d == 1)
                                     {
                                        mov_obi[mov_num][step][0] = get100_x * 20;  /* set new x,y */
                                        mov_obi[mov_num][step][1] = get100_y * 20;
                                        mov_obi[mov_num][step][2] = speed;
                                        mov_obi[mov_num][step][3] = 1; /* type 1=move */
                                        step++;
                                     }
                                  if ((d == 0) || (d == 2)) quit = 1;
             
             
                        break;
             
                        case 1:  /* get pause */
                             mov_obi[mov_num][step][0] = 0;
                             mov_obi[mov_num][step][1] = 0;
                             mov_obi[mov_num][step][2] = wait;
                             mov_obi[mov_num][step][3] = 2; /* type 2=wait time */

                             sprintf(msg, "WAIT %d ", wait);
                             textout(screen, font, msg, 20, 100, 240);
                             rest(1000);
                             step++;
                        break;

                        case 2: /* get prox */
                             mov_obi[mov_num][step][0] = 0;
                             mov_obi[mov_num][step][1] = 0;
                             mov_obi[mov_num][step][2] = prox;
                             mov_obi[mov_num][step][3] = 3; /* type 3=wait prox */
                             sprintf(msg, "PROX %d ", prox);
                             textout(screen, font, msg, 20, 100, 240);
                             rest(1000);
                             step++;

                        break;
                        case 3: /* move to step 0 */
                        /* this exits, but its a good exit! */

                             mov_obi[mov_num][step][0] = 0;
                             mov_obi[mov_num][step][1] = 0;
                             mov_obi[mov_num][step][2] = 0;
                             mov_obi[mov_num][step][3] = 4; /* type 5=loop to 0 */
                             textout(screen, font, "LOOP to O", 20,100, 240);
                             rest(1000);
                             quit=1;
                             mov_ob[mov_num][0] = 1; /* active */


                        break;
             
                     } /* end of switch case */
             
                }  /* end of if mouse_b */
             
          } /* end of if (!quit) */
}
void draw_item_info(int x, int y, int color, int type, int num)
{

extern int mov_ob[20][20];
extern int mov_obi[20][20][4];
extern int zz[20][64];
extern int item[500][16];
extern int Ei[100][10];
extern char item_desc[20][5][40];
extern char eitype_desc[10][10][40];
extern BITMAP *memory_bitmap[512];

int a;
char msg[80];
   rectfill(screen, x,y,x+130,y+20,0 );
   switch (type)
   {
   case 1:
            blit (memory_bitmap[num], screen, 0, 0, x, y, 20, 20);

            sprintf(msg,"BLOCK #%d",num);
            textout(screen, font, msg, x+22, y+2, color);

            sprintf(msg, "SOLID");  /* default */
            if (num < 7) sprintf(msg, "EMPTY");
            if ((num > 7) && (num < 16)) sprintf(msg, "SEMI ");
            if ((num > 23) && (num < 32)) sprintf(msg, "BREAK");
            textout(screen, font, msg, x+22, y+12, color);
   break;

   case 2:
            a = item[num][1]; /* bmp or ans */
            if (a > 999) a = zz[0][a-1000]; /* ans */
            blit (memory_bitmap[a], screen, 0, 0, x, y, 20, 20);

            sprintf(msg,"ITEM #%d",num);
            textout(screen, font, msg, x+22, y+2, color);
            a = item[num][0]; /* type */
            sprintf(msg,"%s", item_desc[a][0]);
            textout(screen, font, msg, x+22, y+12, color);
   break;

   case 3:
            a = Ei[num][1]; /* bitmap  */
            blit (memory_bitmap[a], screen, 0, 0, x, y, 20, 20);

            sprintf(msg,"ENEMY #%d",num);
            textout(screen, font, msg, x+22, y+2, color);

            a = Ei[num][0]; /* type */
            sprintf(msg,"%s", eitype_desc[a][0]);
            textout(screen, font, msg, x+22, y+12, color);

   break;
   case 4:
            for (a=0; a<10; a++)
               rect(screen, x+a,y+a,x+19-a,y+19-a,mov_ob[num][12]+((9-a)*16) );
            text_mode(-1);
            sprintf(msg, "lift #%d", num);
            textout(screen, font, msg, x+4, y+6 ,mov_ob[num][12]+160);
            text_mode(0);
   break;
 } /* end of switch */




}


void edit_menu()
{

extern BITMAP *memory_bitmap[512];
extern int l[100][100];
extern int item[500][16];

extern int mov_ob[20][20];
extern int mov_obi[20][20][4];

extern int bmp_index;
extern int zz[20][64];
extern int Ei[100][10];
extern float Ef[100][10];


int draw_item_type, draw_item_num;
int point_item_type, point_item_num;
int hide_bottom_display = 0;

extern int zzindx; /* to pass to animation() */
extern int bmp_index;
extern int level_num, sprit_num;
int em_WX, em_WY;

char msg[80]; /* temp printing string  */

int em_redraw = 1;
int em_quit = 0;
int wx = 0, wy = 0;
int scrolledge=10;  /* window variables  16x8 edit mode */
int scrollpause=50;
int a, b, c, d, e, x, y;

while (mouse_b & 1); /* if pressed wait for release */
while (key[KEY_ENTER]); /* wait for release */
show_mouse(NULL);
clear(screen);

load(0, level_num, 0, 0, sprit_num);

set_mouse_range(0,0,319,199);
enemy_textdesc_setup();
draw_item_type = 1;
draw_item_num  = 16;

initialize_zz();
em_redraw = 1;


do /*    <---DO---------------------------------<     */
{

/* default = block */
a = l[wx + (mouse_x / 20)][wy + (mouse_y / 20)];
if (a < 256) /* block */
   {
      point_item_type = 1;
      point_item_num = a;
   }
for (d=0; d<500; d++) /* check for item */
   if (item[d][0]) /* if active  */
      {
         x = mouse_x + (wx*20);
         y = mouse_y + (wy*20);
         a = item[d][4];
         b = item[d][5];

         if ( (x > a) && (x < (a+18)) && (y > b+4) && (y < (b+16)) )
            {   /* mouse is on item d */
                point_item_type = 2;
                point_item_num = d;
            }
      }

for (e=0; e<100; e++) /* check for enemy */
   if (Ei[e][0]) /* if enemy active  */
      {
         x = mouse_x + (wx*20);
         y = mouse_y + (wy*20);
         a = Ef[e][0];
         b = Ef[e][1];


         if ( (x > (a+2)) && (x < (a+18)) && (y > (b+2)) && (y < (b+18)) )
            {   /* mouse is on enemy e */
                point_item_type = 3;
                point_item_num = e;
            }
      }


for (d=0; d<20; d++) /* check for mov_ob */
   if (mov_ob[d][0]) /* if active  */
      {
         x = mouse_x + (wx*20);
         y = mouse_y + (wy*20);
         a = mov_obi[d][0][0];
         b = mov_obi[d][0][1];


         if ( (x > a) && (x < (a+8)) && (y > b) && (y < (b+8)) )
            {   /* mouse is on enemy e */
                point_item_type = 4;
                point_item_num = d;
            }
      }


if (!hide_bottom_display)
   {

      rect (screen, 0, 169, 159, 199, 241);
      rect (screen, 160, 169, 319, 199, 246);
      sprintf(msg,"LEVEL EDITOR   LEV%d   X:%2d Y:%2d ",level_num,x/20,y/20 );
      textout(screen, font, msg, 10, 161, 6);
      textout(screen, font, "HIDE", 276, 161, 7);

      textout(screen, font, "DRAW THIS   ", 24, 171, 241);
      textout(screen, font, "mouse", 100, 171, 7);
      textout(screen, font, "b1", 143, 171, 4);

      textout(screen, font, "VIEW THIS ", 184, 171, 246);
      textout(screen, font, "mouse", 261, 171, 7);
      textout(screen, font, "b2", 303, 171, 4);

      draw_item_info(2, 178, 241, draw_item_type, draw_item_num);
      draw_item_info(162, 178, 246, point_item_type, point_item_num);
      if (mouse_x > 276 && mouse_y > 160 && mouse_y < 169 )
         if ((mouse_b & 1) || (mouse_b & 2))
            {
               while ((mouse_b & 1) || (mouse_b & 2));
               hide_bottom_display = 1;
               if (wy>90) wy = 90;
               em_redraw = 1;
            }
   }
if ((mouse_b & 1) && (mouse_y < 160 +(hide_bottom_display*40) )) /* put draw item */
   {
      while (mouse_b & 1); /* wait for release */
      x = wx + (mouse_x / 20);
      y = wy + (mouse_y / 20);
      switch (draw_item_type)
         {
            case 1:  /* block */

                       l[x][y] = draw_item_num;
                       em_redraw=1;
            break;
            case 2:  /* item */

                     for (c=0; c<500; c++) /* find empty item */
                       if (item[c][0] == 0)
                          {
                             for (b=0; b<16; b++) /* copy item  */
                                item[c][b] = item[draw_item_num][b];
                             item[c][4]= x*20; /* get x */
                             item[c][5]= y*20; /* get y */
                             c=500; /* quit loop  */
                          }
                      item_sort();
                      em_redraw=1;
            break;
            case 3:    /* enemy */
            {
               int en_quit=0;
               extern int get100_x;
               extern int get100_y;
               do
                  {
                     int num_empty = 0;
                     int first_empty;
                     for (c=0; c<100; c++) /* find empty and num of empty */
                        if (Ei[c][0] == 0)
                                 {
                                    num_empty++;
                                    if (num_empty == 1) first_empty = c;
                                 }
                   
                     clear(screen);
                     textout(screen, font, "COPY ENEMY TO"  ,205,122,240);
                     textout(screen, font, "-------------"  ,205,130,240);
                     textout(screen, font, "mouse b1"    ,205,138,11);
                     textout(screen, font, "COPY"   ,205,146,11);
                     textout(screen, font, "mouse b2/esc",205,156,10);
                     textout(screen, font, "BACK",       205,164,10);
                     sprintf(msg,"left %d", num_empty);
                     textout(screen, font, msg, 205,176, 12);
                     d = getxy100(draw_item_num);
                     if (d == 1)
                        {
                           for (x=0; x<10; x++) /* copy enemy  */
                              {
                                 Ei[first_empty][x] = Ei[draw_item_num][x];
                                 Ef[first_empty][x] = Ef[draw_item_num][x];
                              }
                           Ef[first_empty][0] = get100_x * 20;  /* set new x,y */
                           Ef[first_empty][1] = get100_y * 20;
                        }
                     if ((d == 0) || (d == 2)) en_quit = 1;
                  } while (!en_quit);
               while (key[KEY_ESC]); /* wait for release */
               while (mouse_b & 2); /* wait for release */
               clear(screen);
               em_redraw = 1;
            }
            break;
         }
   }
if (mouse_b & 2)
   {

      int pop_menu_selection = 999;
      int temp_mouse_x, temp_mouse_y;

      extern char global_string[20][25][80]; /* menu.c */
      switch (point_item_type)
         {
            case 1:
            sprintf(global_string[9][2], "COPY BLOCK #%d", point_item_num);
            sprintf(global_string[9][3], "SELECT BLOCK  ");
            sprintf(global_string[9][4], "              ");
            sprintf(global_string[9][5], "ZERO BLOCK #%d", point_item_num);
            break;
            case 2:
            sprintf(global_string[9][2], "COPY item. #%d", point_item_num);
            sprintf(global_string[9][3], "VIEW item. #%d", point_item_num);
            sprintf(global_string[9][4], "MOVE item. #%d", point_item_num);
            sprintf(global_string[9][5], "ZERO item. #%d", point_item_num);
            break;
            case 3:
            sprintf(global_string[9][2], "COPY ENEMY #%d", point_item_num);
            sprintf(global_string[9][3], "VIEW ENEMY #%d", point_item_num);
            sprintf(global_string[9][4], "MOVE ENEMY #%d", point_item_num);
            sprintf(global_string[9][5], "ZERO ENEMY #%d", point_item_num);
            break;
            case 4:
            sprintf(global_string[9][2], "COPY LIFT  n/a  ");
            sprintf(global_string[9][3], "VIEW LIFT  #%d", point_item_num);
            sprintf(global_string[9][4], "MOVE LIFT  n/a");
            sprintf(global_string[9][5], "ZERO LIFT  #%d", point_item_num);
            break;

          }
      temp_mouse_x = mouse_x;
      temp_mouse_y = mouse_y;

      show_mouse(NULL);
      clear(screen);
      rect (screen, 0, 169, 159, 199, 241);
      rect (screen, 160, 169, 319, 199, 246);
      textout(screen, font, "DRAW ITEM   ", 24, 171, 241);
      textout(screen, font, "VIEW ITEM ", 184, 171, 246);
      draw_item_info(2, 178, 241, draw_item_type, draw_item_num);
      draw_item_info(162, 178, 246, point_item_type, point_item_num);

      pop_menu_selection = pmenu(9,0); /* call the pop up menu */

      position_mouse(temp_mouse_x, temp_mouse_y);

      switch (pop_menu_selection)
         {
            case 2:  /* COPY */
                     if (point_item_type < 4)
                        {
                           draw_item_type = point_item_type;
                           draw_item_num  = point_item_num;
                        }
            break;
            case 3:  /* VIEW */
                     switch (point_item_type)
                        {
                            case 1: /* view bitmap */
                                    select_bitmap(1);
                                    draw_item_type = 1;
                                    draw_item_num  = bmp_index;
                                    while (mouse_b & 1); /* wait for release */
                            break;
                            case 2: /* view item */
                                     new_view_item_list(item[point_item_num][0]);
                            break;
                            case 3: /* view enemy */
                                    enemy_menu(point_item_num);
                            break;
                            case 4: /* view lift */
                                    mov_menu(point_item_num);
                            break;
                        }
            break;
            case 4:  /* MOVE */  switch (point_item_type)
                        {
                            case 1: /* move bitmap */

                            break;
                            case 2: /* move item */


                            break;

                            case 3: /* move enemy */

                            break;

                        }
       
            break;
            case 5:  /* ZERO */
                     x = wx + (mouse_x / 20);
                     y = wy + (mouse_y / 20);
                     switch (point_item_type)
                        {
                            case 1: /* zero block */
                                    l[x][y] = 0;
                            break;
                            case 2: /* zero item */
                                    for (a=0; a<16; a++)
                                       item [point_item_num][a] = 0;
                                    l[x][y] = 0;
                                    item_sort();
                            break;
                            case 3: /* zero enemy */
                                    for (a=0; a<10; a++)
                                       {
                                          Ei[point_item_num][a] = 0;
                                          Ef[point_item_num][a] = 0;
                                       }
                            break;
                            case 4: /* zero lift */
                                    for (a=0; a<20; a++)
                                       {
                                          mov_ob[point_item_num][a] = 0;
                                          for (d=0; d<4; d++)
                                             mov_obi[point_item_num][a][d] = 0;
                                       }
                                    sort_mov();
                            break;
                    
                        }

            break;

            case 6:   /* menu divider */

            break;

            case 7:   /* ZOOM OUT */
                 {

                      int draw_item;
                      if (draw_item_type == 1) draw_item = draw_item_num;
                      else draw_item = 0;
                      c = edit100(wx, wy, draw_item);
                      wy = (c / 100);        /* for mouse and window pos */
                      c = c - (wy * 100);
                      wx = c;
               }
            break;

            case 8:   /* PD */
                      predefined_enemies();
            break;

            case 9:   /* BMP */
                      bitmap_menu();
            break;

            case 10:   /* item */
                       item_menu();
            break;
            case 11:   /* ENEMY */
                       enemy_menu();
            break;
            case 12:   /* LOAD */
                       {
                          extern int level_num, sprit_num;
                          show_mouse(NULL);
                          clear(screen);
                          load(0, level_num, 0, 0, sprit_num);

                       }
            break;
            case 13:   /* SAVE */
                       {
                          extern int level_num, sprit_num;
                          show_mouse(NULL);
                          clear(screen);
                          save(0, level_num, 0, 0, sprit_num); /* F7 SAVE */
                       }
            break;
            case 14:   /* EXIT POP MENU */

            break;
            case 16:   /* MOVEABLE OBJECTS MENU */

                       if (point_item_type == 4) mov_menu(point_item_num);
                       else mov_menu(0);

            break;
            case 17:   /* TOGGLE BOTTOM DISPLAY */
                      if (hide_bottom_display == 0)
                         {
                            hide_bottom_display = 1;
                            if (wy>90) wy = 90;
                         }
                      else if (hide_bottom_display == 1) hide_bottom_display = 0;

            break;
            case 18: level_text_editor();
            break;
            case 19:   /* SAVE AND EXIT LEVEL EDITOR */
            {
                       extern int level_num, sprit_num;
                       show_mouse(NULL);
                       clear(screen);
                       save(0, level_num, 0, 0, sprit_num);
                       em_quit=1;
            }
            break;

            case 20:   /* EXIT LEVEL EDITOR */
                       em_quit=1;
            break;



        } /* end of switch case */
      position_mouse(temp_mouse_x, temp_mouse_y);
      clear(screen);
      em_redraw = 1;
   }


  if (1)  /* - default --- edit menu and - 16x8 edit mode ------ */
   {
        show_mouse(screen);
        /* scroll up */
        if (mouse_y < scrolledge)
           {
              wy--;
              em_redraw=1;
              rest(scrollpause);
              if (wy<0) wy = 0;
           }
        /* scroll down small */
        if ((!hide_bottom_display) && (mouse_y < 160) && (mouse_y > 155))
           {
              wy++;
              em_redraw=1;
              rest(scrollpause);
              if (wy>92) wy = 92;
           }
        /* full screen */
        if  ((hide_bottom_display) && (mouse_y > 195))
           {
              wy++;
              em_redraw=1;
              rest(scrollpause);
              if (wy>90) wy = 90;
           }
      /* scroll left */
        if (mouse_x < scrolledge)
           {
               wx--;
               em_redraw=1;
               rest(scrollpause);
               if (wx<0) wx = 0;
           }
        /* scroll right */
        if (mouse_y < 160 + (hide_bottom_display*40)  && mouse_x < 320 && mouse_x > 320-scrolledge)
           {
              wx++;
              em_redraw=1;
              rest(scrollpause);
              if (wx>84) wx = 84;
           }
        update_animation();
        rest(15);
        /* rem update items on screen ***************************************      */
        show_mouse(NULL);


        for (c=0; c<500; c++)
           if (item[c][0] != 0)   /* if not type 0  */
              {
                 x = (item[c][4]);
                 y = (item[c][5]);
                 em_WX=wx*20;
                 em_WY=wy*20;
                 if ((x > em_WX) && (x < (em_WX + 320)) && (y > em_WY) && (y < (em_WY + 160+(hide_bottom_display*40) )))
                       {
                          int a = item[c][1];
                          if (a < 512) b = a; /* bmp */
                          if (a > 999) b = zz[0][ a-1000 ]; /* ans */
                          blit(memory_bitmap[b], screen, 0, 0, x-em_WX, y-em_WY, 20, 20);
                       }
              }
        if (em_redraw)
           {
              show_mouse(NULL);
              clear(screen);
              em_redraw = 0;
              for (x=0; x<16; x++) /* draw 16 x (8 or 10)  */
                 for (y=0; y<8+(hide_bottom_display*2); y++)
                    {
                       c = l[wx+x][wy+y];
                       if (c < 256) blit(memory_bitmap[c], screen, 0, 0, ((x*20)), (y*20), 20, 20);
                    }
              for (d=0; d<500; d++)
                 if (item[d][0])   /* active */
                    {
                       int x = item[d][4];
                       int y = item[d][5];
                       int x2 = (wx*20);
                       int y2 = (wy*20);


                       if ( (x > x2) && (x < (x2+320))
                         && (y > y2) && (y < (y2+200)) )
                             {
                                 a = item[d][1]; /* bmp or ans */
                                 if (a < 512) b = a; /* bmp */
                                 if (a > 999) b = zz[0][a-1000]; /* ans */
                                 blit(memory_bitmap[b], screen, 0,0,x-x2,y-y2,20,20);
                             }
                    }

               for (d=0; d<20; d++)
                 if (mov_ob[d][0])   /* active */
                    {
                       extern char level_text[100][40];
                       int color = mov_ob[d][12];
                       int text_line = mov_ob[d][13]-1;

                       int x1 = mov_obi[d][0][0];
                       int y1 = mov_obi[d][0][1];
                       int x2 = mov_obi[d][0][0] + (mov_ob[d][10] * 20)-1;
                       int y2 = mov_obi[d][0][1] + (mov_ob[d][11] * 20)-1;

                       int tx = ((x1+x2)/2) - (wx*20);
                       int ty = ((y1+y2)/2) - (wy*20)-2;

                       int mp = 0; /* mouse pointer flag */
                       if ((mouse_x > x1) && (mouse_x < (x1+4)) )
                          if ((mouse_y > y1) && (mouse_y < (y1+4)) )
                             mp = 1; /* mouse pointer on corner */
                       /* if on screen */
                       if ( (x2 > (wx*20)) && (x1 < (wx+16)*20) ) /* x */
                          if ( (y2 > (wy*20)) && (y1 < (wy+ 8+(hide_bottom_display*2))*20) ) /* y */
                             {
                                for (a=0; a<10; a++)
                                   rect(screen, x1-(wx*20)+a, y1-(wy*20)+a, x2-(wx*20)-a, y2-(wy*20)-a, color+((9-a)*16) );
                                rectfill(screen, x1-(wx*20)+a, y1-(wy*20)+a, x2-(wx*20)-a, y2-(wy*20)-a, color);

                                text_mode(-1);
                                sprintf(msg, "lift #%d", d);
                                if (text_line > 2) textout_centre(screen, font, level_text[text_line], tx, ty, color+160);
                                else textout_centre(screen, font, msg, tx, ty, color+160);
                                text_mode(0);

                             } /* end of if on screen */
                    } /* end of if active */
              for (e=0; e<100; e++) /* draw enemies  */
                 if (Ei[e][0] != 0 ) /* if enemy active  */
                    if ( (Ef[e][0] > (wx*20)) && (Ef[e][0] < (wx+16)*20) ) /* x */
                       if ( (Ef[e][1] > (wy*20)) && (Ef[e][1] < (wy+8+(hide_bottom_display*2))*20) ) /* y */
                          blit (memory_bitmap[Ei[e][1]] ,screen, 0, 0, Ef[e][0]-(wx*20), Ef[e][1]-(wy*20), 20, 20);

              show_mouse(screen);
           }

         } /* end of edit menu and 16x8 edit mode----- */
   } while (!em_quit) ;

show_mouse(NULL);
clear(screen);
textout_centre(screen, font, "Exiting Level Editor", SCREEN_W/2,150, 2);
rest(500);
clear_keybuf();
}   /* end of editor menu  */

