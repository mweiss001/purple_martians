#include "pm.h"


extern BITMAP *memory_bitmap[512];
extern int fade_count;
extern PALLETE pallete;


void draw_game_screen(int current_level)
{
   int c;
   int x = 80;
   int y = 70;
   int dc=11; /* done color */
   int nc=10; /* not done color */
   int cc=7; /* current color */

   fade_out(fade_count);

   show_mouse(NULL);
   clear(screen);
   for (c=0;c<16;c++)
      rect(screen, c,c, 319-c, 199-c, 10+(c*16) );
   efm();
   blit(memory_bitmap[8], screen, 0, 0, 30, 70, 20, 20);
   blit(memory_bitmap[8], screen, 0, 0, 270, 70, 20, 20);

   draw_sprite(screen, memory_bitmap[401], 28, 50);
   draw_sprite_h_flip(screen, memory_bitmap[401], 272, 50);

   switch (current_level)
   {

   case 1:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | <--- ", x, y+16, cc);
   textout(screen, font, "2|Armory     |      ", x, y+24, nc);
   textout(screen, font, "3|Hospital   |      ", x, y+32, nc);
   textout(screen, font, "4|Dungeon    |      ", x, y+40, nc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 2:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | <--- ", x, y+24, cc);
   textout(screen, font, "3|Hospital   |      ", x, y+32, nc);
   textout(screen, font, "4|Dungeon    |      ", x, y+40, nc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 3:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | done ", x, y+24, dc);
   textout(screen, font, "3|Hospital   | <--- ", x, y+32, cc);
   textout(screen, font, "4|Dungeon    |      ", x, y+40, nc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 4:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | done ", x, y+24, dc);
   textout(screen, font, "3|Hospital   | done ", x, y+32, dc);
   textout(screen, font, "4|Dungeon    | <--- ", x, y+40, cc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 5:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | done ", x, y+24, dc);
   textout(screen, font, "3|Hospital   | done ", x, y+32, dc);
   textout(screen, font, "4|Dungeon    | done ", x, y+40, dc);
   textout(screen, font, "5|Space Ship | <--- ", x, y+48, cc);
   break;

 }
fade_in(pallete, fade_count);
press_any();

}
void frame_and_title(void)
{
    BITMAP *pm_title;
    BITMAP *temp_title;
    int x,y;

    pm_title = create_bitmap(280,20);
    temp_title = create_bitmap(140,8);
    clear(pm_title);
    clear(temp_title);


      textout_centre(temp_title, font, "Purple Martians!", 70,0,200);
      for (x=0; x<5; x++)
         for (y=0; y<5; y++)
            stretch_sprite(pm_title, temp_title, x,y,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,136);
      stretch_sprite(pm_title, temp_title, 1,1,280,16);
      stretch_sprite(pm_title, temp_title, 1,3,280,16);
      stretch_sprite(pm_title, temp_title, 3,1,280,16);
      stretch_sprite(pm_title, temp_title, 3,3,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,8);
      stretch_sprite(pm_title, temp_title, 2,2,280,16);

  
   clear(screen);
   for (x=0;x<16;x++)
      rect(screen, x,x, SCREEN_W-1-x, SCREEN_H-1-x, 8+(x*16) );

   blit(pm_title, screen,0,0,(SCREEN_W/2)-140,20,280,20);

   blit(memory_bitmap[8], screen, 0, 0, 30, 70, 20, 20);
   blit(memory_bitmap[8], screen, 0, 0, SCREEN_W-50, 70, 20, 20);

   draw_sprite(screen, memory_bitmap[401], 28, 50);
   draw_sprite_h_flip(screen, memory_bitmap[401], SCREEN_W-48, 50);

   text_mode(-1);

#ifdef SW
   textout_centre(screen, font, "Shareware Version 1.00", SCREEN_W/2,SCREEN_H-10, 15);
#else
   textout_centre(screen, font, "Registered Version 2.01", SCREEN_W/2,SCREEN_H-10,15);
#endif
   text_mode(0);

   destroy_bitmap(pm_title);
   destroy_bitmap(temp_title);


}

efm()
{
      BITMAP *temp_title;
      int x, y;
      temp_title = create_bitmap(140,8);
      clear(temp_title);
      textout_centre(temp_title, font, "Escape from Mars", 70,0,202);
      for (x=0; x<5; x++)
         for (y=0; y<5; y++)
            stretch_sprite(screen, temp_title, x+20, y+20,280,16);
      textout_centre(temp_title, font, "Escape from Mars",70,0,154);
      stretch_sprite(screen, temp_title, 21,21,280,16);
      stretch_sprite(screen, temp_title, 21,23,280,16);
      stretch_sprite(screen, temp_title, 23,21,280,16);
      stretch_sprite(screen, temp_title, 23,23,280,16);
      textout_centre(temp_title, font, "Escape from Mars",70,0,10);
      stretch_sprite(screen, temp_title, 22,22,280,16);
      destroy_bitmap(temp_title);
}

time_up()
{
      BITMAP *btemp;
      BITMAP *stemp;

      int ns = 9; /* num of shadows */
      int so = 1; /* shadow offset */
      int sc = 10; /* base color */
      int ci = 16; /* color inc  */
      int st = 6;  /* skip step between 1st and 2nd color  */

      int bxw = 64; /* char * 8  */
      int bxh = 8;  /* lines * 8 */
      int sw = bxw * 5; /* stretch w */
      int sh = bxh * 8; /* stretch h */

      int a;

      btemp = create_bitmap(bxw, bxh);
      stemp = create_bitmap(sw + ns*so, sh + ns*so);
      clear(stemp);
      clear(btemp);

      for (a = ns; a >= 0; a--)
         {
            int b = sc+a*ci;
            if (a) b = sc+( (a+st) * ci); /* not first color */
            textout(btemp, font, "Time Up!", 0, 0, b);
            stretch_sprite(stemp, btemp, a*so, a*so, sw, sh);
         }
      draw_sprite(screen, stemp, (SCREEN_W/2)-sw/2, (SCREEN_H*5/16) );

      destroy_bitmap(btemp);
      destroy_bitmap(stemp);
}
you_died()
{
      BITMAP *btemp;
      BITMAP *stemp;

      int ns = 9; /* num of shadows */
      int so = 1; /* shadow offset */
      int sc = 10; /* base color */
      int ci = 16; /* color inc  */
      int st = 6;  /* skip step between 1st and 2nd color  */

      int bxw = 72; /* char * 8  */
      int bxh = 8;  /* lines * 8 */
      int sw = bxw * 5; /* stretch w */
      int sh = bxh * 8; /* stretch h */

      int a;

      btemp = create_bitmap(bxw, bxh);
      stemp = create_bitmap(sw + ns*so, sh + ns*so);
      clear(stemp);
      clear(btemp);

      for (a = ns; a >= 0; a--)
         {
            int b = sc+a*ci;
            if (a) b = sc+( (a+st) * ci); /* not first color */
            textout(btemp, font, "You Died!", 0, 0, b);
            stretch_sprite(stemp, btemp, a*so, a*so, sw, sh);
         }
      draw_sprite(screen, stemp, (SCREEN_W/2)-sw/2, (SCREEN_H*5/16) );

      destroy_bitmap(btemp);
      destroy_bitmap(stemp);
}
lev_done()
{
      BITMAP *btemp;
      BITMAP *stemp;

      int ns = 9; /* num of shadows */
      int so = 1; /* shadow offset */
      int sc = 11; /* base color */
      int ci = 16; /* color inc  */
      int st = 6;  /* skip step between 1st and 2nd color  */

      int bxw = 88; /* char * 8  */
      int bxh = 8;  /* lines * 8 */
      int sw = bxw * 6; /* stretch w */
      int sh = bxh * 12; /* stretch h */

      int a;

      btemp = create_bitmap(bxw, bxh);
      stemp = create_bitmap(sw + ns*so, sh + ns*so);
      clear(stemp);
      clear(btemp);

      for (a = ns; a >= 0; a--)
         {
            int b = sc+a*ci;
            if (a) b = sc+( (a+st) * ci); /* not first color */
            textout(btemp, font, "Level Done!", 0, 0, b);
            stretch_sprite(stemp, btemp, a*so, a*so, sw, sh);
         }
      draw_sprite(screen, stemp, (SCREEN_W/2)-sw/2, (SCREEN_H/2)-sh-10);

      destroy_bitmap(btemp);
      destroy_bitmap(stemp);

      rest(1000);
      press_any();
}
game_over()
{
      BITMAP *btemp;
      BITMAP *stemp;

      int ns = 8; /* num of shadows */
      int so = 1; /* shadow offset */
      int sc = 14; /* base color */
      int ci = 16; /* color inc  */
      int st = 6;  /* skip step between 1st and 2nd color  */

      int bxw = 80; /* char * 8  */
      int bxh = 8;  /* lines * 8 */
      int sw = bxw * 6; /* stretch w */
      int sh = bxh * 10; /* stretch h */

      int a;

      btemp = create_bitmap(bxw, bxh);
      stemp = create_bitmap(sw + ns*so, sh + ns*so);
      clear(stemp);
      clear(btemp);

      for (a = ns; a >= 0; a--)
         {
            int b = sc+a*ci;
            if (a) b = sc+( (a+st) * ci); /* not first color */
            textout(btemp, font, "Game Over!", 0, 0, b);
            stretch_sprite(stemp, btemp, a*so, a*so, sw, sh);
         }
      draw_sprite(screen, stemp, (SCREEN_W/2)-sw/2, SCREEN_H/8);

      destroy_bitmap(btemp);
      destroy_bitmap(stemp);

      rest(1000);
      press_any();
}
