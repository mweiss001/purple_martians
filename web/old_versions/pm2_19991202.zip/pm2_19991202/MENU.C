#include "pm.h"

char global_string[20][25][80]; /* menu.c */
char help_string[20][60][90];

int load_help()
{
   FILE *filepntr;
   char buff[90], buff2[90];
   char msg[90];
   int num_of_pages, page, line;
   int loop, ch, fexit, c, x, y;

   textout(screen, font, "loading help...", 16, 184, 1);
   if ((exists("pmhelp.txt")) == 0)
      {
         textout(screen, font, "can't find pmhelp.txt", 16, 184, 1);
         rest(1000);
         return 0;
      }
   else
      {
         filepntr=fopen("pmhelp.txt","r");
         /* get num_of_pages, should be 1st line */
         loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
            {
               buff[loop] = ch;
               loop++;
               ch = fgetc(filepntr);
            }
         buff[loop] = NULL;
         if (strncmp(buff, "<num_of_pages=", 14) == 0)
            {
               buff2[0] = buff[14];
               buff2[1] = buff[15];
               buff2[3] = NULL;
               num_of_pages = atoi(buff2);
            }

         /* cycle the pages */
         for (page = 0; page < num_of_pages; page++)
            {
               line = 0;
               do
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     strcpy (help_string[page][line], buff);
                     line++;
                  } while (strcmp(buff, "<end_of_page>") != 0);
            }
         fclose(filepntr);
      }
   return num_of_pages;
}
void help(int page)
{
   extern BITMAP *memory_bitmap[512];
   extern int zz[20][64];
   extern int joy_key;
   int ans, c, b, x, xindent, just, color, rcolor=15, hcolor=14;
   int num_of_pages;
   char msg[90], buff2[90];
   num_of_pages = load_help();
   clear(screen);
   clear_keybuf();
   do {
         c=0;
         while (strcmp(help_string[page][c],"<end_of_page>") != 0)
          {
             xindent = 0;
             just = 0;
             color = rcolor; /* default regular color */
             sprintf(msg, help_string[page][c]);
             if (strncmp(msg, "<ac", 3) == 0)
                  {
                      buff2[0] = msg[3];
                      buff2[1] = msg[4];
                      buff2[2] = msg[5];
                      buff2[3] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,(SCREEN_W/2)-10,4+(c*8),20,20);
                      msg[0]= NULL;
                  }
             if (strncmp(msg, "<s", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = msg[4];
                      buff2[3] = NULL;
                      ans = atoi(buff2);
                      blit(memory_bitmap[ans], screen, 0,0,20,4+(c*8),20,20);
                      for(x=6; x < strlen(msg)+1; x++)
                         buff2[x-6] = msg[x]; /* chop first 6 */
                      strcpy(msg, buff2);
                      xindent = 24;
                  }
             if (strncmp(msg, "<ms", 2) == 0)
                  {
                      int z;
                      for(z=0; z < 20; z++)
                         {

                            buff2[0] = msg[3+z*3];
                            buff2[1] = msg[4+z*3];
                            buff2[2] = msg[5+z*3];
                            buff2[3] = NULL;
                            ans = atoi(buff2);
                            blit(memory_bitmap[ans], screen, 0,0,20+(z*20),4+(c*8),20,20);
                         }
                      strcpy(msg, "");
                  }
               if (strncmp(msg, "<l", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = NULL;
                      color = atoi(buff2);
                      for(x=5; x < strlen(msg)+1; x++)
                         buff2[x-5] = msg[x]; /* chop first 5 */
                      strcpy(msg, buff2);
                  }
               if (strncmp(msg, "<a", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,20,4+(c*8),20,20);
                      for(x=5; x < strlen(msg)+1; x++)
                         buff2[x-5] = msg[x]; /* chop first 5 */
                      strcpy(msg, buff2);
                      xindent = 24;
                  }
             if (strncmp(msg, "<c", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = NULL;
                      color = atoi(buff2);
                      for(x=5; x < strlen(msg)+1; x++)
                         buff2[x-5] = msg[x]; /* chop first five */
                      strcpy(msg, buff2);
                      just = 1;
                  }
             if (just) textout_centre(screen, font, msg, SCREEN_W/2, 16+(c*8), color);
             else textout(screen, font, msg, 20+xindent, 16+(c*8), color);
             c++;
            }

        for (x=0;x<16;x++) rect(screen, x,x, SCREEN_W-1-x, SCREEN_H-1-x, 8+(x*16) );
        sprintf(msg, "PAGE:%d  NEXT-> ESC-QUIT <-PREV", page);
        textout_centre(screen, font, msg, SCREEN_W/2, SCREEN_H-22, 40);

        if (joy_key) poll_joystick();

        if ((key[KEY_LEFT]) || (joy_left)) /* prev */
            {
               if (--page < 0)  page = num_of_pages-1;;
               while (joy_left) poll_joystick();
               clear(screen);
               clear_keybuf();
            }
         if ((key[KEY_RIGHT]) || (joy_right))  /* next */
            {
               if (++page > num_of_pages-1)  page = 0;
               while (joy_right) poll_joystick();
               clear(screen);
               clear_keybuf();
            }
         update_animation();
         rest(20);
      } while ((!key[KEY_ESC]) && (!(mouse_b & 2)) && (!joy_b1) );

   while ((key[KEY_ESC]) || (mouse_b & 2)); /* wait till released */
   while (joy_b1) poll_joystick();
   clear(screen);
}
int zmenu(int menu_num, int menu_pos, int y)  /* this menu function does not pass through like the next one */
{                               /* it waits for a selection and then exits */
   extern int resume_allowed;
   extern int joy_key;
   extern int up_key;
   extern int down_key;

   int highlight = menu_pos;
   int selection = 999;
   int last_list_item;
   int c, b;
   int old_my, new_my;
   char msg[80];

   show_mouse(NULL);
   /* rectfill(screen, 60, y, 300, 140, 0);  */
   clear_keybuf();

   do   /* until selection is made */
      {
          c = 0;
          while (strcmp(global_string[menu_num][c],"end") != 0)
            {
               b = 137; /* dimmer aqua */
               if (c == 0) b = 8; /* purple banner */
               if (c == highlight) b=9; /* brighest aqua */

#ifdef FV
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if ((c==3) || (c==5)) b = 239; /* dim grey */
#else
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if (c==3) b = 239; /* dim grey */
#endif
               textout_centre(screen, font, global_string[menu_num][c], SCREEN_W/2, y+(c*8), b);
               c++;
            }
          last_list_item = c-1;

          position_mouse(160,100);
          old_my=mouse_y;
          rest(20);
          new_my=mouse_y;
#ifdef FV

         if ((key[KEY_DOWN]) || (key[down_key]) || (new_my > old_my+1) || (joy_down))
            {
               if (++highlight > last_list_item) highlight = last_list_item;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if ((highlight==3) || (highlight==5)) highlight++;

               rest(100);
            }
         if ((key[KEY_UP]) || (key[up_key]) || (new_my < old_my-1) || (joy_up))
            {
               if (--highlight < 2) highlight = 2;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
               if ((highlight==3) || (highlight==5)) highlight--;

               rest(100);
            }
#else
         if ((key[KEY_DOWN]) || (key[down_key]) || (new_my > old_my+1) || (joy_down))
            {
               if (++highlight > last_list_item) highlight = last_list_item;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if (highlight==3) highlight++;

               rest(100);
            }
         if ((key[KEY_UP]) || (key[up_key]) || (new_my < old_my-1) || (joy_up))
            {
               if (--highlight < 2) highlight = 2;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
               if (highlight==3) highlight--;

               rest(100);
            }
#endif
         if (key[KEY_ENTER]) selection = highlight;
         if (mouse_b & 1)
            {
               while (mouse_b & 1); /* wait for release */
               selection = highlight; /* get selection */
            }
         while (joy_down) poll_joystick();
         while (joy_up) poll_joystick();


         if (joy_key) /* joystick control */
            {
               poll_joystick();
               if  (joy_b1)
                  {
                     selection = highlight; /* wait for release */
                     do {
                          poll_joystick();
                        } while (joy_b1);
                  }
            }

         if ((key[KEY_ESC]) || (mouse_b & 2))
           {
              while ((key[KEY_ESC]) || (mouse_b & 2)); /* until released */

              selection = last_list_item;
              if (menu_num == 8) selection = 2; /* back is at top of options menu */
           }
      } while (selection == 999);
   return selection;
}
#ifdef FV
void menu_setup(void)
{

   strcpy (global_string[7][0], "GAME MENU"); /* new main menu */
   strcpy (global_string[7][1], "--------");
   strcpy (global_string[7][2], "NEW GAME");
   strcpy (global_string[7][3], "RESUME");
   strcpy (global_string[7][4], "LOAD GAME");
   strcpy (global_string[7][5], "SAVE GAME");
   strcpy (global_string[7][6], "OPTIONS");
   strcpy (global_string[7][7], "HELP");
   strcpy (global_string[7][8], "EXIT");
   strcpy (global_string[7][9], "end");


   strcpy (global_string[8][0], "Options Menu"); /* OPTION MENU new main menu */
   strcpy (global_string[8][1], "----------");
   strcpy (global_string[8][2], "Back to Game Menu");
   strcpy (global_string[8][3], "Keyboard Setup");
   strcpy (global_string[8][4], "Joystick Setup");
   strcpy (global_string[8][5], "Difficulty: Normal");
   strcpy (global_string[8][6], "Speed:Fast");

   strcpy (global_string[8][7], "Sound:On");
   strcpy (global_string[8][8], "Start Level (1)");
   strcpy (global_string[8][9], "Level Editor");

   strcpy (global_string[8][10], "640x480 mode");
   strcpy (global_string[8][11], "800x600 mode");
   strcpy (global_string[8][12],"1024x768 mode");

   strcpy (global_string[8][14],"end");
}
#endif
#ifdef SW
void menu_setup(void)
{

   strcpy (global_string[7][0], "GAME MENU"); /* new main menu */
   strcpy (global_string[7][1], "--------");
   strcpy (global_string[7][2], "NEW GAME");
   strcpy (global_string[7][3], "RESUME");
   strcpy (global_string[7][4], "OPTIONS");
   strcpy (global_string[7][5], "HELP");
   strcpy (global_string[7][6], "EXIT");
   strcpy (global_string[7][7], "end");

   strcpy (global_string[8][0],"Options Menu"); /* OPTION MENU new main menu */
   strcpy (global_string[8][1],"----------");
   strcpy (global_string[8][2],"Back to Game Menu");
   strcpy (global_string[8][3],"Keyboard Setup");
   strcpy (global_string[8][4],"Joystick Setup");
   strcpy (global_string[8][5],"Difficulty: Normal");
   strcpy (global_string[8][6],"Speed:Fast");

   strcpy (global_string[8][7], "640x480 mode");
   strcpy (global_string[8][8], "800x600 mode");
   strcpy (global_string[8][9],"1024x768 mode");



   strcpy (global_string[8][11],"end");
}
#endif

