#include "pm.h"


/* global variables  */
BITMAP *memory_bitmap[512];
BITMAP *level_2000, *scrn_buffer;
BITMAP *map100_bmp, *map100_bkg;
PALLETE pallete;
SAMPLE *snd[20];
int num_sounds = 15;
int lit_item;
int fuse_loop_playing;


int level_num;
char level_filename[20];

char level_text[100][40];
int level_header[20];
int l[100][100];    /* level */
int item[500][16];  /* items */
int Ei[100][10];    /* enemies */
float Ef[100][10];  /* enemies */

float mov_obf[20][4];
int mov_ob[20][20];
int mov_obi[20][20][4];

int zz[20][64];
int passcount;

/* timer variables  */
volatile int msec_timer = 0;

/* new x move stuff */
float right_speed=0, left_speed=0;
float initial_x_speed =1.15, max_x_speed=3;
float p_xmove=0;
float accel=.06, de_accel=.3;
float jump_sinc=.05, fall_sinc = 0.1;
float pmovey = 5;

int joy_key = 1;
int joy_buttons = 1;
int joy_jump;
int joy_fire;
int joy_map;
int joy_menu;
int job[5];
int right_key = 38;
int left_key = 36;
int up_key = 23;
int down_key = 37;
int jump_key = 57;
int fire_key = 46;
int map_key = 15;
int menu_key = 41;

int jump;
int fire;
int speed;

int play_level;
int start_mode;

int resume_allowed=0;
int top_menu_sel = 2;
int dif = 2;
int level_time;
float LIFE;
int LIVES;

int start_level=1;
int WX, WY; /* the 16x10 window */
int sound_on=1;
int frame_speed = 20;
int fade_count = 2;

float PX, PY;
int PXint, PYint;
int num_bullets = 100;
int max_bullets = 200;

int pbullet[50][6];
int bullet_wait_counter=0, request_bullet = 0;
int bullet_wait = 1, bullet_speed = 12;
int pm_bullet_collision_box = 8;

int e_bullet_active[50], e_bullet_shape[50];
int enemy_bullet_colision_window = 2;
float e_bullet_x[50], e_bullet_y[50], e_bullet_xinc[50], e_bullet_yinc[50];

int bomb[20][5];

float itemf[500][4];

int player_ride;

int player_carry=0;
int fire_held = 0;
int map_held = 0;

int left_right=0;
float jump_count=0, fall_count=0;

int map_on=0;

int level_done = 0;
int game_exit = 0;
int num_enemy;

/* counters and temp string  */
int a, b, c, d, e, f, x, y;
char msg[80];
char b_msg[80];
int bottom_msg=0;
int pop_msg=0;

int map100_x = 0, map100_y = 20;
int map100_on=0, top_display_on = 1;
int top_display_x, top_display_y=0, top_display_color=240;
int bottom_display_y=186, bottom_display_color=240;

int map_solid_color = 240, map_semi_color = 3;
int map_break_color = 12, map_empty_color = 0;
int map_enemy_color=5 , map_bullet_color= 14;
int map_item_color=11, map_player_color = 8;

int edit_int_retval;


void inc_msec_timer()
{
   msec_timer++;
}
END_OF_FUNCTION(inc_msec_timer);

#ifdef FV
void sound_setup()
{

     /* 0 - Player Shoots
        1 - Player gets shot "OW"
        2 - Player gets hit  "d'OH"
        3 - Player dead
        4 - Enemy dead  orch hit
        5 - Free Man   "w!ygafm"
        6 - Bonus      "bonus"
        7 - Fuse hiss
        8 - "POW!"  not used
        9 - CFG MIDI la de da  door, key, exit
        10 - "Kaboom" not used
        11 - "bomb noise"
        12 - grunt 1
        13 - grunt 2


    */
   remove_sound();
   if (install_sound(DIGI_SB, MIDI_NONE, NULL) == 0)
      {
         sound_on = 1;
         for (x=0; x<num_sounds; x++)
            {
               char fn[20] = "snd00.wav";
               char *filename;
               if (x>9)
                  {
                     fn[3] = 49; /* 1 */
                     fn[4] = 48 + (x-10);
                  }
               else fn[4] = 48 + x;
               filename = fn;
               snd[x] = load_sample(filename);
            }
      }
   else
     {
        sound_on = 0;
        clear(screen);
        textout_centre(screen, font, "...Sound Card Not Found...", SCREEN_W/2, SCREEN_H*174/200, 10);
        rest(2000);

     }

}
#endif
void set_dif(void)
{
                   extern char global_string[20][25][80]; /* menu.c */
               
                   switch (dif)
                     {
                      case 1:
                           sprintf(global_string[8][5], "DIFFICULTY: EASY");
                           pm_bullet_collision_box = 10;
                           enemy_bullet_colision_window = 4;
                      break;
                      case 2:
                           sprintf(global_string[8][5], "DIFFICULTY: NORMAL");
                           pm_bullet_collision_box = 8;
                           enemy_bullet_colision_window = 5;
                      break;
                      case 3:
                           sprintf(global_string[8][5], "DIFFICULTY: HARD");
                           pm_bullet_collision_box = 6;
                           enemy_bullet_colision_window = 6;
                      break;
                   
                     }
}
void set_speed(void)
{
                  extern char global_string[20][25][80]; /* menu.c */
                  switch (speed)
                  {
                     case 1:
                          sprintf(global_string[8][6],"SPEED:SLOW   ");
                          frame_speed = 30;
                     break;
                     case 2:
                          sprintf(global_string[8][6],"SPEED:NORMAL ");
                          frame_speed = 25;
                     break;
                     case 3:
                          sprintf(global_string[8][6],"SPEED:FAST   ");
                          frame_speed = 20;
                     break;
                     case 4:
                          sprintf(global_string[8][6],"SPEED:FASTER ");
                          frame_speed = 12;
                     break;
                     case 5:
                          sprintf(global_string[8][6],"SPEED:FASTEST");
                          frame_speed = 0;
                     break;
                  }
}


int get_joy_button(void)
{
   do {
         poll_joystick();
      } while ((joy_b1) || (joy_b2) || (joy_b3) || (joy_b4));
      rest(10);
 
   do {
         poll_joystick();
      } while ((!joy_b1) && (!joy_b2) && (!joy_b3) && (!joy_b4));
if (joy_b1) return 1;
if (joy_b2) return 2;
if (joy_b3) return 3;
if (joy_b4) return 4;
}



void press_any()
{
 textout_centre(screen, font, "...press any key to continue...", SCREEN_W/2, (SCREEN_H/2)-4, 5);
 clear_keybuf();
     if (joy_key) /* joystick control */
        {

           do {
                poll_joystick();
              } while ((joy_b1) || (joy_b2));  /* wait for release */
           do {
                poll_joystick();

              } while ((!joy_b1) && (!keypressed()) && (!joy_b2));  /* wait for press */
        }
     else readkey();
}

void draw_lift_lines()
{
  for (x=0; x<20; x++)  /* cycle lifts */
    if (mov_ob[x][0]) /* look for active */
       {
          int col = mov_ob[x][12]+128;
          int sx = mov_obi[x][0][0]+ mov_ob[x][10]*10;
          int sy = mov_obi[x][0][1]+ mov_ob[x][11]*10;
          int px = sx;
          int py = sy;
          int nx;
          int ny;

          for (y=0; y<20; y++)  /* cycle step*/
             if (mov_obi[x][y][3] == 1) /* look for move step */
                {
                   nx = mov_obi[x][y][0] + mov_ob[x][10]*10;
                   ny = mov_obi[x][y][1] + mov_ob[x][11]*10;;
                   line (level_2000, px, py, nx, ny, col);

                   for (c=3; c>=0; c--)
                      {
                         circlefill (level_2000, nx, ny, c,  (col-96)+c*48 );
                      }

                   px = nx;
                   py = ny;
                }
             line (level_2000, sx, sy, nx, ny, col);
       }
}

void maps_and_background_fill()
{
   clear(map100_bmp);
   clear(map100_bkg);
   clear(scrn_buffer);

   for (c=0; c < 500; c++) /* set all of itemf[500][4] to 0 */
      for(y=0; y<4; y++)
         itemf[c][y] = 0;

   for (x=0; x<500; x++)
      if (item[x][0]) /* only if active set float x y */
      {
         itemf[x][0] = item[x][4];
         itemf[x][1] = item[x][5];

      }

   for (x = 0; x < 20; x++)
      for (y = 0; y < 5; y++)
         bomb[x][y] = 0;


   for (d=0; d<20; d++)
      if (mov_ob[d][0]) /* test to see if needed at all !! active */
         {
            mov_ob[d][2] = mov_obi[d][0][0];      /* set x1 from mode 0 */
            mov_ob[d][3] = mov_obi[d][0][1];      /* set y1 from mode 0 */
            mov_ob[d][4] = mov_ob[d][2] + mov_ob[d][10]; /* width */
            mov_ob[d][5] = mov_ob[d][3] - mov_ob[d][11]; /* height */

            mov_obf[d][0] = mov_obi[d][0][0]; /* set float x */
            mov_obf[d][1] = mov_obi[d][0][1]; /* set float y */
            mov_obf[d][2] = 0; /* set float xinc */
            mov_obf[d][3] = 0; /* set float yinc */

            mov_ob[d][6] = 0;  /* mode 0  */
            mov_ob[d][9] = 5;  /* type wait for time   */
            mov_ob[d][8] = 0;  /* 0 = no wait! immediate next mode  */
         }


   for (x=0; x<100; x++) /* fill maps and background */
      for (y=0; y<100; y++)
         {
            c = l[x][y];
            if (c<256) blit(memory_bitmap[c], level_2000, 0, 0, x*20, y*20, 20, 20);


         }

   stretch_blit(level_2000, map100_bkg, 0, 0, 2000, 2000, 0, 0, 100, 100);
   draw_lift_lines();



   for (x=0; x<100; x++) /* finish map */
      for (y=0; y<100; y++)
         {
            c = l[x][y];

            if ((c > 7  ) && (c < 16  ))
               putpixel(map100_bkg, x, y, map_semi_color );
            if ((c > 23 ) && (c < 32  ))
               putpixel(map100_bkg, x, y, map_break_color);
            if (c == 166) putpixel(map100_bkg, x, y, 151 );
            if (c == 134) putpixel(map100_bkg, x, y, 43 );

            if ((((c >= 135 ) && (c <= 141 ))) || (((c >= 171 ) && (c <= 174 ))) || (((c >= 204 ) && (c <= 207 ))) || (((c >= 188 ) && (c <= 191 ))))
                       putpixel(map100_bkg, x, y, 8 );
         }






   jump_count=0; fall_count=0;

   for (c = 0; c < 50; c++)
      {
         e_bullet_xinc[c] = 0;
         e_bullet_yinc[c] = 0;
         e_bullet_y[c] = 0;
         e_bullet_x[c] = 0;
         e_bullet_active[c] = 0;
         e_bullet_shape[c] = 0;
         pbullet[c][0] = 0;
         pbullet[c][1] = 0;
         pbullet[c][2] = 0;
         pbullet[c][3] = 0;
         pbullet[c][4] = 0;
         pbullet[c][5] = 0;
      }
}

#ifdef FV
void save_game()
{
FILE *filepntr;
float junkfloat = 23.3;
int junkint = 448;

   for (x=0; x<500; x++)
      if (item[x][0]) /* only if active set float x y */
      {
         item[x][4] = itemf[x][0];
         item[x][5] = itemf[x][1];

      }


   save_level(900);

   filepntr = fopen("savegame.pm","w");
   fprintf(filepntr,"%f\n",PX);
   fprintf(filepntr,"%f\n",PY);
   fprintf(filepntr,"%f\n",LIFE);
   fprintf(filepntr,"%f\n",junkfloat);    /* padded for the future */
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   
   fprintf(filepntr,"%d\n",LIVES);
   fprintf(filepntr,"%d\n",play_level);
   fprintf(filepntr,"%d\n",num_bullets);
   fprintf(filepntr,"%d\n",level_time);
   fprintf(filepntr,"%d\n",passcount);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   
   fclose(filepntr);
}
void load_game()
{
FILE *filepntr;
char buff[20];
int loop, ch, fexit, c, x, y;

   load_level(900,0);

   textout_centre(screen, font, "loading saved game...", SCREEN_W/2 , (SCREEN_H*176)/200, 245);
   filepntr=fopen("savegame.pm","r");
      for (x=0; x<20; x++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                  buff[loop] = ch;
                  loop++;
                  ch = fgetc(filepntr);
               }
            buff[loop] = NULL;

            switch (x)
               {
                  case 0: PX = atof(buff); break;
                  case 1: PY = atof(buff); break;
                  case 2: LIFE = atof(buff); break;
              /*     case 3:  = atof(buff); break;
                     case 4:  = atof(buff); break;
                     case 5:  = atof(buff); break;
                     case 6:  = atof(buff); break;
                     case 7:  = atof(buff); break;
                     case 8:  = atof(buff); break;
                     case 9:  = atof(buff); break;  */

                  case 10: LIVES = atoi(buff); break;
                  case 11: play_level = atoi(buff); break;
                  case 12: num_bullets = atoi(buff); break;
                  case 13: level_time = atoi(buff); break;
                  case 14: passcount = atoi(buff); break;
              /*     case 15:  = atoi(buff); break;
                     case 16:  = atoi(buff); break;
                     case 17:  = atoi(buff); break;
                     case 18:  = atoi(buff); break;
                     case 19:  = atoi(buff); break;        */
               }
         }

   fclose(filepntr);

   for (x = 0; x < 20; x++)
      for (y = 0; y < 5; y++)
         bomb[x][y] = 0;

   for (c = 0; c < 50; c++)
      {
         e_bullet_xinc[c] = 0;
         e_bullet_yinc[c] = 0;
         e_bullet_y[c] = 0;
         e_bullet_x[c] = 0;
         e_bullet_active[c] = 0;
         e_bullet_shape[c] = 0;
         pbullet[c][0] = 0;
         pbullet[c][1] = 0;
         pbullet[c][2] = 0;
         pbullet[c][3] = 0;
         pbullet[c][4] = 0;
         pbullet[c][5] = 0;
      }
   level_done=0;
   bottom_msg=0;
   right_speed=0;
   left_speed=0;

}
#endif
void save_keys()
{
   FILE *filepntr;
   filepntr = fopen("keycfg.pm","w");

   fprintf(filepntr,"%d\n",up_key);
   fprintf(filepntr,"%d\n",down_key);
   fprintf(filepntr,"%d\n",left_key);
   fprintf(filepntr,"%d\n",right_key);
   fprintf(filepntr,"%d\n",jump_key);
   fprintf(filepntr,"%d\n",fire_key);
   fprintf(filepntr,"%d\n",map_key);
   fprintf(filepntr,"%d\n",menu_key);
   fprintf(filepntr,"%d\n",joy_key);
   fprintf(filepntr,"%d\n",joy_jump);
   fprintf(filepntr,"%d\n",joy_fire);
   fprintf(filepntr,"%d\n",joy_map);
   fprintf(filepntr,"%d\n",joy_menu);
   fprintf(filepntr,"%d\n",dif);
   fprintf(filepntr,"%d\n",speed);
   fprintf(filepntr,"%d\n",sound_on);

   fclose(filepntr);
}
void load_keys()
{
FILE *filepntr;
char buff[20];
int loop, ch, fexit, c, x, y;
   if ((exists("keycfg.pm")) == 0)
      {
         textout(screen, font, "can't find keycfg.pm", 16, (SCREEN_H*184)/200, 1);
         rest(1000);
      }
   else
      {
         filepntr=fopen("keycfg.pm","r");
         for (x=0; x<16; x++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                     buff[loop] = ch;
                     loop++;
                     ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               switch (x)
                  {
                     case 0: up_key = atoi(buff); break;
                     case 1: down_key = atoi(buff); break;
                     case 2: left_key = atoi(buff); break;
                     case 3: right_key = atoi(buff); break;
                     case 4: jump_key = atoi(buff); break;
                     case 5: fire_key = atoi(buff); break;
                     case 6: map_key = atoi(buff); break;
                     case 7: menu_key = atoi(buff); break;
                     case 8: joy_key = atoi(buff); break;
                     case 9: joy_jump = atoi(buff); break;
                     case 10: joy_fire = atoi(buff); break;
                     case 11: joy_map = atoi(buff); break;
                     case 12: joy_menu = atoi(buff); break;
                     case 13: dif = atoi(buff); break;
                     case 14: speed = atoi(buff); break;
                     case 15: sound_on = atoi(buff); break;

                  }
            }
         fclose(filepntr);
         set_dif();
         set_speed();
      }
}

int controller_setup(void)
{

   switch (alert3("Select Joystick Type", NULL, NULL,
		  "None", "Standard", "4-Button", 0, 0, 0))
      {
         case 1:
            return 0;
         break;
         case 2:
   	 joy_type = JOY_TYPE_STANDARD;
   	 if (initialise_joystick()) /* standard found! */
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, SCREEN_H/2, 13);
                  rest(1500);
                  return 0;
               }
            else return 1;
         break;
         case 3:
   	 joy_type = JOY_TYPE_4BUTTON;
            if (initialise_joystick()) /* found! */
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, SCREEN_H/2, 13);
                  rest(1500);
                  return 0;
               }
            else return 4;
         break;
      }

}
void final_wrapup(void)
{
int c;
   bad_load_exit: /* jumps here if bad load */
   for (c=0; c<512; c++)
      destroy_bitmap(memory_bitmap[c]);
   destroy_bitmap(map100_bmp);
   destroy_bitmap(map100_bkg);
   destroy_bitmap(level_2000);
   destroy_bitmap(scrn_buffer);
/*   for (c=0; c<num_sounds; c++)
      destroy_sample(snd[c]);
   remove_sound();
 */
   allegro_exit();
}
int initial_setup(int sx, int sy)
{
int c, x, y;

   allegro_init();
   install_keyboard();
   install_timer();
   install_mouse();

   if (sx == 320) set_gfx_mode(GFX_VGA, sx, sy,0,0);
   else set_gfx_mode(GFX_AUTODETECT, sx, sy,0,0);

   top_display_x = (SCREEN_W/2)-95;

   clear(screen);

   menu_setup(); /* load a bunch of text */
   load_keys();
   set_dif();
   set_speed();

   if (joy_key == 1) joy_type = JOY_TYPE_STANDARD;
   if (joy_key == 4) joy_type = JOY_TYPE_4BUTTON;
   if (joy_key)
      if (initialise_joystick())
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, SCREEN_H/2, 13);
                  joy_key=0;
                  rest(1500);
               }
#ifdef FV
   {
      extern char global_string[20][25][80]; /* menu.c */
      if (sound_on)
         {
            sound_setup();
            sprintf(global_string[8][7],"SOUND:ON");
         }
      else sprintf(global_string[8][7],"SOUND:OFF");
   }
#else
   sound_on = 0;
#endif
   /* timer stuff */
   LOCK_VARIABLE(msec_timer);
   LOCK_FUNCTION(inc_msec_timer);
   install_int(inc_msec_timer,1);


   for (x=0; x<20; x++)
      for (c=0; c<64; c++)   /* animation initial zeroing */
         zz[x][c] = 0;

   for (c=0; c < 100; c++) /* zero enemies */
      for (y=0; y < 10; y++)
         {
            Ef[c][y] = 0;
            Ei[c][y] = 0;
         }
   for (c=0; c<100; c++) /* set all of l[100][100] to 0 */
      for (y=0; y<100; y++)
         l[c][y]=0;

   for (c=0; c < 500; c++) /* set all of itemf[500][4] to 0 */
      for(y=0; y<4; y++)
         itemf[c][y] = 0;
   for (c=0; c < 500; c++) /* set all of item[500][16] to 0 */
      for (y=0; y < 16; y++)
         item[c][y]=0;

   for (c = 0; c < 20; c++)
      for (d = 0; d < 20; d++)
         mov_ob[c][d] = 0;

   for (c = 0; c < 20; c++)
      for (d = 0; d < 20; d++)
         for (y = 0; y < 4; y++)
            mov_obi[c][d][y] = 0;

   for (c=0; c<512; c++)
      {
         memory_bitmap[c] = create_bitmap(20,20);
         clear(memory_bitmap[c]);
      }
   level_2000 = create_bitmap(2000,2000);

   scrn_buffer = create_bitmap(SCREEN_W,SCREEN_H);
   map100_bkg = create_bitmap(100,100);
   map100_bmp = create_bitmap(100,100);

   if (!load_sprit())
      {
         textout_centre(screen, font, "Error loading sprit file...Exiting",SCREEN_W/2, (SCREEN_H/2)-10, 2);
         rest(1000);
         return 0;
      }
   initialize_zz(); /* zero the pass counters in the animation seqs */
   return 1;
}


main(int argument_count, char **argument_array)  /* look how small it is! */
{
if (initial_setup(640, 480))
   {

#ifdef FV
      if (argument_count == 2)
         {
            extern char global_string[20][25][80]; /* menu.c */
            start_level = atoi(argument_array[1]);
            sprintf(global_string[8][8], "START LEVEL (%d)",start_level);
         }
#endif
      do
         {
            frame_and_title();
            if (resume_allowed) top_menu_sel = 3;
            top_menu_sel = zmenu(7, top_menu_sel, 50);
            if (top_menu_sel == 2)
               {
                  textout_centre(screen, font, "GET READY!",SCREEN_W/2, (SCREEN_H*4)/5, 241);
                  level_done = 0;
                  play_level = start_level;
                  num_bullets = 200;
                  LIVES = 5;
                  LIFE = 100;
                  start_mode = 1; /* load start */
                  game_exit = 0;
                  pm_main();
               }
            if ((top_menu_sel == 3) && (resume_allowed))
               {
                  start_mode = 0;  /* resume */
                  game_exit = 0;
                  pm_main();
               }
#ifdef FV
            if (top_menu_sel == 4) /* load game */
               {
                  load_game();
                  maps_and_background_fill();
                  start_mode = 0;
                  game_exit = 0;
                  pm_main();
               }
            if ((top_menu_sel == 5) && (resume_allowed)) save_game();
            if (top_menu_sel == 7) help(0); /* help */
            if (top_menu_sel == 6) /* OPTIONS MENU */
#else
            if (top_menu_sel == 5) help(0); /* help */
            if (top_menu_sel == 4) /* OPTIONS MENU */
#endif
               {
                  int options_menu_sel = 2;
                  do
                     {
                        frame_and_title();
                        options_menu_sel = zmenu(8,options_menu_sel,50);
                        if (options_menu_sel == 3)
                           {
                              clear(screen);
                              clear_keybuf();
                              rest(100);
                              textout_centre(screen, font, "Keyboard Configuration", SCREEN_W/2, 40, 9);

                              textout(screen, font, "Press the new key for 'up'", 10, 60, 9);
                              up_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'down'", 10, 70, 9);
                              down_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'left'", 10, 80, 9);
                              left_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'right'", 10, 90, 9);
                              right_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'jump'", 10, 100, 9);
                              jump_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'fire'", 10, 110, 9);
                              fire_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'map'", 10, 120, 9);
                              map_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'menu'", 10, 130, 9);
                              menu_key = readkey() >> 8;
                            joy_key = 0;
                              save_keys();
                              clear(screen);

                           }
                          if (options_menu_sel == 4)
                           {
                              clear(screen);
                              clear_keybuf();
                              rest(500);

                          text_mode(0);

                          joy_key = controller_setup();
                          rest(500);

                          text_mode(0);

                       if (joy_key == 1) /* standard */
                          {
                              joy_key = 1; /* enable joystick control for the game */

                              textout_centre(screen, font, "Joystick Calibration", SCREEN_W/2, 40, 9);
                              textout_centre(screen, font, "Centre the joystick", SCREEN_W/2, SCREEN_H/2-8, 15);
                              textout_centre(screen, font, "and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);

                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((!joy_b1) && (!joy_b2));


                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((joy_b1) || (joy_b2));
                           
                              clear(screen);
                              textout_centre(screen, font, "Move the joystick to the top", SCREEN_W/2, SCREEN_H/2-8, 15);
                              textout_centre(screen, font, "left corner and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);
                           
                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((!joy_b1) && (!joy_b2));

                              calibrate_joystick_tl();
                           
                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((joy_b1) || (joy_b2));
                           
                              clear(screen);
                              textout_centre(screen, font, "Move the joystick to the bottom", SCREEN_W/2, SCREEN_H/2-8, 15);
                              textout_centre(screen, font, "right corner and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);
                           
                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((!joy_b1) && (!joy_b2));
                           
                              calibrate_joystick_br();

                              joy_menu = 0;
                              joy_map = 0;

                         }  /* end of standard only */


                      if (joy_key) /* standard and 4 button */
                         {
                              clear(screen);
                              textout(screen, font, "Press the button to jump", 10, 60, 9);
                              joy_jump = get_joy_button();
                              rest (500);
                              clear(screen);
                              textout(screen, font, "Press the button to shoot", 10, 60, 9);
                              joy_fire = get_joy_button();
                              rest (500);
                          }
                       if (joy_key == 4) /* 4 button only */
                          {
                              clear(screen);
                              textout(screen, font, "Press the map button", 10, 60, 9);
                              joy_map = get_joy_button();

                              rest (500);
                              clear(screen);
                              textout(screen, font, "Press the menu button", 10, 60, 9);
                              joy_menu = get_joy_button();

                              rest(500);
                          }
                     save_keys();
                     clear(screen);

                }
             if (options_menu_sel == 5) /* Difficulty  */
               {
                   if (++dif > 3) dif=1;
                   set_dif();
               }
            if (options_menu_sel == 6) /* Speed */
               {
                  if (++speed > 5) speed = 1;
                  set_speed();
               }

#ifdef FV
            if (options_menu_sel == 7) /* Sound */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  sound_on = (!sound_on);
                  if (sound_on) sound_setup();

                  if (sound_on) sprintf(global_string[8][7],"SOUND:ON ");
                  else sprintf(global_string[8][7],"SOUND:OFF");
               }


            if (options_menu_sel == 8) /* START LEVEL */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  int old_mouse;
                  int quit = 0;
                  while (key[KEY_ENTER]);
                  while (mouse_b&1);
                  while (joy_b1) poll_joystick(); /* wait for release */
                  while (!quit)
                     {

                        if (joy_key) poll_joystick();
                        /* make it red */
                        sprintf(msg, "(%d) ",start_level );
                        textout(screen, font, msg, (196*SCREEN_W)/320,114, 10);
                        if ((key[KEY_UP]) || (key[up_key]) || (joy_up))
                           {
                              if (++start_level > 99) start_level=99;
                              while ((key[KEY_UP]) || (key[up_key]));
                              while (joy_up) poll_joystick(); /* wait for release */
                           }
                        if ((key[KEY_DOWN]) || (key[down_key]) || (joy_down))
                           {
                              if (--start_level < 1) start_level=1;
                              while ((key[KEY_DOWN]) || (key[down_key]));
                              while (joy_down) poll_joystick(); /* wait for release */
                           }
                        position_mouse(160,100);
                        old_mouse = mouse_y;
                        rest(10);
                        if (mouse_y > old_mouse) if (--start_level < 1) start_level=1;
                        if (mouse_y < old_mouse) if (++start_level > 99) start_level = 99;
                        if (mouse_y != old_mouse) rest(50);

                        if (key[KEY_ESC]) quit = 1;
                        if (key[KEY_ENTER]) quit = 1;
                        if ((mouse_b&1) || (mouse_b&2)) quit = 1;
                        if (joy_b1) quit = 1;
                      } /* end of while ! quit */

                      while ((key[KEY_ESC]) || (key[KEY_ENTER]));
                      while ((mouse_b&1) || (mouse_b&2));
                      while (joy_b1) poll_joystick(); /* wait for release */

                  sprintf(global_string[8][8], "START LEVEL (%d)",start_level);
               }

            if (options_menu_sel == 9) /* Level Editor */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  int l = start_level;
                  char *fname[20];
                  final_wrapup();
                  sprintf(*fname, "pmfle.exe %d", l);
                  l = system(*fname); /* set level num from level editor */
                  initial_setup(640,480);
                  start_level = l;
                  sprintf(global_string[8][8], "START LEVEL (%d)",start_level);

                  /* to immediately start playing the level after level editor */
                  textout_centre(screen, font, "GET READY!",SCREEN_W/2, (SCREEN_H*4)/5, 241);
                  level_done = 0;
                  play_level = start_level;
                  num_bullets = 200;
                  LIVES = 5;
                  LIFE = 100;
                  start_mode = 1;
                  game_exit = 0;
                  pm_main();

               }

            if (options_menu_sel == 10) /* set 640 x 480 mode */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  int l = start_level;

                  final_wrapup();
                  initial_setup(640,480);

                  start_level = l;
                  sprintf(global_string[8][8], "START LEVEL (%d)",start_level);
                  resume_allowed = 0;
                  top_menu_sel = 2;
               }

             if (options_menu_sel == 11) /* set 800 x 600 mode */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  int l = start_level;

                  final_wrapup();
                  initial_setup(800,600);

                  start_level = l;
                  sprintf(global_string[8][8], "START LEVEL (%d)",start_level);
                  resume_allowed = 0;
                  top_menu_sel = 2;
               }
             if (options_menu_sel == 12) /* set 1024 x 768 mode */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  int l = start_level;

                  final_wrapup();
                  initial_setup(1024,768);

                  start_level = l;

                  sprintf(global_string[8][8], "START LEVEL (%d)",start_level);
                  resume_allowed = 0;
                  top_menu_sel = 2;
               }
#endif

#ifdef SW
            if (options_menu_sel == 7) /* set 640 x 480 mode */
               {
                  int l = start_level;
                  final_wrapup();
                  initial_setup(640,480);
                  start_level = l;
                  resume_allowed = 0;
                  top_menu_sel = 2;
               }

             if (options_menu_sel == 8) /* set 800 x 600 mode */
               {
                  int l = start_level;
                  final_wrapup();
                  initial_setup(800,600);
                  start_level = l;
                  resume_allowed = 0;
                  top_menu_sel = 2;
               }
             if (options_menu_sel == 9) /* set 1024 x 768 mode */
               {
                  int l = start_level;
                  final_wrapup();
                  initial_setup(1024,768);
                  start_level = l;
                  resume_allowed = 0;
                  top_menu_sel = 2;
               }
#endif



            }  while (options_menu_sel != 2); /* end of options menu */
                  save_keys();
                  rest(100);
                  clear(screen);
               }
#ifdef FV
           }  while (top_menu_sel != 8); /* end of game menu */
#else
           }  while (top_menu_sel != 6); /* end of game menu */
#endif


   }
show_mouse(NULL);
textout_centre(screen, font, "Thanks for playing Purple Martians!", SCREEN_W/2,SCREEN_H-24, 10);
rest(1000);
final_wrapup();
exit(0);
}

