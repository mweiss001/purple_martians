#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>


/* for is_solid functions */
extern int l[100][100];
extern int mov_ob[20][20];

int edit_int( int x, int y, int initial, int inc, int lv, int uv)
{
extern int edit_int_retval;
int imx = mouse_x;
int imy = mouse_y;
int quit_mode = 0, retval, quit=0, old_mouse;
char msg[80];

if (mouse_b & 1) quit_mode = 1;   /* set mouse exit mode if b1 pressed on enter */
clear_keybuf();
do
   {
      sprintf(msg,"%d  ",initial);
      textout(screen, font, msg, x, y, 1);
      if (key[KEY_UP])
         {
            clear_keybuf();
            rest(5);
            initial += inc;

         }
     if (key[KEY_DOWN])
         {
            clear_keybuf();
            rest(5);
            initial -= inc;
         }
  if (quit_mode == 1)
   {
        if (!(mouse_b & 1))
         {
            clear_keybuf();
            sprintf(msg,"%d  ",initial);
            textout(screen, font, msg, x, y, 34);
            edit_int_retval = initial;
            retval = 1;
            quit = 1;

         }
   }
if (quit_mode == 0)
   {
    if ((key[KEY_ENTER]) || (mouse_b & 1))
         {
            clear_keybuf();
            sprintf(msg,"%d  ",initial);
            textout(screen, font, msg, x, y, 34);
            edit_int_retval = initial;
            retval = 1;
            quit = 1;

         }
   }
    if ((key[KEY_ESC]) || (mouse_b & 2))
         {
            clear_keybuf();
            retval = 0;
            quit = 1;

         }
    position_mouse(160, 100);
    old_mouse = mouse_y;
    rest(10);
    initial = initial - ((mouse_y - old_mouse) * inc);
    if (initial > uv) initial = uv;
    if (initial < lv) initial = lv;
   } while (!quit);

position_mouse(imx, imy);
return retval;
}

void initialize_zz(void)
{
   extern int passcount;
   extern int zz[20][64];
   int c;
   for (c=0; c<64; c++)
      zz[2][c]=0;  /* reset the passcount */
   passcount = 0;
}

void update_animation(void)
{
   extern int passcount;
   extern int zz[20][64];
   int y;
   passcount++;   /* animation update */
   for (y=0; y<64; y++)
      if (zz[4][y] != 0)
         if ((passcount - zz[2][y]) > zz[3][y])
            {
               zz[1][y]++;     /* next bitmap */
               zz[2][y] = passcount;      /* set counter */
               if (zz[1][y] > zz[4][y]) zz[1][y] = 0;    /* is bitmap past end? */
               zz[0][y] = zz[ 5 + zz[1][y] ] [y];      /* put shape in 0 */
            }
}


int get_rot_from_xyinc(int EN)
{
extern float Ef[100][10];
float angle, xlen, ylen;
int rot=0;


xlen = abs(Ef[EN][2]);
if (xlen == 0) xlen = .001; /* to prevent divide by zero */
ylen = abs(Ef[EN][3]);

angle = atan(ylen/xlen);
angle *= (64/1.57); /* convert from radians (0 to pi/2) to fixed (0 to 64) */


if (Ef[EN][2] <= 0)    /* xinc <= 0 */
    {
       if (Ef[EN][3] <= 0) rot += 64+angle;   /* yinc <= 0 */
       if (Ef[EN][3] >  0) rot += 64-angle;   /* yinc > 0 */
    }
if (Ef[EN][2] > 0)    /* xinc > 0 */
    {
       rot += 128;
       if (Ef[EN][3] >  0) rot += 64+angle;   /* yinc > 0 */
       if (Ef[EN][3] <= 0) rot += 64-angle;   /* yinc <= 0 */
    }
return rot;

}
void seek_set_xyinc(int EN, int EXint, int EYint)
{
extern float Ef[100][10];
extern int PXint, PYint;
float angle, xlen, ylen, xinc, yinc;

xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .001;
ylen = abs(PYint - EYint);

angle = atan(ylen/xlen);
xinc = cos(angle) * Ef[EN][8];  /* hypotenuse is the speed! */
yinc = sin(angle) * Ef[EN][8];

if (EXint < PXint) Ef[EN][2] = +xinc;
if (EXint > PXint) Ef[EN][2] = -xinc;
if (EYint < PYint) Ef[EN][3] = +yinc;
if (EYint > PYint) Ef[EN][3] = -yinc;
}

int get_rot_from_PXY(int EN, int EXint, int EYint)
{
extern float Ef[100][10];
extern int PXint, PYint;
float angle, xlen, ylen;
int rot=0;


xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .001; /* to prevent divide by zero */
ylen = abs(PYint - EYint);

angle = atan(ylen/xlen);
angle *= (64/1.57); /* convert from radians (0 to pi/2) to fixed (0 to 64) */

if (EXint >= PXint)
    {
       if (EYint >= PYint) rot += 64+angle;
       if (EYint <  PYint) rot += 64-angle;
    }
if (EXint < PXint)
    {
       rot += 128;
       if (EYint <= PYint) rot += 64+angle;
       if (EYint >  PYint) rot += 64-angle;
    }
return rot;
}
void fire_enemy_bulleta(int EN, int EXint, int EYint, int ans) /* animation */
{
extern int e_bullet_active[50];
extern int e_bullet_shape[50];
extern int zz[20][64];
extern float e_bullet_x[50];
extern float e_bullet_y[50];
extern float e_bullet_xinc[50];
extern float e_bullet_yinc[50];
extern float Ef[100][10];
extern int PXint, PYint;
float angle, xlen, ylen, xinc, yinc;
int z;


xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .00001;
ylen = abs(PYint - EYint);
if (ylen == 0) ylen = .00001;
angle = atan(ylen/xlen);
xinc = cos(angle) * Ef[EN][7];
yinc = sin(angle) * Ef[EN][7];

for (z=0; z<50; z++)  /* find empty e_bullet */
   if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_shape[z] = 1000+ans;
         e_bullet_x[z] = EXint;
         e_bullet_y[z] = EYint;
         if (EXint <  PXint) e_bullet_xinc[z] = +xinc;
         if (EXint >  PXint) e_bullet_xinc[z] = -xinc;
         if (EXint == PXint) e_bullet_xinc[z] = 0;
         if (EYint <  PYint) e_bullet_yinc[z] = +yinc;
         if (EYint >  PYint) e_bullet_yinc[z] = -yinc;
         if (EYint == PYint) e_bullet_yinc[z] = 0;
         z=50;
      }
}

void fire_enemy_x_bullet(int EN, int EXint, int EYint)
{
extern int e_bullet_active[50];
extern int e_bullet_shape[50];
extern float e_bullet_x[50];
extern float e_bullet_y[50];
extern float e_bullet_xinc[50];
extern float e_bullet_yinc[50];
extern float Ef[100][10];
extern int PXint, PYint;

int z;
int x_bullet_speed = abs(Ef[EN][2] * 3);  /* bullet speed fromx move */
if (x_bullet_speed < 5) x_bullet_speed =5; /* default if low x_move */
for (z=0; z<50; z++)  /* find empty e_bullet */
   if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_yinc[z] = 0;
         e_bullet_x[z] = EXint;
         e_bullet_y[z] = EYint;
         if (EXint < PXint)
            {
               e_bullet_xinc[z] = x_bullet_speed;
               e_bullet_shape[z] = 488;
            }
         if (EXint >= PXint)
            {
               e_bullet_xinc[z] = -x_bullet_speed;
               e_bullet_shape[z] = 489;
            }
         z=50; /* end loop */
      }
}
int is_right_solid(int solid_x, int solid_y)
{
         int a, b, c, d;
         int xx = (solid_x / 20) + 1;
         int yy = (solid_y / 20);
         int cc = (solid_y / 20) + 1;
         a = solid_y % 20;
          for (d = 0; d<20; d++)
            if (mov_ob[d][0]) /* if active */
               if (solid_y > mov_ob[d][3] - 18)
                  if (solid_y < mov_ob[d][5] - 2)
                     if (solid_x < mov_ob[d][2] - 8)
                        if (solid_x > mov_ob[d][2] - 18)
                           return 32+d;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][cc];
                 if ((c > 7 ) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17)) /* dual compare with ||  */
             {
                 b = l[xx][yy];
                 c = l[xx][cc];
                 if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }


         return 0;
}
 int is_left_solid(int solid_x, int solid_y)
{


         int a, b, c, d;
         int xx = (solid_x / 20);
         int yy = (solid_y / 20);
         int cc = (solid_y / 20)+1;
         a = solid_y % 20;
          for (d = 0; d<20; d++)
            if (mov_ob[d][0]) /* if active */
               if (solid_y > mov_ob[d][3] - 18)
                  if (solid_y < mov_ob[d][5] - 2)
                     if (solid_x < mov_ob[d][4] + 2)
                        if (solid_x > mov_ob[d][4] - 8)
                           return 32+d;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][cc];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17))/* dual compare with ||  */
             {
                b = l[xx][yy];
                c = l[xx][cc];
                if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }

         return 0;
}
int is_down_solid(int solid_x, int solid_y, int lift_check)
{

         int a, b, c, d;
         int yy = (solid_y / 20)+1;
         int cc = (solid_x / 20);
         int xx = (solid_x / 20)+1;
         a = solid_x % 20;

         if (lift_check)
            for (d = 0; d<20; d++)  /* check for mov first */
               if (mov_ob[d][0])    /* if active */
                  if (solid_x > mov_ob[d][2]-18)
                     if (solid_x < mov_ob[d][4]-2)
                        if (solid_y > mov_ob[d][3] - 25)
                           if (solid_y < mov_ob[d][3] - 10)
                               return d+32;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[cc][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a <17)) /* dual compare with ||  */
             {
                 b = l[xx][yy];
                 c = l[cc][yy];
                 if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }

         return 0;
}

int is_up_solid(int solid_x, int solid_y, int lift_check, int semi_check)
{
         int a, b, c, d, e;
         int yy = (solid_y-2)/20;
         int cc = (solid_x / 20);
         int xx = (solid_x / 20)+1;
         if (semi_check) e = 15;
         else e = 7;
         a = solid_x % 20;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][yy];

                 if ((c > e) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[cc][yy];

                 if ((c > e) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17))/* dual compare with ||  */
             {
                 b = l[cc][yy];
                 c = l[xx][yy];
                 if ( ((b > e) && (b < 256)) || ((c > e) && (c < 256)) ) return 1;
             }
         if (lift_check)
            for (d = 0; d<20; d++)
               if (mov_ob[d][0]) /* if active */
                  if (solid_x > mov_ob[d][2] - 18)
                     if (solid_x < mov_ob[d][4] - 2)
                        if (solid_y < mov_ob[d][5] + 2)
                           if (solid_y > mov_ob[d][5] - 10)
                              return 2;
         return 0;
}

