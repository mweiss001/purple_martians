/* New Lift Viewer */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"
#include "lift.h"

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];
extern int num_lifts;

extern int db;
extern char msg[80];
extern int current_lift;

char fst[80];

/* function prototypes */
void set_lift(int lift, int step);
void lift_editor(int lift);
void draw_step_button(int txc, int ty, int lift, int step, int tc, int rc);
void draw_lift_mp();
void set_lift_initial_not_in_file(int lift);


DIALOG edit_text_line[] =
{
   /* (dialog proc)     (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)    (d2)  (dp)       (dp2) (dp3) */
   { d_box_proc,        100,  100,  200,  100,  255,  0,    0,    0,       0,      0,    NULL,      NULL, NULL  },
   { d_ctext_proc,      200,  110,    0,    0,   13,  0,    0,    0,       0,    0,    "Edit Lift Name" },
   { d_edit_proc,       110,  130,  100,  10,   255,  0,    0,    0,       sizeof(fst)-1,   0,    fst,       NULL, NULL  },
   { d_button_proc,     110,  175,  80,  20,   255,  0,    13,    D_EXIT,  0,      0,    "OK",      NULL, NULL  },
   { d_button_proc,     210,  175,  80,  20,   255,  0,    27,    D_EXIT,  0,      0,    "Cancel",  NULL, NULL  },
   { NULL,              0,    0,    0,    0,    0,   0,    0,    0,       0,      0,    NULL,      NULL, NULL  },
};

void show_all_lifts(void)
{
   int l, s;
   clear(screen);
   show_mouse(NULL);
   for (l=0; l<num_lifts; l++)
      {
         sprintf(msg,"l:%-2d w:%-2d h:%-2d col:%-2d ns:%-2d  name:%s  ", l, lifts[l]->width, lifts[l]->height, lifts[l]->color, lifts[l]->num_steps, lifts[l]->lift_name);
         textout(screen, font, msg, 10, l*8, 15);
      }
   tsw();
}
int construct_lift(int l,char* lift_name,int width,int height,int color,int num_steps)
{
   /*  allocate new lift */
   int ret = 0;
   if (lifts[l] = (struct lift*) malloc(sizeof(struct lift))) ret = 1;

   /*  allocate space for string */
   lifts[l] -> lift_name = (char*) malloc(strlen(lift_name)+1);
   strcpy(lifts[l] -> lift_name, lift_name);

   lifts[l] -> width = width;
   lifts[l] -> height = height;
   lifts[l] -> color = color;
   lifts[l] -> num_steps = num_steps;

   lifts[l] -> x1 = 0;
   lifts[l] -> y1 = 0;
   lifts[l] -> x2 = 0;
   lifts[l] -> y2 = 0;
   lifts[l] -> current_step = 0;
   lifts[l] -> limit_type = 0;
   lifts[l] -> limit_counter = 0;
   return ret;
}
void destroy_lift(int lift)
{
   if (lifts[lift] != NULL) /* only free if non null pointer */
      {
         /* first free the string */
         free(lifts[lift] -> lift_name);
         /* then free the lift structure */
         free(lifts[lift]);
      }
}
int construct_lift_step(int lift, int step, int x, int y, int val, int type)
{
   int ret = 0;
   if (lift_steps[lift][step] = (struct lift_step*) malloc(sizeof(struct lift_step))) ret = 1;
   lift_steps[lift][step] -> x    = x;
   lift_steps[lift][step] -> y    = y;
   lift_steps[lift][step] -> val  = val;
   lift_steps[lift][step] -> type = type;
   return ret;
}
void destroy_lift_step(int lift, int step)
{
    if (lift_steps[lift][step] != NULL)
       free(lift_steps[lift][step]);
}
void erase_lift(int lift)
{
   int a, b;
   /* erase the lift */
   destroy_lift(lift);
   for (b=0; b<20; b++)
      destroy_lift_step(lift, b);

   /* slide down to close hole in pointer array */
   for (a=lift; a<num_lifts; a++)
      {
         lifts[a] = lifts[a+1];
         for (b=0; b<20; b++)
            lift_steps[a][b] = lift_steps[a+1][b];
      }

   /* set last lift pointer to NULL */
   lifts[num_lifts] = NULL;
   for (b=0; b<20; b++)
      lift_steps[num_lifts][b] = NULL;
      
   /* one less lift */
   num_lifts--;
}
void set_lift_xyinc(int d, int step) /* used by move lift everywhere */
{
   float speed, angle, xlen, ylen, xinc, yinc;
   speed = lift_steps[d][step] -> val;
   speed /=10;
   xlen = abs( lifts[d] -> x1 - lift_steps[d][step] -> x );
   if (xlen == 0) xlen = .000001;
   ylen = abs( lifts[d] -> y1 - lift_steps[d][step] -> y );
   if (ylen == 0) ylen = .000001;
   angle = atan(ylen/xlen);
   xinc = cos(angle) * speed;
   yinc = sin(angle) * speed;
   if (xlen > ylen)
      lifts[d] -> limit_counter = abs( xlen / xinc); /* distance/speed=time! */
   if (xlen <= ylen)
      lifts[d] -> limit_counter = abs( ylen / yinc); /* distance/speed=time! */
   lifts[d] -> limit_type = 7; /* step countdown limit type 7 */
   
   if (lifts[d] -> x1  < lift_steps[d][step] -> x) lifts[d]->fxinc = +xinc;
   if (lifts[d] -> x1 == lift_steps[d][step] -> x) lifts[d]->fxinc = 0;
   if (lifts[d] -> x1  > lift_steps[d][step] -> x) lifts[d]->fxinc = -xinc;
   
   if (lifts[d] -> y2  < lift_steps[d][step] -> y) lifts[d]->fyinc = +yinc;
   if (lifts[d] -> y2 == lift_steps[d][step] -> y) lifts[d]->fyinc = 0;
   if (lifts[d] -> y2  > lift_steps[d][step] -> y) lifts[d]->fyinc = -yinc;
}
void draw_steps(int highlight_step, int fc)
{
    int num_steps = lifts[current_lift] -> num_steps;
    int step;
    int x, jh = 13;
    int ty = 40;
    extern int txc;

    show_mouse(NULL);

    title("List of Steps", txc, ty+((jh-2)*12)-3, 15, 13);

    rect(screen, txc-98, ty+((jh-1)*12), txc+96, ty+((jh-1)*12)+10, 11);
    sprintf(msg,"#  Type of Step");
    textout(screen, font, msg, txc-96, ty+((jh-1)*12)+2, 14);

      /* draw and count steps */
      for (step = 0; step < num_steps; step ++)
         if (lift_steps[current_lift][step] -> type) /* step is valid */
            {
               if (highlight_step == step)
                  draw_step_button(txc, ty+(step+jh)*12, current_lift, step, 14, fc);
               else
                  draw_step_button(txc, ty+(step+jh)*12, current_lift, step, 15, 9);
            }
}
void fast_draw_lifts(void)
{
   extern int level_header[20];
   int color, x1, y1, x2, y2, x3, y3, a, d;
   for (d=0; d<num_lifts; d++)  /* cycle lifts */
        {
           color = lifts[d] -> color;  /* set all x , y  are 0-2000 */

           x3 = lifts[d] -> width*20;  /* convert to 0-2000 */
           y3 = lifts[d] -> height*20;
           x1 = lifts[d] -> x1 +4;      /* 0-2000 */
           y1 = lifts[d] -> y1 +4;
           x2 = x1 + x3-4;           /* set x2, y2 */
           y2 = y1 + y3-4;

           if (d == current_lift) /* mark current lift */
              {

                 line(screen, ((x1+x2)/2)*db/20, 0, ((x1+x2)/2)*db/20, db*100-1, 10);
                 line(screen, 0, ((y1+y2)/2)*db/20, db*100-1, ((y1+y2)/2)*db/20, 10);

                 rect(screen, (x1*db/20)-1, (y1*db/20)-1, (x2*db/20)+1, (y2*db/20)+1, 15);

              }

           /* draw lift */
           for (a=0; a<10; a++)
               rect(screen, (x1+a)*db/20, (y1+a)*db/20, (x2-a)*db/20, (y2-a)*db/20, color+ (9-a)*16 );
           rectfill(screen, (x1+a)*db/20, (y1+a)*db/20, (x2-a)*db/20, (y2-a)*db/20, color );


           if (1) /* display text */
              {

                 int tc = color + 128 + 32; /* text color */

                 int tl, th;
                 int ntl, nth;

                 int txc = (x1+x2)/2;   /* find centre of lift */
                 int tyc = (y1+y2)/2;

                 BITMAP *tbmp;

                 sprintf(msg, lifts[d] -> lift_name);

                 /* find text length and height pixels */
                 tl = text_length(font, msg);
                 th = text_height(font);

                 /* create a clear a bitmap */
                 tbmp = create_bitmap(tl, th);
                 clear(tbmp);

                 /* draw text on tbmp */
                 text_mode(-1);
                 textout(tbmp, font, msg, 0, 0, tc);
                 text_mode(0);

                 /* put on screen */
                 stretch_sprite(screen, tbmp, (txc*db/20) - (((tl/2)*db)/20), (tyc*db/20)- (((th/2)*db)/20), (tl*db)/20, (th*db)/20 );

                 destroy_bitmap(tbmp);
              }

      }
}
void draw_lift_mp() /* draws the current lift on mp */
{
   BITMAP *mp_big;
   extern BITMAP *mp;
   int color = lifts[current_lift] -> color;

   int a, c, d, x, y;

   int szx = lifts[current_lift] -> width;
   int szy = lifts[current_lift] -> height;


/*   destroy_bitmap(mp);  */
/*    mp = create_bitmap(szx*db, szy*db);      /* 100 */
   mp_big = create_bitmap(szx*20, szy*20);  /* 400 */

   clear(mp_big);
   clear(mp);

   d = current_lift;

   for (a=0; a<10; a++)
       rect(mp_big, a, a, (lifts[d] -> width*20)-1-a, (lifts[d] -> height*20)-1-a, color+((9-a)*16) );
   rectfill(mp_big, a, a, (lifts[d] -> width*20)-1-a, (lifts[d] -> height*20)-1-a, color);

   text_mode(-1);
   textout_centre(mp_big, font, lifts[d] -> lift_name, (lifts[d] -> width*10)-2, (lifts[d] -> height*10)-2, color+128+32);
   text_mode(0);

   stretch_sprite(mp, mp_big, 0, 0, szx*db, szy*db);
   destroy_bitmap(mp_big);
}

int get_new_lift_step(int step)
{
   extern int get100_x;
   extern int get100_y;
   extern int edit_int_retval;
   extern int txc;

   int ty = 80;

   int wait = 100;
   int prox = 80;
   int speed = 20;
   int quit = 0;
   int redraw = 1;
   int a, b, c, d, x;
   int jh;
   int  xsize = 5; /* default x size */
   int  ysize = 1; /* default y size */
   int  color = 12;  /* default color  */
   int  other = 0;  /* default other  */

   /* loop and get steps */
   while (!quit)
      {
         if (redraw)
            {
               redraw = 0;
               rectfill(screen, txc-100, ty-36, txc+98, ty+(7*12)+9, 0);
               textout_centre(screen, font, "Choose New Step to Add", txc, ty-2, 10);
               jh = 1;
               sprintf(msg, "Move to pos (speed=%-2d)", speed);
               textout_centre(screen, font, msg, txc, ty+(jh*12)+2,  7);
               rect(screen, txc-98, ty+(jh*12), txc+96, ty+(jh*12)+10, 13);
      
               jh = 2;
               sprintf(msg, "Wait time   (time=%-3d)", wait);
               textout_centre(screen, font, msg, txc, ty+(jh*12)+2,  7);
               rect(screen, txc-98, ty+(jh*12), txc+96, ty+(jh*12)+10, 13);
      
               jh = 3;
               sprintf(msg, "Wait prox   (prox=%-3d)", prox);
               textout_centre(screen, font, msg, txc, ty+(jh*12)+2,  7);
               rect(screen, txc-98, ty+(jh*12), txc+96, ty+(jh*12)+10, 13);
      
               jh = 4;
               sprintf(msg, "Loop to step 0 (finish)", prox);
               textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 7);
               rect(screen, txc-98, ty+(jh*12), txc+96, ty+(jh*12)+10, 13);

               jh = 5;
               textout_centre(screen, font, "Cancel", txc, ty+(jh*12)+2, 7);
               rect(screen, txc-98, ty+(jh*12), txc+96, ty+(jh*12)+10, 13);

            }

         show_mouse(screen);
         rest(20);
         show_mouse(NULL);

         if ((mouse_b & 2) || (key[KEY_ESC])) quit = 99;

         if ((mouse_b & 1) && (mouse_y > ty) && (mouse_y < ty+(6*12) ))
            {
               int selection = (mouse_y-ty)/12-1;
               redraw = 1;
               if ((mouse_x > txc+60) && (mouse_x < txc+95)) /* edit values */
                  {
                     switch (selection)
                       {
                          case 0: /* edit speed */
                                if (edit_int(txc+64, ty+(selection*12)+14, speed, 1, 1, 29))
                                speed = edit_int_retval;
                          break;
                          case 1: /* edit wait */
                                if (edit_int(txc+60, ty+(selection*12)+14, wait, 10, 10, 2000))
                                wait = edit_int_retval;
                          break;
                          case 2: /* edit prox */
                              if (edit_int(txc+56, ty+(selection*12)+14, prox, 10, 20, 200))
                                prox = edit_int_retval;
                          break;
                       }
                  }
               if ((mouse_x > txc-95) && (mouse_x < txc+60)) /* set step */
                  {
                     while(mouse_b & 1); /* wait for release */
                     quit = 1;

                     /* free old step */
                     destroy_lift_step(current_lift, step);

                     switch (selection)
                       {
                          case 0:
                               /* set for getxy   type 1 = move */
                               construct_lift_step(current_lift, step, 0, 0, speed, 1);
                               lift_steps[current_lift][step] -> type = 1;
                               if (getxy("Set lift position", 4, NULL, step) == 1)
                                  {
                                     lift_steps[current_lift][step] -> x = get100_x * 20;  /* set new x,y */
                                     lift_steps[current_lift][step] -> y = get100_y * 20;
                                  }
                               else quit = 99;
                          break;
                          case 1:  /* set wait for time step */
                               construct_lift_step(current_lift, step, 0, 0, wait, 2);
                          break;
                          case 2: /* set wait for proximity step */
                               construct_lift_step(current_lift, step, 0, 0, prox, 3);
                          break;
                          case 3: /* set loop to 0 step */
                               construct_lift_step(current_lift, step, 0, 0, 0, 4);
                               quit=37;  /* this exits, but its a good exit! */
                          break;
                          case 4: /* cancel */
                               quit=99;
                          break;
                       } /* end of switch case */
                 }  /* end of set step */
              if (quit == 99) destroy_lift_step(current_lift, step);
            }  /* end of if mouse click on buttons */
         set_lift(current_lift, step);
         fast_draw_lifts();
   } /* end of while (!quit) */
  return quit;
}
void draw_step_button(int txc, int ty, int lift, int step, int tc, int rc)
{
   switch (lift_steps[lift][step] -> type)
      {
         case 1: sprintf(msg, "%-2d Move to. Speed:%d", step, lift_steps[lift][step] -> val ); break;
         case 2: sprintf(msg, "%-2d Wait for. Time:%d", step, lift_steps[lift][step] -> val ); break;
         case 3: sprintf(msg, "%-2d Proximity Dist:%d", step, lift_steps[lift][step] -> val ); break;
         case 4: sprintf(msg, "%-2d Loop to Start    ", step); break;
      }
   textout(screen, font, msg, txc-96, ty+2, tc);
   rect(screen, txc-98, ty, txc+96, ty+10, rc);
}
int create_lift(void)
{
   extern int get100_x;
   extern int get100_y;
   extern int edit_int_retval;
   extern BITMAP *mp;
   int tx = db*100+20;
   int ty = 100;
   int wait = 100;
   int prox = 80;
   int speed = 20;
   int quit = 0;
   int step = 0;
   int redraw = 1;
   int a, b, c, d, x;

   extern int current_lift;
   extern int num_lifts;

   draw_big();

   num_lifts++;
   current_lift = num_lifts-1; /* set global current lift */



   construct_lift(current_lift, "", 3,1,10,0);

/* Step 1 - Lift size and color */
   while (!quit)
      {
         if (redraw)
            {
               redraw = 0;
               clear(screen);
      
               textout_centre(screen, font, "------------",SCREEN_W/2,28,9);
               textout_centre(screen, font, "Lift Creator",SCREEN_W/2,20,9);

               textout_centre(screen, font, "Set lift width, height, and color",SCREEN_W/2,ty-28,15);
               textout_centre(screen, font, "Click and drag on values to edit",SCREEN_W/2,ty-20,15);
      
               /* put lift on mp */
               draw_lift_mp();
      
               /* show it on screen */
               draw_sprite(screen, mp, SCREEN_W/2+100, ty);

               textout_centre(screen, font, " Lift Width:", SCREEN_W/2,ty,9);
               sprintf(msg,"%-2d", lifts[current_lift] -> width);
               textout(screen,font,msg,SCREEN_W/2+52,ty,11);
            
               textout_centre(screen, font, "Lift Height:", SCREEN_W/2,ty+10,9);
               sprintf(msg,"%-2d", lifts[current_lift] -> height);
               textout(screen,font,msg,SCREEN_W/2+52,ty+10,11);

               textout_centre(screen, font, " Lift Color:", SCREEN_W/2,ty+20, lifts[current_lift] -> color);
               sprintf(msg,"%-2d", lifts[current_lift] -> color);
               textout(screen,font,msg,SCREEN_W/2+52,ty+20,11);
            
               textout_centre(screen, font, "When you are satisifed, press continue",SCREEN_W/2, ty+40, 15);

               textout_centre(screen, font, "Continue", SCREEN_W/2,ty+60,11);
               textout_centre(screen, font, "--------", SCREEN_W/2,ty+68,11);
            
               textout_centre(screen, font, "Abort", SCREEN_W/2,ty+80,10);
               textout_centre(screen, font, "-----", SCREEN_W/2,ty+88,10);

            } /* end of if redraw */

         show_mouse(screen); rest(20); show_mouse(NULL);
      
         if ((mouse_b & 1) && (mouse_x > SCREEN_W/3) && (mouse_x < SCREEN_W*3/4) && (mouse_y > ty) && (mouse_y < ty+100))
            {
              redraw = 1;
              switch ((mouse_y-ty)/10)
              {
                    case 0: /* edit x size */
                    if (edit_int(SCREEN_W/2+52, ty+00, lifts[current_lift] -> width, 1, 1, 100))
                       lifts[current_lift] -> width = edit_int_retval;
                    break;
                    case 1: /* edit y size */
                    if (edit_int(SCREEN_W/2+52, ty+10, lifts[current_lift] -> height, 1, 1, 100))
                       lifts[current_lift] -> height = edit_int_retval;
                    break;
                    case 2: /* edit color */
                    if (edit_int(SCREEN_W/2+52, ty+20, lifts[current_lift] -> color, 1, 1, 15))
                       lifts[current_lift] -> color = edit_int_retval;
                    break;

                    case 6: /* CONTINUE */ quit = 1; break;
                    case 8: /* ABORT */  quit = -1; break;
              }
            }
      } /* end of while (!quit) end of Step 1 lift size and color*/
   while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
   if (quit == 1) quit = 0;


/* Step 2 - Get initial position */

   if (quit != -1)
      {

         title_obj(4, NULL, current_lift);
         draw_steps(step, 10);

/*         destroy_lift_step(current_lift, step);  */
         construct_lift_step(current_lift, step, 0, 0, speed, 1);

         if (getxy("Set initial position", 4, NULL, step) == 1)
            {
               /* set step 0 and main x y*/
               lifts[current_lift] -> x1 = lift_steps[current_lift][step] -> x = get100_x * 20;
               lifts[current_lift] -> y1 = lift_steps[current_lift][step] -> y = get100_y * 20;
               /* set speed */
               lift_steps[current_lift][step] -> val = speed;
               /* set size */
               lifts[current_lift] -> x2 = lifts[current_lift] -> x1 + (lifts[current_lift] -> width*20)-1;
               lifts[current_lift] -> y2 = lifts[current_lift] -> y1 + (lifts[current_lift] -> height*20)-1;
               /* set num of steps */
               lifts[current_lift] -> num_steps = 1;
               set_lift(current_lift, step);
               fast_draw_lifts();
               title_obj(4, NULL, current_lift);
               draw_steps(step, 10);
               quit = 1;
            }
         else quit = -1;
       }

/* Step 3 - Get more steps */
   if (quit == 1) quit = 0;

   if (quit != -1)
      {
          do {
               d = get_new_lift_step(++step);

               lifts[current_lift] -> num_steps++; /* add one to steps */

               set_lift(current_lift, step);

               /* redraw a bunch of crap */
               show_mouse(NULL);
               draw_big();
               show_big();

               /* erase right panel */
               rectfill(screen, db*100, 0, SCREEN_W-1, (db*100)-2, 0 );
               /* erase bottom panel */
               rectfill(screen, 0, (db*100), SCREEN_W-1, SCREEN_H-1, 0 );
               title_obj(4, NULL, current_lift);

               /* steps */
               draw_steps(step, 10);

               if ((step == 19) && (d != 37))
                  {
                      /* set last step to loop to zero */
                      lift_steps[current_lift][step] -> type = 4;
                      d = 37;
                  }
            } while (d == 1); /* good step */
         if (d == 37) quit =1; /* loop to zero */
         if (d == 99) quit =-1;

      }
/* Step 4 - Finish lift */

     if (quit == 1)   /* finish lift */
       {
          set_lift(current_lift, 0); /* set step 0 for lift */
          return 1;
       }
    else
       {
          erase_lift(current_lift);
          current_lift--;
          return 0;
       }
}
void draw_big_no_lifts(void)
{
   extern int l[100][100];
   extern int item[500][16];
   extern int zz[20][NUM_ANS];
   extern int   Ei[100][32];
   extern int db;
   extern float Ef[100][16];
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern BITMAP *l2000;
   extern BITMAP *l700;  /* 1024x768 */
   extern BITMAP *l600;  /*  800x600 */
   extern BITMAP *l400;  /*  640x480 */
   int a,d,x,y;
   
   clear(l2000);

   for (x=0; x<100; x++)
      for (y=0; y<100; y++)
         if (l[x][y] < 256) blit(memory_bitmap[l[x][y]], l2000, 0, 0, x*20, y*20, 20, 20);
   
   for (x=0; x<100; x++)
      if (Ei[x][0])
         {
            int a, b;
            int ex = Ef[x][0];
            int ey = Ef[x][1];
   
            a = Ei[x][1]; /* bmp or ans */
            if (a < NUM_SPRITES) b = a; /* bmp */
            if (a > 999) b = zz[5][a-1000]; /* ans */
            blit(memory_bitmap[b], l2000, 0, 0, ex, ey, 20, 20);
   
         }
   for (x=0; x<500; x++)
      if (item[x][0])
         {
            int a, b;
            int ex = item[x][4];
            int ey = item[x][5];
            b = item[x][1]; /* bmp or ans */
            if (b > 1000) b = zz[0][b-1000]; /* ans */
            blit (memory_bitmap[b], l2000, 0, 0, ex, ey, 20, 20);
         }
   switch (db)
      {
         case 7:
            clear(l700);
            stretch_blit(l2000, l700, 0, 0, 2000, 2000, 0, 0, 700, 700);
         break;
         case 6:
            clear(l600);
            stretch_blit(l2000, l600, 0, 0, 2000, 2000, 0, 0, 600, 600);
         break;
         case 4:
            clear(l400);
            stretch_blit(l2000, l400, 0, 0, 2000, 2000, 0, 0, 400, 400);
         break;
      }
}
void lift_setup(void)
{
   int d;
   for (d=0; d<num_lifts; d++)
      set_lift(d, 0);
}
void set_lift_initial_not_in_file(int lift)
   {
      lifts[lift] -> x1 = lift_steps[lift][0] -> x;  /* from step 0 */
      lifts[lift] -> y1 = lift_steps[lift][0] -> y;
      lifts[lift] -> x2 = lifts[lift] -> x1 + lifts[lift] -> width*20; /* width */
      lifts[lift] -> y2 = lifts[lift] -> y1 - lifts[lift] -> height*20; /* height */

      lifts[lift]->fx = lifts[lift] -> x1; /* set float x */
      lifts[lift]->fy = lifts[lift] -> y1; /* set float y */
      lifts[lift]->fxinc = 0; /* set float xinc */
      lifts[lift]->fyinc = 0; /* set float yinc */

      lifts[lift] -> current_step = 0;
      lifts[lift] -> limit_counter = 0;
      lifts[lift] -> limit_type = 5;
   }
void set_lift(int lift, int step)
{
   int c;
   /* check if step is a move step     */
   /* if not a move step, go back till you find one */
   while ((lift_steps[lift][step] -> type != 1) && (--step >= 0));

   lifts[lift] -> x1 = lift_steps[lift][step] -> x;  /* set x1 cur step */
   lifts[lift] -> y1 = lift_steps[lift][step] -> y;  /* set y1  */
   lifts[lift] -> x2 = lifts[lift] -> x1 + lifts[lift] -> width*20; /* width */
   lifts[lift] -> y2 = lifts[lift] -> y1 - lifts[lift] -> height*20; /* height */
   lifts[lift] -> fx = lifts[lift] -> x1; /* set float x */
   lifts[lift] -> fy = lifts[lift] -> y1; /* set float y */
   lifts[lift] -> fxinc = 0; /* set float xinc */
   lifts[lift] -> fyinc = 0; /* set float yinc */

   c = step-1;
   if (c < 0) c = 0;
   lifts[lift] -> current_step = c;  /* initial step  */
   lifts[lift] -> limit_type = 5;  /* type wait for time   */
   lifts[lift] -> limit_counter = 0;  /* 0 = no wait! immediate next mode  */
}

void move_lifts(int times)
{
   int a, d;
   for (a=0; a< times; a++)
      {
         for (d=0; d<num_lifts; d++)
            {
               int next_mode = 0;
               lifts[d]->fx += lifts[d]->fxinc; /* xinc */
               lifts[d]->fy += lifts[d]->fyinc; /* yinc */
   
               lifts[d] -> x1 = lifts[d]->fx; /* put as int in x1 */
               lifts[d] -> y1 = lifts[d]->fy; /* put as int in y1 */
               lifts[d] -> x2 = lifts[d] -> x1 + (lifts[d] -> width*20)-1; /* width  */
               lifts[d] -> y2 = lifts[d] -> y1 + (lifts[d] -> height*20)-1; /* height */
      
               /* limits */
               switch (lifts[d] -> limit_type) /* limit type */
                  {
                     case 5: /* timer wait */
                             if (--lifts[d] -> limit_counter < 0)
                             next_mode = 1;
                     break;
                     case 6: /* prox wait */ next_mode = 1; break;
                     case 7: /* step count */
                             if (--lifts[d] -> limit_counter < 0)
                             next_mode = 1;
                     break;
                  }
               if (next_mode)
                  {
                     int step = ++lifts[d] -> current_step;
                     next_mode = 0;
                     switch (lift_steps[d][step] -> type)
                        {
                           case 1: /* move */ set_lift_xyinc(d, step); break;
                           case 2: /* wait time */
                              lifts[d] -> limit_type = 5; /* time is limit type 5 */
                              lifts[d] -> limit_counter = lift_steps[d][step] -> val; /* limit */
                              lifts[d]->fxinc = 0; /* no xinc */
                              lifts[d]->fyinc = 0; /* no yinc */
                           break;
                           case 3: /* wait prox */
                              lifts[d] -> limit_type = 6; /* wait prox is limit type 6 */
                              lifts[d] -> limit_counter = lift_steps[d][step] -> val; /* limit */
                              lifts[d]->fxinc = 0; /* no xinc */
                              lifts[d]->fyinc = 0; /* no yinc */
                           break;
                           case 4: /* loop to step 0 */
                              {
                                 step = lifts[d] -> current_step = 0; /* set step 0 */
                                 set_lift_xyinc(d, step);
                              }
                           break;
                        }
                  }
            } /* end of cycle lifts */
      }  /* end of times */
}
void fill_ll(void)
{
   int x, y, c;
   extern BITMAP *ll400;
   extern BITMAP *ll600;
   extern BITMAP *ll700;
 
   if (db == 4) clear(ll400);
   if (db == 6) clear(ll600);
   if (db == 7) clear(ll700);
 
   for (x=0; x<num_lifts; x++)  /* cycle lifts */
      {
         int col = lifts[x] -> color+128;
         int sx = ((lift_steps[x][0] -> x + lifts[x] -> width*10) *db)/20;
         int sy = ((lift_steps[x][0] -> y + lifts[x] -> height*10) *db)/20;
         int px = sx;
         int py = sy;
         int nx;
         int ny;
 
         for (y=0; y<lifts[x]->num_steps; y++)  /* cycle step*/
            if (lift_steps[x][y] -> type == 1) /* look for move step */
               {
                  nx = ((lift_steps[x][y] -> x + lifts[x] -> width*10) *db)/20;
                  ny = ((lift_steps[x][y] -> y + lifts[x] -> height*10) *db)/20;
 
                  /* draw lift lines */
                    switch (db)
                       {
                          case 4:
                                  line(ll400, px, py, nx, ny, col);
                                  for (c=1; c>=0; c--)
                                     circlefill (ll400, nx, ny, c,  (col-96)+c*48 );
                          break;
                          case 6:
                                  line(ll600, px, py, nx, ny, col);
                                  for (c=2; c>=0; c--)
                                     circlefill (ll600, nx, ny, c,  (col-96)+c*48 );
                          break;
                          case 7:
                                   line(ll700, px, py, nx, ny, col);
                                  for (c=3; c>=0; c--)
                                     circlefill (ll700, nx, ny, c,  (col-96)+c*48 );
                          break;
                       }
                  px = nx;
                  py = ny;
               }
          switch (db)   /* connect to step 0 */
             {
                case 4: line(ll400, sx, sy, nx, ny, col); break;
                case 6: line(ll600, sx, sy, nx, ny, col); break;
                case 7: line(ll700, sx, sy, nx, ny, col); break;
             }
      }
}
void lift_editor(int lift)
{
   extern BITMAP *l400;
   extern BITMAP *l600;
   extern BITMAP *l700;
   extern BITMAP *ll400;
   extern BITMAP *ll600;
   extern BITMAP *ll700;
   extern int edit_int_retval;
   int b, c, d, e, f;
   int tx = (SCREEN_H/100)*100+2;
   int ty = 40;
   int sb = 13; /* step 0 button */
   int mb;
   extern int txc;
   int current_step = 0;
   int step = 0;
   int step_pointer=0;
   int step_color;
   int old_step=99;

   extern int txc;
   extern int db;
   extern int tw;   /* button width */
   extern int bts;  /* button spacing */
   int z; /* temp for sliders */

   int xa = txc-tw;
   int xb = txc+tw;
   int a=0;
   int obt = 4;    /* lifts */
   int type = 0;
   int x, y, x1, y1;
  
   int jh;
   int quit = 0;
   int redraw = 1;

   xa = 4+SCREEN_W-(SCREEN_W-(db*100));
   xb = SCREEN_W-4;

   bts=20;

   current_lift = lift; /* set global value to passed value */

   ll400 = create_bitmap(400,400);
   ll600 = create_bitmap(600,600);
   ll700 = create_bitmap(700,700);

   do {

        if (redraw)
           {
              old_step = 99; /* to make sure steps redraw */
              redraw = 0;
              show_mouse(NULL);

              title_obj(4, NULL, lift);

              draw_big_no_lifts();
              fill_ll();

              /* draw map */
              if (db==4)
                 {
                    blit(l400, screen, 0, 0, 0, 0, 400, 400);
                    draw_sprite(screen, ll400, 0, 0);
                 }
              if (db==6)
                 {
                    blit(l600, screen, 0, 0, 0, 0, 600, 600);
                    draw_sprite(screen, ll600, 0, 0);
                 }
              if (db==7)
                 {
                    blit(l700, screen, 0, 0, 0, 0, 700, 700);
                    draw_sprite(screen, ll700, 0, 0);
                 }


              /* outline map  */
              rect(screen, 0, 0, 100*db-1, 100*db-1, 13);
              /* outline screen */
              rect(screen, 0, 0,  SCREEN_W-1, 100*db-1, 13);

              /* set up all lifts */
              lift_setup();

              /* set current step in current lift */
              set_lift(current_lift, current_step);

              /* draw lifts on map*/
              fast_draw_lifts();

              /* draw current lift on menu */
              if (1)
                 {
                    int a, b, c, d;
                    int x1 = tx+20;
                    int x2 = x1 + (lifts[current_lift] -> width * 20) -1;
                    int y1 = ty+160+lifts[current_lift] -> num_steps*12; /* only see in 2 highest screen modes */

                    int y2 = y1 + (lifts[current_lift] -> height * 20) -1;
                    int color = lifts[current_lift] -> color;
                    for (a=0; a<10; a++)
                       rect(screen, x1+a, y1+a, x2-a, y2-a, color + ((9 - a)*16) );
                    rectfill(screen, x1+a, y1+a, x2-a, y2-a, color );

                    text_mode(-1);
                    textout_centre(screen, font, lifts[current_lift] -> lift_name, ((x1+x2)/2), ((y1+y2)/2)-2, color+128+32);
                    text_mode(0);

                 }
            } /* end of if redraw */

        if (old_step != step_pointer) /* redraw steps */
           {
               old_step = step_pointer;
               draw_steps(step_pointer, step_color);
           }

         if (edit_int_slider(xb-40, ty-26, xb, ty-20, 26, 0, type, obt, 0,15,0,10,0,0,0,0)) redraw =1; /* button height */
         if (edit_int_slider(xa, ty+((a+3)*bts), xb, ty+((a+4)*bts)-2, 43, current_lift, type, obt, 0,12,15,11,0,0,0,0)) redraw = 1; /* lift width */
         if (edit_int_slider(xa, ty+((a+4)*bts), xb, ty+((a+5)*bts)-2, 44, current_lift, type, obt, 0,12,15,11,0,0,0,0)) redraw = 1;  /* lift height */

         z = lifts[current_lift] -> color;
         color_selector(xa, ty+((a+5)*bts), xb, ty+((a+6)*bts)-2, 4, current_lift, type, obt, 0,15,13,14,0,0,0,0); /* lift color */
         if (lifts[current_lift] -> color != z) redraw = 1;

         if (new_button(xa, ty+((a+1)*bts), txc-50, ty+((a+2)*bts)-2, 22,    0, type, obt, 0,  13, 13,  0,   0,0,0,0))   /* next */
            {
               while (mouse_b & 1); /* wait for release */
               if (++current_lift > num_lifts-1)
                  current_lift = num_lifts-1;
               redraw = 1;
            }
         if (new_button(txc+10, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 23,    0, type, obt, 0,  13, 13,  0,   0,0,0,0))  /* prev */
            {
               while (mouse_b & 1); /* wait for release */
               if (--current_lift < 0)
                  current_lift++;
               redraw = 1;
            }
         if (new_button(txc-36, ty+((a+2)*bts), txc+26, ty+((a+3)*bts)-2, 21, 0, type, obt, 0,10,10,0,0,0,0,0))  /* delete */
            {
               while (mouse_b & 1); /* wait for release */
               erase_lift(current_lift);
               if (current_lift > num_lifts-1)
                  current_lift = num_lifts-1;
               if (current_lift < 0)
                  {
                     current_lift = 0;
                     quit = 1;
                  }
               redraw = 1;
            }
         if (new_button(txc+30, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 20, 0, type, obt, 0,3,9,0,0,0,0,0))   /* create new */
            {
               while (mouse_b & 1); /* wait for release */
               create_lift();
               redraw = 1;
            }
         if (new_button(txc-46, ty+((a+1)*bts), txc+6, ty+((a+2)*bts)-2, 25, 0, type, obt, 0,  12, 8,  0,   0,0,0,0))  /* help */
            {
               while (mouse_b & 1); /* wait for release */
               help("Lift Viewer");
               redraw = 1;
            }
         if (new_button(xa, ty+((a+6)*bts), xb, ty+((a+7)*bts)-2, 29, current_lift, type, obt, 0,  12, 15,  0,   0,0,0,0))  /* new name */
            {
               while (mouse_b & 1); /* wait for release */

               strcpy(fst, lifts[current_lift] -> lift_name);
               if (popup_dialog(edit_text_line, 2) == 3)
                  {
                     /* reallocate space for string */
                     free(lifts[current_lift] -> lift_name);
                     lifts[current_lift] -> lift_name = (char*) malloc(strlen(lifts[current_lift] -> lift_name)+1);
                     strcpy(lifts[current_lift] -> lift_name, fst);
                  }
               clear_keybuf();
               redraw = 1;
            }
          if (new_button(xa, ty+((a+2)*bts), txc-40, ty+((a+3)*bts)-2, 28, current_lift, type, obt, 0,3,9,0,0,0,0,0))  /* run lifts */
            {
               while (mouse_b & 1); /* wait for release */
               if (1)
                  {
                     int rquit = 0;
                     int old_step;
      
                     /* temp screen background */
                     BITMAP *sb;
                     sb = create_bitmap(SCREEN_W, SCREEN_H);
                     clear(sb);
                     if (db==4) blit(l400, sb, 0, 0, 0, 0, 400, 400);
                     if (db==6) blit(l600, sb, 0, 0, 0, 0, 600, 600);
                     if (db==7) blit(l700, sb, 0, 0, 0, 0, 700, 700);
                     if (db==4) draw_sprite(sb, ll400, 0, 0);
                     if (db==6) draw_sprite(sb, ll600, 0, 0);
                     if (db==7) draw_sprite(sb, ll700, 0, 0);
      
                     lift_setup();
                     set_lift(current_lift, current_step);
                     lifts[current_lift] -> current_step = current_step; /* put current step in current lift */
                     while (!rquit)
                        {
                           if ((key[KEY_ESC]) || (mouse_b & 2)) rquit = 1;
                           blit(sb, screen, 0, 0, 0, 0, db*100, db*100);
                           fast_draw_lifts();
                           rest(20); move_lifts(2);
      
                           if (old_step != lifts[current_lift] -> current_step)   /* outline current step */
                              {
                                 old_step = lifts[current_lift] -> current_step;
                                 draw_steps(old_step, 14);
                              }
                        }
                     while (key[KEY_ESC]); /* wait for release */
                     while (mouse_b & 2);  /* wait for release */
      
                     /* set to previous step */
                     current_step = lifts[current_lift] -> current_step-1;
                     if (current_step < 0) current_step = 0;
      
                     destroy_bitmap(sb);
                  }
               redraw = 1;
            }

         show_mouse(screen);
         rest(20);
         show_mouse(NULL);

         /* mouse x on buttons */
         if ((mouse_x > txc-95) && (mouse_x < txc+95))
            {
               /* calculate step */
               int step = (mouse_y - ty) / 12 - sb;
               /* is step valid */
               if ((step >= 0) && (step < lifts[current_lift]->num_steps))
                  {
                     step_pointer = step;
                     step_color = 12;

                     if (mouse_b & 1)
                        {
                           redraw = 1;
                           if ((mouse_x > txc+50) && (mouse_x < SCREEN_W-10))
                              {
                                 switch (lift_steps[current_lift][step] -> type ) /* step type */
                                    {
                                       case 1: /* edit speed */
                                               if (edit_int(txc+48, 2+ty+(sb+step)*12, lift_steps[current_lift][step] -> val, 1, 1, 29))
                                                  lift_steps[current_lift][step] -> val = edit_int_retval;
                                       break;
                                       case 2: /* edit wait */
                                               if (edit_int(txc+48, 2+ty+(sb+step)*12, lift_steps[current_lift][step] -> val, 10, 10, 2000))
                                                  lift_steps[current_lift][step] -> val = edit_int_retval;
                                       break;
                                       case 3: /* edit prox */
                                               if (edit_int(txc+48, 2+ty+(sb+step)*12, lift_steps[current_lift][step] -> val, 10, 20, 200))
                                                  lift_steps[current_lift][step] -> val = edit_int_retval;
                                       break;
                                    }
                              }
                           else
                              {
                                 while  (mouse_b & 1);
                                 current_step = step;
                              }
                        } /* end of if mouse_b & 1 */
                     if (mouse_b & 2) /* button pop up menu */
                        {
                           extern char global_string[20][25][80]; /* menu.c */
                           int ytype = lift_steps[current_lift][step] -> type;
                           int x, y, msel;

                           int mx = mouse_x;
                           int my = mouse_y;
                           if (mx > SCREEN_W-100) mx = SCREEN_W-100;

                           if (my > SCREEN_W-100) mx = SCREEN_W-100;


                           /* set menu */
                           sprintf(global_string[6][4],"Delete Step %d", step);
                           sprintf(global_string[6][5],"Insert Step %d", step);
                           if (ytype == 1) /* only move step type 1 */
                               sprintf(global_string[6][3],"Move Step %d", step);
                            else
                               sprintf(global_string[6][3],"             ");

                           /* blank and frame for menu */
                           rectfill(screen, mx-80, my-40, mx+80, my+60, 0);
                           rect(screen, mx-80, my-40, mx+80, my+60, 13);

                           msel = pmenu(6); /* call the pop up menu */
                           redraw = 1;
                           switch (msel)
                              {
                                 case 3: /* move step location */
                                      if ((ytype == 1) && (getxy("Set new location", 4,  NULL, step) == 1))
                                           {
                                              extern int get100_x;
                                              extern int get100_y;
                                              lift_steps[current_lift][step] -> x = get100_x*20;
                                              lift_steps[current_lift][step] -> y = get100_y*20;
                                           }
                                 break;
                                 case 4: /* delete step */
                                        for (x=step; x<lifts[current_lift]->num_steps; x++)   /* slide all down */
                                           {
                                              lift_steps[current_lift][x] -> x    = lift_steps[current_lift][x+1] -> x ;
                                              lift_steps[current_lift][x] -> y    = lift_steps[current_lift][x+1] -> y ;
                                              lift_steps[current_lift][x] -> val  = lift_steps[current_lift][x+1] -> val ;
                                              lift_steps[current_lift][x] -> type = lift_steps[current_lift][x+1] -> type ;
                                           }
                                        destroy_lift_step(current_lift, lifts[current_lift]->num_steps);
                                        lifts[current_lift] -> num_steps--;
                                        if (--current_step < 0) current_step = 0;
                                 break;
                                 case 5: /* insert step */
                                        construct_lift_step(current_lift, ++lifts[current_lift]->num_steps, 0,0,0,0);
                                        for (x=lifts[current_lift]->num_steps; x>=step; x--)
                                           {
                                              lift_steps[current_lift][x+1] -> x    = lift_steps[current_lift][x] -> x ;
                                              lift_steps[current_lift][x+1] -> y    = lift_steps[current_lift][x] -> y ;
                                              lift_steps[current_lift][x+1] -> val  = lift_steps[current_lift][x] -> val ;
                                              lift_steps[current_lift][x+1] -> type = lift_steps[current_lift][x] -> type ;
                                           }
                                        /* get the new step */
                                       get_new_lift_step(step);
                                 break;
                              }  /* end of switch (msel) */
                        }
                  }  /* end of valid step */
            }
         else /* not on buttons at all*/
            {
                     if (step_color != 10) old_step = 99;
                     step_pointer = current_step;
                     step_color = 10;
            }
       if  ( (key[KEY_ESC]) || (mouse_b & 2)) quit = 1;
    } while (!quit);
  lift_setup();
  draw_big();
  destroy_bitmap(ll400);
  destroy_bitmap(ll600);
  destroy_bitmap(ll700);

}





