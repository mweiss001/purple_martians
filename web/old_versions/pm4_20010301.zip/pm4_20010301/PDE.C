#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"

int load_PDE()
{
   FILE *filepntr;
   extern int PDEi[100][32];
   extern float PDEf[100][16];
   extern char PDEt[100][20][40];
   int PDE_load_error;
   int loop, ch, c, x, y;
   char buff[80], msg[80];

   textout_centre(screen, font, "loading PDE...", SCREEN_W/2, 176, 10);

   PDE_load_error = 0;
   if (!exists("PDE.PM"))
      {
         textout(screen, font, "Can't find PDE.PM", 0, 160, 10);
         PDE_load_error = 2;
      }

   if (!PDE_load_error) /* file exists */
      if ((filepntr=fopen("PDE.PM","r")) == NULL)
         {
            textout(screen, font, "Error opening PDE.PM", 0, 160, 10);
            PDE_load_error = 3;
         }
   if (!PDE_load_error) /* file exists and is open! */
      {
         for (c=0; c<100; c++) /* read PDE enemy floats */
            for (x=0; x<16; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        buff[loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  PDEf[c][x] = atof(buff);
                  if (ch == EOF)
                     {
                        textout(screen, font, "Error reading floats in PDE", 0, 176, 10);
                        rest(3000);
                        PDE_load_error = 4;
                     }
               }

         for (c=0; c < 100; c++)  /* enemy ints */
            for (x=0; x<32; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        buff[loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  PDEi[c][x] = atoi(buff);
                  if (ch == EOF)
                     {
                        textout(screen, font, "Error reading ints in PDE", 0, 176, 10);
                        rest(3000);
                        PDE_load_error = 5;
                     }
               }


         for (c=0; c < 100; c++)  /* enemy text */
            for (x=0; x<20; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        PDEt[c][x][loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  PDEt[c][x][loop] = NULL;
                  if (ch == EOF)
                     {
                        sprintf(msg,"Error reading text at %d %d %d in PDE", loop, c, x);
                        textout(screen, font, msg, 0, 176, 10);
                        rest(3000);
                        PDE_load_error = 6;
                     }
               }

         fclose(filepntr);

      }
   if  (PDE_load_error)
      {

         sprintf(msg,"Error %d", PDE_load_error);
         textout(screen, font, msg, 0, 200, 10);

         rest(2000);
         return 0;
      }
   else return 1;
}


#ifdef MV /* used by PDE only as far as I know */

int bottom_menu(int menu_num)
   /* this is a pass through once funtion and should be called in a loop */
{
   extern char global_string[20][25][80];
   char msg[80];
   int selection, c, d;
   show_mouse(screen);
   rest(5);
   show_mouse(NULL);
   if (mouse_y > 186) selection = (mouse_x / 40);   /* highlight only */
   for (c=0; c <= 7; c++)
      {
         if (c == selection) d = 9; else d = 9+64;
         sprintf(msg," F%-1d  ",c+1);
         textout(screen, font, msg,                   c*40, 184, d);
         textout(screen, font, global_string[menu_num][c], c*40, 192, d);
      }
   selection = 999; /* normal return --  nothing happened */
   if ((mouse_b & 1) && (mouse_y > 186))
      {
         selection = (mouse_x / 40);
         while (mouse_b & 1);   /* wait for release */
      }


   if (selection == 7) selection = -1;
   if (key[KEY_F1])
      {
         while (key[KEY_F1]);
         selection = 0;
      }
   if (key[KEY_F2])
      {
         while (key[KEY_F2]);
         selection = 1;
      }
   if (key[KEY_F3])
      {
         while (key[KEY_F3]);
         selection = 2;
      }
   if (key[KEY_F4])
      {
         while (key[KEY_F4]);
         selection = 3;
      }
   if (key[KEY_F5])
      {
         while (key[KEY_F5]);
         selection = 4;
      }
   if (key[KEY_F6])
      {
         while (key[KEY_F6]);
         selection = 5;
      }
   if (key[KEY_F7])
      {
         while (key[KEY_F7]);
         selection = 6;
      }
   if (key[KEY_F8])
      {
         while (key[KEY_F8]);
         selection = -1;
      }
   if (key[KEY_ESC])
      {
         while (key[KEY_ESC]);
         selection = -1;
      }
   if ((mouse_b & 2) && (mouse_y > 160))
      {
         selection = -1;
         while (mouse_b & 2); /* wait for release */
      }
   return selection;
}
void save_PDE()
{
   FILE *filepntr;
   extern char PDEt[100][20][40];
   extern int PDEi[100][32];
   extern float PDEf[100][16];
   char msg[80];
   int c, x;
   filepntr = fopen("PDE.PM","w");
   for (c=0; c < 100; c++)  /* enemy float */
      for (x=0; x<16; x++)
         fprintf(filepntr,"%f\n",PDEf[c][x]);

   for (c=0; c < 100; c++) /* enemy int */
      for (x=0; x<32; x++)
         fprintf(filepntr,"%d\n",PDEi[c][x]);

   for (c=0; c < 100; c++) /* enemy text */
      for (x=0; x<20; x++)
         fprintf(filepntr,"%s\n",PDEt[c][x]);

      fclose(filepntr);
}
void predefined_enemies(void)
{
   extern int PDEi[100][32];
   extern float PDEf[100][16];
   extern char PDEt[100][20][40];
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern int zz[20][NUM_ANS];
   extern float finitial, fxinc, fyinc, flv, fuv, edit_float_retval;
   extern int edit_int_retval;

if (load_PDE())
   {
      int x,y,z, EN = 0, redraw = 1, menu_sel;
      char msg[80], temp_string[80];
      clear_keybuf();

      do
         {
            show_mouse(screen);
            rest(10);
            show_mouse(NULL);
            menu_sel = (bottom_menu(5));   /* call the menu handler */

            if (redraw)
               {
                  int a,b=0;
                  int rt = PDEi[EN][0];
                  redraw = 0;
                  clear(screen);

                  a = PDEi[EN][1]; /* bmp or ans */
                  if (a < NUM_SPRITES) b = a; /* bmp */
                  if (a > 999) b = zz[5][a-1000]; /* ans */

                  blit(memory_bitmap[b], screen, 0,0,0,0,20,20);

                  if (rt < 99)
                     {
                        sprintf(msg, "Predefined Enemy %d", EN);
                        textout(screen, font, msg, 40, 0, 240);


                        for (x=0; x<16; x++) /* three columns */
                           {
                              sprintf(msg, "Ef%-1d %f", x, PDEf[EN][x]);
                              textout(screen, font, msg, 256, 20+(x*8), 240);
                        
                              sprintf(msg, "Ei%-1d %d", x, PDEi[EN][x]);
                              textout(screen, font, msg, 400, 20+(x*8), 240);

                              sprintf(msg, "Ei%-1d %d", x+16, PDEi[EN][x+16]);
                              textout(screen, font, msg, 500, 20+(x*8), 240);
                            }
                       for (x=0; x<20; x++)
                           textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);

                     }
                  if ((rt > 99) && (rt < 200))
                     {
                        sprintf(msg, "Predefined Object %d", EN);
                        textout(screen, font, msg, 40, 0, 240);
                        for (x=0; x<10; x++)
                           {
                              textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);
                              textout(screen, font, PDEt[EN][x+10], 0, 100+(x*8), 240);
                           }
                        for (x=0; x<16; x++)
                           {
                              sprintf(msg, "I%-2d %d", x, PDEi[EN][x]);
                              textout(screen, font, msg, 400, 20+(x*8), 240);
                           }
                     }
                  if (rt > 199)
                     {
                        sprintf(msg, "Creator %d", EN);
                        textout(screen, font, msg, 40, 0, 240);


                       for (x=0; x<16; x++) /* three columns */
                           {
                              sprintf(msg, "Ef%-1d %f", x, PDEf[EN][x]);
                              textout(screen, font, msg, 256, 20+(x*8), 240);
                        
                              sprintf(msg, "Ei%-1d %d", x, PDEi[EN][x]);
                              textout(screen, font, msg, 400, 20+(x*8), 240);

                              sprintf(msg, "Ei%-1d %d", x+16, PDEi[EN][x+16]);
                              textout(screen, font, msg, 500, 20+(x*8), 240);
                            }

                        for (x=0; x<10; x++)
                           {
                              textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);
                              textout(screen, font, PDEt[EN][x+10], 0, 100+(x*8), 240);
                           }
                     }
               }
            if ((mouse_b & 1) && (mouse_x < 240) && (mouse_y > 20) && (mouse_y < 180))
               {    /* edit text */
                  int k, tx = 0, ty = 0;
                  int line_length = 30;
                  ty = (mouse_y-20)/8;
                  tx = mouse_x/8;
                  redraw = 1;
                  do
                     {

                        show_mouse(screen);
                        rest(10);
                        show_mouse(NULL);
                         if (redraw)
                           for (x=0; x<20; x++)
                              {
                                 redraw = 0;
                                 textout(screen, font, "                               ", 0, 20+(x*8), 240); /* 31 spaces */
                                 textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);
                              }
                        msg[0] = PDEt[EN][ty][tx];
                        if (msg[0] == NULL) msg[0] = 32;
                        msg[1] = NULL;
                        text_mode(1);
                        textout(screen, font, msg, (tx*8), 20+(ty*8), 240);
                        text_mode(0);

                        if (keypressed()) /* don't wait for keypress */
                           {
                              k = readkey();
                              redraw = 1;

                           }
                        else k = 0;
                 
                        k = (k & 0xFF);  /* strip upper bits */
                        if ((k>31) && (k<128))   /* if alphanumeric */
                           {
                              z = strlen(PDEt[EN][ty]);
                              if (z > line_length) z = line_length;
                              for (x=z; x>tx; x--)
                                 PDEt[EN][ty][x] = PDEt[EN][ty][x-1];

                              PDEt[EN][ty][tx] = k;
                              if (++tx > line_length) /* end of line? */
                                 {
                                    PDEt[EN][ty][tx] = NULL; /* terminate the line */
                                    ty++;  /* LF */
                                    tx = 0; /* CR */
                                 }
                           }
                        if (key[KEY_BACKSPACE])
                           {
                              if (--tx<0) tx = 0;
                              z = strlen(PDEt[EN][ty]);
                              for (x=tx; x<z; x++)
                                 PDEt[EN][ty][x] = PDEt[EN][ty][x+1];
                           }
                        if (key[KEY_ENTER])
                           {


                              for (y=19; y>ty; y--)  /* slide all down */
                                 {
                                    strcpy(PDEt[EN][y],PDEt[EN][y-1]);
                                 }
                              if (strlen(PDEt[EN][ty]) == 999) /* cursor past end of line */
                                 {
                                    PDEt[EN][ty+1][0] = NULL; /* next line empty */
                                 }
                              if (strlen(PDEt[EN][ty]) >= tx) /* cursor not past end of line */
                                 {
                                    for (x=0; x <= 30-tx; x++)         /* split line at tx */
                                        PDEt[EN][ty+1][x] = PDEt[EN][ty+1][tx+x];

                                    PDEt[EN][ty][tx] = NULL;  /* terminate top line */
                                    tx = 0;
                                    ty++;
                                 }


                           }
                        if (key[KEY_DEL])
                           {
                              if (PDEt[EN][ty][tx] == NULL)
                                 {

                                    for (x=0; x<=30-tx; x++) /* get portion from line below */
                                        PDEt[EN][ty][tx+x] = PDEt[EN][ty+1][x];

                                    for (y=ty+1; y<19; y++)  /* slide all up */
                                       strcpy(PDEt[EN][y],PDEt[EN][y+1]);

                                    PDEt[EN][19][0] = NULL; /* last line empty */

                                 }
                              else
                                 {
                                    z = strlen(PDEt[EN][ty]);
                                    for (x=tx; x<z; x++)
                                       PDEt[EN][ty][x] = PDEt[EN][ty][x+1];
                                 }
                           }
       
                        if (key[KEY_RIGHT])  if (++tx > line_length-1) tx = line_length-1;
                        if (key[KEY_LEFT]) if (--tx < 0) tx = 0;
                        if (key[KEY_UP]) if (--ty < 0) ty = 0;
                        if (key[KEY_DOWN]) if (++ty > 19) ty = 19;
                        if ((mouse_b & 1) && (mouse_x < 250) && (mouse_y > 20) && (mouse_y < 180))
                           {
                              redraw = 1;
                              ty = (mouse_y-20)/8;
                              tx = mouse_x/8;
                           }
                     
                        if (tx > strlen(PDEt[EN][ty])) tx = strlen(PDEt[EN][ty]);


                        clear_keybuf();
                     } while ((k != 27) && (!(mouse_b & 2)) );
                  clear_keybuf();
                  redraw = 1;

               }
            if (key[KEY_PGDN])
               {
                  EN -=10;
                  if (EN < 0) EN = 0;
                  clear_keybuf();

                  redraw =1;
               }
            if ((key[KEY_CONTROL]) && (key[KEY_DEL]))
               { /* DELETE PD */
                  while ((key[KEY_CONTROL]) && (key[KEY_DEL]));
                  for (x=0; x<10; x++)
                     {
                        PDEi[EN][x] = 0;
                        PDEf[EN][x] = 0;
                        strcpy(PDEt[EN][x]," ");
                        strcpy(PDEt[EN][x+10]," ");
                     }
                     redraw =1;
               }
            if ((key[KEY_CONTROL]) && (key[KEY_S]))
               { /* sort */
                  int swap_flag = 1;
                  int do_swap = 0;
                  int st1, st2;
                  redraw = 1;

                  while (swap_flag)
                     {
                        do_swap = 0;
                        swap_flag = 0;
                        for (x=0;x<99;x++)
                           {
                              while (key[KEY_P]);
                              if (key[KEY_Q])
                                 {
                                    swap_flag = 0;
                                    break;

                                 }
                              sprintf(msg, "x=%d sf=%d st1=%d st2=%d", x, swap_flag, st1, st2);
                              textout(screen, font, msg , 100, 120, 10);

                              if ( PDEi[x][0] > 199)   /* creator */
                                 if (strncmp(PDEt[x][1], PDEt[x+1][1], strlen(PDEt[x][1])) > 0)
                                       do_swap = 1; /* sort by text line 1 */

                              if ( PDEi[x][0] < 200) /* item and enemy  */
                                 {
                                    if ( PDEi[x][0] < PDEi[x+1][0] ) do_swap = 1;  /* sort by type */
                                    if ( PDEi[x][0] == PDEi[x+1][0] ) /* secondary sort by text line 1 */
                                       if (strncmp(PDEt[x][1], PDEt[x+1][1], strlen(PDEt[x][1]) ) > 0)
                                          do_swap = 1;
                                 }
                             if (do_swap) /* do the swap */
                                {
                                    swap_flag++; /* if any swaps */
                                    st1 = PDEi[x][0];
                                    st2 = PDEi[x+1][0];


                                    do_swap = 0;
                                    for (y=0; y<32; y++)
                                       {
                                          int temp;

                                          temp = PDEi[x][y];
                                          PDEi[x][y] = PDEi[x+1][y];
                                          PDEi[x+1][y] = temp;

                                       }
                                    for (y=0; y<16; y++)
                                       {
                                          float temp;

                                          temp = PDEf[x][y];
                                          PDEf[x][y] = PDEf[x+1][y];
                                          PDEf[x+1][y] = temp;

                                       }
                                    for (y=0; y<10; y++)
                                       {
                                          char stemp[80];

                                          strcpy(stemp,PDEt[x][y] );
                                          strcpy(PDEt[x][y],PDEt[x+1][y] );
                                          strcpy(PDEt[x+1][y], stemp);

                                          strcpy(stemp,PDEt[x][y+10] );
                                          strcpy(PDEt[x][y+10],PDEt[x+1][y+10] );
                                          strcpy(PDEt[x+1][y+10], stemp);

                                       }
                                 } /* end of swap */
                            } /* end of for x */
                     } /* end of while swap flag */
               }

           if (key[KEY_PGUP])
               {
                  EN +=10;
                  if (EN > 99) EN = 99;
                  clear_keybuf();

                  redraw =1;
               }
            if ((key[KEY_RIGHT]) || (menu_sel == 2))
               {
                  if (++EN > 99) EN = 99;
                  clear_keybuf();
                  while (mouse_b & 1); /* wait for release */
                  redraw =1;
               }
            if ((key[KEY_LEFT]) || (menu_sel == 1))
               {
                  if (--EN < 0) EN = 0;
                  clear_keybuf();
                  while (mouse_b & 1); /* wait for release */
                  redraw =1;
               }
            if (menu_sel == 4)  /* copy to new location */
               {
                  int new_EN = EN + 1;
                  int menu_exit = 0;
                  clear(screen);
                  while (!menu_exit)
                     {
                        show_mouse(screen);
                        rest(5);
                        show_mouse(NULL);

                        textout(screen, font, "COPY THIS PD TO A NEW PD ",100, 80, 10);
                        textout(screen, font, "WARNING! ERASES DESTINATION",100, 90, 10);
                        sprintf(msg, "SOURCE:PD#%d  ", EN);
                        textout(screen, font, msg    , 100, 110, 10);
                        sprintf(msg, "TARGET:PD#%d  ",new_EN);
                        textout(screen, font, msg    , 100, 120, 10);

                        textout(screen, font, "YES |  NO",100, 130, 10);

                        if ((mouse_b & 2) || (key[KEY_ESC]))
                           menu_exit=1;

                        if (mouse_b & 1)
                           {
                              if ((mouse_y > 129) && (mouse_y < 138) && (mouse_x < 134))
                                 {  /* yes pressed */
                                    for (x=0; x<20; x++)
                                       strcpy(PDEt[new_EN][x],PDEt[EN][x] );
                                    for (x=0; x<32; x++)
                                       PDEi[new_EN][x] = PDEi[EN][x];
                                    for (x=0; x<16; x++)
                                      PDEf[new_EN][x] = PDEf[EN][x];
                                    menu_exit=1;
                                    redraw =1;
                                 }
                              if ((mouse_y > 119) && (mouse_y < 128) && (mouse_x > 134))
                                 if (edit_int(180, 120, new_EN, 1, 0, 99)) new_EN = edit_int_retval;                                    redraw=1;
                           }
                     }
               }
            if (menu_sel == 5)
               {
                  save_PDE();
                  clear_keybuf();
                  redraw =1;
               }
         /* edit variables */
            if ((mouse_y > 20) && (mouse_y < 340) && (mouse_b & 1))
               {
                  int tab = 0;
                  y = (mouse_y-20)/8;
                  if (y>9) tab = 8;
                  redraw=1;
                  if ((mouse_x > 400) && (mouse_x < 500))
                     if (edit_int(432 + tab, 20+(y*8), PDEi[EN][y], 1, -1, 20000)) PDEi[EN][y] = edit_int_retval;
                  if ((mouse_x > 500) && (mouse_x < 600))
                     if (edit_int(540, 20+(y*8), PDEi[EN][y+16], 1, -1, 20000)) PDEi[EN][y+16] = edit_int_retval;
                  if ((mouse_x > 256) && (mouse_x < 400))
                     {  /* edit float */
                        fxinc=.01;  /* y inc */
                        fyinc=.1;   /* x inc */
                        flv=-2000;  /* lv    */
                        fuv=2000;   /* uv    */
                        finitial = PDEf[EN][y];
                        if (edit_float(288+tab, 20+(y*8))) PDEf[EN][y] = edit_float_retval;
                     }
               }

         } while (!(key[KEY_ESC]) && (menu_sel != -1));

   } /* end of if load succesfull */

}

#endif
