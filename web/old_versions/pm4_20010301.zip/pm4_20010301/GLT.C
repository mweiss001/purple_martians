#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"

#ifdef MV

global_level()
{


   int le[200]; /* level exists array */

   int blt[512];

   int num_levs = 0;
   char msg[80];
   char fn[20] = "levels/level000.PML";
   int a, b, c, d, x, y, z;
   show_mouse(NULL);
   clear(screen);

   for (x=0; x<100; x++) /* clear array */
      le[x] = 0;


   /* clear block list */
   for (z=0; z<512; z++)
      blt[z] = 0;


   for (x=60; x<200; x++) /* look in first 100 levels */
      {
         int h, d, u, rem = x;

         h = rem/100;
         fn[12] = 48+h;
         rem -=h*100;

         d = rem/10;
         fn[13] = 48 + d;
         rem -=d*10;

         fn[14] = 48 + rem;

         if (exists(fn)) /* does file exist? */
            le[num_levs++] = x; /* put in array */
      }

   for (x=0; x<num_levs; x++) /* cycle existing levels */
      {
         extern int l[100][100];
         extern int Ei[100][32];
         extern float Ef[100][16];
         extern int item[500][16];
         extern int level_header[20];
         int a, b, c, d;

         sprintf(msg, "lev:%d", le[x]);
         textout(screen, font, msg, 10, 10+x*8, 11);

         load_level(le[x], 0);

         /* do something here !!!!    */

         for (y=0; y<500; y++)
            if (item[y][0] == 99)
               item[y][0] = 0;


         for (y=0; y<100; y++)
            for (z=0; z<100; z++)
               {
                  blt[l[y][z]]++; /* inc block counter */

                  /* replace blocks here */
   /*               if (l[y][z] == 109) l[y][z] = 990;
                  if (l[y][z] == 76) l[y][z] = 657;
                  if (l[y][z] == 119) l[y][z] = 625;
                  if (l[y][z] == 135) l[y][z] = 592;
                  if (l[y][z] == 149) l[y][z] = 624;
                  if (l[y][z] == 74) l[y][z] = 656;
                  if (l[y][z] == 118) l[y][z] = 620;
                  if (l[y][z] == 147) l[y][z] = 621;
                  if (l[y][z] == 114) l[y][z] = 622;
                  if (l[y][z] == 146) l[y][z] = 623;

                  if (l[y][z] == 115) l[y][z] = 616;
                  if (l[y][z] == 140) l[y][z] = 584;
                  if (l[y][z] == 116) l[y][z] = 617;
                  if (l[y][z] == 137) l[y][z] = 585;
                  if (l[y][z] == 117) l[y][z] = 618;
                  if (l[y][z] == 141) l[y][z] = 586;
                  if (l[y][z] == 180) l[y][z] = 619;
                  if (l[y][z] == 138) l[y][z] = 587;
                  if (l[y][z] == 170) l[y][z] = 588;
                  if (l[y][z] == 203) l[y][z] = 589;
                  if (l[y][z] == 142) l[y][z] = 590;
                  if (l[y][z] == 202) l[y][z] = 591;


                  if (l[y][z] == 148) l[y][z] = 612;
                  if (l[y][z] == 181) l[y][z] = 614;
                  if (l[y][z] == 139) l[y][z] = 580;

                  if (l[y][z] == 136) l[y][z] = 582;
                  if (l[y][z] == 201) l[y][z] = 582;

                  if (l[y][z] == 73) l[y][z] = 644;
                  if (l[y][z] == 75) l[y][z] = 645;

                  if (l[y][z] == 171) l[y][z] = 576;
                  if (l[y][z] == 173) l[y][z] = 577;
                  if (l[y][z] == 172) l[y][z] = 578;
                  if (l[y][z] == 174) l[y][z] = 579;

                  if (l[y][z] == 150) l[y][z] = 608;
                  if (l[y][z] == 151) l[y][z] = 609;
                  if (l[y][z] == 182) l[y][z] = 610;
                  if (l[y][z] == 183) l[y][z] = 611;

                  if (l[y][z] == 41)  l[y][z] = 640;
                  if (l[y][z] == 43)  l[y][z] = 641;
                  if (l[y][z] == 105) l[y][z] = 642;
                  if (l[y][z] == 107) l[y][z] = 643;


                  if (l[y][z] == 32) l[y][z] = 128;
                  if (l[y][z] == 33) l[y][z] = 129;
                  if (l[y][z] == 34) l[y][z] = 130;
                  if (l[y][z] == 35) l[y][z] = 135;
                  if (l[y][z] == 36) l[y][z] = 136;
                  if (l[y][z] == 37) l[y][z] = 137;
                  if (l[y][z] == 38) l[y][z] = 160;
                  if (l[y][z] == 39) l[y][z] = 167;

                  if (l[y][z] == 48) l[y][z] = 138;
                  if (l[y][z] == 49) l[y][z] = 139;
                  if (l[y][z] == 50) l[y][z] = 140;
                  if (l[y][z] == 51) l[y][z] = 141;
                  if (l[y][z] == 52) l[y][z] = 142;
                  if (l[y][z] == 53) l[y][z] = 143;
                  if (l[y][z] == 54) l[y][z] = 160;

                  if (l[y][z] == 14) l[y][z] = 164;

                  if (l[y][z] == 8) l[y][z] = 32;
                  if (l[y][z] == 9) l[y][z] = 33;
                  if (l[y][z] == 10) l[y][z] = 34;
                  if (l[y][z] == 11) l[y][z] = 35;

                  if (l[y][z] == 16) l[y][z] = 64;

                  if (l[y][z] == 24) l[y][z] = 96;
                  if (l[y][z] == 25) l[y][z] = 97;
                  if (l[y][z] == 26) l[y][z] = 98;
                  if (l[y][z] == 30) l[y][z] = 99;
                  if (l[y][z] == 31) l[y][z] = 100;

              if (l[y][z] == 42) l[y][z] = 646;
              if (l[y][z] == 106) l[y][z] = 647;
                  */
               }

         for (y=0; y<100; y++)
            if (Ei[y][0])
               {
                  /* Ei[y][29] = Ei[y][9]; /* set cb in all */

                  if (Ei[y][0] == 9999)  /* set bonus */
                     {
                        Ei[y][24] = 3;
                        Ei[y][25] = 3;
                     }

                  if (Ei[y][0] == 9999)  /* erase enemy types here*/
                     {
                        for (z=0; z<32; z++)
                           Ei[y][z] = 0;
                        for (z=0; z<16; z++)
                           Ef[y][z] = 0;
                      }

               }

     /*    sort_enemy();  */

         save_level(le[x]-100);

         sprintf(msg, "lev:%d", le[x]);
         textout(screen, font, msg, 110, 10+x*8, 10);

      }
   /* show block list */

   /*

   y = 0;
   rectfill(screen, 200, 0, SCREEN_W-1, SCREEN_H-1, 0);

   for (z=0; z<512; z++)
      if (blt[z])
         {
            extern int sa[512][2];
            int col = 11;
            if (sa[z][0] != 1) col = 10;

            sprintf(msg, "sa%d   block# %d   count %d ",sa[z][0],  z, blt[z] );
            textout(screen, font, msg, 200, 10+y*8, col);
            y++;
          }
          tsw();

   */

}
#endif



