#include "pm.h"
/* sound.c */
/*
        0 - Player Shoots
        1 - "d'OH"
        2 - bonus
        3 - Fuse hiss
        4 - CFG MIDI la de da  door, key, exit
        5 - explosion noise
        6 - grunt 1
        7 - grunt 2
        8 - phew for enemy killed
*/

extern int sound_on;
extern SAMPLE *snd[20];
extern char global_string[20][25][80]; /* menu.c */


#ifdef SOUND

void load_sound() /* for normal loading of sound driver and samples */
{
   char msg[80];
   int num_sounds = 9;
   sprintf(msg, "Initializing Sound Card");
   textout_centre(screen, font, msg, SCREEN_W/2, SCREEN_H/2, 10);

   if (install_sound(DIGI_AUTODETECT, MIDI_NONE, NULL) == 0)
      {
         int x;
         sound_on = 1;
         set_config_int("GAMECONTROLS", "sound_on", sound_on);
         sprintf(global_string[8][7],"Sound:On");
         for (x=0; x<num_sounds; x++)
            {
               char fn[20] = "snd/snd00.wav";
               char *filename;
               if (x>9)

                  {
                     fn[3+4] = 49; /* 1 */
                     fn[4+4] = 48 + (x-10);
                  }
               else fn[4+4] = 48 + x;
               filename = fn;
               snd[x] = load_sample(filename);
            }
      }
   else
     {
        sound_on = 0;
        set_config_int("GAMECONTROLS", "sound_on", sound_on);
        sprintf(global_string[8][7],"Sound:Off");
        clear(screen);
        textout_centre(screen, font, "...Sound Card Not Found...", SCREEN_W/2, SCREEN_H*174/200, 10);
        rest(2000);
     }
}
void sound_setup()  /* to toggle sound configuration */
{
   if (sound_on)
      {
         remove_sound();
         sound_on = 0;
         set_config_int("GAMECONTROLS", "sound_on", sound_on);
         sprintf(global_string[8][7],"Sound:Off");
      }
   else
      {
         sound_on = 1;
         set_config_int("GAMECONTROLS", "sound_on", sound_on);
         sprintf(global_string[8][7],"Sound:On");
         load_sound();
      }
}
#endif
