/* New Enemy View */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"


extern int Ei[100][32];
extern float Ef[100][16];

char msg[80];

int create_item(int);

void draw_pmsg(int c, int x, int y)
{
   extern int item[500][16];
   extern char *pmsg[500];

   int len = strlen(pmsg[c]);
   char msg[80];
   char dt[20][80];
   int row = 0, col = 0;
   int longest_line_len = 1; /* default */
   int num_lines = 0;
   int xpos_c = x;
   int ypos = y;
   int xw;
   int a;
   int tc = item[c][8];
   int fc = item[c][9];
   int px, py, px2, py2;

   for (a=0; a<len+1; a++)
      {
          if (pmsg[c][a] == 13) /* line break */
            {
               row++;
               col=0;
               dt[row][col] = NULL; /* in case len = 0 */
            }
         else  /* regular char */
            {
               dt[row][col] = pmsg[c][a];
               if (col > longest_line_len) longest_line_len = col;
               col++;
               dt[row][col] = NULL;
            }
      }
   num_lines = row;

   xw = (longest_line_len+1)*4;
   px  = xpos_c-xw-2-8;
   py  = ypos-2-8;
   px2 = xpos_c+xw+8;
   py2 = ypos+(num_lines+1)*8+8;

   a = 7;  /* erase */
   rectfill(screen, px+a,py+a,px2-a,py2-a,0);

   for (a=0; a<8; a++) /* frame */
      rect(screen, px+a,py+a,px2-a,py2-a,fc+a*16);

   for (row=0; row<=num_lines; row++) /* text */
      textout_centre(screen, font, dt[row], xpos_c, ypos+row*8, tc);
}
void erase_item(int num)
{
   extern int item[500][16];
   extern char *pmsg[500];
   int x;
   if (item[num][0] == 10) free (pmsg[num]);
   for (x=0; x<16; x++)
      item[num][x] = 0;
}
int get_empty_item(int type) /* finds, sets, sorts refinds */
{
   extern int item[500][16];
   int mt = 0;
   char msg[80];
   while ((mt < 500) && (item[mt][0] != 0)) mt++;
   if (mt > 499) alert("Item lift full!", NULL, NULL,"OK", NULL, NULL, NULL);
   else
      {
         erase_item(mt);
         item[mt][0] = type; /* set type */
         item[mt][9] = 9999; /* mark to find after sort !! */
         item_sort();
         mt = 0;
         while ((mt < 500) && (item[mt][9] != 9999)) mt++;
         item[mt][9] = 0; /* remove mark */
      }
   return mt;
}
int get_empty_enemy(int type) /* type */
{
   extern int Ei[100][32];
   extern int e_num_of_type[50];   /* sort stuff used by others */
   extern int e_first_num[50];
   int en, d;

   /* cycle backwards to find first empty enemy */
   for (d=99; d>-1; d--)
      if (Ei[d][0] == 0) en = d;

   Ei[en][0] = type;
   sort_enemy();
   en = e_first_num[type]+e_num_of_type[type]-1;
   return en;
}
void recalc_pod(int num)
{
   extern int Ei[100][32];
   extern float Ef[100][16];
   float angle, xlen, ylen, xinc, yinc;
   int x1 = Ef[num][0];
   int y1 = Ef[num][1];
   int x2 = Ef[num][5];
   int y2 = Ef[num][6];

   xlen = abs(x1-x2);
   if (xlen == 0) xlen = .00001;
   ylen = abs(y1-y2);
   if (ylen == 0) ylen = .00001;
   angle = atan(ylen/xlen);

   xinc = cos(angle) * Ef[num][9];
   yinc = sin(angle) * Ef[num][9];

   /* set number of steps */
   if (xlen > ylen)
      {
         Ei[num][7] = xlen/xinc;
      }
   if (ylen >= xlen)
      {
         Ei[num][7] = ylen/yinc;
      }

   /* set xinc, yinc */
   if (x1 > x2) Ef[num][2] = -xinc;
   if (x1 == x2) Ef[num][2] = 0;
   if (x1 < x2) Ef[num][2] = +xinc;
   if (y1 > y2) Ef[num][3] = -yinc;
   if (y1 == y2) Ef[num][3] = 0;
   if (y1 < y2) Ef[num][3] = +yinc;
   Ei[num][20] = get_rot_from_xyinc(num);
   draw_big();
}
int move_trigger_box(int num)
{
   if (getbox("Get New Trigger Box") == 1)
      {
          extern int bx1, bx2, by1, by2;
          Ei[num][11] = bx1-1; /* why -1 ? */
          Ei[num][12] = by1-1;
          Ei[num][13] = bx2;
          Ei[num][14] = by2;
          return 1;
      }
   else return 0;
}
int move_pod_extended(int num)
{
   if (getxy("Set Extended Position", 3, 7, num) == 1)
      {
         extern int get100_x;
         extern int get100_y;
         Ef[num][5] = get100_x * 20;  /* set dest x,y */
         Ef[num][6] = get100_y * 20;
         recalc_pod(num);
         draw_big();
         return 1;
      }
   else return 0;
}

int sort_enemy(void)
{
   extern int e_num_of_type[50];   /* sort stuff used by others */
   extern int e_first_num[50];
   
   extern int Ei[100][32];
   extern float Ef[100][16];
   int swap_flag = 1;
   int do_swap = 0;
   int temp;
   float ftemp;
   int num_enem;
   int a, b, c, d, x, y, z;
   
   while (swap_flag)
      {
         do_swap = 0;
         swap_flag = 0;
         for (x=0;x<99;x++)
            {
               if ( Ei[x][0] < Ei[x+1][0] )
                  do_swap = 1;
               if (do_swap) /* do the swap */
                 {
                     swap_flag = 1;
                     do_swap = 0;
                     for (y=0; y<32; y++)
                        {
                           temp = Ei[x][y];
                           Ei[x][y] = Ei[x+1][y];
                           Ei[x+1][y] = temp;
                        }

                     for (y=0; y<16; y++)
                        {
                           ftemp = Ef[x][y];
                           Ef[x][y] = Ef[x+1][y];
                           Ef[x+1][y] = ftemp;
                         }
                 } /* end of swap */
            } /* end of for x */
      } /* end of while swap flag */


   /* get data about first 50 enem types and
      make sub lists of enem types using these variables */
   
   for (c=0; c<50; c++)   /* zero the counters */
      {
         e_num_of_type[c] = 0;
         e_first_num[c] = 0;
      }
   num_enem = 0;
   for (c=0; c<100; c++)  /* counts */
      {
         e_num_of_type[Ei[c][0]]++;   /* inc number of this type  */
         if (Ei[c][0]) ++num_enem;    /* inc total num */
       }

   for (c=0; c<50; c++)  /* get first nums */
      if (e_num_of_type[c] > 0)  /* are there any of this type?  */
         for (d=0; d<100; d++)
            if (Ei[d][0] == c)
               {
                  e_first_num[c] = d;
                  d=100;   /* exit loop */
                }
   return num_enem;
}
void create_cloner(void)
{
   extern int e_num_of_type[50];   /* sort stuff used by others */
   extern int e_first_num[50];
   extern float Ef[100][16];
   extern int Ei[100][32];
   extern int get100_x, get100_y;
   extern int bx1, by1, bx2, by2;
   char msg[80];
   int rx, ry, d, en;

   /* cycle backwards to find first empty */
   for (d=99; d>-1; d--)
      if (Ei[d][0] == 0) en = d;

   Ei[en][0] = 9;
   sort_enemy();
   en = e_first_num[9]+e_num_of_type[9]-1;

   if (getxy( "Set cloner location", 3, 9, en) == 1)
      {
         rx = get100_x;
         ry = get100_y;

         Ei[en][0] = 9;     /* type 9 - cloner */
         Ei[en][1] = 231;   /* shape !! */
         Ei[en][2] = 1;     /* draw type */

         Ei[en][5] = 1;     /* mode */

         Ei[en][24] = 25;     /* bonus */
         Ei[en][25] = 25;     /* bonus */

         Ei[en][6] = 1000;  /* default delay */
         Ei[en][7] = 1000;  /* default delay */
         Ef[en][12] = 1;  /* scale */
         Ef[en][0] = get100_x * 20;  /* ans x,y */
         Ef[en][1] = get100_y * 20;
         draw_big();
         show_big();

         if (getbox("Set source area"))
            {
               Ef[en][6] = bx1*20;
               Ef[en][7] = by1*20;
               Ef[en][2] = (bx2-bx1)*20;
               Ef[en][3] = (by2-by1)*20;

               if (getxy("Set destination area", 3, 9, en ) == 1)
                  {
                     Ef[en][8] = get100_x * 20;  /* dest x,y */
                     Ef[en][9] = get100_y * 20;

                     if (move_trigger_box(en)) sort_enemy();
                     else Ei[en][0] = 0;
                  }
               else Ei[en][0] = 0;
            }  /* end of get source area */
         else Ei[en][0] = 0;
      }  /* end of set cloner location */
   else Ei[en][0] = 0;
   set_wx(rx+4,ry);
   sort_enemy();
}
int create_pod(void)
{
   extern float Ef[100][16];
   extern int Ei[100][32];
   extern int get100_x, get100_y;
   char msg[80];
   int rx, ry;
   int en = get_empty_enemy(7); /* type */


   if (getxy("Set podzilla location", 3, 7, en) == 1)
      {
         rx = get100_x; ry = get100_y; /* used to set return window */
         Ef[en][0] = rx * 20;  /* set new x,y */
         Ef[en][1] = ry * 20;
         Ef[en][7] = 6;     /* bullet speed */
         Ei[en][1] = 374;   /* shape !! */
         Ei[en][2] = 0;     /* draw type */

         Ei[en][24] = 12;     /* bonus */
         Ei[en][25] = 12;     /* bonus */

         Ei[en][7] = 20;    /* default seq delay */
         Ei[en][9] = 20;    /* default delay */
         Ef[en][9] = 10;    /* default speed */
         Ef[en][12] = 1;    /* default scale */

         draw_big();
         show_big();

         if (move_pod_extended(en))
            {
               if (move_trigger_box(en) != 1)
                  Ei[en][0] = 0;
            }
         else Ei[en][0] = 0;

      }  /* end of set loc */
   else Ei[en][0] = 0;
   sort_enemy();
   set_wx(rx+4, ry);
   return Ei[en][0]; /* type if succesful, 0 if not */
}

int msg_text_editor(int msg)
{


}

void show_cursor(char *f, int cursor_pos, int cursor_color)
{
   char dt[20][80];
   int row=0, col=0;
   int cursor_row=0, cursor_col=0;
   int xpos_c = SCREEN_W/2;
   int ypos = 80;
   int a;

   /* get cursor row and column and fill dt */
   for (a=0; a<strlen(f)+1; a++)
      {
          if (a == cursor_pos)
             {
                cursor_row = row;
                cursor_col = col;
             }
          if (f[a] == 13) /* line break */
            {
               row++;
               col=0;
               dt[row][col] = NULL; /* in case len = 0 */
            }
         else  /* regular char */
            {
               dt[row][col] = f[a];
               col++;
               dt[row][col] = NULL;
            }
      }

   text_mode(-1);
   textout(screen, font, "_", cursor_col*8+xpos_c - strlen(dt[cursor_row])*4, ypos+cursor_row*8, cursor_color);
   text_mode(0);
}
void dpm(int c, char *f, int cursor_pos)
{
   extern int item[500][16];
   int len = strlen(f);
   char msg[80];
   char dt[20][80];
   int row = 0, col = 0;
   int longest_line_len = 1; /* default */
   int num_lines = 0;
   int xpos_c = SCREEN_W/2;
   int ypos = 80;
   int xw;
   int a;
   int tc = item[c][8];
   int fc = item[c][9];
   int px, py, px2, py2;

   for (a=0; a<len+1; a++)
      {
          if (f[a] == 13) /* line break */
            {
               row++;
               col=0;
               dt[row][col] = NULL; /* in case len = 0 */
            }
         else  /* regular char */
            {
               dt[row][col] = f[a];
               if (col > longest_line_len) longest_line_len = col;
               col++;
               dt[row][col] = NULL;
            }
      }
   num_lines = row;

   xw = (longest_line_len+1)*4;
   px  = xpos_c-xw-2-8;
   py  = ypos-2-8;
   px2 = xpos_c+xw+8;
   py2 = ypos+(num_lines+1)*8+8;

   a = 7;  /* erase */
   rectfill(screen, px+a,py+a,px2-a,py2-a,0);

   for (a=0; a<8; a++) /* frame */
      rect(screen, px+a,py+a,px2-a,py2-a,fc+a*16);

   for (row=0; row<=num_lines; row++) /* text */
      textout_centre(screen, font, dt[row], xpos_c, ypos+row*8, tc);
}
int create_pmsg(int c, int new_message)
{
   extern int item[500][16];
   extern char *pmsg[500]; /* for pop up messages */
   extern int edit_int_retval;
   int char_count;
   int cursor_pos=0;
   int old_cp=0;
   int blink_count = 40;
   int blink_counter = 0;
   int a, k;
   char f[200];
   int redraw = 1;
   int quit = 0;
   int my = 144; /* menu y */


   if (new_message)
      {
         f[0] = NULL;
         char_count = 0;
         item[c][8] = 14; /* default text color (yellow) */
         item[c][9] = 10; /* default frame color (red) */
      }
   else
      {
         strcpy(f, pmsg[c]);
         char_count = strlen(f);
      }
   while (!quit)
      {
         if (redraw)
            {
               redraw = 0;
               show_mouse(NULL);
               clear(screen);
               textout_centre(screen, font, "Pop Up Message Creator",SCREEN_W/2,0,9);
               textout_centre(screen, font, "----------------------",SCREEN_W/2,8,9);

               dpm(c, f, cursor_pos);

               textout(screen, font, "     Text Color:", 80,my+(2*8),item[c][8]);
               sprintf(msg,"%-2d", item[c][8]);
               textout(screen,font,msg,216,160,13);
            
               textout(screen, font, "    Frame Color:", 80,my+(3*8),item[c][9]);
               sprintf(msg,"%-2d",item[c][9]);
               textout(screen,font,msg,216,168,13);

               textout(screen, font, "        Continue", 80,my+(6*8),11);
               textout(screen, font, "           Abort", 80,my+(7*8),10);
               show_mouse(screen);
            } /* end of if redraw */
      
         if (blink_counter++ < blink_count)
            show_cursor(f, cursor_pos, 10);
         else show_cursor(f, cursor_pos, 0);
         if (blink_counter> blink_count*2) blink_counter = 0;
      
         if (cursor_pos != old_cp)
            {
               show_cursor(f, old_cp, 0); /* erase old if moved */
               old_cp = cursor_pos;
               blink_counter = 0;
            }
         if (key[KEY_RIGHT])
            {
               if (++cursor_pos > char_count) cursor_pos = char_count;
               redraw = 1;
            }
         if (key[KEY_LEFT])
            {
               if (--cursor_pos < 0) cursor_pos = 0;
               redraw = 1;
            }
         if ((key[KEY_DEL]) && (cursor_pos < char_count))
            {
               for (a = cursor_pos; a < char_count; a++)
                 f[a]=f[a+1];
               char_count--;
               /* set last to NULL */
               f[char_count] = NULL;
               redraw = 1;
               clear(screen);
               clear_keybuf();
            }
         if (keypressed()) /* don't wait for keypress */
            {
               k = readkey();
               clear_keybuf();
            }
         else k = 0;
         k = (k & 0xFF);  /* strip upper bits */
         if ((k == 8) && (cursor_pos > 0)) /* BACKSPACE */
            {
               for (a = cursor_pos; a < char_count; a++)
                 f[a]=f[a+1];
               char_count--;
               cursor_pos--;
               /* set last to NULL */
               f[char_count] = NULL;
               clear(screen);
               redraw = 1;
            }
         else if ((k>12) && (k<127))   /* if alphanumeric and return */
            {
               /* move over to make room */
               for (a = char_count; a>=cursor_pos; a--)
                  f[a+1]=f[a];

               /* set char */
               f[cursor_pos] = k;
      
               /* inc both */
               cursor_pos++;
               char_count++;
      
               /* set last to NULL */
               f[char_count] = NULL;
      
               clear(screen);
               redraw = 1;
      
            }

         show_mouse(screen); rest(10); show_mouse(NULL);
         if ((mouse_b & 1) && (mouse_x > 100) && (mouse_x < 230) && (mouse_y > my) && (mouse_y < my+(11*8)))
            {
               redraw = 1;
               switch ((mouse_y-144)/8)
                  {
                     case 2: /* edit text color */
                     if (edit_int(216, my+(2*8), item[c][8], 1, 1, 15))
                        item[c][8] =edit_int_retval; break;
                     case 3: /* edit frame color */
                     if (edit_int(216, my+(3*8), item[c][9], 1, 1, 15))
                        item[c][9] =edit_int_retval; break;
                     case 6: /* CONTINUE */ quit = 1; break;
                     case 7: /* ABORT */  quit = -1; break;
                  }
            }
      } /* end of while (!quit) */
   if (quit != -1)
      {
         free(pmsg[c]);
         pmsg[c] = (char*) malloc (strlen(f)+1);
         strcpy(pmsg[c], f);
         return 1;
      }
   return 0;
}
int create_obj(int obt, int sub_type, int sent_num)
{
   extern int e_num_of_type[50];   /* sort stuff used by others */
   extern int e_first_num[50];

   int num = sent_num; /* default */
   int ret;

   if (obt == 2) /* items */
      {
         ret = create_item(sub_type);
         if (ret > 500)
            {
                  num = sent_num;
                  alert("No creator exists for the current item type.",
                  "Copy from an existing item of that type,",
                  "or get one from the selection window",
                  "OK", NULL, NULL, NULL);
            }
         else num = ret;
      }
   if (obt == 3)
      {
         if (sub_type == 9)
            {
               create_cloner();
               num = e_first_num[sub_type]+e_num_of_type[sub_type]-1;
            }
         if (sub_type == 7)
            {
               create_pod();
               num = e_first_num[sub_type]+e_num_of_type[sub_type]-1;
            }
      }
   return num;  /* to return number of created obj */
}
int create_item(int type)
{
   extern int item[500][16];
   extern int l[100][100];
   extern int get100_x, get100_y;

   extern int item_num_of_type[20];   /* sort stuff used by others */
   extern int item_first_num[20];

   extern int db;
   extern int tx;

   int c=0, d, x, y;
   int erase = 0;
   int num;

   char msg[80];

   c = get_empty_item(type); /* get a place to put it */

   if (c > 499) return c; /* no items */

   num = c;

   /* check for no creator */
   if ((type != 1) && (type != 3) && (type != 4) && (type != 5) && (type != 10))
     return 9999;

   switch (type)
      {
            case 1: /* door creator  */
            if (getxy("Put door location", 2, 1, num) == 1)
               {
                  item[c][4] = get100_x*20;
                  item[c][5] = get100_y*20;

                  l[item[c][4]/20][item[c][5]/20] = 0;   /* zero block */

                  item[c][0] = 1;    /* type 1 */
                  item[c][1] = 1005; /* ans    */
                  item[c][2] = 1;    /* draw mode normal */
                  item[c][3] = 0;    /* stationary */

                  draw_big();
                  show_big();

                  if (getxy("Put door destination", 2, 1, num) == 1)
                     {
                        item[c][6] = get100_x;
                        item[c][7] = get100_y;
                        l[item[c][6]][item[c][7]] = 0;   /* zero block */
                     }
                  else erase = 1;
               }
            else erase = 1;
         break;
         case 3: /* exit creator */
            if (getxy("Put exit location", 2, 3, num) == 1) /* xorg, yorg */
               {
                  item[c][0] = 3 ;   /* type 3 exit */
                  item[c][1] = 1022;   /* default animation seq */
                  item[c][2] = 1;    /* draw mode */
                  item[c][3] = 0;    /* stationary */
                  item[c][4] = get100_x*20;  /* mouse click x */
                  item[c][5] = get100_y*20;  /* mouse click y */
                  item[c][8] = 0;    /* NOT ALL DEAD */

                  l[item[c][4]/20][item[c][5]/20] = 0; /* zero block */
               }
            else erase = 1;
         break;
         case 4: /* key creator */
            {
               extern BITMAP *memory_bitmap[NUM_SPRITES];
               int key_color, x, exit=0;
               while (mouse_b & 1); /* wait for release */
               show_mouse(NULL);
               clear(screen);
               textout_centre(screen, font, "Key and Locked Block Creator", SCREEN_W/2, 10, 240);
               textout_centre(screen, font, "----------------------------", SCREEN_W/2, 18, 208);
               textout_centre(screen, font, "b1 to choose a color", SCREEN_W/2, 180, 240);
               textout_centre(screen, font, "b2 or <esc> to quit", SCREEN_W/2, 188, 208);

               for (x=0; x<4; x++)
                  draw_sprite(screen, memory_bitmap[220+x],SCREEN_W/2,(x*20)+60);
               show_mouse(screen);
               while (!exit)
                  {
                     if ((mouse_b & 2) || (key[KEY_ESC]))  exit = 1;
                     if ((mouse_b & 1) && (mouse_x > (SCREEN_W/2)) && (mouse_x < ((SCREEN_W/2)+20) ))
                        {
                           key_color = (mouse_y - 60)/20;
                           exit = 1;
                           rest(20);

                           if ((key_color < 0) || (key_color > 3))
                              key_color = 0;
                        }
                   }
               while (mouse_b & 1); /* wait for release */


               show_mouse(NULL);
               clear(screen);

                  if (getxy("Put key location", 2, 4, num) == 1)
                     {
                        item[c][4] = get100_x*20;
                        item[c][5] = get100_y*20;

                        l[item[c][4]/20][item[c][5]/20] = 0; /* zero block */

                        item[c][0] = 4; /* type 4 - block killer ! */
                        item[c][1] = 1039 + key_color; /* animation seq */
                        item[c][2] = 1; /* draw mode */
                        item[c][3] = 1; /* fall */

                        if (getbox("Locked block range"))
                           {
                               extern int bx1, bx2, by1, by2;

                               bx2-=1;
                               by2-=1;

                               if (bx2 < bx1) bx2 = bx1;
                               if (by2 < by1) by2 = by1;

                               item[c][6] = bx1;
                               item[c][7] = by1;
                               item[c][8] = bx2;
                               item[c][9] = by2;

                               /* set the block range */
                               for (x = item[c][6];x <= item[c][8];x++)
                                  for (y = item[c][7];y <= item[c][9];y++)
                                     {
                                         int base_shape = 220;
                                         if (l[x][y] == 136) base_shape = 188;
                                         if (l[x][y] == 139) base_shape = 204;
       
                                         l[x][y] = base_shape+key_color; /* keyed block */
                                     }
                               draw_big();
                               draw_bs(15);
                               rest(500);
                           } /* end of trigger box */
                        else erase = 1;
                     }  /* end of key location */
                  else erase = 1;
               }
         break;
         case 5:     /* initial PX, PY */
            for (x=0; x<500; x++)  /* erase all other starts*/
                if (item[x][0] == 5)
                   for (y=0; y<16; y++)
                      item[x][y] = 0;
 
            if (getxy("Put Start Location", 2, 5, num) == 1)  /* xorg, yorg */
               {
                  item[c][0] = 5 ;   /* type 5 start */
                  item[c][1] = 1021;   /* default animation seq */
                  item[c][2] = 1;  /* draw mode */
                  item[c][3] = 0;  /* stationary */
                  item[c][4] = get100_x*20;  /* mouse click x */
                  item[c][5] = get100_y*20;  /* mouse click y */
                  item[c][8] = 300;  /* default level_time */
                  l[item[c][4]/20][item[c][5]/20] = 0; /* zero l */
               }
            else erase = 1;

            break;

            case 10: /* pop up message creator */
                 if (create_pmsg(c, 1))
                    {
                       if (getxy("Put message location", 2, 10, num)==1)
                          {
                             item[c][0] = 10 ;  /* type 10 msg */
                             item[c][1] = 1036;  /*  animation seq */
                             item[c][2] = 1; /* draw mode */
                             item[c][3] = 0; /* stationary */
                    
                             item[c][4] = get100_x*20;  /* mouse click x */
                             item[c][5] = get100_y*20;  /* mouse click y */

                             l[item[c][4]/20][item[c][5]/20] = 0; /* zero block */
                          }
                       else erase = 1;
                    }
                 else erase = 1;
            break;
         }  /* end of switch case */
      item_sort();
      num = item_first_num[type]+item_num_of_type[type]-1;

      if (erase)
         {
            erase_item(c);
            item_sort();
            num = item_first_num[type]+item_num_of_type[type]-1;
         }
      set_wx(item[c][4]/20+4, item[c][5]/20);
      return num;
}

