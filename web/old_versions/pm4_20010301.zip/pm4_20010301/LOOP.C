#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <allegro.h>
#include "pm.h"
#include "lift.h"

void pm_main(void);
void mtextout_centre(BITMAP* , char *txt1, int, int, float, float, int);



/* global variables  */

extern int lines[50][6];
extern float y_adj;


#ifdef TIMER
extern int timer_points[50][8];
extern char timer_point_text[50][80];
extern volatile int tmsec_timer;
extern float fps;  /* frames per second */
#endif

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

extern BITMAP *memory_bitmap[NUM_SPRITES];
extern BITMAP *level_2000, *scrn_buffer;
extern BITMAP *map100_bmp, *map100_bkg;
extern PALLETE pallete;
extern SAMPLE *snd[20];
extern int fuse_loop_playing;
extern int phit_loop_playing;
extern int sample_delay[8];
extern int lit_item;

extern int ap_mode;
extern int up;
extern int down;
extern int left;
extern int right;

extern int l[100][100];    /* level */
extern int item[500][16];  /* items */
extern int Ei[100][32];    /* enemies */
extern float Ef[100][16];  /* enemies */
extern int zz[20][NUM_ANS];

/* timer variables  */
extern volatile int msec_timer;
extern int level_time;
extern int passcount;

/* new x move stuff */
extern float right_speed, left_speed;
extern float initial_x_speed, max_x_speed;
extern float p_xmove;
extern float accel, de_accel;
extern float jump_sinc, fall_sinc;
extern float pmovey;
extern int ex_jump;

extern int jump;
extern int fire;

extern int play_level;
extern int start_level;
extern int start_mode;
extern int resume_allowed;

extern int top_menu_sel;

extern int speed;
extern int dif;

extern float LIFE;
extern int LIVES;

extern int sound_on;
extern int frame_speed;
extern int fade_count;

extern int WX, WY;
extern float PX, PY;
extern int PXint, PYint;
extern int num_bullets;

extern int max_bullets;
extern int pbullet[50][6];
extern int bullet_wait_counter, request_bullet;
extern int bullet_wait, bullet_speed;
extern int pm_bullet_collision_box;

extern int e_bullet_active[50], e_bullet_shape[50];
extern int enemy_bullet_colision_window;
extern float e_bullet_x[50], e_bullet_y[50], e_bullet_xinc[50], e_bullet_yinc[50];

extern int bomb[20][5];

extern float itemf[500][4];

extern int player_ride;
extern int player_carry;

extern int fire_held;

extern int left_right;
extern float jump_count, fall_count;

extern int level_done;
extern int game_exit;
extern int num_enemy;

/* counters and temp string  */
int a, b, c, d, e, f, x, y;
extern char msg[80];
extern char b_msg[40][80];
extern int bottom_msg;
extern int pop_msg;
extern int pop_msg_count;

extern int map_double; /* game map double */
extern int map100_x, map100_y;
extern int game_map_on, top_display_on;
extern int top_display_x, top_display_y, top_display_color;
extern int bottom_display_y, bottom_display_color;

extern int map_solid_color, map_semi_color;
extern int map_break_color, map_empty_color;
extern int map_enemy_color , map_bullet_color;
extern int map_item_color, map_player_color;

extern int md; /* menu map double */
extern int mx;
extern int my;


void event(int ev)
{
   extern int sample_delay[8];
   int text_on = 1;
   if (sound_on)
      {
         switch (ev) {
/*
        0 - player shoots
        1 - d'OH
        2 - bonus
        3 - hiss
        4 - la de da  door, key, exit
        5 - explosion
        6 - grunt 1 shot
        7 - grunt 2 hit
        8 - enemy killed
*/
            case  1: play_sample( snd[ 0], 180, 127,  800, 0);
            break;
            case  2: case  4: case  5:
               if (sample_delay[4]+30 < passcount)
                  {
                     sample_delay[4] = passcount;
                     play_sample(snd[4], 200, 127, 1000, 0);
                  }
            break;
            case  6: case  7:  case  8: case  9:
               if (sample_delay[2]+30 < passcount)
                  {
                     sample_delay[2] = passcount;
                     stop_sample(snd[2]); play_sample( snd[2], 200, 127, 1000, 0);
                  }
            break;
            case 11: play_sample( snd[6], 127, 127, 1000, 0); break;
            case 10: case 12:
               if (sample_delay[7]+14 < passcount)
                  {
                      sample_delay[7] = passcount;
                      stop_sample(snd[7]); play_sample( snd[7], 127, 127, 1000, 0);
                  }
            break;
            case 13: play_sample( snd[8], 200, 127, 1200, 0); break;
            case 21: play_sample( snd[1], 255, 127, 1000, 0); break;
            case 22: stop_sample(snd[5]); play_sample( snd[5], 200, 127, 1000, 0); break;
         }
      }
   if (text_on)
      {
         extern char eitype_desc[50][32][40];
         extern int e_killed_type;
         erase_last_bmsg();
         switch (ev) {
            case   1:/* player bullet fired */ break;
            case   2: slide_bmsg();sprintf(b_msg[0], "You got a key!"); bottom_msg = 120; erase_last_bmsg(); break;
            case   3: slide_bmsg();sprintf(b_msg[0], "%d enemies still alive!", num_enemy); bottom_msg = 120; erase_last_bmsg(); break;
            case   4: /* level_done  */ break;
            case   5: slide_bmsg();sprintf(b_msg[0], "Door!"); bottom_msg = 120; erase_last_bmsg(); break;
            case   6: slide_bmsg();sprintf(b_msg[0], "Health Bonus! %d", item[x][7]); bottom_msg = 120; erase_last_bmsg(); break;
            case   7: slide_bmsg();sprintf(b_msg[0], "Bullet Bonus! %d", item[x][8]); bottom_msg = 120; erase_last_bmsg(); break;
            case   8: slide_bmsg();sprintf(b_msg[0], "Timer Bonus! %d",  item[x][9]); bottom_msg = 120; erase_last_bmsg(); break;
            case   9: slide_bmsg();sprintf(b_msg[0], "Wahoo! You got a Free Man!"); bottom_msg = 200; erase_last_bmsg(); break;
            case  10: slide_bmsg();sprintf(b_msg[0], "You hit a Mine!"); bottom_msg = 120;erase_last_bmsg(); break;
            case  11: slide_bmsg();sprintf(b_msg[0], "You got shot!"); bottom_msg = 120; erase_last_bmsg(); break;
            case  12: slide_bmsg();sprintf(b_msg[0], "You got hit by %s!", eitype_desc[e_killed_type][0]); bottom_msg = 120; erase_last_bmsg(); break;
            case  13: slide_bmsg();sprintf(b_msg[0], "%s killed!...%d enemies left", eitype_desc[e_killed_type][0],  num_enemy-1);  bottom_msg = 120; erase_last_bmsg(); break;
            case  14: /* cloner cloned something */ break;
            case  15: /* jump  */ break;
            case  16: /* arrow fired */ break;
            case  17: /* green fired */ break;
            case  18: /* cannonball  */ break;
            case  19: /* twirly      */ break;
            case  20: slide_bmsg();sprintf(b_msg[0], "No bullets!"); bottom_msg = 120; erase_last_bmsg(); break;
            case  21: /* you died! */ break;
            case  22: /* explosion */ break;
            case  23: slide_bmsg();sprintf(b_msg[0], "Enemy killed by bomb!"); bottom_msg = 120; bottom_msg = 120; erase_last_bmsg(); break;
            case  24: slide_bmsg();sprintf(b_msg[0], "#%d bomb with %d second fuse",item[x][7]/20, item[x][9]/10 ); bottom_msg = 120+item[x][9]; erase_last_bmsg(); break;
            case  25: slide_bmsg();sprintf(b_msg[0], "Rocket!"); bottom_msg = 120; erase_last_bmsg(); break;
/*          case  26: slide_bmsg();sprintf(b_msg[0], "you already have perfect health!"); bottom_msg = 120; erase_last_bmsg(); break;
            case  27: slide_bmsg();sprintf(b_msg[0], "you already have %d bullets!", num_bullets); bottom_msg = 120; erase_last_bmsg(); break;
  */        case  28: /* timer full (unused)  */ break;
            case  29: slide_bmsg();sprintf(b_msg[0], "Bonus! (%d health) (%d bullets)", item[x][7], item[x][8]); bottom_msg = 120; erase_last_bmsg();/* fruit bonus */ break;
            case  30: slide_bmsg();sprintf(b_msg[0], "You got a Switch"); bottom_msg = 120; erase_last_bmsg();/*  */ break;
            case  31: slide_bmsg();sprintf(b_msg[0], "Sproingy!"); bottom_msg = 120; erase_last_bmsg();/*  */ break;


         }
      }
}
player_move()
{
   if (!((player_carry) && (item[player_carry-1][0] == 98)))
      {
         if (left)
            {
               left_right = 0;
               if (left_speed < initial_x_speed) left_speed = initial_x_speed;
               else
                  {
                     left_speed += accel;
                     if (left_speed > max_x_speed) left_speed = max_x_speed;
                  }
            }
         else
            {
               left_speed -= de_accel;
               if (left_speed < 0) left_speed = 0;
            }
         if (right)
            {
               left_right = 1;
               if (right_speed < initial_x_speed) right_speed = initial_x_speed;
               else
                  {
                     right_speed += accel;
                     if (right_speed > max_x_speed) right_speed = max_x_speed;
                  }
            }
         else
            {
               right_speed -= de_accel;
               if (right_speed < 0) right_speed = 0;
            }

         p_xmove = right_speed - left_speed;
         PXint = PX + p_xmove;
         PYint = PY;
         /* check for player being pushed by lift */
         a = (is_left_solid(PXint,PYint));
         if ( a > 31 )
            {
               p_xmove += lifts[a-32]->fxinc + left_speed;
               left_speed=0;
            }
         a = is_right_solid(PXint,PYint);
         if ( a > 31 )
            {
               p_xmove += lifts[a-32]->fxinc - right_speed;
               right_speed = 0;
            }
         /* check if trying to move through wall */
         if ((p_xmove > 0) && (!is_right_solid(PXint+ (int) p_xmove,PYint)) )
                  {
                     PX += p_xmove;
                     if (PX>1980) PX=1980;
                     PXint = PX;
                  }
         if ((p_xmove < 0) && (!is_left_solid(PXint+ (int) p_xmove,PYint)) )
                  {
                     PX += p_xmove;
                     if (PX<0) PX=0;
                     PXint = PX;
                  }
         /* Y MOVEMENT   */
         /* check if in the middle of a jump */
         if (jump_count)
            {
               jump_count -= jump_sinc;
               if (jump_count < .1)
                  {
                     jump_count = 0;
                     fall_count = 1.57;
                  }
               else
                  {
                     if (!jump) jump_count -= (jump_sinc*4); /* jump released */
                     if (is_up_solid(PXint, PYint, 1, 0))
                        {
                           jump_count = 0;
                           fall_count = 1.57;
                        }
                     else PY -= (sin(jump_count) * pmovey);
                  }
            }
         else   /* not jump  */
            {
               if (fall_count)
                  {
                     fall_count -= fall_sinc;
                     if (fall_count < .1) fall_count = .1;
                     PY += (sin(1.57 - fall_count) * pmovey);
                     PYint = PY;
                     a = is_down_solid(PXint,PYint, 1);
                     if (a == 1)
                        {
                           fall_count = 0;
                           PY -= fmod (PY, 20); /* align with floor */
                        }
                     if ((a > 31) && (a < 1024)) /* on lift */
                        {
                           fall_count = 0;
                           player_ride = a; /* lift num */

                        }
                     if (a > 1023) /* on line */
                        {
                           fall_count = 0;
                           player_ride = a;
                           PY = y_adj; /* align with line */
                        }
                  }
               else /* not jump or fall */
                  {
                     a = is_down_solid(PXint,PYint, 1); /* on lift? */
                     if ((a > 31) && (a < 1024)) /* lift below */
                        {
                           player_ride = a ; /* number of shape he's riding */
                           if (lifts[a-32]->fyinc < 0) /* yinc (up) */
                              {
                                 PYint = PY + lifts[a-32]->fyinc;
                                 if (is_up_solid(PXint, PYint, 1, 0))  /* hit ceiling? */
                                    {
                                       player_ride = 0;    /* fall off lift */
                                       fall_count = 1.57;
                                       PY += 5; /* set y so he falls*/
                                    }
                              }
                           if (lifts[a-32]->fyinc > 0) /* yinc (down)*/
                              {
                                 PYint = PY + lifts[a-32]->fyinc;
                                 if (is_down_solid(PXint, PYint, 0))  /* floor below? */
                                    {
                                       player_ride = 0;   /* off lift */
                                       fall_count = 1.57;
                                       PY -= 5; /* set y */
                                    }
                              }
                        }
                     if (a > 1023) /* line below */
                        {
                           player_ride = a ; /* number of line he's on */
                           PY = y_adj;
                        }
                     if (a == 0)  /* start fall? */
                        {
                           player_ride = 0;
                           fall_count = 1.57;
                        }
                     if ((a) && (jump)) /* check if jump pressed  */
                        {
                           player_ride = 0;
                           jump_count=1.57;
                           event(15);
                        }
                  }
            } /* end of else not jump and end of Y_MOVE */
      } /* end of if ! ride rocket */
}
draw_player()
{
   PXint = PX;
   PYint = PY;
   b = 9;
   if (up)   b=10;
   if (down) b=11;


   x = (PXint/4) % zz[4][b];
   if ((jump_count) || (fall_count)) x = 0;
   if ((player_ride) && (right_speed<.5) && (left_speed<.5)) x = 0;
   if ((player_carry) && (item[player_carry-1][0] == 98)) x = 0;
   y = zz[x+5][b];
   if (left_right) draw_sprite(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
   else draw_sprite_h_flip(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
   if (game_map_on)
      {
        /*  rectfill(map100_bmp,((PXint+10)/20)-1, (PYint/20)-1,((PXint+10)/20)+1, (PYint/20)+1,152);
          */

         if ((passcount % 20) < 10 )
            {
               putpixel(map100_bmp,((PXint+10)/20)+1, (PYint/20),74);
               putpixel(map100_bmp,((PXint+10)/20)-1, (PYint/20),74);
               putpixel(map100_bmp,((PXint+10)/20), (PYint/20)+1,74);
               putpixel(map100_bmp,((PXint+10)/20), (PYint/20)-1,74);
            }
         if ((passcount % 20) > 9 )
            {
               putpixel(map100_bmp,((PXint+10)/20)+1, (PYint/20)+1,74);
               putpixel(map100_bmp,((PXint+10)/20)-1, (PYint/20)-1,74);
               putpixel(map100_bmp,((PXint+10)/20)+1, (PYint/20)-1,74);
               putpixel(map100_bmp,((PXint+10)/20)-1, (PYint/20)+1,74);
            }
          putpixel(map100_bmp,((PXint+10)/20), (PYint/20),10);
      }
}
proc_pbullets()
{
   request_bullet=0;
   if ((fire) && (!fire_held) && (!bullet_wait_counter)) /* fire button pressed */
      {
         if (num_bullets > 0)
            {
               request_bullet = 1;
               bullet_wait_counter = bullet_wait;
               fire_held=1;
            }
         else event(20); /* out of bullets */

      }
   else if (--bullet_wait_counter < 0) bullet_wait_counter = 0;
   for (b = 0; b < 50; b++)
      {
         if (pbullet[b][0])  /* if bullet not active skip to next one */
            {
               pbullet[b][2] += pbullet[b][4];  /* xinc */
               pbullet[b][3] += pbullet[b][5];  /* yinc */
               if ((pbullet[b][2] < 5) || (pbullet[b][2] > 1995) || (pbullet[b][3]<5) || (pbullet[b][3] > 1995) )
                  pbullet[b][0];
               x = ( (pbullet[b][2] + 10) / 20);
               y = ( (pbullet[b][3] + 10) / 20);
               d = l[x][y];
               if ((d > 63) && (d < NUM_SPRITES)) /* if hit solid or breakable */
                  {
                     pbullet[b][0] = 0;  /* bullet dies  */
                     if ((d > 95) && (d < 128)) /* breakable wall */
                        {
                           l[x][y] = 0; /* wall dies too */
                           blit(memory_bitmap[0], level_2000, 0, 0, (x*20), (y*20), 20, 20);
                           putpixel(map100_bkg, x, y, map_empty_color);
                        }
                  }
               draw_sprite(scrn_buffer, memory_bitmap[zz[0][4]], pbullet[b][2]-WX, pbullet[b][3]-WY);
               if (game_map_on) putpixel(map100_bmp, x, y, map_bullet_color);
            }
         else if (request_bullet)
            {
                      /* setting initial...*/
                request_bullet = 0;
                event(1);
                pbullet[b][0] = 1;
                pbullet[b][2] = PXint;
                pbullet[b][3] = PYint + 1;
                pbullet[b][4] = 0; /* xinc */
                pbullet[b][5] = 0; /* yinc */
                num_bullets--;
                if (up)
                   {
                      pbullet[b][5] = -bullet_speed;
                      pbullet[b][2] = -5 + PXint + (left_right*10);
                   }
                else if (down)
                   {
                      pbullet[b][5] = bullet_speed;
                      pbullet[b][2] = -5 + PXint + (left_right*10);
                   }
                else pbullet[b][4] = (left_right * (bullet_speed*2) ) - bullet_speed;
            }
      }
}
proc_ebullets()
{
   for (b = 0; b < 50; b++)
      if (e_bullet_active[b])  /* if bullet not active skip to next one */
         {
            int ex, ey;
            e_bullet_x[b] += e_bullet_xinc[b]; /* inc x */
            e_bullet_y[b] += e_bullet_yinc[b]; /* inc y */
            ex = e_bullet_x[b];
            ey = e_bullet_y[b];
            if ((ex<0) || (ex>2000) || (ey<0) || (ey>2000))
               e_bullet_active[b] = 0;
            x = (ex+10)/20;
            y = (ey+10)/20;
            d = l[x][y];
            if ((d > 63) && (d<NUM_SPRITES)) /* bullet hit solid or breakable wall */
               {
                  e_bullet_active[b] = 0;  /* bullet dies */
                  if ((d > 95) && (d < 128)) /* remove breakable wall */
                     {
                        l[x][y] = 0;
                        blit(memory_bitmap[0], level_2000, 0, 0, (x*20), (y*20), 20, 20);
                        putpixel(map100_bkg, x, y, map_empty_color);
                     }
               }
            if (e_bullet_shape[b] > 1000)
               {
                   d =  e_bullet_shape[b]-1000;
                   d = zz[0][d];
                   draw_sprite(scrn_buffer, memory_bitmap[d], ex-WX, ey-WY);

               }
            else draw_sprite(scrn_buffer, memory_bitmap[e_bullet_shape[b]], ex-WX, ey-WY);
            if (game_map_on) putpixel(map100_bmp, x, y, map_bullet_color);
            /* check for collision with player */
            if (ex > (PXint - enemy_bullet_colision_window ))
               if (ex < (PXint + enemy_bullet_colision_window ))
                  if (ey > (PYint - enemy_bullet_colision_window ))
                     if (ey < (PYint + enemy_bullet_colision_window ))
                              {
                                 /* player got hit ! */

                                 switch (e_bullet_shape[b])
                                    {
                                       /* arrow */
                                       case 488:  LIFE -= 5  * dif; break;
                                       case 489:  LIFE -= 5  * dif; break;
                                       /* cannon ball */
                                       case 1055:  LIFE -= 7 * dif; break;
                                       /* yellow things */
                                       case 1020:  LIFE -= 9 * dif; break;
                                       /* green ball */
                                       case 1054:  LIFE -= 10 * dif; break;
                                       case 1062:  LIFE -= 8 * dif; break;
                                   
                                    }
                                 event(11);
                                 e_bullet_active[b] = 0;
                              }
         } /* end of if active */
}
void pm_main(void) /* game loop! */
{
   int loop_time = msec_timer;
#ifdef TIMER
   int old_msec_timer = msec_timer;
   int stime;
   int ttime= tmsec_timer;
   clear_timer_points();
#endif
   text_mode(-1);  /* masked */
   if (!start_mode) stimp();
   while (!game_exit) /* game loop */
      {
         if (start_mode)
            {
               if (start_mode == 1)  /* load level */
                  {
                     if (load_level(play_level,0))
                        {
                           set_zz(0);
                           maps_and_background_fill();
                        }
                     else
                        {
                           game_exit = 1;
                           resume_allowed = 0;
                           goto badload;
                        }
                  }
               if (start_mode == 2) /* resume after death */
                  {
                     LIFE = 100;
                     num_bullets = 100;
                  }
               for (c=0; c<500; c++)  /* get start and time */
                  if (item[c][0] == 5)
                     {
                        PX = itemf[c][0];
                        PY = itemf[c][1];
                        level_time = item[c][8] * 50;
                        stimp();
                        break;
                     }
               for (c=0; c<8; c++)
                  sample_delay[c] = passcount;

               player_carry = 0;
               player_ride = 0;
               level_done = 0;
               bottom_msg=0;
               pop_msg_count=0;
               right_speed = left_speed = 0;
               jump_count = fall_count = 0;
               clear_keybuf();
               start_mode = 0;
            }
         /*  true game loop starts here !!!!  above is only setup */

         if (ex_jump)
            if (!jump_count)
               {
                  ex_jump = 0;
                  jump_sinc=.05;
                  pmovey = 5;
               }

#ifdef TIMER
         insert_timer_point(0, ttime, tmsec_timer);
         ttime = tmsec_timer;
#endif

         /* frame speed delay */
#ifdef TIMER
         stime  = tmsec_timer;
#endif
         while ((msec_timer-loop_time) < frame_speed);
#ifdef TIMER
         insert_timer_point(1, stime, tmsec_timer);
         if (passcount % 20 == 0) /* calc frames per sec */
            {
               fps =  1000*( (float)20/(float)(msec_timer-old_msec_timer) );
               old_msec_timer = msec_timer;
            }
#endif
         loop_time = msec_timer;
         if (--bottom_msg > 0)
            {
               int a;
               int bc = 15; /* base color */
               int nb = 5;  /* NUM_BOTTOM_MSG_LINES */
               float is = 1.8; /* initial size */
               float fs = .2;  /* final size */
               float ypos = SCREEN_H - is*8;
               for (a=0; a< nb; a++)
                 {
                    float aa = (float)a/nb;
                    float sc = is-aa*(is-fs);
                    float xh = sc*8;
                    int ar = aa*12;

                    mtextout_centre(scrn_buffer, b_msg[a], SCREEN_W/2,
                       (int)ypos, sc, sc , bc+(ar*16));
                    ypos -= xh;

                 }
             }
         if (--pop_msg_count > 0) draw_pop_msg();
         else pop_msg = 0;

#ifdef TIMER
         stime = tmsec_timer;
#endif
         if (top_display_on) draw_top_display();
#ifdef TIMER
         insert_timer_point(10, stime, tmsec_timer);
         stime = tmsec_timer;
#endif
         if (game_map_on) draw_map();

#ifdef TIMER
insert_timer_point(9, stime, tmsec_timer);
stime = tmsec_timer;
#endif

         blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W,SCREEN_H); /* screen buffer to screen */

#ifdef TIMER
insert_timer_point(8, stime, tmsec_timer);
#endif

         move_lifts();
         if (ap_mode == 1) proc_ap_control();

#ifdef MV
         else if (ap_mode == 2) rec_ap_control();
#endif
         else proc_controllers();
         player_move();

#ifdef TIMER
stime = tmsec_timer;
#endif
         get_new_background();
#ifdef TIMER
insert_timer_point(3, stime, tmsec_timer);
stime = tmsec_timer;
#endif

         update_animation();
         draw_items();

#ifdef TIMER
insert_timer_point(4, stime, tmsec_timer);
stime = tmsec_timer;
#endif

         draw_player();

#ifdef TIMER
insert_timer_point(5, stime, tmsec_timer);
stime = tmsec_timer;
#endif

         draw_lifts();

#ifdef TIMER
insert_timer_point(6, stime, tmsec_timer);
show_timer_points();
#endif

         proc_ebullets();
         proc_pbullets();
         enemy_move();

#ifdef TIMER
stime = tmsec_timer;
#endif

         enemy_draw_and_collision();

#ifdef TIMER
insert_timer_point(2, stime, tmsec_timer);
#endif

         proc_lit_rocket();
         proc_player_carry();
         proc_item_collison();
         proc_item_move();
         proc_lit_bomb();

#ifdef TIMER
stime = tmsec_timer;
#endif

         if (sound_on)
            {
               if ((!fuse_loop_playing) && (lit_item))
                  {
                     fuse_loop_playing = 1;
                     play_sample(snd[3], 200, 127, 1000, 1);
                  }
               if ((fuse_loop_playing) && (!lit_item))
                  {
                     fuse_loop_playing = 0;
                     stop_sample(snd[3]);
                  }
               lit_item = 0;
            }
#ifdef TIMER
insert_timer_point(7, stime, tmsec_timer);
#endif

         if (--level_time < 40) LIFE = -1;
         if (LIFE>100) LIFE = 100;
         if (LIFE < 0)
            {
               if (sound_on)
                  {
                     stop_sample( snd[3] ); /* fuse hiss */
                     fuse_loop_playing = 0;
                  }
               start_mode = 2;
               event(21);
               if (--LIVES < 0)
                  {
                     stretch_text("Game", "Over!", 14);
                     resume_allowed = 0;
                     top_menu_sel = 3; /* not resume */
                     game_exit = 1;
                  }
               else if (level_time < 40) /* out of time */
                  stretch_text("Time Up!", NULL, 10);
               else stretch_text("You", "Died!", 10);
            }
         if (level_done)
            {
               if (sound_on) stop_sample( snd[3] );
               stretch_text("Level", "Done!", 9);
               play_level++;
               start_mode = 1;
            }

     } /* end of while (!game_exit) */

   badload:
   if (resume_allowed) top_menu_sel = 4; /* resume */
   if (sound_on)
      {
         stop_sample( snd[3] ); /* fuse hiss */
         fuse_loop_playing = 0;
      }
   stamp();
   text_mode(0);  /* normal */
   clear_keybuf();
}

