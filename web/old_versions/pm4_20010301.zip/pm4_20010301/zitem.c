#include <math.h>
#include <allegro.h>
#include "lift.h"
#include "pm.h"

/* global variables  */
extern int item[500][16];
extern float itemf[500][4];
extern struct lift *lifts[20];
extern BITMAP *memory_bitmap[NUM_SPRITES];
extern BITMAP *level_2000, *scrn_buffer;
extern BITMAP *map100_bmp, *map100_bkg;
extern BITMAP *dtemp;
extern int zz[20][NUM_ANS];
extern int l[100][100];    /* level */

extern float PX, PY;
extern int PXint, PYint;
extern int WX, WY;
extern int passcount;

extern int game_map_on, map_empty_color;

extern int player_ride;
extern int player_carry;

extern float right_speed, left_speed;
extern int jump;
extern int fire;

extern int level_done;
extern int num_enemy;


extern float jump_count, fall_count;
extern float LIFE;
extern int LIVES;

extern int bomb[20][5];

extern int lines[50][6];
extern float y_adj;

extern int lit_item;
extern int up;
extern int down;
extern int left_right;
extern int left;
extern int right;
extern float pmovey;
extern float p_xmove;


int a, b, c, d, e, f, x, y;

draw_items()
{
   int x, y;
   for (c=0; c<500; c++) /* rem update items on scrn_buffer */
      if (item[c][0])   /* if not type 0  */
         {
            int shape = 255; /* default */
            x = (int) itemf[c][0];
            y = (int) itemf[c][1];
            if (game_map_on) putpixel(map100_bmp, x/20, y/20, 7);
            if ((item[c][0] != 99) && ((player_carry-1) != c) )
               if ((x > WX-20) && (x < (WX + SCREEN_W)) && (y > WY-20) && (y < (WY + SCREEN_H)))
                  {
                    /* get shape */
                    a = item[c][1];
                    if (a < NUM_SPRITES) shape = a; /* bitmap */
                    if (a > 999) shape = zz[0][a-1000]; /* ans */
                    /* do draw mode */
                    if (item[c][0] == 11) rotate_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY, itofix(item[c][10]/10));
                    else if (item[c][2] == 1) /* draw mode normal */
                        draw_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY);
                  }
          }
}
proc_item_move()
{
   for (c=0; c<500; c++)  /* item move */
      if ((item[c][0]) && (item[c][3])) /* active and not stationary */
         if (item[c][0] != 98) /* not lit rocket */
            if (c != (player_carry-1)) /* not carrying */
               {
                  itemf[c][0] += itemf[c][2];  /* xinc */
                  itemf[c][1] += itemf[c][3];  /* yinc */
                  x = (int) itemf[c][0];
                  y = (int) itemf[c][1];
                  if (itemf[c][2] > 0) itemf[c][2] -= .01; /* slow down x move */
                  if (itemf[c][2] < 0) itemf[c][2] += .01; /* slow down x move */
   
                  if (itemf[c][2] > 0) /* right */
                     if (is_right_solid(x,y)) /* check for block right */
                        itemf[c][2] = 0;  /* stop */
   
                  if (itemf[c][2] < 0) /* left */
                     if (is_left_solid(x,y)) /* check for block left */
                        itemf[c][2] = 0;  /* stop */
   
                  if (itemf[c][3] < 0) /* rising */
                    {
                       if (!is_up_solid(x,y,0,0)) itemf[c][3] += .1; /* de-accel */
                       else itemf[c][3] = 0; /* stop y move if hit ceiling */
                    }
                 if (itemf[c][3] > 0) /* falling */
                    {
                       if (!is_down_solid(x,y, 1)) /* check for block below */
                          {
                             itemf[c][3] += .1;  /* accel */
                             if (itemf[c][3] > 3) itemf[c][3] = 3;  /* max accel */
                          }
                       else
                          {
                             if (itemf[c][2] > 0) itemf[c][2] -= .15; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .15; /* slow down x move if on ground */
   
                             itemf[c][1] = ((y/20)*20); /* align with ground */
   
                             itemf[c][3] = 0; /* stop y move if on ground */
                          }
                     }
                if (itemf[c][3] == 0) /* yinc steady */
                    {
                       a = is_down_solid(x,y,1); /* check for block below */
                       if (a==0)
                          {
                             itemf[c][3] += .1;  /* accel */
                             if (itemf[c][3] > 4) itemf[c][3] = 4;  /* max accel */
                          }
                       if (a==1)
                          {
                             itemf[c][3] = 0; /* stop y move if on ground */
                             if (itemf[c][2] > 0) itemf[c][2] -= .03; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .03; /* slow down x */
                          }
                       if ((a > 31) && (a < 1024)) /* item riding mov  */
                          {
                             itemf[c][0] += lifts[a-32]->fxinc; /* move with xinc */
                             itemf[c][1]  = lifts[a-32]->fy - 20 + lifts[a-32]->fyinc; /* align with Y1 */
                             if (itemf[c][2] > 0) itemf[c][2] -= .03; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .03; /* slow down x */
                          }
                       if (a > 1023) /* item on line  */
                          {
                             itemf[c][1]  = y_adj ; /* align with line */
                             itemf[c][2] = 0; /* xinc */
                             itemf[c][3] = 0; /* yinc */
                          }
                     }
               }  /* end of if not carry */
}
proc_item_collison()
{
   for (x=0; x<500; x++) /* item collision with man */
      if (item[x][0])  /* is object active */
         if ((PX > itemf[x][0] - 16) && (PX < itemf[x][0] + 16))
            if ((PY > itemf[x][1] - 16) && (PY < itemf[x][1] + 16))
               {
                  if (item[x][3] == -1) /* try to pick up item */
                     if ((fire) && (!player_carry))  /* if not already carrying */
                        player_carry = x+1;
                  switch (item[x][0]) /* type */
                     {
                        case 1:  /* door */
                           event(5);


                           PX = item[x][6] * 20;
                           PY = item[x][7] * 20;
                           left_speed=0;
                           right_speed=0;
                           jump_count=0;
                           fall_count=0;
                     
            /*               if (WX < 0) WX = 0;
                           if (WX > 1680) WX = 1680;
                           if (WY>1800) WY = 1800;
                           if (WY < 0) WY = 0;
                           fade_out(10);
                           blit(level_2000, scrn_buffer, WX, WY, 0, 0, 320, 200);
                           fade_in(pallete,10);*/
                        break;
                        case 2:
                        {
                           int ev;
                           if (item[x][7])
                              {
                                 extern float LIFE;
                                 if (LIFE < 100)
                                    {
                                       item[x][0] = 0;
                                       LIFE += item[x][7];
                                       if (LIFE > 100) LIFE = 100;
                                       ev = 6;
                                    }
                                 else ev = 26;
                              }
                           if (item [x][8])
                              {
                                 extern int num_bullets;
                                 extern int max_bullets;
                                 if (num_bullets < max_bullets) /* only if not full */
                                    {
                                       item[x][0] = 0;
                                       num_bullets += item[x][8];
                                       if (num_bullets > max_bullets) num_bullets = max_bullets;
                                       ev = 7;
                                    }
                                 else ev = 27;

                              }
                           if (item[x][9])
                              {
                                 extern int level_time;
                                 item[x][0] = 0;
                                 level_time += item[x][9] * 50;
                                 ev=8;
                              }
                           if ((item[x][7]) && (item[x][8])) /* fruit */
                              event(29);
                           else event(ev);

                        }
                        break;
                        case 3: /* exit */
                            if ( (item[x][8]) && (num_enemy) )
                               {
                                    event(3);
                               }
                            else
                               {
                                  level_done = 1;
                                  event(4);
                               }
                         break;
                         case 4: /* key */
                         item[x][0] = 0;
                         draw_items();
#ifdef KEY_ANIMATION
                         /* key animation */
                         {
                            float x1 = itemf[x][0];
                            float y1 = itemf[x][1];
                            float x2 = (item[x][6] + item[x][8]) * 10;
                            float y2 = (item[x][7] + item[x][9]) * 10;
                            float xsize = x2-x1;
                            float ysize = y2-y1;
                            float vx=x1;
                            float vy=y1;
                            float xinc;
                            float yinc;
                            float bsize;
                            int steps;
                            int div;
                            int shape, b, a;
                            if (fabs(xsize)>fabs(ysize)) bsize = fabs(xsize);
                            else bsize = fabs(ysize);

                            div = 12+bsize/2000*14;

                            steps = bsize/div;

                            xinc = xsize/steps;
                            yinc = ysize/steps;

                            for (b=0; b<steps; b++)
                               {
                                  vx += xinc;
                                  vy += yinc;

                                  WX = vx-SCREEN_W/2;
                                  WY = vy-SCREEN_H/2;

                                  if (WX < 0) WX = 0;
                                  if (WX > 2000-SCREEN_W) WX = 2000-SCREEN_W;
                                  if (WY > 2000-SCREEN_H) WY = 2000-SCREEN_H;
                                  if (WY < 0) WY = 0;

                                  blit(level_2000, scrn_buffer, WX, WY, 0, 0, SCREEN_W, SCREEN_H);


                                  if (1)
                                     {
                                        int x, y;
                                        int b = 9;
                                        if (up)   b=10;
                                        if (down) b=11;
                                        x = (PXint/4) % zz[4][b];
                                        y = zz[x+5][b];
                                        if (left_right) draw_sprite(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
                                        else draw_sprite_h_flip(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
                                     }

                                  a = item[x][1];
                                  shape = 255; /* default */
                                  if (a < NUM_SPRITES) shape = a; /* bitmap */
                                  if (a > 999) shape = zz[5][a-1000]; /* ans */
                                  draw_sprite(scrn_buffer, memory_bitmap[shape], vx-WX, vy-WY);
                                  enemy_draw_and_collision();
                                  draw_items();
                                  blit(scrn_buffer, screen, 0, 0, 0, 0,SCREEN_W, SCREEN_H );
                                  rest(2);
                               }


                            for (b=0; b<60; b++)
                               {
                                  rest(8);
                                  a = item[x][1];
                                  if (a < NUM_SPRITES) shape = a; /* bitmap */
                                  if (a > 999) shape = zz[5][a-1000]; /* ans */
                                  blit(memory_bitmap[0], screen, 0, 0, vx-WX, vy-WY, 20, 20);
                                  rotate_scaled_sprite(screen, memory_bitmap[shape], vx-WX, vy-WY, itofix(0), ftofix(1));
                               }
#endif
                         event(2);
                         for (c = item[x][6]; c <= item[x][8]; c++)
                            for (y = item[x][7]; y <= item[x][9]; y++)
                               {
                                  l[c][y] = 0;
                                  blit(memory_bitmap[0], level_2000, 0, 0, c*20, y*20, 20, 20);
                                  putpixel(map100_bkg, c, y, map_empty_color);

                               }
                         draw_lift_lines();
#ifdef KEY_ANIMATION
                         blit(level_2000, scrn_buffer, WX, WY, 0, 0, SCREEN_W, SCREEN_H);

                                  if (1)
                                     {
                                        int x, y;
                                        int b = 9;
                                        if (up)   b=10;
                                        if (down) b=11;
                                        x = (PXint/4) % zz[4][b];
                                        y = zz[x+5][b];
                                        if (left_right) draw_sprite(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
                                        else draw_sprite_h_flip(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
                                     }



                         enemy_draw_and_collision();
                         draw_items();
                         blit(scrn_buffer, screen, 0, 0, 0, 0,SCREEN_W, SCREEN_H );
                         rest(300);
                         for (b=0; b<steps; b++) /* go back */
                            {
                               vx -= xinc;
                               vy -= yinc;
                               WX = vx-SCREEN_W/2;
                               WY = vy-SCREEN_H/2;
                               if (WX < 0) WX = 0;
                               if (WX > 2000-SCREEN_W) WX = 2000-SCREEN_W;
                               if (WY > 2000-SCREEN_H) WY = 2000-SCREEN_H;
                               if (WY < 0) WY = 0;

                               blit(level_2000, scrn_buffer, WX, WY, 0, 0, SCREEN_W, SCREEN_H);

                                  if (1)
                                     {
                                        int x, y;
                                        int b = 9;
                                        if (up)   b=10;
                                        if (down) b=11;
                                        x = (PXint/4) % zz[4][b];
                                        y = zz[x+5][b];
                                        if (left_right) draw_sprite(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
                                        else draw_sprite_h_flip(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
                                     }

                               enemy_draw_and_collision();
                               draw_items();
                               blit(scrn_buffer, screen, 0, 0, 0, 0,SCREEN_W, SCREEN_H );
                               rest(2);
                            }
                            blit(level_2000, scrn_buffer, WX, WY, 0, 0, SCREEN_W, SCREEN_H);
                            rest(300);
                         }
#endif

                         break;
                         case 6: /* free man */
                            item[x][0] = 0;
                            LIVES++;
                            event(9);
                         break;

                         case 7:
                           event(10);
                           LIFE -= (float) item[x][8]/10;
                         break;
                         case 8: /* un-lit bomb */
                           event(24);
                           item[x][0] = 99; /* lit bomb */
                           item[x][3] = -1; /* carry */
                           for (d=0; d<20; d++)
                              if (!bomb[d][0])  /* find empty */
                                 {
                                    bomb[d][0] = 32 + x; /* link to item */
                                    bomb[d][1] = item[x][9] * zz[4][25]; /* total fuse wait */
                                    bomb[d][2] = item[x][9]; /* seq fuse wait */
                                    bomb[d][3] = item[x][7]; /* damage */
                                    bomb[d][4] = 1; /* for blow up */
                                    d = 20; /* end bomb loop */
                                 }
                               else if (d == 19) item[x][0] = 0; /* erase if no space in the bomb array */
                         break;
                         case 10: /* POP UP MESSAGE */
                         {
                            extern int pop_msg;
                            extern int pop_msg_count;
                            pop_msg = x+1;
                            pop_msg_count = 120;
                         }
                         break;
                         case 11: /* rocket */

                           event(25);
                           item[x][0] = 98; /* new type - lit rocket */
                           item[x][1] = 1026; /* new ans */
                           item[x][2] = 0; /* no draw */
                           item[x][3] = -1; /* carryable */
                           itemf[x][3] = 0; /* stop if falling */
                         break;


                        case 12: /* warp */
                          {
                            extern int start_mode, play_level;

                            play_level = item[x][8];
                            start_mode = 1;
                          }
                            break;



                         case 14: /* switch */

                            /* if not busy */
                         if (item[x][7]<passcount-4)
                            {
                               /* if falling and landing on it */
                               if ((PX > itemf[x][0] - 12) && (PX < itemf[x][0] + 12))
                                  if ((PY > itemf[x][1] - 16) && (PY < itemf[x][1] - 8))
                                     if (fall_count)
                                       {
                                           event(30);
                                           item[x][7] = passcount;
                                           item[x][6] = !item[x][6];
                                           if (item[x][6])  /* on */
                                              item[x][1] = item[x][8]; /* on bmp */
                                           if (!item[x][6]) /* off */
                                              item[x][1] = item[x][9]; /* off bmp */
                                           /* toggle blocks */
                                           for (c=0; c<100; c++)
                                              for (y=0; y<100; y++)
                                                 {
                                                    if (l[c][y] == item[x][11]) /* empty block */
                                                       {
                                                          l[c][y] = item[x][10]; /* replace with solid block */
                                                          blit(memory_bitmap[item[x][10]], level_2000, 0, 0, c*20, y*20, 20, 20);
                                                          putpixel(map100_bkg, c, y, 10);
                                                          draw_lift_lines();
                                                       }
                                                    else if (l[c][y] == item[x][10]) /* solid block */
                                                       {
                                                          l[c][y] = item[x][11]; /* replace with empty */
                                                          blit(memory_bitmap[item[x][11]], level_2000, 0, 0, c*20, y*20, 20, 20);
                                                          putpixel(map100_bkg, c, y, 0);
                                                          draw_lift_lines();
                                                       }
                                                 }
                                       }
                              }

                         break;
                         case 15: /* Sproingy */
                           /* if falling and landing on it and jump pressed */

                            if ((PX > itemf[x][0] - 10) && (PX < itemf[x][0] + 10))
                                 if ((PY > itemf[x][1] - 16) && (PY < itemf[x][1] - 8))
                                     if (fall_count)
                                       if (jump)
                                          {
                                              extern float jump_sinc;
                                              extern float pmovey;
                                              extern int ex_jump;
                                              event(31);
                                              ex_jump = 1;
                                              jump_count=1.27;
                                              jump_sinc=item[x][6];
                                              jump_sinc = jump_sinc/100;
                                              if (jump_sinc < .005) jump_sinc = .05;
                                              pmovey = item[x][7];
                                              if (pmovey < 5) pmovey = 5;

                                          }

                         break;


             
                      } /* end of switch case */
               } /* end of if on screen */

}
proc_lit_rocket()
{
   int speed, shape;
   float angle;

   /* get these from item data */

   int accel = 12;
   int max_speed = 8000;
   int rot_inc = 12;

   for (c=0; c<500; c++)
      if (item[c][0] == 98) /* lit rocket! */
         {
            int speed = item[c][11];
            int max_speed = item[c][8]*1000;
            int accel = item[c][9];
            int rot_inc = item[c][6];
            lit_item = 1;

            if (item[c][11] < max_speed) item[c][11]+=accel; /* speed and accel */

            /* set angle and speed */
            angle = ( (float) (item[c][10]-640) / 64/10)*1.57; /* convert to radians */

            itemf[c][2] = cos(angle) * item[c][11]/1000;  /* hypotenuse is the speed! */
            itemf[c][3] = sin(angle) * item[c][11]/1000;

            x = itemf[c][0] += itemf[c][2]; /* do the increments */
            y = itemf[c][1] += itemf[c][3];

            shape = zz[0][item[c][1]-1000]; /* ans */
            rotate_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY, itofix(item[c][10]/10));
            if (game_map_on) putpixel(map100_bmp, x/20, y/20, 14);
            if (c == (player_carry-1)) /* player is riding this rocket! */
               {
                  fall_count=0;
                  PY = itemf[c][1] + itemf[c][3];
                  if (PX >= itemf[c][0]) PX = itemf[c][0] + itemf[c][2] +14;
                  if (PX < itemf[c][0])  PX = itemf[c][0] + itemf[c][2] -14;
                  PXint = PX;
                  PYint = PY;

                  if (left)  item[c][10]-=rot_inc;
                  if (right) item[c][10]+=rot_inc;

               }
            if ( ((itemf[c][3]<0) && (is_up_solid(x,y,0,0)==1)) ||
                 ((itemf[c][3]>0) && (is_down_solid(x,y,0)==1)) )
               {
                  if (c == (player_carry-1)) /* player is riding this rocket! */
                     if (is_down_solid(PXint, PYint,0)==1)
                        PY -= fmod (PY, 20); /* align with floor */

                  for (d=0; d<20; d++)  /* make boom! */
                     if (!bomb[d][0])  /* find empty */
                        {
                           itemf[c][3] = .1; /* slow down */
                           bomb[d][0] = 32 + c; /* link to item */
                           bomb[d][1] = 5; /* total fuse wait */
                           bomb[d][2] = 1; /* seq fuse wait */
                           bomb[d][3] = item[c][7]; /* damage */
                           bomb[d][4] = 1; /* for blow up */
                           item[c][0] = 99; /* change to lit bomb */
                           d = 20; /* end bomb loop */
                        }

                     if (d == 19) item[c][0] = 0; /* erase, if no space in the bomb array */
               }
         }
}
proc_player_carry()
{
   if (player_carry)  /* move with player */
      {
         int pc = player_carry-1;
         if (item[pc][0] != 98) /* not lit rocket */
            {
               itemf[pc][1] = PY - 2;
               if (!left_right) itemf[pc][0] = PX - 15;
               if (left_right) itemf[pc][0] = PX + 15;
               x = (int) itemf[pc][0];
               y = (int) itemf[pc][1];
               if (game_map_on) putpixel(map100_bmp, x/20, y/20, 7);
               if (item[pc][0] != 99) /* not lit bomb */
                     {
                       int shape;
                       a = item[pc][1]; /* get shape */
                       if (a < NUM_SPRITES) shape = a; /* bitmap */
                       if (a > 999) shape = zz[0][a-1000]; /* ans */
                       if (item[pc][2] == 1) /* draw mode normal */
                           draw_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY);
                     }
               }
         if (!fire) /* drop */
            {
               player_carry = 0;
               if (item[pc][0] != 98) /* not lit rocket */
                  {
                     x = itemf[pc][0];
                     y = itemf[pc][1];
                     itemf[pc][2] = 0;  /* xinc = 0 */
                     if (fall_count) itemf[pc][3] = (sin(1.57-fall_count) * pmovey);
                     if (jump_count) itemf[pc][3] = (sin(jump_count) * pmovey);
  
                     if (up) itemf[pc][3] = - 6 -(sin(jump_count) * pmovey)/4 ; /* throw up */

                     if (p_xmove > 0)
                        if (!is_right_solid(x,y))
                           itemf[pc][2] = p_xmove;
  
                     if (p_xmove < 0)
                        if (!is_left_solid(x,y))
                           itemf[pc][2] = p_xmove;
                  }
               else /* lit rocket */
                  {

                  }

            } /* end of if (!fire) */
      } /* end of if player carry */
}
proc_lit_bomb()
{
   for (d=0; d<20; d++)   /* lit bomb handler! */
      if (bomb[d][0])   /* bomb lit! */
         {
            lit_item = 1;
            if (--bomb[d][1] > 0)  /* dec the fuse count */
               {
                  e = bomb[d][1] / bomb[d][2]; /* shape # */
                  c = zz[16-e][25];
                  x = itemf[bomb[d][0]-32][0];
                  y = itemf[bomb[d][0]-32][1];
   
                  if (bomb[d][1] < (bomb[d][2] * 5)) /* start blow-up */
                     {
                        if (player_carry-1 == bomb[d][0]-32) player_carry = 0;
                        a = ((bomb[d][2] * 6) - bomb[d][1]); /* 50 - ticks */
                        a = 2 * a * bomb[d][3]; /* 2 times damage */
                        a = a / (bomb[d][2] * 5);  /* / 50 */
   
                        if (game_map_on)
                           {
                              rect(map100_bmp, (x/20)-(a/40), (y/20)-(a/40),(x/20)+(a/40), (y/20)+(a/40),10);
                              stretch_sprite(map100_bmp, memory_bitmap[c], (x/20) - (a/40), (y/20) - (a/40), 1 + (a/20), 1 + (a/20) );
                           }
                        stretch_sprite(scrn_buffer, memory_bitmap[c], (x-WX) - (a/2), (y-WY) - (a/2), 20 + a, 20 +a );
                     }
                  else draw_sprite(scrn_buffer, memory_bitmap[c], x-WX, y-WY);
               }
            if (bomb[d][1] < (bomb[d][2] * 6)) /* fuse done !*/
               if (bomb[d][4])  /* first time only */
                  {
                     /* check for other co-located bombs */
                     for (c=0; c<20; c++)
                        if ((bomb[c][0]) && (c != d))
                           if (x == itemf[bomb[c][0]-32][0])
                              if (y == itemf[bomb[c][0]-32][1])
                                 if (bomb[d][1] == bomb[c][1]-1)
                                    {
                                       item[ bomb[c][0]-32 ] [0] = 0;
                                       bomb[c][0] = 0;
                                    }

                     event(22);
                     bomb[d][1] = 23;  /* speed up ans */
                     bomb[d][2] = 4;
                     bomb[d][4] = 0;
                  }
            if (bomb[d][1] < (bomb[d][2] * 3)) /* do the damage! */
               {
                  extern int Ei[100][32];
                  extern float Ef[100][16];
                  c = bomb[d][3];  /* damage window */
                  x = itemf[ bomb[d][0]-32 ][0];
                  y = itemf[ bomb[d][0]-32 ][1];
   
                  for (e=0;e<100;e++) /* enemies in damage window? */
                     if (Ei[e][0])
                        if (Ef[e][0] > ((x-c)) )
                           if (Ef[e][0] < ((x+c)) )
                              if (Ef[e][1] > ((y-c)) )
                                 if (Ef[e][1] < ((y+c)) )
                                    {
                                       Ei[e][31] = 2; /* set bomb hit */
                                       event(23);
                                    }
   
                  if (PX > (x-c)) /* is player in window?*/
                     if (PX < (x+c))
                        if (PY > (y-c))
                           if (PY < (y+c))
                              {
                                 LIFE -= 3;
                              }
                  c /= 20;  /* convert to (0-100)  */
                  x /= 20;
                  y /= 20;
   
                  for (e = (x-c); e < (x+c)+1; e++)    /* erase on the maps */
                     for (f = (y-c); f < (y+c)+1; f++)
                       if ((e>0) && (e<99) && (f>0) && (f<99)) /* if on screen */
                           if ((l[e][f] > 63) && (l[e][f] < 96)) /* if bombable */
                                 {
                                    l[e][f] = 0;
                                    putpixel(map100_bkg, e, f, map_empty_color);
                                    blit(memory_bitmap[0], level_2000, 0, 0, e*20, f*20, 20, 20);
                                 }
                  draw_lift_lines();
               } /* end of damage */
            if (bomb[d][1] < 1)  /* bomb done */
               {
                  item[ bomb[d][0]-32 ] [0] = 0;
                  bomb[d][0] = 0;  /* set to inactive */
               }
         } /* end of if lit bomb */
}
