#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"
#include "lift.h"

extern int num_lifts;
extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

void draw_edit_item_shape(int x, int y, int obt, int sub_type, int num)
{
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern int zz[20][NUM_ANS];
   extern int Ei[100][32];
   extern int item[500][16];
   extern int bts, txc, ty;  /* button centre */

   show_mouse(NULL);

   if (obt == 2) /* item */
      draw_item_shape(num, x, y);
   if (obt == 3)
      {
         draw_enemy_shape(num, x, y);
         if (sub_type == 4) /* bouncer shape toggle buttons */
            {
            }
      }
   show_mouse(screen);
}
void edit_cb(int mb, int num)
{
   extern int Ei[100][32];
   extern int edit_int_retval;
   extern int txc;  /* button centre */
   extern int ty;   /* button y start */
   extern int bts;  /* button y spacing */
   if (edit_int(txc+48, ty+(mb*bts)+2, Ei[num][9], 1, 8, 18)) Ei[num][9] = edit_int_retval;
}
void edit_hd(int mb, int num)
{
   extern float Ef[100][16];
   extern float finitial, fxinc, fyinc, flv, fuv, edit_float_retval;
   extern int txc;  /* button centre */
   extern int ty;   /* button y start */
   extern int bts;  /* button y spacing */

   fxinc=.1;   /* y inc */
   fyinc=.01;   /* x inc */
   flv=.1;     /* lv    */
   fuv=2;   /* uv    */
   finitial = Ef[num][4];
   if (edit_float(txc+24, ty+(mb*bts)+2)) Ef[num][4] = edit_float_retval;
}

void draw_button(int b_num, char *msg, int tc, int rc)
{
   extern int txc;  /* button centre */
   extern int tw;   /* button width */
   extern int ty;   /* button y start */
   extern int bts;  /* button y spacing */
   int y = ty + (bts*b_num);
   int x1 = txc - tw;
   int x2 = txc + tw;
   textout_centre(screen, font, msg, txc, y+(bts-8)/2, tc);
   rect(screen, x1, y, x2, y+bts-2, rc);
}
void crosshairs(int mx, int my, int x, int y, int color) /* funtion to draw rentangle and crosshairs */
{
   extern int db;
   rectfill(screen, mx+(x*db), my+(y*db), mx+(x*db)+db-1, my+(y*db)+db-1, color);
   hline(screen, mx, my+(y*db)+db/2, mx+(100*db), color);
   vline(screen, mx+(x*db)+db/2, my, my+(100*db), color);
}
void title(char *txt, int y, int tc, int fc)
{
   extern int txc;
   extern int db;
   int x;
   for (x = 0; x < 15; x++)
      hline(screen, db*100, y+x, SCREEN_W, fc+(x*16));
   text_mode(-1);
   textout_centre(screen, font, txt, txc, y+3, tc);
   text_mode(0);
}
int item_sort(void)
{
   extern int item_num_of_type[20];   /* sort stuff used by others */
   extern int item_first_num[20];
   extern int item[500][16];
   extern char item_desc[20][40];
   extern char* pmsg[500];
   char msg[2000];
   int inum, b, c, d, quit, temp, swap;
   quit=0;
   while (!quit) /* sort item list */
      {
         quit=1; /* quit if no swap */
         for (c=0; c < 499; c++)
            {
               if (item[c][0] < item[c+1][0]) /* sort by first value 'type' */
                  swap = 1;
               else if (item[c][0] == item[c+1][0]) /* if type is the same */
                  if (item[c][1] < item[c+1][1]) /* sort by 2nd value 'ans' */
                     swap =1;
               if (swap)
                  {
                     quit=0;      /* as long as a swap has been made */
                     swap = 0;
                     if ((item[c][0] == 10) && (item[c+1][0] == 10)) /* both messages */
                        {
                           strcpy(msg, pmsg[c]);
                           free(pmsg[c]);
                           pmsg[c] = (char*) malloc (strlen(pmsg[c+1])+1);
                           strcpy(pmsg[c], pmsg[c+1]);
                           free(pmsg[c+1]);
                           pmsg[c+1] = (char*) malloc (strlen(msg)+1);
                           strcpy(pmsg[c+1], msg);
                        }
                     if ((item[c][0] == 10) && (item[c+1][0] != 10)) /* first only */
                        {
                           pmsg[c+1] = (char*) malloc (strlen(pmsg[c])+1);
                           strcpy(pmsg[c+1], pmsg[c]);
                           free(pmsg[c]);
                        }
                     if ((item[c][0] != 10) && (item[c+1][0] == 10)) /* second only */
                        {
                           pmsg[c] = (char*) malloc (strlen(pmsg[c+1])+1);
                           strcpy(pmsg[c], pmsg[c+1]);
                           free(pmsg[c+1]);
                        }
                     for (d=0; d<16; d++)
                        {
                           temp = item[c][d];
                           item[c][d] = item[c+1][d];
                           item[c+1][d] = temp;
                        }

                }
            }
      }

   /* get data about first 20 item types  */
   /* and make sub lists of item types using these variables */
   inum = 0;    /* zero the counters */
   for (c=0; c<20; c++)
      {
         item_num_of_type[c] = 0;
         item_first_num[c] = 0;
      }
   
   for (c=0; c<500; c++)    /* get the type counts */
      {
         item_num_of_type[item[c][0]]++;   /* inc number of this type */
         if (item[c][0]) inum++;
      }
   for (c=0; c<20; c++)  /* get first nums */
      if (item_num_of_type[c] > 0)  /* are there any of this type?  */
         for (d=0; d<500; d++)
            if (item[d][0] == c)
               {
                  item_first_num[c] = d;
                  d=500;   /* exit loop */
               }
   return inum;
}

void title_obj(int obj_type, int sub_type, int num)
{
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern int zz[20][NUM_ANS];
   extern int l[100][100];
   extern int Ei[100][32];
   extern float Ef[100][16];
   extern int e_num_of_type[50];   /* sort results */
   extern int e_first_num[50];
   extern char eitype_desc[50][32][40];

   extern int item[500][16];
   extern int item_num_of_type[20];   /* sort results */
   extern int item_first_num[20];
   extern char item_desc[20][40];

   extern BITMAP *mp;
   extern char msg[80];
   extern int current_lift;

   extern int txc;
   extern int db;
   extern int txc;  /* button centre */
   extern int tw;   /* button width */
   extern int ty;   /* button y start */
   extern int bts;  /* button y spacing */

   char lmsg[5][80];
   int nll; /* num of legend lines */
   int lc[5];

   int b, x, y, x1, y1;

   if (obj_type == 2)  /* item x, y */
      {
         x1 = item[num][4]/20;
         y1 = item[num][5]/20;
      }
   if (obj_type == 3) /* enemy x, y */
      {
         x1 = Ef[num][0]/20;
         y1 = Ef[num][1]/20;
      }
   if (obj_type == 4)  /* lift x, y */
      {
         x1 = lifts[num]->x1;
         y1 = lifts[num]->y1;
      }

   show_mouse(NULL);
   clear(screen);

   if (obj_type == 2) title("Item Viewer",  0, 15, 13);
   if (obj_type == 3) title("Enemy Viewer", 0, 15, 13);
   if (obj_type == 4) title("Lift Viewer",  0, 15, 13);

   show_big();

   /* draw  location crosshairs */
   if (obj_type != 4) crosshairs(0, 0, x1, y1, 13);

   /* outline map  */
   rect(screen, 0, 0, 100*db-1, 100*db-1, 13);
   /* outline screen */
   rect(screen, 0, 0,  SCREEN_W-1, 100*db-1, 13);

   /* show the obj num and num of subtype */

   if (obj_type != 4) /* no legend for lift */
      {
         nll = 2; /* default number of lines */
      
         for (x=0; x<5; x++) /* clear text */
            sprintf(lmsg[x],"");
      
         /* default line colors */
         lc[0] = 7;   /* legend color */
         lc[1] = 13;  /* location color */
         lc[2] = 14;  /*  yellow  */
         lc[3] = 10;  /*   red */
         lc[4] = 0;  /* unused */
       }
   if (obj_type == 4)  /* lifts */
      {
         /* draw small lift */
         draw_lift_mp();
         draw_sprite(screen, mp, txc - 86, 24);
      
         /* draw current lift num and num of lifts */
         rect(screen, txc-90, 20, txc+90, 43, 15);
         sprintf(msg,"Lift %d of %d",current_lift+1, num_lifts);
         textout_centre(screen, font, msg, txc, 29, 13);
      }
   if (obj_type == 3)  /* enemies */
      {
         rect(screen, txc-tw, 20, txc+tw, 43, 15);
         draw_enemy_shape(num, txc-tw+2, 22);
         sprintf(msg,"%s %d of %d", eitype_desc[sub_type],1+num - e_first_num[sub_type],e_num_of_type[sub_type]);
         textout(screen, font, msg, txc-tw+28, 29, 13);
         switch (sub_type)
            {
               case 3:
                  {
                     int bs = Ei[num][17]/20*db;
                     /* draw yellow bullet prox */
                     rect(screen, (x1*db)-bs, (y1*db)-bs, (x1*db)+db-1+bs, (y1*db)+db-1+bs, 14);
                     sprintf(lmsg[1],"ArchWagon Location");
                     sprintf(lmsg[2],"Bullet Proximity");
                     nll = 3;
      
                  }
               break;

               case 4: sprintf(lmsg[1],"Bouncer Location"); break;
               case 6: sprintf(lmsg[1],"Cannon Location"); break;
               case 7:
                  {
                     int bs = Ei[num][8]/20*db;
                     float ex, ey;
                     int j;
                     char msg[80];
                     ex = Ef[num][0];
                     ey = Ef[num][1];
                     sprintf(lmsg[1],"Podzilla Location");
                     sprintf(lmsg[2],"Trigger Box");
                     sprintf(lmsg[3],"Extended Postion");
                     nll = 4;
                     /* draw trigger box */
                     rect(screen, (Ei[num][11]+1)*db, (Ei[num][12]+1)*db, Ei[num][13]*db, Ei[num][14]*db, 14);
      
                     /* extended position */
                     for (j=0; j<Ei[num][6]; j++)
                        {
                           ex = ex + Ef[num][2];
                           ey = ey + Ef[num][3];
                        }
                     crosshairs(0,0, ex/20, ey/20, 10);
                  }
               break;
               case 8:
                 {
                     int bs = Ei[num][17]/20*db;
                     sprintf(lmsg[1],"TrakBot Location");
                     sprintf(lmsg[2],"Bullet Proximity");
                     nll = 3;
      
                     /* draw yellow bullet prox */
                     rect(screen, (x1*db)-bs, (y1*db)-bs, (x1*db)+db-1+bs, (y1*db)+db-1+bs, 14);
                 }
               break;
               case 9:
                  {
      
                     int cx1 = Ef[num][6]-2;    /* source x */
                     int cy1 = Ef[num][7]-2;    /* source y */
                     int cx2 = cx1 + Ef[num][2];   /* sizes */
                     int cy2 = cy1 + Ef[num][3];
                     int cx3 = Ef[num][8]-2;    /* dest x */
                     int cy3 = Ef[num][9]-2;    /* dest y */
                     int cx4 = cx3 + Ef[num][2];   /* sizes */
                     int cy4 = cy3 + Ef[num][3];

                     /* draw trigger box */
                     rect(screen, (Ei[num][11]+1)*db, (Ei[num][12]+1)*db, Ei[num][13]*db, Ei[num][14]*db, 14);


                     rect(screen, (cx1*db)/20, (cy1*db)/20, (cx2*db)/20, (cy2*db)/20, 10);
                     rect(screen, (cx3*db)/20, (cy3*db)/20, (cx4*db)/20, (cy4*db)/20, 11);
                     sprintf(lmsg[1],"Cloner Location");
                     sprintf(lmsg[2],"Source Area");
                     sprintf(lmsg[3],"Destination Area");
                     sprintf(lmsg[4],"Trigger Box");
                     nll = 5;
                     lc[2] = 10;
                     lc[3] = 11;
                     lc[4] = 14;
                  }
               break;
               case 11: sprintf(lmsg[1],"Block Walker Location"); break;
               case 12:
                  {
                     int bw = Ei[num][17]/20*db;
                     int by1 = Ei[num][18]/20*db;
                     int by2 = Ei[num][19]/20*db;

                     /* draw yellow bullet prox */
                     rect(screen, (x1*db)-bw, (y1*db)-by1, (x1*db)+db-1+bw, (y1*db)+db-1+by2, 14);
                     sprintf(lmsg[1],"Flapper Location");
                     sprintf(lmsg[2],"Bullet Trigger Box");
                     nll = 3;
                  }
              break;
            }
      }
   if (obj_type == 2)  /* items */
      {
         rect(screen, txc-tw, 20, txc+tw, 43, 15);
         draw_item_shape(num, txc-tw+2, 22);
         sprintf(msg,"%s %d of %d", item_desc[sub_type], 1+num - item_first_num[sub_type],item_num_of_type[sub_type]);
         textout(screen, font, msg, txc-tw+28, 29, 13);
         switch (sub_type)
            {
               case 1: /* door */
                  {
                     int x2 = item[num][6];
                     int y2 = item[num][7];
                     /* draw destination */
                     crosshairs(0, 0, x2, y2, 10);
                     sprintf(lmsg[1],"Door Location");
                     sprintf(lmsg[2],"Destination");
                     lc[2]=10;
                     nll = 3;
                  }
               break;
               case 2: sprintf(lmsg[1],"Bonus Location"); break;
               case 3: sprintf(lmsg[1],"Exit Location"); break;
               case 4: /* key */
                  {
                     int x2 = item[num][6];
                     int y2 = item[num][7];
                     int x3 = item[num][8];
                     int y3 = item[num][9];
                     int x4 = (x2+x3)/2;
                     int y4 = (y2+y3)/2;
      
                     /* draw range */
                     hline(screen, 0, y4*db+db/2, 100*db-1, 10);
                     vline(screen, x4*db+db/2, 0, 100*db-1, 10);
                     rect(screen, x2*db, y2*db, x3*db+db-1, y3*db+db-1, 10);
                     sprintf(lmsg[1],"Key Location");
                     sprintf(lmsg[2],"Block Range");
                     lc[2]=10;
                     nll = 3;
                  }
               break;
               case 5: sprintf(lmsg[1],"Start Location"); break;
               case 6: sprintf(lmsg[1],"Free Man Location"); break;
               case 7: sprintf(lmsg[1],"Mine Location"); break;
               case 8:
                  {
                       int bs = (item[num][7] / 20) * db;
                       sprintf(lmsg[1],"Bomb Location");
                       sprintf(lmsg[2],"Damage Range");
                       lc[2]=14;
                       nll = 3;
      
                     /* draw yellow bomb damage */
                     rect(screen, x1*db-bs, y1*db-bs, x1*db+db-1+bs, y1*db+db-1+bs, 14);
                  }
               break;
               case 10: sprintf(lmsg[1],"Message Location"); break;
               case 11:
                  {
                       int bs = (item[num][7] / 20) * 7;
                       sprintf(lmsg[1],"Rocket Location");
                       sprintf(lmsg[2],"Damage Range");
                       lc[2]=14;
                       nll = 3;
                     /* draw yellow bomb damage */
                     rect(screen, x1*db-bs, y1*db-bs, x1*db+db-1+bs, y1*db+db-1+bs, 14);
                  }
               break;
               case 12: sprintf(lmsg[1],"Warp Location"); break;
               case 14: sprintf(lmsg[1],"Switch Location"); break;
               case 15: sprintf(lmsg[1],"Sproingy Location"); break;
            } /* end of switch case */
      }  /* end of items */

   if (obj_type != 4)  /* no legend for lifts */
      {
         /* draw text lines */
         for (x=1; x<nll; x++)
             textout_centre(screen, font, lmsg[x], txc, db*100-26+(3-nll+x)*8, lc[x]);
      
         textout_centre(screen, font,   "Legend", txc, db*100-36+ (4-nll)*8, lc[0]);
      
         /* big frame */
         rect(screen, txc-100, db*100-38+ (4-nll)*8, txc+100, db*100-1, 13);
      
         /* top frame */
         rect(screen, txc-100, db*100-38+ (4-nll)*8, txc+100, db*100-28+ (4-nll)*8, 13);
      }
}
void edit_item(int ei, int num) /* BOTH ENEMIES AND ITEMS */
{
   extern int Ei[100][32];
   extern float Ef[100][16];
   extern int e_num_of_type[50];   /* sort results */
   extern int e_first_num[50];

   extern int item[500][16];
   extern int item_num_of_type[20];   /* sort results */
   extern int item_first_num[20];
   extern char item_desc[20][40];
   extern int edit_int_retval;
   extern float finitial, fxinc, fyinc, flv, fuv, edit_float_retval;
   extern int txc;
   extern int db;
   extern int ty;   /* button start */
   extern int tw;   /* button width */
   extern int bts;  /* button spacing */

   extern int rits;  /* redraw slider linker */
   extern int gnum;


   int mb;  /* button selection */
   int obt;  /* object type  */
   int type; /* sub type */

   int redraw = 1;
   char msg[80];
   int quit = 0;
   int a, b, c, d, e, f;

   int xa = txc-tw;
   int xb = txc+tw;
   xa = 4+SCREEN_W-(SCREEN_W-(db*100));
   xb = SCREEN_W-4;

   rits = 0;
   bts = 18;


   if (!ei)
      {
         obt = 2;    /* items */
         type = item[num][0];
      }
   else
      {
         obt = 3; /* enemies */
         type = Ei[num][0];
      }
   while (!quit)
      {
         if  ( (key[KEY_ESC]) || (mouse_b & 2)) quit = 1;

         mb = 0;

         /* loop sliders */
          a=0;
          /* common buttons */
          edit_int_slider(xb-40, ty-33, xb, ty-27, 26, num, type, obt, 0,15,0,10,0,0,0,0); /* button height */

          if (new_button(xa, ty+((a+0)*bts), txc-50, ty+((a+1)*bts)-2, 22,    num, type, obt, 0,  13, 13,  0,   0,0,0,0)) mb = 21;  /* next */
          if (new_button(txc+10, ty+((a+0)*bts), xb, ty+((a+1)*bts)-2, 23,    num, type, obt, 0,  13, 13,  0,   0,0,0,0)) mb = 22; /* prev */
          if (new_button(txc-46, ty+((a+0)*bts), txc+6, ty+((a+1)*bts)-2, 25, num, type, obt, 0,  12, 8,  0,   0,0,0,0)) mb = 24;  /* help */

          if (new_button(xa, ty+((a+1)*bts), txc-40, ty+((a+2)*bts)-2, 19, num, type, obt, 0,3,9,0,0,0,0,0)) mb = 18;  /* move item location */
          if (new_button(txc+30, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 20, num, type, obt, 0,3,9,0,0,0,0,0)) mb = 19;  /* create new */
          if (new_button(txc-36, ty+((a+1)*bts), txc+26, ty+((a+2)*bts)-2, 21, num, type, obt, 0,10,10,0,0,0,0,0)) mb = 20;  /* delete */

          if (new_button(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 24, num, type, obt, 0,7,6,0,0,0,0,0)) mb = 23;  /* copy */
          a += 2;

         if (obt == 3) /* enemies */
            {
               switch (type) /* enemy subtypes */
                  {
                     case 3: /* archwag */
                            edit_int_slider(xa, ty+((a+1 )*bts), xb, ty+((a+2 )*bts)-2, 12, num, type, obt, 0, 12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+2 )*bts), xb, ty+((a+3 )*bts)-2, 13, num, type, obt, 0, 12,15,11,0,0,0,0);
                                 new_button(xa, ty+((a+3 )*bts), xb, ty+((a+4 )*bts)-2, 8,  num, type, obt, 0, 7, 6,0,0,0,0,0);
                                 new_button(xa, ty+((a+4 )*bts), xb, ty+((a+5 )*bts)-2, 9,  num, type, obt, 0,15,13,0,0,0,0,0);
                            edit_int_slider(xa, ty+((a+6 )*bts), xb, ty+((a+7 )*bts)-2, 15, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+7 )*bts), xb, ty+((a+8 )*bts)-2, 16, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+8 )*bts), xb, ty+((a+9 )*bts)-2, 17, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+9 )*bts), xb, ty+((a+10)*bts)-2, 18, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+10)*bts), xb, ty+((a+11)*bts)-2, 19, num, type, obt, 0,9,0,9,0,0,0,0);
                            edit_int_slider(xa, ty+((a+11)*bts), xb, ty+((a+12)*bts)-2, 20, num, type, obt, 0,9,0,9,0,0,0,0);
                            edit_int_slider(xa, ty+((a+12)*bts), xb, ty+((a+13)*bts)-2, 21, num, type, obt, 0,9,0,9,0,0,0,0);
                            edit_int_slider(xa, ty+((a+13)*bts), xb, ty+((a+14)*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+14)*bts), xb, ty+((a+15)*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+15)*bts), xb, ty+((a+16)*bts)-2, 41, num, type, obt, 0,4,14,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+16)*bts), xb, ty+((a+17)*bts)-2, 42, num, type, obt, 0,4,14,11,0,0,0,0);
                            a += 17;
                     break;
                     case 4: /* bouncer */
                                 new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 10, num, type, obt, 0,12,15,0,0,0,0,0);
                            edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 22, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+3)*bts), xb, ty+((a+4)*bts)-2, 23, num, type, obt, 0,12,15,11,0,0,0,0);

                                 new_button(xa, ty+((a+5)*bts), xb, ty+((a+6)*bts)-2, 13, num, type, obt, 0,8,9,0,0,0,0,0);
                                 new_button(xa, ty+((a+7)*bts), xb, ty+((a+8)*bts)-2, 14, num, type, obt, 0,8,9,0,0,0,0,0);

                            edit_int_slider(xa, ty+((a+9 )*bts), xb, ty+((a+10)*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+10)*bts), xb, ty+((a+11)*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+11)*bts), xb, ty+((a+12)*bts)-2, 41, num, type, obt, 0,4,14,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+12)*bts), xb, ty+((a+13)*bts)-2, 42, num, type, obt, 0,4,14,11,0,0,0,0);
                            a += 13;
                     break;
                     case 6: /* cannon */
                                 new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 10, num, type, obt, 0,12,15,0,0,0,0,0);
                            edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 22, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+3)*bts), xb, ty+((a+4)*bts)-2, 23, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+4)*bts), xb, ty+((a+5)*bts)-2, 19, num, type, obt, 0,10,0,10,0,0,0,0);
                            edit_int_slider(xa, ty+((a+5)*bts), xb, ty+((a+6)*bts)-2, 21, num, type, obt, 0,10,0,10,0,0,0,0);

                            edit_int_slider(xa, ty+((a+6)*bts), xb, ty+((a+7)*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+7)*bts), xb, ty+((a+8)*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+8)*bts), xb, ty+((a+9)*bts)-2, 35, num, type, obt, 0,15,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+9)*bts), xb, ty+((a+10)*bts)-2, 41, num, type, obt, 0,4,14,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+10)*bts), xb, ty+((a+11)*bts)-2, 42, num, type, obt, 0,4,14,11,0,0,0,0);
                            a += 11;
                     break;
                     case 7: /* podzilla */
                            edit_int_slider(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 29, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 30, num, type, obt, 0,15,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+3)*bts), xb, ty+((a+4)*bts)-2, 19, num, type, obt, 0,15,0,14,0,0,0,0);
                                 new_button(xa, ty+((a+4)*bts), xb, ty+((a+5)*bts)-2, 15, num, type, obt, 0,10,10,0,0,0,0,0);
                                 new_button(xa, ty+((a+5)*bts), xb, ty+((a+6)*bts)-2, 16, num, type, obt, 0,14,14,0,0,0,0,0);
                            edit_int_slider(xa, ty+((a+6)*bts), xb, ty+((a+7)*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+7)*bts), xb, ty+((a+8)*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+8)*bts), xb, ty+((a+9)*bts)-2, 41, num, type, obt, 0,4,14,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+9)*bts), xb, ty+((a+10)*bts)-2, 42, num, type, obt, 0,4,14,11,0,0,0,0);
                            a += 10;
                     break;
                     case 8: /* trakbot */
                            edit_int_slider(xa, ty+((a+1 )*bts), xb, ty+((a+2 )*bts)-2, 45, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+2 )*bts), xb, ty+((a+3 )*bts)-2, 46, num, type, obt, 0,12,15,11,0,0,0,0);
                                 new_button(xa, ty+((a+3 )*bts), xb, ty+((a+4 )*bts)-2, 11, num, type, obt, 0,11,11,0,0,0,0,0);
                                 new_button(xa, ty+((a+4 )*bts), xb, ty+((a+5 )*bts)-2, 12, num, type, obt, 0,11,11,0,0,0,0,0);
                            edit_int_slider(xa, ty+((a+5 )*bts), xb, ty+((a+6 )*bts)-2, 20, num, type, obt, 0,9,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+6 )*bts), xb, ty+((a+7 )*bts)-2, 19, num, type, obt, 0,9,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+7 )*bts), xb, ty+((a+8 )*bts)-2, 21, num, type, obt, 0,9,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+8 )*bts), xb, ty+((a+9 )*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+9 )*bts), xb, ty+((a+10)*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+10)*bts), xb, ty+((a+11)*bts)-2, 41, num, type, obt, 0,4,14,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+11)*bts), xb, ty+((a+12)*bts)-2, 42, num, type, obt, 0,4,14,11,0,0,0,0);
                            a = +12;
                     break;
                     case 9: /* cloner */
                            edit_int_slider(xa, ty+((a+ 1)*bts), xb, ty+((a+2 )*bts)-2, 34, num, type, obt, 0,12,15,11,0,0,0,0);
                                 new_button(xa, ty+((a+ 2)*bts), xb, ty+((a+3 )*bts)-2, 27, num, type, obt, 0,12,15,0,0,0,0,0);
                                 new_button(xa, ty+((a+ 3)*bts), xb, ty+((a+4 )*bts)-2, 17, num, type, obt, 0,10,10,0,0,0,0,0);
                                 new_button(xa, ty+((a+ 4)*bts), xb, ty+((a+5 )*bts)-2, 18, num, type, obt, 0,11,11,0,0,0,0,0);
                                 new_button(xa, ty+((a+ 5)*bts), xb, ty+((a+6 )*bts)-2, 16, num, type, obt, 0,14,14,0,0,0,0,0);
                            edit_int_slider(xa, ty+((a+ 6)*bts), xb, ty+((a+7 )*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+ 7)*bts), xb, ty+((a+8 )*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+ 8)*bts), xb, ty+((a+9 )*bts)-2, 41, num, type, obt, 0,4,14,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+ 9)*bts), xb, ty+((a+10)*bts)-2, 42, num, type, obt, 0,4,14,11,0,0,0,0);
                            a += 10;
                     break;
                     case 11: /* block walker */
                            edit_int_slider(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 12, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 13, num, type, obt, 0,12,15,11,0,0,0,0);
                                 new_button(xa, ty+((a+3)*bts), xb, ty+((a+4)*bts)-2, 8, num, type, obt, 0,7,6,14,0,0,0,0);
                                 new_button(xa, ty+((a+4)*bts), xb, ty+((a+5)*bts)-2, 9, num, type, obt, 0,15,13,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+6)*bts), xb, ty+((a+7)*bts)-2, 15, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+7)*bts), xb, ty+((a+8)*bts)-2, 16, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+8)*bts), xb, ty+((a+9)*bts)-2, 17, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+9)*bts), xb, ty+((a+10)*bts)-2, 18, num, type, obt, 0,7,15,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+10)*bts), xb, ty+((a+11)*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+11)*bts), xb, ty+((a+12)*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            a += 12;
                     break;
                     case 12: /* flapper */
                            edit_int_slider(xa, ty+((a+1 )*bts), xb, ty+((a+2 )*bts)-2, 33, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+2 )*bts), xb, ty+((a+3 )*bts)-2, 36, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+3 )*bts), xb, ty+((a+4 )*bts)-2, 19, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+4 )*bts), xb, ty+((a+5 )*bts)-2, 21, num, type, obt, 0,12,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+5 )*bts), xb, ty+((a+6 )*bts)-2, 38, num, type, obt, 0,14,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+6 )*bts), xb, ty+((a+7 )*bts)-2, 39, num, type, obt, 0,14,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+7 )*bts), xb, ty+((a+8 )*bts)-2, 40, num, type, obt, 0,14,0,14,0,0,0,0);
                            edit_int_slider(xa, ty+((a+8 )*bts), xb, ty+((a+9 )*bts)-2, 24, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+9 )*bts), xb, ty+((a+10)*bts)-2, 25, num, type, obt, 0,4,15,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+10)*bts), xb, ty+((a+11)*bts)-2, 41, num, type, obt, 0,4,14,11,0,0,0,0);
                            edit_int_slider(xa, ty+((a+11)*bts), xb, ty+((a+12)*bts)-2, 42, num, type, obt, 0,4,14,11,0,0,0,0);
                            a += 12;
                     break;
                  }
             }

         if (obt == 2) /* items */
            {
               switch (type) /* item subtypes */
                  {
                     case 1: /* door */
                             new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 2, num, type, obt, 0,15,13,14,0,0,0,0);
                             new_button(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 4, num, type, obt, 0,10,10,0,0,0,0,0);
                             a += 3;
                     break;
                     case 2: /* bonus */
                             new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 26, num, type, obt, 0,15,13,14,0,0,0,0);
                             if (item[num][7])
                                edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 1, num, type, obt, 0,12,0,11,0,0,0,0);
                             if (item[num][8])
                                edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 2, num, type, obt, 0,12,0,11,0,0,0,0);
                             if (item[num][9])
                                edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 3, num, type, obt, 0,12,0,11,0,0,0,0);
                             a += 3;
                     break;
                     case 3: /* exit */
                             new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 26, num, type, obt, 0,15,13,14,0,0,0,0);
                             new_button(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 3, num, type, obt, 0,15,13,14,0,0,0,0);
                             a += 3;
                     break;
                     case 4: /* key */
                             new_button(xa, ty+(a+1)*bts, xb, ty+((a+2)*bts)-2, 2, num, type, obt, 0,15,13,14,0,0,0,0);
                             new_button(xa, ty+(a+2)*bts, xb, ty+((a+3)*bts)-2, 5, num, type, obt, 0,10,10,0,0,0,0,0);
                             a += 3;
                     break;
                     case 5: /* Start */
                                  new_button(xa, ty+(a+1)*bts, xb, ty+((a+2)*bts)-2, 26, num, type, obt, 0,15,13,14,0,0,0,0);
                             edit_int_slider(xa, ty+(a+2)*bts, xb, ty+((a+3)*bts)-2, 27, num, type, obt, 0,12,0,11,0,0,0,0);
                             a += 3;
                     break;
                     case 6: /* Free Man */
                                  new_button(xa, ty+((a+1)*bts),  xb, ty+((a+2)*bts)-2, 2, num, type, obt, 0,15,13,0,0,0,0,0);
                             a += 2;
                     break;
                     case 7: /* mine */
                                  new_button(xa, ty+(a+1)*bts, xb, ty+((a+2)*bts)-2, 26, num, type, obt, 0,15,13,14,0,0,0,0);
                             edit_int_slider(xa, ty+(a+2)*bts, xb, ty+((a+3)*bts)-2, 11, num, type, obt, 0,10,15,14,0,0,0,0);
                             a += 3;
                     break;
                     case 8: /* bomb */
                                  new_button(xa, ty+(a+1)*bts, xb, ty+((a+2)*bts)-2, 26,num, type, obt, 0,15,13,14,0,0,0,0);
                             edit_int_slider(xa, ty+(a+2)*bts, xb, ty+((a+3)*bts)-2, 4, num, type, obt, 0,14,0,10,0,0,0,0);
                             edit_int_slider(xa, ty+(a+3)*bts, xb, ty+((a+4)*bts)-2, 5, num, type, obt, 0,10,15,11,0,0,0,0);
                             a += 4;
                     break;
                     case 10: /* message */
                            draw_pmsg(num, txc, ty+(a+6)*bts);

                                new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 26,num, type, obt, 0,15,13,14,0,0,0,0);
                                new_button(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 7, num, type, obt, 0,15,13,14,0,0,0,0);
                            color_selector(xa, ty+((a+3)*bts), xb, ty+((a+4)*bts)-2, 2, num, type, obt, 0,15,13,14,0,0,0,0);
                            color_selector(xa, ty+((a+4)*bts), xb, ty+((a+5)*bts)-2, 3, num, type, obt, 0,15,13,14,0,0,0,0);
                            a += 10;
                     break;
                     case 11: /* rocket */
                                  new_button(xa, ty+((a+1)*bts),  xb, ty+((a+2)*bts)-2, 2, num, type, obt, 0,15,13,0,0,0,0,0);
                                  new_button(xa, ty+((a+2)*bts),  xb, ty+((a+3)*bts)-2, 6, num, type, obt, 0,15,13,0,0,0,0,0);
                             edit_int_slider(xa, ty+((a+3)*bts),  xb, ty+((a+4)*bts)-2, 4, num, type, obt, 0,14,0,10,0,0,0,0);
                             edit_int_slider(xa, ty+((a+4)*bts),  xb, ty+((a+5)*bts)-2, 6, num, type, obt, 0,12,0,14,0,0,0,0);
                             edit_int_slider(xa, ty+((a+5)*bts),  xb, ty+((a+6)*bts)-2, 7, num, type, obt, 0,12,15,14,0,0,0,0);
                             edit_int_slider(xa, ty+((a+6)*bts),  xb, ty+((a+7)*bts)-2, 8, num, type, obt, 0,12,15,14,0,0,0,0);
                             a += 7;

                     break;
                     case 14: /* switch */
                                  new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 26, num, type, obt, 0,15,13,0,0,0,0,0);
                             a += 2;
                     break;
                     case 15: /* sproingy */
                                  new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 26, num, type, obt, 0,15,13,0,0,0,0,0);
                             edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2,  9, num, type, obt, 0,12,15,10,0,0,0,0);
                             edit_int_slider(xa, ty+((a+3)*bts), xb, ty+((a+4)*bts)-2, 10, num, type, obt, 0,12,15,10,0,0,0,0);
                             a += 4;
                     break;
                     case 12: /* warp */
                                  new_button(xa, ty+((a+1)*bts), xb, ty+((a+2)*bts)-2, 26, num, type, obt, 0,15,13,0,0,0,0,0);
                             edit_int_slider(xa, ty+((a+2)*bts), xb, ty+((a+3)*bts)-2, 28, num, type, obt, 0,12,15,10,0,0,0,0);
                     break;
                  }
             }


         if (rits)
            {
                redraw = 1;
                rits = 0;
            }

         /* change to controll this with exit codes */
         switch(mb)
            {
                case 18: /* MOVE */
                 if (getxy("Set New Location",obt, type, num))
                    {
                       extern int get100_x;
                       extern int get100_y;
                       if (obt==3) /* enemy */
                          {
                              Ef[num][0] = get100_x*20;
                              Ef[num][1] = get100_y*20;
                          }
                       if (obt==2) /* item */
                          {
                              item[num][4] = get100_x*20;
                              item[num][5] = get100_y*20;
                          }
                       draw_big();
                    }
               break;
               case 19:
                  num = (create_obj(obt, type, num));
               break;
               case 20: /* DELETE */
                  if (obt ==3)
                     {
                        Ei[num][0] = 0;
                        sort_enemy();
                        if (num >= e_first_num[type]+e_num_of_type[type]) num--;
                        if (e_num_of_type[type] < 1) quit = 1;
                     }
                  if (obt==2)
                     {
                        erase_item(num);
                        item_sort();
                        if (num >= item_first_num[type]+item_num_of_type[type])
                           num--;
                        if (item_num_of_type[type] < 1) quit = 1;
                     }
                  draw_big();
               break;
               case 21: /* NEXT */
                  if ((obt==3)  && (++num >= e_first_num[type]+e_num_of_type[type]))
                     num--;
                  if ((obt==2) && (++num >= item_first_num[type]+item_num_of_type[type]))
                     num--;
               break;
               case 22: /* PREV */

                  if ((obt==3) && (--num < e_first_num[type]))
                     num++;
                  if ((obt==2) && (--num < item_first_num[type]))
                     num++;
               break;
               case 23: /* Copy to Draw Item */
               {
                  extern int draw_item_num, draw_item_type;
                  draw_item_num = num;
                  draw_item_type = obt;
               }
             break;
             case 24:  /* help */
                if (obt==3)
                   {
                      if (type == 3)  help("Archwagon Viewer");
                      if (type == 4)  help("Bouncer Viewer");
                      if (type == 6)  help("Cannon Viewer");
                      if (type == 7)  help("Podzilla Viewer");
                      if (type == 8)  help("Trakbot Viewer");
                      if (type == 9)  help("Cloner Viewer");
                      if (type == 11) help("Block Walker Viewer");
                      if (type == 12) help("Flapper Viewer");
                   }
                if (obt==2)
                   {
                      if (type == 1)  help("Door Viewer");
                      if (type == 2)
                         {
                            if (item[num][7])
                               help("Health Bonus Viewer");
                            if (item[num][8])
                               help("Bullet Bonus Viewer");
                            if (item[num][9])
                               help("Timer Bonus Viewer");
                         }
                      if (type == 3)  help("Exit Viewer");
                      if (type == 4)  help("Key Viewer");
                      if (type == 5)  help("Start Viewer");
                      if (type == 6)  help("Free Man Viewer");
                      if (type == 7)  help("Mine Viewer");
                      if (type == 8)  help("Bomb Viewer");
                      if (type == 10)  help("Message Viewer");
                      if (type == 11)  help("Rocket Viewer");
                      if (type == 14)  help("Switch Viewer");
                      if (type == 15)  help("Sproingy Viewer");
                   }
                break;
             } /* end of switch (mb) */
         draw_edit_item_shape(txc-tw+2, 22, obt, type, num);
         if (redraw)
            {
               redraw = 0;  /* the only place it gets set to zero is here */
               title_obj(obt, type, num);
            }
         else
           {
              show_mouse(screen);
              rest(20);
              show_mouse(NULL);
           }
      } /* end of while (!quit); */
   while ((key[KEY_ESC]) || (mouse_b & 2)); /* wait for release */
   show_mouse(NULL);
}


