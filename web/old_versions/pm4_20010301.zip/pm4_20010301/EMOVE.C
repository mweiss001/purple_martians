#include <math.h>
#include <allegro.h>
#include "pm.h"

/* global variables  */
extern BITMAP *memory_bitmap[NUM_SPRITES];
extern int Ei[100][32];
extern float Ef[100][16];
extern int zz[20][NUM_ANS];
extern int passcount;
extern int PXint, PYint;
extern int WX, WY;
extern int e_killed_type;

int EXint, EYint, EN, a, b, c, d, e, x, y;

enemy_draw_and_collision(void)
{
   int nec = 0;
   extern int pbullet[50][6];
   extern int pm_bullet_collision_box;
   extern BITMAP *scrn_buffer;
   extern BITMAP *map100_bmp;
   extern BITMAP *dtemp;
   extern int game_map_on, map_enemy_color;
   extern int num_enemy;

   for (e = 0; e < 100; e++)
      if (Ei[e][0])  /* if enemy active */
         {
            int EXint = Ef[e][0];
            int EYint = Ef[e][1];
            nec++;
            for (c=0; c<50; c++)  /* check all bullets */
               if (pbullet[c][0]) /* if active */
                {
                  a = abs(pbullet[c][4]/2) + pm_bullet_collision_box; /* bullet stretch collision box size */
                  b = abs(pbullet[c][5]/2) + pm_bullet_collision_box;
                     if (abs(pbullet[c][2] - EXint) < a)
                        if ((abs(pbullet[c][3] - EYint) < b) && (Ei[e][0] !=99))
                                {
                                    Ei[e][31] = 1;  /* enemy got shot with bullet */
                                    pbullet[c][0] = 0; /* bullet dies */
                                 }
               }
            b = Ei[e][29]; /* collision box size */

            if (PXint > (EXint -b)) /* check for collision with player */
               if (PXint < (EXint +b))
                  if (PYint > (EYint -b))
                     if (PYint < (EYint +b))
                        {
                           /* player got hit */
                           Ei[e][22] = 1;
                        }
              /* check for on screen */
              if ((EXint > WX - 20) && (EXint < WX + SCREEN_W))
                 if ((EYint > WY - 20) && (EYint < WY + SCREEN_H))
                    {
                       float a = Ef[e][12]; /* scale */
                       clear(dtemp);
                       /* put shape in dtemp and process flips */
                       if (Ei[e][2] == 0)  draw_sprite_h_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
                       if (Ei[e][2] == 1)         draw_sprite(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
                       if (Ei[e][2] == 2)  draw_sprite_v_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
                       if (Ei[e][2] == 3) draw_sprite_vh_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);

                       if (a) rotate_scaled_sprite(scrn_buffer, dtemp, EXint-WX-(20*a-20)/2, EYint-WY-(20*a-20)/2, itofix(Ei[e][20]), ftofix(a) );
                     }
              if (game_map_on) putpixel(map100_bmp, (EXint/20), (EYint/20), map_enemy_color);
         } /* end of if active */
   num_enemy=nec; /* this function uses num_enemy so...*/
}

void enemy_move()
{
   for (EN=0; EN<100; EN++)
      if (Ei[EN][0]) /* if enemy active */
         {
            EXint = Ef[EN][0];
            EYint = Ef[EN][1];
            switch (Ei[EN][0])
               {
                  case 99: /* enemy type 99 death_count_down  */
                  if (--Ei[EN][30] < 0) /* dec and check countdown timer */
                     {
                        /* create bonus */
                        extern int item[500][16];  /* items */
                        extern float itemf[500][4];
                        /* find empty */
                        for (c=0; c<500; c++)
                           if (item[c][0] == 0)
                              {
                                 for (y=0; y<16; y++)
                                    item[c][y] = 0;

                                 item[c][0] = Ei[EN][27];  /* type   */
                                 item[c][1] = Ei[EN][26];  /* shape  */
                                 item[c][2] = 1; /* draw mode normal */
                                 item[c][3] = 1; /* fall mode */
                                 item[c][4] = itemf[c][0] = EXint;
                                 item[c][5] = itemf[c][1] = EYint;

                                 item[c][7] = Ei[EN][25];  /*  life    */
                                 item[c][8] = Ei[EN][24];  /*  bullets */

                                 itemf[c][2]= 0;
                                 itemf[c][3]= 0;

                                 c = 500; /* end loop */
                              }

                         /* kill enemy */
                         Ei[EN][0] = 0;
                     }

                  Ei[EN][20] += Ef[EN][13]; /* rot inc */
                  Ef[EN][12] *= Ef[EN][11]; /* scale inc*   */

                  Ef[EN][4] = 0; /* cant hurt anymore */

                  Ei[EN][1] = zz[0][ Ei[EN][3] ]; /* draw current ans shape */

                  break;
                  case 3: /* enemy type 3  ArchWagon
                             follows man with regard to walls and gravity

                             Ei[EN][6] = jump wait (0=none)
                             Ei[EN][7] = jump when player above
                             Ei[EN][8] = follow(0) or bounce(1)
                             Ei[EN][11] = jump before hole
                             Ei[EN][12] = jump before wall

                             Ef[EN][5] = speed
                             Ef[EN][8] = fall and fallcount
                             Ef[EN][9] = jump and jumpcount

                             common
                             Ei[EN][22] = player hit
                             Ei[EN][23] = player hit retrigger
                             Ei[EN][24] = bullet bonus
                             Ei[EN][25] = health bonus
                             Ei[EN][26] = bonus type
                             Ei[EN][27] = bonus shape
                             Ei[EN][28] = number of extra hits to kill
                             Ei[EN][30] = death loop count
                             Ei[EN][31] = enemy hit

                             Ef[EN][0] = x
                             Ef[EN][1] = y
                             Ef[EN][2] = xinc
                             Ef[EN][3] = yinc
                             Ef[EN][4] = LIFE decrement
                             Ef[EN][7] = bullet speed
                             Ef[EN][11] = scale multiplier
                             Ef[EN][12] = scale;
                             Ef[EN][13] =  rot inc
                     */

                     if (Ei[EN][31]) /* hit */
                        {
                           int na = 34; /* new ans */
                           int dl = 20; /* delay */
                           int ht = Ei[EN][31]; /* hit type */

                           Ei[EN][27] = 2; /* bonus type */
                           Ei[EN][26] = 929+(ht-1)*32; /* shape */

                           Ei[EN][24]*=ht; /* bullet bonus */
                           Ei[EN][25]*=ht; /* health bonus */

                           Ei[EN][3] = na; /* new ans */
                           Ei[EN][30] = dl; /* death_loop_wait; /* set delay */
                           Ef[EN][11] = 1.08; /* scale multiplier  */
                           Ef[EN][13] = 0;/* 255/dl/2; /* rot inc  */

                           zz[0][na] = zz[5][na]; /* set shape */
                           zz[1][na] = 0;         /* point to zero */
                           zz[2][na] = passcount; /* set counter */
                           zz[3][na] = dl / (zz[4][na]+1); /* set ans timer */

                           Ei[EN][0] = 99; /* set type to death loop */
                           e_killed_type = 3;
                           event(13);
                           break; /* to stop rest of execution */
                        }
                     if (--Ei[EN][23]<0) /* hit player retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                extern float LIFE;
                                LIFE -= Ef[EN][4];
                                e_killed_type = 3;
                                event(12);
                                Ei[EN][22] = 0;  /* clear hit */
                                Ei[EN][23] = 40; /* set retrigger amount */
                              }
                        }
                     else Ei[EN][22] = 0;

                     /* shoot arrow */
                     if (Ei[EN][15])
                        {
                           if (--Ei[EN][16] > 0) /* if  wait */
                              {
                                 Ei[EN][3] = 3; /* empty wagon ans */
                              }
                           else
                              {
                                 Ei[EN][3] = 2; /* wagon with arrow ans */
                                 if ((Ef[EN][1] > PYint - 5) && (Ef[EN][1] < PYint + 5))
                                    {
                                       if (Ei[EN][2]) /* attempt shoot right */
                                          if ((EXint > PXint - Ei[EN][17]) && (EXint < PXint) )
                                             {
                                                fire_enemy_x_bullet(EN, EXint, EYint);
                                                Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                             }
                                       if (!Ei[EN][2]) /* attempt shoot left */
                                          if ((EXint > PXint) && (EXint < PXint + Ei[EN][17]))
                                             {
                                                fire_enemy_x_bullet(EN, EXint, EYint);
                                                Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                             }
                                    }
                              }
                        }
                     if (!Ei[EN][8]) /* follow mode */
                        {
                           if ((EXint < PXint) && (Ef[EN][2] < 0))
                              Ef[EN][2] = -Ef[EN][2];
                           if ((EXint > PXint) && (Ef[EN][2] > 0))
                              Ef[EN][2] = -Ef[EN][2];
                        }
                     if ((Ef[EN][2]) > 0)  /* move right */
                        {
                          Ei[EN][2] = 1; /* no h_flip */
                          Ef[EN][0] += Ef[EN][2];
                          EXint=Ef[EN][0];
                          if (Ei[EN][12]) /* jump before wall */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (is_right_solid(EXint+Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                          if (Ei[EN][11]) /* jump before hole */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (!is_right_solid(EXint+Ei[EN][11]-18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
                          if (is_right_solid(EXint, EYint))
                             {
                                Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                EXint=Ef[EN][0];
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
                           Ei[EN][2] = 0; /* h_flip to face left */
                           Ef[EN][0] += Ef[EN][2];
                           EXint=Ef[EN][0];
                           if (Ei[EN][12]) /* jump before wall */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (is_left_solid(EXint-Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                           if (Ei[EN][11]) /* jump before hole */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (!is_left_solid(EXint-Ei[EN][11]+18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                 if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                 EXint=Ef[EN][0];
                              }
                        }
                     if (Ef[EN][9])  /* jump */
                        {
                           Ef[EN][9] -= .05;
                           if (Ef[EN][9] < .1)      /* top of jump */
                              {
                                 Ef[EN][9] = 0;    /* jump done */
                                 Ef[EN][8] = 1.6;   /* start fall */
                              }
                           else
                              {
                                 Ef[EN][1] -= (sin(Ef[EN][9]) * Ef[EN][3]);
                                 EYint=Ef[EN][1];
                                 if (is_up_solid(EXint, EYint, 1, 0))
                                    {
                                       Ef[EN][9] = 0;   /* abort jump */
                                       Ef[EN][8] = 1.6;   /* start fall */
                                    }
                              }
                        }
                     else  /* not jump */
                        {
                           if (Ef[EN][8])   /* if fall = 1 */
                              {
                                 Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                                 if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                                 Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                                 if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                                 EYint=Ef[EN][1];
                                 if (is_down_solid(EXint, EYint, 1))  /* look for end of fall */
                                    {
                                       Ef[EN][8] = 0; /*  fall=0;  */
                                       Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                       EYint=Ef[EN][1];
                                    }
                              }
                           if (!Ef[EN][8])  /* fall = 0 */
                              {
                                 /* start fall? look for no block below */
                                 if (!is_down_solid(EXint, EYint, 1)) Ef[EN][8] = 1.6;
      
                                 /* passcount jump */
                                 if ((Ei[EN][6] > 0) && ((passcount % Ei[EN][6]) == 1))
                                    Ef[EN][9] = 1.6; /* jump! */
      
                                 /* jump when player passes over width */
                                 if ((Ei[EN][7] > 0) && (EXint < (PXint + Ei[EN][7])) && (EXint > (PXint - Ei[EN][7])) && (EYint > PYint))
                                    Ef[EN][9] = 1.6;
                              } /* end of fall = 0  */
                        } /* end of else if not fall  */
                     /* set the bitmap and drawing mode */
                     b = Ei[EN][3];      /* ans */
                     c = zz[4][b];         /* num_of_shapes in seq */
                     if (Ei[EN][4] == 0) Ei[EN][1] = Ei[EN][3]; /* bmp, not ans */
                     if (Ei[EN][4] == 1) Ei[EN][1] = zz[0][b];    /* animate with time */
                     if (Ei[EN][4] == 2) /* animate with h move */
                        {
                           if (Ei[EN][2] == 1) /* right */
                              {
                                 x = (EXint/3) % c;
                                 Ei[EN][1] = zz[x+5][b];
                              }
                           if (Ei[EN][2] == 0) /* left */
                              {
                                 x = (EXint/3) % c;
                                 Ei[EN][1] = zz[5+c-x][b];
                              }
                        }
                     if (Ei[EN][4] == 3) /* animate with v move */
                        {
                           x = (EYint/3) % c;
                           Ei[EN][1] = zz[x+5][b];
                        }
                     if (Ei[EN][4] == 4) /* animate with v and h move */
                        {
                           x = ((EYint/3) % c) + ((EXint/3) % c);
                           if (x > c) x-=c;
                           Ei[EN][1] = zz[x+5][b];
                        }
                  break;
                  case 4: /* enemy type 4  bouncer

                             Ei[EN][5] = main ans
                             Ei[EN][6] = seek ans
                             Ei[EN][7] = seek counter
                             Ei[EN][8] = seek count

                             Ef[EN][5] = speed */

                     if (Ei[EN][31]) /* bouncer hit */
                        {
                           int na = Ei[EN][3]; /* new ans */
                           int dl = 20;
                           int ht = Ei[EN][31]; /* hit type */
                           Ei[EN][27] = 2; /* bonus type */
                           Ei[EN][26] = 928+(ht-1)*32; /* shape */

                           Ei[EN][24]*=ht; /* bullet bonus */
                           Ei[EN][25]*=ht; /* health bonus */

                           if (na == 29) na = 46;
                           if (na == 14) na = 13;
                           Ei[EN][3] = na; /* new ans */

                           Ei[EN][30] = dl; /* death_loop_wait; /* set delay */
                           Ef[EN][11] = 1.03; /* scale multiplier  */
                           Ef[EN][13] = 2; /* 255/dl/2; /* rot inc  */

                           zz[0][na] = zz[5][na]; /* set shape */
                           zz[1][na] = 0;         /* point to zero */
                           zz[2][na] = passcount; /* set counter */
                           zz[3][na] = dl / (zz[4][na]+1); /* set ans timer */
                           Ei[EN][0] = 99; e_killed_type = 4; event(13); /* set type to death loop */
                           break;
                        }
                     if (--Ei[EN][23]<0) /* hit player retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                extern float LIFE;
                                LIFE -= Ef[EN][4];
                                e_killed_type = 4;
                                event(12);
                                Ei[EN][22] = 0;  /* clear hit */
                                Ei[EN][23] = 60; /* set retrigger amount */
                              }
                        }
                    else Ei[EN][22] = 0;

                    if ((Ei[EN][8]) && (Ei[EN][7] > Ei[EN][8])) /* seek */
                       {
                          Ei[EN][7] = 0;
                          seek_set_xyinc(EN, EXint, EYint);
                          Ei[EN][20] = get_rot_from_xyinc(EN);
                          Ei[EN][3] = Ei[EN][6]; /* seek ans */
                       }
                    if (Ei[EN][7]) Ei[EN][3] = Ei[EN][5]; /* main ans */

                    if ((Ef[EN][2]) > 0)  /* move right */
                        {
                          Ef[EN][0] += Ef[EN][2];
                          EXint = Ef[EN][0];
                          if (is_right_solid(EXint, EYint))
                             {
                                Ei[EN][7]++;
                                Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                Ef[EN][0] += Ef[EN][2];
                                EXint = Ef[EN][0];
                                Ei[EN][20] = get_rot_from_xyinc(EN);
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
                           Ef[EN][0] += Ef[EN][2];
                           EXint = Ef[EN][0];
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                 Ef[EN][0] += Ef[EN][2];
                                 EXint = Ef[EN][0];
                                 Ei[EN][20] = get_rot_from_xyinc(EN);
                              }
                        }
                     if (Ef[EN][3] > 0) /* move down */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           EYint = Ef[EN][1];
                           if (is_down_solid(EXint, EYint, 1))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
                                 Ei[EN][20] = get_rot_from_xyinc(EN);
                              }
                        }
                     if (Ef[EN][3] < 0)  /* move up */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           EYint = Ef[EN][1];
                           if (is_up_solid(EXint, EYint, 0, 0))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
                                 Ei[EN][20] = get_rot_from_xyinc(EN);
                              }
                        }
                     /* set the bitmap from animation sequence */
                     /* always with time */
                     Ei[EN][1] = zz[0][Ei[EN][3]];

                 break;
                 case 6: /* enemy type 6  cannon

                             Ei[EN][7] = seek counter
                             Ei[EN][8] = seek count
                             Ei[EN][28] = hits;
                             Ef[EN][5] = speed */

                     if (Ei[EN][31]) /* enemy hit */
                        {
                           if (Ei[EN][28] == 0) /* dead */
                              {
                                 int na = 37; /* new ans */
                                 int dl = 20;
                                 int ht = Ei[EN][31]; /* hit type */
                                 Ei[EN][27] = 2; /* bonus type */
                                 Ei[EN][26] = 930+(ht-1)*32; /* shape */
                                 Ei[EN][24]*=ht; /* bullet bonus */
                                 Ei[EN][25]*=ht; /* health bonus */

                                 Ei[EN][3] = na;
                                 Ei[EN][30] = dl; /* death_loop_wait; /* set delay */
                                 Ef[EN][11] = 1.08; /* scale multiplier  */
                                 Ef[EN][13] = 1; /* 255/dl/2; /* rot inc  */

                                 zz[0][na] = zz[5][na]; /* set shape */
                                 zz[1][na] = 0;         /* point to zero */
                                 zz[2][na] = passcount; /* set counter */
                                 zz[3][na] = dl / (zz[4][na]+1); /* set ans timer */

                                 Ei[EN][0] = 99; e_killed_type = 6; event(13); /* set type to death loop */
                                 break;
                              }
                           else
                              {
                                 Ei[EN][28] --;  /* one less hit */
                                 Ei[EN][31] = 0; /* clear hit */
                                 Ef[EN][2]  *= 1.2; /* x speed */
                                 Ef[EN][3]  *= 1.2; /* y speed */
                                 Ef[EN][5]  *= 1.2; /* seek speed */
                                 Ef[EN][7]  *= 1.2; /* bullet speed */
                                 Ef[EN][12] *= 1.12; /* scale */
                              }
                        }

                     /* cannonballs */
                     if (Ei[EN][15])
                        if (--Ei[EN][16] < 0) /* bullet  wait */
                        {
                           fire_enemy_bulleta(EN, EXint, EYint, 55);
                           Ei[EN][16] = Ei[EN][15];
                        }

                    if ((Ei[EN][8]) && (Ei[EN][7] > Ei[EN][8])) /* seek */
                       {
                          seek_set_xyinc(EN, EXint, EYint);
                          Ei[EN][7] = 0;
                       }
                    Ei[EN][20] = get_rot_from_PXY(EN, EXint, EYint);

                   /* set bitmap */
                   if (.7 < (float)Ei[EN][16] / (float)Ei[EN][15] )
                      Ei[EN][1] = 506; /* red cannon */
                   else Ei[EN][1] = 507;  /* green cannon */
      
                     if ((Ef[EN][2]) > 0)  /* move right */
                        {
                          Ef[EN][0] += Ef[EN][2];
                          EXint = Ef[EN][0];
                          if (is_right_solid(EXint, EYint))
                             {
                                Ei[EN][7]++;
                                Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                Ef[EN][0] += Ef[EN][2];
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
                           Ef[EN][0] += Ef[EN][2];
                           EXint = Ef[EN][0];
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                 Ef[EN][0] += Ef[EN][2];
      
                              }
                        }
                     if (Ef[EN][3] > 0) /* move down */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           if (is_down_solid(EXint, EYint, 1))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
                              }
                        }
                     if (Ef[EN][3] < 0)  /* move up */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           if (is_up_solid(EXint, EYint, 0, 0))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
                              }
                        }
                     if (--Ei[EN][23]<0) /* player hit retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                extern float LIFE;
                                LIFE -= Ef[EN][4];
                                e_killed_type = 6;
                                event(12);
                                Ei[EN][22] = 0;  /* clear hit */
                                Ei[EN][23] = 40; /* new retrigger delay */
                              }
                        }
                     else Ei[EN][22] = 0; /* clear hit */

                   break;
                   case 7:/* Podzilla
                             Ei[EN][5] = mode
                             Ei[EN][6] = sequence counter
                             Ei[EN][7] = sequence limit
                             Ei[EN][8] = wait count
                             Ei[EN][9] = wait limit
                             Ei[EN][11] = trigger box x1
                             Ei[EN][12] = trigger box x1
                             Ei[EN][13] = trigger box x2
                             Ei[EN][14] = trigger box y2
*/

                     if (Ei[EN][31]) /* podzilla hit */
                        {
                           int na = 45; /* new ans */
                           int dl = 40; /* delay */
                           int ht = Ei[EN][31]; /* hit type */
                           Ei[EN][27] = 2; /* bonus type */
                           Ei[EN][26] = 932+(ht-1)*32; /* shape */
                           Ei[EN][24]*=ht; /* bullet bonus */
                           Ei[EN][25]*=ht; /* health bonus */
                           Ei[EN][3] = na; /* new ans */
                           Ei[EN][30] = dl; /* death_loop_wait; /* set delay */
                           Ef[EN][12] = 2.8; /* initial scale */
                           Ef[EN][11] = .94; /* scale multiplier  */
                           Ef[EN][13] = 0;  /* 255/dl/2; /* rot inc  */

                           zz[0][na] = zz[5][na]; /* set shape */
                           zz[1][na] = 0;         /* point to zero */
                           zz[2][na] = passcount; /* set counter */
                           zz[3][na] = dl / (zz[4][na]+1); /* set ans timer */
                           Ei[EN][0] = 99; e_killed_type = 7; event(13); /* set type to death loop */
                           break;
                        }
                     if (--Ei[EN][23]<0) /* hit player retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                extern float LIFE;
                                LIFE -= Ef[EN][4];
                                e_killed_type = 7;
                                event(12);
                                Ei[EN][22] = 0;
                                Ei[EN][23] = 40;
                              }
                        }
                     else Ei[EN][22] = 0;

                     if (!Ei[EN][5]) /* only trigger from mode 0 */
                        if ((PXint > Ei[EN][11]*20) && (PXint < Ei[EN][13]*20))
                           if ((PYint > Ei[EN][12]*20) && (PYint < Ei[EN][14]*20))
      
                              {
                                 Ei[EN][5] = 1; /* triggered! mode 1; */
                                 Ei[EN][6] = 0;  /* zero counter */
                              }
                     if (Ei[EN][5] == 1) /* mode 1; out */
                        {
                           Ef[EN][0] += Ef[EN][2];
                           Ef[EN][1] += Ef[EN][3];
                           if (++Ei[EN][6] > Ei[EN][7]) /* if (++count > limit) */
                              {
                                 Ei[EN][5] = 2; /* next mode */
                                 Ei[EN][8] = passcount;
                             }
                        }
                     if (Ei[EN][5] == 2)  /* mode 2; shoot */
                        {
                           if (Ei[EN][8] < (passcount-Ei[EN][9]) )
                              {
                                 fire_enemy_bulleta(EN, EXint, EYint, 54);
                                 Ei[EN][5] = 3; /* next mode */
                                 Ei[EN][8] = passcount;
                              }
                        }
                     if (Ei[EN][5] == 3)  /* mode 3; post shoot pause */
                        {
                           if (Ei[EN][8] < (passcount-Ei[EN][9]) )
                              {
                                 Ei[EN][5] = 4; /* next mode */
                                 Ei[EN][8] = passcount;
                              }
                        }
                     if (Ei[EN][5] == 4) /* mode 4; in */
                        {
                           Ef[EN][0] -= Ef[EN][2];
                           Ef[EN][1] -= Ef[EN][3];
                           if (--Ei[EN][6] < 1 ) /* if (--count < 1) */
                              Ei[EN][5] = 0; /* done; back to mode 0 */
                        }
                   Ei[EN][1] = zz[ 5 + (Ei[EN][6] * zz[4][15] / Ei[EN][7]) ][15];
                   /* bitmap =           counter * numshapes / limit  */
                  if ( (Ei[EN][5] == 2) || (Ei[EN][5] == 3) )
                     {
                        Ei[EN][20] = get_rot_from_PXY(EN, EXint, EYint);
                        Ei[EN][1] = 335; /* green cannon */
                     }
                  else Ei[EN][20] = get_rot_from_xyinc(EN);
                  break;
                  case 8:   /* trakbot */
                  {
/*                   Ei[EN][5] = mode
                     Ei[EN][7] = fall when player below
                     Ef[EN][8] = fall and fallcount
*/
                     int bullet_request = 0;
                     int mode = Ei[EN][5];
                     int prox = Ei[EN][17];
                     int te = 4;

                     /* bullet prox */
                     if ((prox) && (--Ei[EN][16] < 0))
                        {
                           bullet_request = 1;
                           Ei[EN][3] = 17;
                        }
                     else Ei[EN][3] = 18;
      
                     if (--Ei[EN][23]<0) /* hit player retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                extern float LIFE;
                                LIFE -= Ef[EN][4];
                                e_killed_type = 8;
                                event(12);
                                Ei[EN][22] = 0;
                                Ei[EN][23] = 40;
                               }
                        }
                     else Ei[EN][22] = 0;

                     if (Ei[EN][31]) /* hit */
                        {
                           int na = 44; /* new ans */
                           int dl = 12;

                           int ht = Ei[EN][31]; /* hit type */
                           Ei[EN][27] = 2; /* bonus type */
                           Ei[EN][26] = 931+(ht-1)*32; /* shape */
                           Ei[EN][24]*=ht; /* bullet bonus */
                           Ei[EN][25]*=ht; /* health bonus */

                           Ei[EN][3] = na; /* new ans */

                           Ei[EN][30] = dl; /* death_loop_wait; /* set delay */
                           Ef[EN][11] = 1.00; /* scale multiplier  */
                           Ef[EN][13] =  255/dl*3/4; /* rot inc  */

                           zz[0][na] = zz[5][na]; /* set shape */
                           zz[1][na] = 0;         /* point to zero */
                           zz[2][na] = passcount; /* set counter */
                           zz[3][na] = dl / (zz[4][na]+1); /* set ans timer */
                           Ei[EN][0] = 99; e_killed_type = 8; event(13); /* set type to death loop */
                           break;
                        }
                     if (Ef[EN][8])   /* if fall = 1 */
                        {
                           Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                           if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                           Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                           if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                           EYint=Ef[EN][1];
                           if (is_down_solid(EXint, EYint, 0))  /* look for end of fall */
                              {
                                 Ef[EN][8] = 0; /*  fall=0;  */
                                 Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                 EYint=Ef[EN][1];
                              }
                        }
                     if (!Ef[EN][8])  /* if not fall */
                        {
                          if ( (Ei[EN][7]) && (EXint < (PXint + 15)) && (EXint > (PXint - 15))
                            && (EYint < (PYint     )) ) /* if above */
                             {
                                if (mode == 2)
                                   {
                                      Ef[EN][8] = 1.6; /* fall */
                                      mode = 4;
                                      Ei[EN][2] = 0;
                                      Ei[EN][20] = 0;
                                   }
                                if (mode == 6)
                                   {
                                      Ef[EN][8] = 1.6; /* fall */
                                      mode = 0;
                                      Ei[EN][2] = 1;
                                      Ei[EN][20] = 0;
                                   }
                             
                             }
                        } /* end of fall = 0  */
                     if (!Ef[EN][8])  /* not fall */
                        switch (mode)
                           {
                              case 0: /* floor right */
                                 if (!is_down_solid(EXint, EYint, 0))
                                    {
                                       mode = 3;
                                       Ef[EN][0] = 19 + (EXint/20)*20;
                                       Ef[EN][1] += te;
                                       Ei[EN][2] = 1;
                                       Ei[EN][20] = 32;
                                       break;
                                    }
                                 if (is_right_solid(EXint, EYint))
                                    {
                                       mode = 1;
                                       Ef[EN][0] = (EXint/20)*20;
                                       Ei[EN][2] = 1;
                                       Ei[EN][20] = 224;
                                       break;
                                    }
                                 if (bullet_request)
                                    if (EYint >= PYint)
                                       if ((EYint-prox) < PYint)
                                          if (EXint < PXint)
                                             if ((EXint+prox) > PXint)
                                                {
                                                   fire_enemy_bulleta(EN, EXint, EYint, 20);
                                                   Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                                }
                                 Ei[EN][2] = 1;
                                 Ei[EN][20] = 0;
                                 Ef[EN][0] += Ef[EN][2];
                              break;
                              case 1: /* rwall up */
                                 if (!is_right_solid(EXint, EYint))
                                   {
                                      mode = 0;
                                      Ef[EN][1] = (EYint/20)*20;
                                      Ef[EN][0] += te;
                                      Ei[EN][2] = 1;
                                      Ei[EN][20] = 224;
                                      break;
                                   }
                                if (is_up_solid(EXint, EYint, 0, 1))
                                   {
                                      mode = 2;
                                      Ef[EN][1] = (((EYint+te)/20)*20)-1;
                                      Ei[EN][2] = 1; /* no flip */
                                      Ei[EN][20] = 160; /* rotation */
                                      break;
                                   }
                                if (bullet_request)
                                   if (EYint >= PYint)
                                      if ((EYint-prox) < PYint)
                                         if (EXint > PXint)
                                            if ((EXint-prox) < PXint)
                                              {
                                                 fire_enemy_bulleta(EN, EXint, EYint, 20);
                                                 Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                              }
                                Ei[EN][2] = 1;
                                Ei[EN][20] = 192;
                                Ef[EN][1] -= Ef[EN][3];
                                break;
                         case 2: /* ceil left */
                         if (!is_up_solid(EXint, EYint, 0, 1))
                            {
                               mode = 1;
                               Ef[EN][0] = (EXint/20)*20;
                               Ef[EN][1] -= te;
                               Ei[EN][2] = 160; /* rotation */
                               break;
                            }
                       if (is_left_solid(EXint, EYint))
                            {
                               mode = 3;
                               Ef[EN][0] = 19 + (EXint/20)*20;
                               Ei[EN][2] = 1; /* no flip */
                               Ei[EN][20] = 96; /* rotation */
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint > PXint)
                                     if ((EXint-prox) < PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                       }
                         Ei[EN][2] = 1;
                         Ei[EN][20] = 128;
                         Ef[EN][0] -= Ef[EN][2];
                         break;
                         case 3: /* lwall down */
                         if (!is_left_solid(EXint, EYint))
                            {
                               mode = 2;
                               Ef[EN][1] = 19 + (EYint/20)*20;
                               Ef[EN][0] -= te;
                               Ei[EN][2] = 1; /* rotation */
                               Ei[EN][20] = 96; /* rotation */
                               break;
                            }
                         if (is_down_solid(EXint, EYint, 0))
                            {
                               mode = 0;
                               Ef[EN][1] = (EYint/20)*20;
                               Ei[EN][2] = 1;
                               Ei[EN][20] = 32; /* rotation */
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint < PXint)
                                     if ((EXint+prox) > PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                       }
                         Ei[EN][2] = 1;
                         Ei[EN][20] = 64;
                         Ef[EN][1] += Ef[EN][3];
                         break;
                         case 4: /* floor left */
                          if (!is_down_solid(EXint, EYint, 0))
                            {
                               mode = 7;
                               Ef[EN][0] = (EXint/20)*20;
                               Ef[EN][1] += te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 224;
                               break;
                            }
                         if (is_left_solid(EXint, EYint))
                            {
                               mode = 5;
                               Ef[EN][0] = 19+((EXint)/20)*20;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 32;
                               break;
                            }
                         if (bullet_request)
                            if (EYint >= PYint)
                               if ((EYint-prox) < PYint)
                                  if (EXint > PXint)
                                     if ((EXint-prox) < PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 0;
                         Ef[EN][0] -= Ef[EN][2];
                         break;
                         case 5: /* lwall up */
                          if (!is_left_solid(EXint, EYint))
                            {
                               mode = 4;
                               Ef[EN][1] = (EYint/20)*20;
                               Ef[EN][0] -= te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 32;
                               break;
                            }
                         if (is_up_solid(EXint, EYint, 0, 1))
                            {
                               mode = 6;
                               Ef[EN][1] = (((EYint+te)/20)*20)-1;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 96;
                               break;
                            }
                         if (bullet_request)
                            if (EYint >= PYint)
                               if ((EYint-prox) < PYint)
                                  if (EXint < PXint)
                                     if ((EXint+prox) > PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                       }
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 64;
                         Ef[EN][1] -= Ef[EN][3];
                         break;
                         case 6: /* ceil right */
                         if (!is_up_solid(EXint, EYint, 0, 1))
                            {
                               mode = 5;
                               Ef[EN][0] = 19+(EXint/20)*20;
                               Ef[EN][1] -= te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 96;
                               break;
                            }
                       if (is_right_solid(EXint, EYint))
                            {
                               mode = 7;
                               Ef[EN][0] = (EXint/20)*20;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 160;
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint < PXint)
                                     if ((EXint+prox) > PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                       }
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 128;
                         Ef[EN][0] += Ef[EN][2];
                         break;
                         case 7: /* rwall down */
                         if (!is_right_solid(EXint, EYint))
                            {
                               mode = 6;
                               Ef[EN][1] = 19 + (EYint/20)*20;
                               Ef[EN][0] += te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 160;
                               break;
                            }
                         if (is_down_solid(EXint, EYint, 0))
                            {
                               mode = 4;
                               Ef[EN][1] = (EYint/20)*20;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 224;
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint > PXint)
                                     if ((EXint-prox) < PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                       }
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 192;
                         Ef[EN][1] += Ef[EN][3];
                         break;

                         } /* end of switch mode */
                             /* set the bitmap and drawing mode */
                             b = Ei[EN][3];    /* ans */
                             c = zz[4][b];     /* num_of_shapes in seq */
                             d = 2;            /* to link movement to seq */
                             if (mode % 2) /* ymove, if odd */
                                {
                                   if ((Ei[EN][5] == 1) || (Ei[EN][5] == 5))
                                      {
                                         x = (EYint/d) % c;
                                         Ei[EN][1] = zz[x+5][b];
                                      }
                                   if ((Ei[EN][5] == 3) || (Ei[EN][5] == 7))
                                      {
                                         x = (EYint/d) % c;
                                         Ei[EN][1] = zz[c+5-x][b];
                                      }
      
                                }
                             else  /* xmove, if even */
                                {
                                   if ((Ei[EN][5] == 2) || (Ei[EN][5] == 4))
                                      {
                                         x = (EXint/d) % c;
                                         if (x > c) x-=c;
                                         Ei[EN][1] = zz[x+5][b];
                                      }
                                   if ((Ei[EN][5] == 0) || (Ei[EN][5] == 6))
                                      {
                                         x = (EXint/d) % c;
                                         if (x > c) x-=c;
                                         Ei[EN][1] = zz[c+5-x][b];
                                      }
                                }
      
                  if (Ei[EN][5] == mode) Ei[EN][8] = 0;
                  if (Ei[EN][5] != mode)
                     {
                        Ei[EN][5] = mode;
                        if (++Ei[EN][8] > 4) /* twirling */
                           {
                              Ef[EN][8] = 1.6; /* fall */
                              Ei[EN][5] = 0;
                              Ei[EN][2] = 1;
                              Ei[EN][20] = 0;
                           }
                     }
                  }

                  break; /* end of case 8 */
                  case 9: {
                     /* CLONER
                     Ei[EN][6] = create wait
                     Ei[EN][7] = create wait counter
                     Ei[EN][8] = trigger mode (0 = wait, 1=reset, 2=immed)
                     Ei[EN][11] = trigger box x1
                     Ei[EN][12] = trigger box y1
                     Ei[EN][13] = trigger box x2
                     Ei[EN][14] = trigger box y2
                     Ef[EN][2] = copy box x size
                     Ef[EN][3] = copy box y size
                     Ef[EN][6] = copy box x (2000)
                     Ef[EN][7] = copy box y (2000)
                     Ef[EN][8] = dest box x (2000)
                     Ef[EN][9] = dest box y (2000) */
      
                     int x1 = Ef[EN][6]-2;    /* source x */
                     int y1 = Ef[EN][7]-2;    /* source y */
                     int x2 = x1 + Ef[EN][2];   /* sizes */
                     int y2 = y1 + Ef[EN][3];

                     int x3 = Ef[EN][8]-2;    /* dest x */
                     int y3 = Ef[EN][9]-2;    /* dest y */
                     int x4 = x3 + Ef[EN][2];   /* sizes */
                     int y4 = y3 + Ef[EN][3];
                     extern BITMAP *scrn_buffer;
                     extern int WX,WY;
                     char msg[80];

                     float ratio = (float) Ei[EN][7] / (float) Ei[EN][6] * 10;
                     b = 10 - (int) ratio;
                     Ei[EN][2] = 1;
                     Ei[EN][1] = zz[5+b][53];

                     if (--Ei[EN][23]<0) /* hit player retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                Ei[EN][22] = 0; /* clear hit */
                                Ei[EN][23] = 40;
                              }
                        }
                     else Ei[EN][22] = 0; /* clear hit */

                     if (Ei[EN][31]) /* hit */
                        {
                           int na = 53;
                           int dl = 40;
                           int ht = Ei[EN][31]; /* hit type */

                           Ei[EN][27] = 2; /* bonus type */
                           Ei[EN][26] = 934+(ht-1)*32; /* shape */
                           Ei[EN][24]*=ht; /* bullet bonus */
                           Ei[EN][25]*=ht; /* health bonus */


                           Ei[EN][3] = na; /* new ans */
                           Ei[EN][30] = dl; /* death_loop_wait; /* set delay */

                        /* Ef[EN][11] = .98; /* scale multiplier  */
                        /* Ef[EN][13] = 255/dl; /* rot inc  */

                           Ef[EN][11] = .98; /* scale multiplier  */
                           Ef[EN][13] = 306/dl; /* rot inc  */

                           zz[0][na] = zz[5][na]; /* set shape */
                           zz[1][na] = 0;         /* point to zero */
                           zz[2][na] = passcount; /* set counter */
                           zz[3][na] = dl / zz[4][na]; /* set ans timer */

                           Ei[EN][0] = 99; e_killed_type = 9; event(13); /* set type to death loop */
                           break;
                        }
#ifdef CLONERLINES
                     /* show counter
                     sprintf(msg, "%d" ,Ei[EN][7] );
                     textout(screen, font, msg, x1-WX+24, y1-WY+24, 15);
                     */
                     if ((ratio < 4 ) && (ratio > 2 )) /* leading indicator */
                        {
                           int il = (ratio-3)*8;
                           int li = (2 - (ratio-3))*8;
                           rect (scrn_buffer, x1-WX-il, y1-WY-il, x2-WX+il, y2-WY+il, 10);
                           rect (scrn_buffer, x1-WX-li, y1-WY-li, x2-WX+li, y2-WY+li, 10);
                           line(scrn_buffer, x1-WX-il,  y1-WY-il, x1-WX-li, y1-WY-li, 10);
                           line(scrn_buffer, x2-WX+il,  y2-WY+il, x2-WX+li, y2-WY+li, 10);
                           line(scrn_buffer, x1-WX-il,  y2-WY+il, x1-WX-li, y2-WY+li, 10);
                           line(scrn_buffer, x2-WX+il,  y1-WY-il, x2-WX+li, y1-WY-li, 10);
                        }
                     if (ratio < 2 ) /* leading indicator */
                        {
                           int il = (ratio-1)*8;
                           int li = (2 - (ratio-1))*8;
                           rect (scrn_buffer, x3-WX-li, y3-WY-li, x4-WX+li, y4-WY+li, 11);
                           rect (scrn_buffer, x3-WX-il, y3-WY-il, x4-WX+il, y4-WY+il, 11);
                           line(scrn_buffer, x3-WX-il,  y3-WY-il, x3-WX-li, y3-WY-li, 11);
                           line(scrn_buffer, x4-WX+il,  y4-WY+il, x4-WX+li, y4-WY+li, 11);
                           line(scrn_buffer, x3-WX-il,  y4-WY+il, x3-WX-li, y4-WY+li, 11);
                           line(scrn_buffer, x4-WX+il,  y3-WY-il, x4-WX+li, y3-WY-li, 11);
                        }
#endif
                     if (Ei[EN][5] == 1) /* in trig box */
                        switch (Ei[EN][8])
                           {
                              case 0: case 1: case 2:
                                 if ((PXint > Ei[EN][11]*20) && (PXint < Ei[EN][13]*20) && (PYint > Ei[EN][12]*20) && (PYint < Ei[EN][14]*20))
                                    {  /* still in */
                                       if (--Ei[EN][7] < 0)  Ei[EN][5] = 2; /* time for create */
                                    }
                                 else Ei[EN][5] = 0; /* mode 0 - out of box */
                               break;
                           }
                     if (Ei[EN][5] == 0) /* not in trig box */
                        switch (Ei[EN][8]) /* trigger mode */
                           {
                              case 0: /* wait continue  */
                                 if ((PXint > Ei[EN][11]*20) && (PXint < Ei[EN][13]*20) && (PYint > Ei[EN][12]*20) && (PYint < Ei[EN][14]*20))
                                    Ei[EN][5] = 1; /* set mode 1 - in box */

                              break;
                              case 1: /* reset when retriggered */
                                 if ((PXint > Ei[EN][11]*20) && (PXint < Ei[EN][13]*20) && (PYint > Ei[EN][12]*20) && (PYint < Ei[EN][14]*20))
                                    {
                                        Ei[EN][7] = Ei[EN][6]; /* reset counter */
                                        Ei[EN][5] = 1; /* set mode 1 - in box */
                                    }
                              break;

                              case 2: /* immediate when retriggered  */
                                 if ((PXint > Ei[EN][11]*20) && (PXint < Ei[EN][13]*20) && (PYint > Ei[EN][12]*20) && (PYint < Ei[EN][14]*20))
                                    {
                                       Ei[EN][7] = 0; /* set counter to zero! */
                                       Ei[EN][5] = 1; /* set mode 1 - in box */
                                    }
                              break;
                           }
                     if (Ei[EN][5] == 2)  /* mode 2 - create */
                        {
                           extern int item[500][16];
                           extern float itemf [500][4];
                           Ei[EN][5] = 1; /* set mode 1 - in trig box */
                           event(14);
#ifdef CLONERLINES
                           rectfill (scrn_buffer, x1-WX, y1-WY, x2-WX, y2-WY, 10);
                           rectfill (scrn_buffer, x3-WX, y3-WY, x4-WX, y4-WY, 11);
#endif

                           Ei[EN][7] = Ei[EN][6]; /* reset counter */
                           Ei[EN][1] = zz[15][53]; /* full red */
                
      
                           for (b=0; b<100; b++) /* check for enemies in box */
                              if (Ei[b][0])     /* if active */
                                 if (Ef[b][0] > x1)
                                    if (Ef[b][0] < x2)
                                       if (Ef[b][1] > y1)
                                          if (Ef[b][1] < y2)
                                             {
                                                /* copy to dest box */
                                                /* find empty */
                                                for (c=0; c<100; c++)
                                                   if (Ei[c][0] == 0)
                                                      {
                                                         for (y=0; y<32; y++)
                                                            Ei[c][y] = Ei[b][y];
                                                         for (y=0; y<16; y++)
                                                            Ef[c][y] = Ef[b][y];
      
                                                         Ef[c][0]= x3 + (Ef[b][0]-x1);
                                                         Ef[c][1]= y3 + (Ef[b][1]-y1);
                                                         c = 100; /* end loop */
                                                      }
                                             }
      
                           for (b=0; b<500; b++) /* check for items in box */
                              if (item[b][0])     /* if active */
                                 if (itemf[b][0] > x1)
                                    if (itemf[b][0] < x2)
                                       if (itemf[b][1] > y1)
                                          if (itemf[b][1] < y2)
                                             {
                                                /* copy to dest box */
                                                /* find empty */
                                                for (c=0; c<500; c++)
                                                   if (item[c][0] == 0)
                                                      {
                                                         for (y=0; y<16; y++)
                                                            item[c][y] = item[b][y];
      
                                                         itemf[c][0]= x3 + (itemf[b][0]-x1);
                                                         itemf[c][1]= y3 + (itemf[b][1]-y1);
                                                         itemf[c][2]= 0;
                                                         itemf[c][3]= 0;
      
      
                                                         c = 500; /* end loop */
                                                      }
                                             }
                        }
                     }

                  break;
                  case 11: /* Block Walker
                             Ei[EN][6] = jump wait (0=none)
                             Ei[EN][7] = jump when player above
                             Ei[EN][8] = follow(0) or bounce(1)
                             Ei[EN][11] = jump before hole
                             Ei[EN][12] = jump before wall
      
                             Ef[EN][8] = fall and fallcount
                             Ef[EN][9] = jump and jumpcount
                             */


                     if (--Ei[EN][23]<0) /* hit player retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                extern float LIFE;
                                LIFE -= Ef[EN][4];
                                e_killed_type = 11;
                                event(12);
                                Ei[EN][22] = 0;
                                Ei[EN][23] = 40;
                              }
                        }
                     else Ei[EN][22] = 0;

                             if (Ei[EN][31]) /* hit */
                                       {
                                          extern BITMAP *map100_bkg, *level_2000;
                                          extern int l[100][100];
                                          int tx = EXint/20;
                                          int ty = EYint/20;

                                          l[tx][ty] = 168;
                                          blit(memory_bitmap[168], level_2000, 0, 0, (tx*20), (ty*20), 20, 20);
                                          putpixel(map100_bkg, tx, ty, 8);
                                          e_killed_type = 11;
                                          event(13);
                                          Ei[EN][0] = 0;

                                       }

                     if (!Ei[EN][8]) /* follow mode */
                        {
                           if ((EXint < PXint) && (Ef[EN][2] < 0))
                              Ef[EN][2] = -Ef[EN][2];
                           if ((EXint > PXint) && (Ef[EN][2] > 0))
                              Ef[EN][2] = -Ef[EN][2];
                        }
                     if ((Ef[EN][2]) > 0)  /* move right */
                        {
                          Ei[EN][2] = 1; /* h_flip to face right */
                          Ef[EN][0] += Ef[EN][2];
                          if (Ei[EN][12]) /* jump before wall */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (is_right_solid(EXint+Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                          if (Ei[EN][11]) /* jump before hole */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (!is_right_solid(EXint+Ei[EN][11]-18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
                          if (is_right_solid(EXint, EYint))
                             {
                                Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                EXint=Ef[EN][0];
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
                           Ei[EN][2] = 0; /* no h_flip */
                           Ef[EN][0] += Ef[EN][2];
                           EXint=Ef[EN][0];
                           if (Ei[EN][12]) /* jump before wall */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (is_left_solid(EXint-Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                           if (Ei[EN][11]) /* jump before hole */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (!is_left_solid(EXint-Ei[EN][11]+18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
      
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                 if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
      
                                 EXint=Ef[EN][0];
                              }
                        }
      
                     if (Ef[EN][9])  /*jump*/
                        {
                           Ef[EN][9] -= .05;
                           if (Ef[EN][9] < .1)      /* top of jump */
                              {
                                 Ef[EN][9] = 0;    /* jump done */
                                 Ef[EN][8] = 1.6;   /* start fall */
      
                              }
                           else
                              {
                                 Ef[EN][1] -= (sin(Ef[EN][9]) * Ef[EN][3]);
                                 EYint=Ef[EN][1];
                                 if (is_up_solid(EXint, EYint, 1, 0))
                                    {
                                       Ef[EN][9] = 0;   /* abort jump */
                                       Ef[EN][8] = 1.6;   /* start fall */
                                    }
                              }
                        }
      
                     else  /* not jump */
                        {
                           if (Ef[EN][8])   /* if fall = 1 */
                              {
                                 Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                                 if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                                 Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                                 if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                                 EYint=Ef[EN][1];
                                 if (is_down_solid(EXint, EYint, 1))  /* look for end of fall */
                                    {
                                       Ef[EN][8] = 0; /*  fall=0;  */
                                       Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                       EYint=Ef[EN][1];
                                    }
                              }
                           if (!Ef[EN][8])  /* fall = 0 */
                              {
                                 /* start fall? look for no block below */
                                 if (!is_down_solid(EXint, EYint, 1)) Ef[EN][8] = 1.6;
      
                                 /* passcount jump */
                                 if ((Ei[EN][6] > 0) && ((passcount % Ei[EN][6]) == 1))
                                    Ef[EN][9] = 1.6; /* jump! */
      
                                 /* jump when player passes over width */
                                 if ((Ei[EN][7] > 0) && (EXint < (PXint + Ei[EN][7])) && (EXint > (PXint - Ei[EN][7])) && (EYint > PYint))
                                    Ef[EN][9] = 1.6;
                              } /* end of fall = 0  */
                        } /* end of else if not fall  */
      
                             /* set the bitmap and drawing mode */
                             b = Ei[EN][3];      /* ans */
                             c = zz[4][b];         /* num_of_shapes in seq */
      
                             if (Ei[EN][4] == 0) Ei[EN][1] = Ei[EN][3]; /* bmp, not ans */
                             if (Ei[EN][4] == 1) Ei[EN][1] = zz[0][b];    /* animate with time */
                             if (Ei[EN][4] == 2) /* animate with h move */
                                {
                                   x = (EXint/3) % c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
                             if (Ei[EN][4] == 3) /* animate with v move */
                                {
                                   x = (EYint/3) % c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
                             if (Ei[EN][4] == 4) /* animate with v and h move */
                                {
                                   x = ((EYint/3) % c) + ((EXint/3) % c);
                                   if (x > c) x-=c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
                  break;
                  case 12: /* flapper

                             Ei[EN][18] = bullet trigger box y1
                             Ei[EN][19] = bullet trigger box y2
                         */
                     if (Ei[EN][31]) /* hit */
                        {
                           int na = 63;
                           int dl = 20;
                           int ht = Ei[EN][31]; /* hit type */
                           Ei[EN][27] = 2; /* bonus type */
                           Ei[EN][26] = 933+(ht-1)*32; /* shape */

                           Ei[EN][24]*=ht; /* bullet bonus */
                           Ei[EN][25]*=ht; /* health bonus */

                           Ei[EN][3] = na; /* new ans */
                           Ei[EN][30] = dl; /* death_loop_wait; /* set delay */
                           Ef[EN][11] = 1.04; /* scale multiplier  */
                           Ef[EN][13] = 0; /* rot inc  */

                           zz[0][na] = zz[5][na]; /* set shape */
                           zz[1][na] = 0;         /* point to zero */
                           zz[2][na] = passcount; /* set counter */
                           zz[3][na] = dl / zz[4][na]; /* set ans timer */

                           Ei[EN][0] = 99; e_killed_type = 12; event(13); /* set type to death loop */
                           break;
                        }
                     if (--Ei[EN][23]<0) /* hit player retrigger */
                        {
                           if (Ei[EN][22]) /* player hit! */
                              {
                                extern float LIFE;
                                LIFE -= Ef[EN][4];
                                e_killed_type = 12;
                                event(12);
                                Ei[EN][22] = 0;
                                Ei[EN][23] = 40;
                              }
                        }
                     else Ei[EN][22] = 0;
                    /* follow in y axis */
                    if (EYint < PYint)
                       {
                          Ef[EN][1] += Ef[EN][3];
                          EYint=Ef[EN][1];
                          if (is_down_solid(EXint, EYint, 1, 0))
                             Ef[EN][1] -= Ef[EN][3]; /* take back move */
                       }
                    if (EYint > PYint)
                       {
                          Ef[EN][1] -= Ef[EN][3];
                          EYint=Ef[EN][1];
                          if (is_up_solid(EXint, EYint, 1, 1))
                             Ef[EN][1] += Ef[EN][3]; /* take back move */
                       }
                     /* bounce in x axis */
                     if ((Ef[EN][2]) > 0)  /* move right */
                        {
                           int prox = Ei[EN][17];
                           Ei[EN][2] = 1; /* h_flip to face right */
                           /* try to shoot right */
                           if (--Ei[EN][16] < 0)
                              if (EYint+Ei[EN][18] > PYint)
                                  if ((EYint-Ei[EN][19]) < PYint)
                                     if (EXint < PXint)
                                        if ((EXint+prox) > PXint)
                                          {
                                             fire_enemy_bulleta(EN, EXint, EYint, 62);
                                             Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                          }
                          Ef[EN][0] += Ef[EN][2];
                          if (is_right_solid(EXint, EYint))
                             {
                                Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                EXint=Ef[EN][0];
                             }
                        }
                     else if ((Ef[EN][2]) < 0)  /* move left */
                        {
                           int prox = Ei[EN][17];
                           Ei[EN][2] = 0; /* no h_flip */
                           /* try to shoot right */
                           if (--Ei[EN][16] < 0)
                              if (EYint+Ei[EN][18] > PYint)
                                  if ((EYint-Ei[EN][19]) < PYint)
                                     if (EXint-prox < PXint)
                                        if ((EXint) > PXint)
                                          {
                                             fire_enemy_bulleta(EN, EXint, EYint, 62);
                                             Ei[EN][16] = Ei[EN][15]; /* set new prox wait */
                                          }
                           Ef[EN][0] += Ef[EN][2];
                           EXint=Ef[EN][0];
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                 Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                 EXint=Ef[EN][0];
                              }
                        }
#ifdef NEWLINES
                     /* put line on head */
                        {
                           int a = 0;
                           extern int lines[50][6];
                                 lines[a][0] = 2;
                                 lines[a][2] = EXint-20;
                                 lines[a][3] = EYint;
                                 lines[a][4] = EXint+40;
                                 lines[a][5] = EYint;
                        }
#endif
                     if (Ei[EN][16] < 0) Ei[EN][3] = 61;
                     else Ei[EN][3] = 60;
                     /* animate with h move */
                       {
                         int b = Ei[EN][3]; /* ans */
                         int c = zz[4][b];  /* num of shapes in seq */
                         x = (EXint/5) % c;
                         Ei[EN][1] = zz[x+5][b];
                       }
                  break;
               }  /* end of switch enemy type */
         } /* end of if enemy active */
}
