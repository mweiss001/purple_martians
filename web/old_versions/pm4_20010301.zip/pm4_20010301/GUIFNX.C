/* guifnx  */


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"

#ifdef MV


extern BITMAP *memory_bitmap[NUM_SPRITES];


/* function prototypes  */

void update_animation(void);
void initialize_zz(void);

int quit_proc();
int load_sprit_proc();
int save_sprit_proc();

int replace_color_proc();
int gridlines_proc();
int line_draw_proc();
int rect_draw_proc();
int new_selection();
int select_all();
int rectfill_draw_proc();
int circle_draw_proc();
int circlefill_draw_proc();
int floodfill_draw_proc();

int rb1_proc(int msg, DIALOG *d, int c);
int rb2_proc(int msg, DIALOG *d, int c);
int rb3_proc(int msg, DIALOG *d, int c);
int rb4_proc(int msg, DIALOG *d, int c);
int rb5_proc(int msg, DIALOG *d, int c);
int rb6_proc(int msg, DIALOG *d, int c);
int rb7_proc(int msg, DIALOG *d, int c);
int ar1_proc(int msg, DIALOG *d, int c);
int ar2_proc(int msg, DIALOG *d, int c);
int ar3_proc(int msg, DIALOG *d, int c);
int ar4_proc(int msg, DIALOG *d, int c);
int ar5_proc(int msg, DIALOG *d, int c);
int ar6_proc(int msg, DIALOG *d, int c);
int bm_rot_proc();
int bm_flip_x_axis_proc();
int bm_flip_y_axis_proc();
int bm_scroll_up_proc();
int bm_scroll_down_proc();
int bm_scroll_left_proc();
int bm_scroll_right_proc();



int quit_proc()
{
   return D_CLOSE;
}
int load_sprit_proc()
{
    load_sprit();
    return D_REDRAW;
}
int save_sprit_proc()
{
   save_sprit();
   return D_REDRAW;
}
int replace_color_proc()
{
   extern int line_draw_mode;
   line_draw_mode = 7;
   return D_REDRAW;
}
int new_selection_proc()
{
   extern int line_draw_mode;
   line_draw_mode = 8;
   return D_REDRAW;
}
int select_all_proc()
{
   extern int slx0, slx1, sly0, sly1;

   slx0 = 0;
   sly0 = 0;
   slx1 = 20;
   sly1 = 20;
   return D_REDRAW;
}
int gridlines_proc()
{
   extern int grid_flag;
   grid_flag = !grid_flag;
   return D_REDRAW;
}
int line_draw_proc()
{
   extern int line_draw_mode;
   line_draw_mode= 1;
   return D_REDRAW;
}
int rect_draw_proc()
{
   extern int line_draw_mode;
   line_draw_mode= 2;
   return D_REDRAW;
}
int rectfill_draw_proc()
{
   extern int line_draw_mode;
   line_draw_mode= 3;
   return D_REDRAW;
}
int circle_draw_proc()
{
   extern int line_draw_mode;
   line_draw_mode= 4;
   return D_REDRAW;
}
int circlefill_draw_proc()
{
   extern int line_draw_mode;
   line_draw_mode= 5;
   return D_REDRAW;
}
int floodfill_draw_proc()
{
   extern int line_draw_mode;
   line_draw_mode= 6;
   return D_REDRAW;
}

int rb1_proc(int msg, DIALOG *d, int c)
{
   extern int line_draw_mode;
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to button function   */
   if (ret == D_CLOSE) {
            line_draw_mode = 0;
            return D_REDRAW;
   }
   return ret;
}
int rb2_proc(int msg, DIALOG *d, int c)
{
   extern int line_draw_mode;
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to button function   */
   if (ret == D_CLOSE) {
            line_draw_mode = 1;
            return D_REDRAW;
   }
   return ret;
}
int rb3_proc(int msg, DIALOG *d, int c)
{
   extern int line_draw_mode;
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to button function   */
   if (ret == D_CLOSE) {
            line_draw_mode = 2;
            return D_REDRAW;
   }
   return ret;
}
int rb4_proc(int msg, DIALOG *d, int c)
{
   extern int line_draw_mode;
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to button function   */
   if (ret == D_CLOSE) {
            line_draw_mode = 3;
            return D_REDRAW;
   }
   return ret;
}
int rb5_proc(int msg, DIALOG *d, int c)
{
   extern int line_draw_mode;
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to button function   */
   if (ret == D_CLOSE) {
            line_draw_mode = 4;
            return D_REDRAW;
   }
   return ret;
}
int rb6_proc(int msg, DIALOG *d, int c)
{
   extern int line_draw_mode;
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to button function   */
   if (ret == D_CLOSE) {
            line_draw_mode = 5;
            return D_REDRAW;
   }
   return ret;
}
int rb7_proc(int msg, DIALOG *d, int c)
{
   extern int line_draw_mode;
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to button function   */
   if (ret == D_CLOSE) {
            line_draw_mode = 6;
            return D_REDRAW;
   }
   return ret;
}
int ar1_proc(int msg, DIALOG *d, int c)
{
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to function   */
   if (ret == D_CLOSE) {

      bm_scroll_up_proc();

      return D_REDRAW; 
   }
   return ret;
}
int ar2_proc(int msg, DIALOG *d, int c)
{
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to function   */
   if (ret == D_CLOSE) {

      bm_scroll_down_proc();

      return D_REDRAW; 
   }
   return ret;
}
int ar3_proc(int msg, DIALOG *d, int c)
{
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to function   */
   if (ret == D_CLOSE) {

      bm_scroll_left_proc();

      return D_REDRAW; 
   }
   return ret;
}
int ar4_proc(int msg, DIALOG *d, int c)
{
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to function   */
   if (ret == D_CLOSE) {

      bm_scroll_right_proc();

      return D_REDRAW; 
   }
   return ret;
}
int ar5_proc(int msg, DIALOG *d, int c)
{
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to function   */
   if (ret == D_CLOSE) {

      bm_flip_x_axis_proc();

      return D_REDRAW; 
   }
   return ret;
}
int ar6_proc(int msg, DIALOG *d, int c)
{
   int ret;
   ret = d_button_proc(msg, d, c);  /* pass to function   */
   if (ret == D_CLOSE) {

      bm_flip_y_axis_proc();

      return D_REDRAW; 
   }
   return ret;
}


int bm_rot_proc()
{
   extern int bmp_index;
   extern int slx0, sly0, slx1, sly1;
   int x_size = slx1 - slx0;
   int y_size = sly1 - sly0;

   int x,y;
   BITMAP *temp_bitmap;
   temp_bitmap = create_bitmap(x_size, y_size);
   clear(temp_bitmap);

   blit(memory_bitmap[bmp_index], temp_bitmap, slx0, sly0,
          0, 0, x_size, y_size);

   rectfill (memory_bitmap[bmp_index], slx0, sly0, slx1-1, sly1-1, 0);

   rotate_sprite(memory_bitmap[bmp_index],  temp_bitmap, slx0, sly0, itofix(32));

   destroy_bitmap(temp_bitmap);
   return D_REDRAW;
}
int bm_flip_x_axis_proc()
{
   extern int bmp_index;
   extern int slx0, sly0, slx1, sly1;
   int x_size = slx1 - slx0;
   int y_size = sly1 - sly0;

   int x,y;
   BITMAP *temp_bitmap;
   temp_bitmap = create_bitmap(x_size, y_size);
   clear(temp_bitmap);

   blit(memory_bitmap[bmp_index], temp_bitmap, slx0, sly0,
          0, 0, x_size, y_size);

   rectfill (memory_bitmap[bmp_index], slx0, sly0, slx1-1, sly1-1, 0);

   draw_sprite_h_flip(memory_bitmap[bmp_index],  temp_bitmap, slx0, sly0);

   destroy_bitmap(temp_bitmap);
   return D_REDRAW;
}
int bm_flip_y_axis_proc()
{
   extern int bmp_index;
   extern int slx0, sly0, slx1, sly1;
   int x_size = slx1 - slx0;
   int y_size = sly1 - sly0;

   int x,y;
   BITMAP *temp_bitmap;
   temp_bitmap = create_bitmap(x_size, y_size);
   clear(temp_bitmap);

   blit(memory_bitmap[bmp_index], temp_bitmap, slx0, sly0,
          0, 0, x_size, y_size);

   rectfill (memory_bitmap[bmp_index], slx0, sly0, slx1-1, sly1-1, 0);

   draw_sprite_v_flip(memory_bitmap[bmp_index],  temp_bitmap, slx0, sly0);

   destroy_bitmap(temp_bitmap);
   return D_REDRAW;
}
int bm_scroll_up_proc()
{
   extern int bmp_index;
   extern int slx0, sly0, slx1, sly1;
   int temp, x, y;
   for (x=slx0; x<slx1; x++)
      {
         temp=getpixel(memory_bitmap[bmp_index],x,sly0);
         for (y=sly0; y<sly1-1; y++)
             putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x,y+1)) );
         putpixel(memory_bitmap[bmp_index],x,sly1-1,temp);
      }
   return D_REDRAW;
}
int bm_scroll_down_proc()
{
   extern int bmp_index;
   extern int slx0, sly0, slx1, sly1;
   int temp, x, y;
   for (x=slx0; x<slx1; x++)
      {
         temp=getpixel(memory_bitmap[bmp_index],x,sly1-1);
         for (y=sly1-1; y>sly0; y--)
             putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x,y-1)) );
         putpixel(memory_bitmap[bmp_index],x,sly0,temp);
      }
   return D_REDRAW;
}
int bm_scroll_left_proc()
{
   extern int bmp_index;
   extern int slx0, sly0, slx1, sly1;
   int temp, x, y;
   for (y=sly0; y<sly1; y++)
      {
         temp=getpixel(memory_bitmap[bmp_index],slx0,y);
         for (x=slx0; x<slx1-1; x++)
             putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x+1,y)) );
         putpixel(memory_bitmap[bmp_index],slx1-1,y,temp);
      }
   return D_REDRAW;
}
int bm_scroll_right_proc()
{
   extern int bmp_index;
   extern int slx0, sly0, slx1, sly1;
   int temp, x, y;
   for (y=sly0; y<sly1; y++)
      {
         temp=getpixel(memory_bitmap[bmp_index],slx1-1,y);
         for (x=slx1-1; x>slx0; x--)
             putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x-1,y)) );
         putpixel(memory_bitmap[bmp_index],slx0,y,temp);
      }
   return D_REDRAW;
}


#endif

