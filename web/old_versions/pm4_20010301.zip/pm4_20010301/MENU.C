/* menu.c  menu stuff and text setup */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"

/* global - declared in menu.c */
char global_string[20][25][80];
char help_string[2400][90];

int pmenu(int menu_num)  /* this menu function does not pass through like the next one */
{                        /* it waits for a selection and then exits */
   int highlight = 2;
   int selection = 999;
   int last_list_item;
   int c, b;
   int kx = mouse_x;
   int ky = mouse_y-20;
   int up = 0;
   char msg[80];
   if (kx < 100) kx = 100;

   if (kx > SCREEN_W-100) kx = SCREEN_W-100;

   if (menu_num == 9) if (ky > SCREEN_H - 160) up=1;
   if (menu_num == 6) if (ky > SCREEN_H - 60) up=1;

   if (!up) /* reverse version ! */
      {
   
         do   /* until selection is made */
            {
               c = 0;
               rest(20);
               show_mouse(NULL);
               while (strcmp(global_string[menu_num][c],"end") != 0)
                 {
                    b = 9 + 96;
                    if (c == 0) b = 9;
                    if (c == highlight) b=9;
                    textout_centre(screen, font, global_string[menu_num][c], kx, ky+(c*8), b);
                    c++;
                 }
               last_list_item = c-1;
               show_mouse(screen);
               highlight = 2;
               if ( (mouse_x > (kx - 100)) && (mouse_x < (kx+100)) )
                   if ( (mouse_y > ky ) && (mouse_y < ky + ((last_list_item+1)*8)) )
                      highlight = (mouse_y-ky) / 8;
      
               if (!(mouse_b & 2)) selection = highlight; /* mouse b2 released */

            } while (selection == 999);
      }
   if (up)  /* normal version */
      {
         ky = mouse_y+12;
         if (ky > SCREEN_H) ky = SCREEN_H;
         do   /* until selection is made */
            {
               c = 0;
      
               rest(20);
               show_mouse(NULL);
               while (strcmp(global_string[menu_num][c],"end") != 0)
                 {
                    b = 9+96;
                    if (c == 0) b = 9;
                    if (c == highlight) b=9;
                    textout_centre(screen, font, global_string[menu_num][c], kx, ky-(c*8), b);
                    c++;
                 }
               last_list_item = c-1;
               show_mouse(screen);
               highlight = 2;
               if ( (mouse_x > (kx - 100)) && (mouse_x < (kx+100)) )
                   if ( (mouse_y < ky ) && (mouse_y > ky - ((last_list_item+1)*8) ) )
                      highlight = (ky-mouse_y+8) / 8;
      
               if (!(mouse_b & 2)) selection = highlight; /* mouse b2 released */
      
            } while (selection == 999);
      }
   show_mouse(NULL);
   return selection;
}



int load_help(void)
{
   FILE *filepntr;
   char buff[90], msg[80];
   int line=0;
   int loop;
   int ch=0;

   if ((exists("pmhelp.txt")) == 0)
      {
         textout(screen, font, "can't find pmhelp.txt", 16, 184, 10);
         rest(5000);
         return 0;
      }
   else
      {
         filepntr=fopen("pmhelp.txt","r");
         while(ch != EOF)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                     buff[loop] = ch;
                     loop++;
                     ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               strcpy (help_string[line], buff);
               line++;
            }
        fclose(filepntr);
      }
   return line;
}
void help(char *topic)
{
   BITMAP *screenbuf;
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern int zz[20][NUM_ANS];
   int ans, c, b, k, x, xindent, just, color, rcolor=15, hcolor=14;
   int got_num =0;
   int redraw = 1;
   int num_of_lines;
   int last_pos;
   int sl = 13; /* position of section list */

   int xo = (SCREEN_W-640)/2;
   int yo = 0;
   int sc=10;  /* section divider */
   int stc=14; /* section divider text color */

   int fc=4;  /* frame color */
   int tc=9;  /* bottom line text color */


   int line = 0;
   int num_sections;
   int section_first_lines[60];
   char section_names[60][80];
   int lpp = (SCREEN_H-48)/8; /* lines per page */
   int y = 8;
   char msg[90], buff2[90];





   screenbuf = create_bitmap(640, SCREEN_H);

   num_of_lines = load_help();

   /* fill section_name, section_first_lines and set last_pos */
   num_sections = 0;
   line = 0;
   while (line < num_of_lines)
      {
         if (strncmp(help_string[line], "<section>", 9) != 0)
            line++;
         else
            {
               strcpy(msg, help_string[line]);
               for(x=9; x < strlen(msg)+1; x++)
                  buff2[x-9] = msg[x]; /* chop first 9 */
               strcpy(section_names[num_sections], buff2);
               section_first_lines[num_sections] = line;

               if (num_sections < 10)
                  sprintf(help_string[line], "<section>0%-1d - %s",  num_sections, section_names[num_sections]);
               else
                  sprintf(help_string[line], "<section>%-2d - %s",  num_sections, section_names[num_sections]);

               line++;
               num_sections++;
            }
         last_pos = section_first_lines[num_sections-1];
       }
   line=0;

   /* add section headings to page 1 */

   /* slide all down */
   for(x=num_of_lines+num_sections; x > (sl-1+num_sections); x--)
      strcpy(help_string[x], help_string[x-num_sections]);

   for (c=0; c<num_sections; c++)
      {
         /* slide section first line numbers */
         if (c > 0) section_first_lines[c]+=num_sections;

         if (c < 10)
            sprintf(msg, "<l07>         0%-1d   %s", c, section_names[c] );
         else
            sprintf(msg, "<l07>         %-2d   %s", c, section_names[c] );
         strcpy(help_string[sl+c], msg);
      }

   last_pos+= num_sections;
   num_of_lines+=num_sections;
   text_mode(-1);

   /* topic */
   if (strlen(topic)>1)
      for (c=0; c<num_sections; c++)
         if (strncmp(section_names[c], topic, strlen(topic)) == 0)
            line = section_first_lines[c];

   show_mouse(NULL);
   clear_keybuf();

   while (!((key[KEY_ESC]) || (mouse_b & 2)))
      {
         if (redraw)
            {
               clear(screenbuf);
               for (x=0;x<16;x++)
                  {
                     hline(screenbuf, x, SCREEN_H-1-x, 639-x, fc+(x*16) );
                     hline(screenbuf, x, x, 639-x, fc+(x*16) );
                     vline(screenbuf, x, x, SCREEN_H-1-x, fc+(x*16) );
                     vline(screenbuf, 639-x, x, SCREEN_H-1-x, fc+(x*16) );
                     textout(screenbuf, font, "<UP><DOWN>", 16, 2, tc);
                     textout(screenbuf, font, "<ESC>-quits", 640-(11*8)-16, 2, tc);
                     textout(screenbuf, font, "<PAGEUP><PAGEDOWN>", 16, SCREEN_H-9, tc);
                     textout(screenbuf, font, "<HOME><END>", 640-(11*8)-16, SCREEN_H-9, tc);
                     textout_centre(screenbuf, font, "Purple Martians Help", 320, 2, tc);
                  }
            }
         else rest(20);
         update_animation();
         for (c=0; c<lpp; c++) /* cycle lines */
            {
               xindent = 0;
               just = 0;
               color = rcolor; /* default regular color */
               sprintf(msg, help_string[line+c]);
               if (strncmp(msg, "<ac", 3) == 0)
                  {
                      buff2[0] = msg[3];
                      buff2[1] = msg[4];
                      buff2[2] = msg[5];
                      buff2[3] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,xo+(640/2)-10,yo+y+4+(c*8),20,20);
                      msg[0]= NULL;
                  }
               if (strncmp(msg, "<a", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,xo+20,yo+y+4+(c*8),20,20);
                      for(x=5; x < strlen(msg)+1; x++)
                         buff2[x-5] = msg[x]; /* chop first 5 */
                      strcpy(msg, buff2);
                      xindent = 24;
                  }
               if (redraw)
                  {
                     if (strncmp(msg, "<section>", 9) == 0)
                        {
                            for(x=9; x < strlen(msg)+1; x++)
                               buff2[x-9] = msg[x]; /* chop first 9 */
                            strcpy(msg, buff2);
                            just = 1;
                            color = stc;
                            for (x=0;x<16;x++)
                               {
                                  hline(screenbuf, 0+x, y+20+(c*8)+x, 640-1-x, sc+(x*16) );
                                  hline(screenbuf, 0+x, y+20+(c*8)-x, 640-1-x, sc+(x*16) );
                               }
                        }
                     if (strncmp(msg, "<s", 2) == 0)
                        {
                            buff2[0] = msg[2];
                            buff2[1] = msg[3];
                            buff2[2] = msg[4];
                            buff2[3] = NULL;
                            ans = atoi(buff2);
                            blit(memory_bitmap[ans], screenbuf, 0,0,20,y+4+(c*8),20,20);
                            for(x=6; x < strlen(msg)+1; x++)
                               buff2[x-6] = msg[x]; /* chop first 6 */
                            strcpy(msg, buff2);
                            xindent = 24;
                        }
                     if (strncmp(msg, "<ms", 2) == 0)
                        {
                            int z;
                            for(z=0; z < 20; z++)
                               {
      
                                  buff2[0] = msg[3+z*3];
                                  buff2[1] = msg[4+z*3];
                                  buff2[2] = msg[5+z*3];
                                  buff2[3] = NULL;
                                  ans = atoi(buff2);
                                  blit(memory_bitmap[ans], screenbuf, 0,0,20+(z*20),y+4+(c*8),20,20);
                               }
                            strcpy(msg, "");
                        }
                     if (strncmp(msg, "<l", 2) == 0)
                        {
                            buff2[0] = msg[2];
                            buff2[1] = msg[3];
                            buff2[2] = NULL;
                            color = atoi(buff2);
                            for(x=5; x < strlen(msg)+1; x++)
                               buff2[x-5] = msg[x]; /* chop first 5 */
                            strcpy(msg, buff2);
                        }
                     if (strncmp(msg, "<c", 2) == 0)
                        {
                            buff2[0] = msg[2];
                            buff2[1] = msg[3];
                            buff2[2] = NULL;
                            color = atoi(buff2);
                            for(x=5; x < strlen(msg)+1; x++)
                               buff2[x-5] = msg[x]; /* chop first five */
                            strcpy(msg, buff2);
                            just = 1;
                        }

                     if (just) textout_centre(screenbuf, font, msg, 640/2, y+16+(c*8), color);
                     else textout(screenbuf, font, msg, 20+xindent, y+16+(c*8), color);
                  }
            }
         if (redraw)
            {
               blit(screenbuf, screen, 0,0,xo,yo, 640, SCREEN_H);
               redraw = 0;
            }

         if ( (key[KEY_UP] & KB_EXTENDED) ||
             ((key[KEY_UP] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line--;
            }
         if ( (key[KEY_DOWN] & KB_EXTENDED) ||
             ((key[KEY_DOWN] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line++;
            }
         if ( (key[KEY_PGUP] & KB_EXTENDED) ||
             ((key[KEY_PGUP] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line--;
               while ((strncmp(help_string[line], "<section>", 9) != 0) && (line > 0))
                  line--;
               while (key[KEY_PGUP]);
            }
         if ( (key[KEY_PGDN] & KB_EXTENDED) ||
             ((key[KEY_PGDN] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line++;
               while ((strncmp(help_string[line], "<section>", 9) != 0) && (line < num_of_lines - lpp))
                  line++;
               while (key[KEY_PGDN]);
            }
         if ( (key[KEY_HOME] & KB_EXTENDED) ||
             ((key[KEY_HOME] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line = 0;
            }
         if ( (key[KEY_END] & KB_EXTENDED) ||
             ((key[KEY_END] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line = last_pos;
            }
         /* limits */
         if (line < 0)  line = 0;
         if (line > last_pos)  line = last_pos;


         if (got_num)
            {
               sprintf(msg, "jump to section %c_", got_num);
               textout_centre(screen, font, msg, xo+320, SCREEN_H-9, tc);
            }
         if (keypressed()) /* don't wait for keypress */
            {
               k = readkey();
               k = (k & 0xFF);  /* strip upper bits */
               if ((k>47) && (k<58))   /* if alphanumeric and return */
                 {
                    clear_keybuf();
                    if (got_num) /* last keypress was num */
                       {
                          int sn = (got_num-48)*10 + (k-48);
                          if (sn < num_sections)
                             line = section_first_lines[sn];
                          redraw = 1;
                          got_num = 0;
                       }
                    else got_num = k;
                 }
               else got_num = 0; /* keypressed but not num */
            }

      }
   while ((key[KEY_ESC]) || (mouse_b & 2)); /* wait till released */
   text_mode(0);
   destroy_bitmap(screenbuf);
   clear(screen);
}
void text_setup()
{
   extern char item_desc[20][40];
   extern char eftype_desc[50][16][40];
   extern char eitype_desc[50][32][40];

   strcpy (item_desc[0],"item_empty");
   strcpy (item_desc[1],"Door");
   strcpy (item_desc[2],"Bonus");
   strcpy (item_desc[3],"Exit");
   strcpy (item_desc[4],"Key");
   strcpy (item_desc[5],"Start");
   strcpy (item_desc[6],"Free Man");
   strcpy (item_desc[7],"Mine");
   strcpy (item_desc[8],"Bomb");
   strcpy (item_desc[9], "undefined");
   strcpy (item_desc[10],"Message");
   strcpy (item_desc[11],"Rocket");
   strcpy (item_desc[12],"Warp");
   strcpy (item_desc[14],"Switch");
   strcpy (item_desc[15],"Sproingy");

  /* --- enemy type 0 variable descriptions --- */
   strcpy (eitype_desc[0][0],"<empty>");
   strcpy (eitype_desc[0][1],"!rsvd bitmap");
   strcpy (eitype_desc[0][2],"!rsvd draw_mode");
   strcpy (eitype_desc[0][3],"ans");
   strcpy (eitype_desc[0][4],"ans type");
   strcpy (eitype_desc[0][5],"-");
   strcpy (eitype_desc[0][6],"-");
   strcpy (eitype_desc[0][7],"-");
   strcpy (eitype_desc[0][8],"-");
   strcpy (eitype_desc[0][9],"collision window");

   strcpy (eftype_desc[0][0],"x pos");
   strcpy (eftype_desc[0][1],"y pos");
   strcpy (eftype_desc[0][2],"x inc");
   strcpy (eftype_desc[0][3],"y inc");
   strcpy (eftype_desc[0][4],"health dec");
   strcpy (eftype_desc[0][5],"-");
   strcpy (eftype_desc[0][6],"-");
   strcpy (eftype_desc[0][7],"-");
   strcpy (eftype_desc[0][8],"-");
   strcpy (eftype_desc[0][9],"-");
   /* --- enemy type 1 variable descriptions --- */
   strcpy (eitype_desc[1][0],"FOLLOWER no walls, grav");
   strcpy (eitype_desc[1][1],"!rsvd bitmap");
   strcpy (eitype_desc[1][2],"!rsvd draw_mode");
   strcpy (eitype_desc[1][3],"ans");
   strcpy (eitype_desc[1][4],"ans type");
   strcpy (eitype_desc[1][5],"-");
   strcpy (eitype_desc[1][6],"-");
   strcpy (eitype_desc[1][7],"-");
   strcpy (eitype_desc[1][8],"-");
   strcpy (eitype_desc[1][9],"collision window");
   strcpy (eftype_desc[1][0],"x pos");
   strcpy (eftype_desc[1][1],"y pos");
   strcpy (eftype_desc[1][2],"x inc");
   strcpy (eftype_desc[1][3],"y inc");
   strcpy (eftype_desc[1][4],"health dec");
   strcpy (eftype_desc[1][5],"-");
   strcpy (eftype_desc[1][6],"-");
   strcpy (eftype_desc[1][7],"-");
   strcpy (eftype_desc[1][8],"-");
   strcpy (eftype_desc[1][9],"-");

   strcpy (eitype_desc[2][0],"FOLLOWER with walls, grav");
   strcpy (eitype_desc[2][1],"!rsvd bitmap");
   strcpy (eitype_desc[2][2],"!rsvd draw_mode");
   strcpy (eitype_desc[2][3],"ans");
   strcpy (eitype_desc[2][4],"ans type");
   strcpy (eitype_desc[2][5]," - ");
   strcpy (eitype_desc[2][6]," - ");
   strcpy (eitype_desc[2][7]," - ");
   strcpy (eitype_desc[2][8]," - ");
   strcpy (eitype_desc[2][9],"collision window");
   strcpy (eftype_desc[2][0],"x pos");
   strcpy (eftype_desc[2][1],"y pos");
   strcpy (eftype_desc[2][2],"x inc");
   strcpy (eftype_desc[2][3],"y inc");
   strcpy (eftype_desc[2][4],"health dec");
   strcpy (eftype_desc[2][5]," - ");
   strcpy (eftype_desc[2][6]," - ");
   strcpy (eftype_desc[2][7]," - ");
   strcpy (eftype_desc[2][8]," - ");
   strcpy (eftype_desc[2][9]," - ");

   strcpy (eitype_desc[3][0],"ArchWagon");
   strcpy (eitype_desc[3][1],"!rsvd bitmap");
   strcpy (eitype_desc[3][2],"!rsvd draw_mode");
   strcpy (eitype_desc[3][3],"ans");
   strcpy (eitype_desc[3][4],"ans type");
   strcpy (eitype_desc[3][5],"bullet wait (0)none");
   strcpy (eitype_desc[3][6],"jump when under player");
   strcpy (eitype_desc[3][7],"jump wait count");
   strcpy (eitype_desc[3][8],"x move (0)follow (1)bounce");
   strcpy (eitype_desc[3][9],"collision window");
   strcpy (eftype_desc[3][0],"x pos");
   strcpy (eftype_desc[3][1],"y pos");
   strcpy (eftype_desc[3][2],"x inc");
   strcpy (eftype_desc[3][3],"y inc");
   strcpy (eftype_desc[3][4],"health dec");
   strcpy (eftype_desc[3][5],"bullet prox wait count");
   strcpy (eftype_desc[3][6],"bullet prox");
   strcpy (eftype_desc[3][7],"bullet prox wait");
   strcpy (eftype_desc[3][8],"!rsvd fall count");
   strcpy (eftype_desc[3][9],"!rsvd jumpcount");

   strcpy (eitype_desc[4][0],"Bouncer");
   strcpy (eitype_desc[4][1],"!rsvd bitmap");
   strcpy (eitype_desc[4][2],"!rsvd draw_mode");
   strcpy (eitype_desc[4][3],"ans");
   strcpy (eitype_desc[4][4],"ans type");
   strcpy (eitype_desc[4][5],"main ans");
   strcpy (eitype_desc[4][6],"seek ans");
   strcpy (eitype_desc[4][7],"bounce count");
   strcpy (eitype_desc[4][8],"seek bounce count wait");
   strcpy (eitype_desc[4][9],"collision window");
   strcpy (eftype_desc[4][0],"x pos");
   strcpy (eftype_desc[4][1],"y pos");
   strcpy (eftype_desc[4][2],"x inc");
   strcpy (eftype_desc[4][3],"y inc");
   strcpy (eftype_desc[4][4],"health dec");
   strcpy (eftype_desc[4][5],"");
   strcpy (eftype_desc[4][6],"");
   strcpy (eftype_desc[4][7],"");
   strcpy (eftype_desc[4][8],"seek speed");
   strcpy (eftype_desc[4][9],"!rsvd sekk");

   strcpy (eitype_desc[6][0],"Cannon");
   strcpy (eitype_desc[6][1],"!rsvd bitmap");
   strcpy (eitype_desc[6][2],"!rsvd draw_mode");
   strcpy (eitype_desc[6][3],"");
   strcpy (eitype_desc[6][4],"");
   strcpy (eitype_desc[6][5],"");
   strcpy (eitype_desc[6][6],"bullet wait");
   strcpy (eitype_desc[6][7],"bounce count");
   strcpy (eitype_desc[6][8],"seek bounce count wait");
   strcpy (eitype_desc[6][9],"collision window");
   strcpy (eftype_desc[6][0],"x pos");
   strcpy (eftype_desc[6][1],"y pos");
   strcpy (eftype_desc[6][2],"x inc");
   strcpy (eftype_desc[6][3],"y inc");
   strcpy (eftype_desc[6][4],"health dec");
   strcpy (eftype_desc[6][5],"");
   strcpy (eftype_desc[6][6],"");
   strcpy (eftype_desc[6][7],"bullet speed");
   strcpy (eftype_desc[6][8],"seek speed");
   strcpy (eftype_desc[6][9],"resvd sekk");

   strcpy (eitype_desc[7][0],"PodZilla ");
   strcpy (eitype_desc[7][1],"!rsvd bitmap");
   strcpy (eitype_desc[7][2],"!rsvd draw_mode");
   strcpy (eitype_desc[7][3],"!rsvd wait count");
   strcpy (eitype_desc[7][4],"wait limit");
   strcpy (eitype_desc[7][5],"seq count");
   strcpy (eitype_desc[7][6],"seq limit");
   strcpy (eitype_desc[7][7],"mode");
   strcpy (eitype_desc[7][8],"trigger distance");
   strcpy (eitype_desc[7][9],"collision window");
   strcpy (eftype_desc[7][0],"x pos");
   strcpy (eftype_desc[7][1],"y pos");
   strcpy (eftype_desc[7][2],"x inc");
   strcpy (eftype_desc[7][3],"y inc");
   strcpy (eftype_desc[7][4],"health dec");
   strcpy (eftype_desc[7][5],"x dest");
   strcpy (eftype_desc[7][6],"y dest");
   strcpy (eftype_desc[7][7],"bullet speed");
   strcpy (eftype_desc[7][8],"");
   strcpy (eftype_desc[7][9],"speed");

   strcpy (eitype_desc[8][0], "TrakBot");
   strcpy (eitype_desc[9][0], "Cloner");
   strcpy (eitype_desc[11][0], "Block Walker");
   strcpy (eitype_desc[12][0], "Flapper");

#ifdef MV
   strcpy (global_string[5][0],"PUT"); /* PD sub menu */
   strcpy (global_string[5][1],"PREV");
   strcpy (global_string[5][2],"NEXT");
   strcpy (global_string[5][3],"");
   strcpy (global_string[5][4],"COPY");
   strcpy (global_string[5][5],"SAVE");
   strcpy (global_string[5][6],"");
   strcpy (global_string[5][7],"BACK");
#endif

   strcpy (global_string[6][0],"Step Pop-Up Menu");
   strcpy (global_string[6][1],"----------------");
   strcpy (global_string[6][2],"Cancel");
   strcpy (global_string[6][3],"Move Step");
   strcpy (global_string[6][4],"Delete Step");
   strcpy (global_string[6][5],"Insert Step");
   strcpy (global_string[6][6],"end");


   strcpy (global_string[9][0], "Level Editor Pop-Up Menu");
   strcpy (global_string[9][1], "------------------------");
   strcpy (global_string[9][2], "Copy ---");
   strcpy (global_string[9][3], "View ---");
   strcpy (global_string[9][4], "Delete ---");
   strcpy (global_string[9][5], "------------------------");
   strcpy (global_string[9][6], "Zoom Full Screen");
   strcpy (global_string[9][7], "Show Status Window");
   strcpy (global_string[9][8], "Show Selection Window");
   strcpy (global_string[9][9], "640x480");
   strcpy (global_string[9][10],"800x600");
   strcpy (global_string[9][11],"1024x768");
   strcpy (global_string[9][12],"Load Level");
   strcpy (global_string[9][13],"Save Level");
   strcpy (global_string[9][14],"Save and Quit");
   strcpy (global_string[9][15],"Help Screens");
   strcpy (global_string[9][16],"Quit Level Editor");
   strcpy (global_string[9][17],"end");

#ifdef MV
   strcpy (global_string[9][17],"----");
   strcpy (global_string[9][18],"Bitmap Menu");
   strcpy (global_string[9][19],"Block Editor");
   strcpy (global_string[9][20],"Predefined Enemy Editor");
   strcpy (global_string[9][21],"Global Level Thingy!!");
   strcpy (global_string[9][22],"end");
#endif

}






