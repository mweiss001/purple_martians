#include "pm.h"
#include "lift.h"

extern int num_lifts;
extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];


