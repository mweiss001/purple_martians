#include "pm.h"

/* global variables  */

struct lift *lifts[20];
struct lift_step *lift_steps[20][20];
int num_lifts;

PALLETE pallete;
BITMAP *memory_bitmap[NUM_SPRITES];
int bcmt[NUM_SPRITES]; /* block color map table */
int sa[NUM_SPRITES][2];
int swbl[NUM_SPRITES][2];
int swbn;

BITMAP *l2000;
BITMAP *l700;   /* 1024x768 */
BITMAP *l600;   /*  800x600 */
BITMAP *l400;   /*  640x480 */
BITMAP *ll700;  /* 1024x768 */
BITMAP *ll600;  /*  800x600 */
BITMAP *ll400;  /*  640x480 */
BITMAP *gtemp;
BITMAP *gtemp2;
BITMAP *gtemp3;
BITMAP *dtemp;

BITMAP *mp;     /*  mouse_pointer */

int rits;

int db;
int txc;
int ty = 46;   /* button start */
int tw = 94;   /* button width */
int bts = 12;  /* button spacing */

int current_lift;

BITMAP *ft_bmp;  /*  file temp paste bmp */

int level_num;

char level_filename[80];
char sel_filename[80];


int exit_link = 0;
int bx1, bx2, by1, by2;
int slx0=0, sly0=0, slx1=20, sly1=20;


int level_header[20];
int l[100][100];    /* level */
int item[500][16];  /* items */

char *pmsg[500]; /* for pop up messages */

int Ei[100][32];    /* enemies */
float Ef[100][16];  /* enemies */
int zz[20][NUM_ANS];
int passcount;
int PDEi[100][32];
float PDEf[100][16];
char PDEt[100][20][40];

int e_num_of_type[50];   /* sort stuff used by others */
int e_first_num[50];

char item_edit_text[80];

char eftype_desc[50][16][40];   /* enemy.c */
char eitype_desc[50][32][40];   /* enemy.c */
char item_desc[20][5][40];

int bmp_index = 255, zzindx = 3;  /* used by edit menu */
int b1_color = 3, bs_win = 0;

int item_num_of_type[20];   /* sort stuff used by others */
int item_first_num[20];
int item_coloc_num;
int item_coloc_x;
int item_coloc_y;

int get100_x, get100_y; /* used by edit functions */
int edit_int_retval;
float edit_float_retval;
float finitial, fxinc, fyinc, flv, fuv;

int stx=10;  /* selection */
int sty=10;
int sux=40;
int suy=30;
int copy_blocks=1;
int copy_enemies=1;
int copy_items=1;
int copy_lifts=1;
int copy_mode = 0;
int fcopy_mode = 0;
int brf_mode =0;
int lines[500][5];
int lc;


int ft_level_header[20];
int ft_l[100][100];
int ft_item[500][16];
char *ft_pmsg[500];
int ft_Ei[100][32];
float ft_Ef[100][16];

char ft_ln[20][80];
int ft_lift[20][4];
int ft_ls[20][20][4];

/* gui stuff   */
int text_draw_flag=0;

int wx=0;
int wy=0;


int draw_item_num;
int draw_item_type;
int point_item_num;
int point_item_type;

int old_draw_item_num;
int old_draw_item_type;
int old_point_item_num;
int old_point_item_type;
int old_line_draw_mode;

int line_draw_mode;
int grid_flag = 0;


BITMAP *select_window_bmp;
BITMAP *status_window_bmp;


int status_window_active = 1;
int status_window_redraw = 1;

int status_window_x;
int status_window_y = 35;
int status_window_w = 320;
int status_window_h = 43;

int select_window_active = 1;
int select_window_redraw = 1;

int select_window_x;
int select_window_y = 100;
int select_window_w = 322;
int select_window_h;
int select_window_text_y;

int select_window_block_on = 1;
int select_window_num_block_lines = 2;
int swnbl = 2;

int select_window_block_y;
int old_b_pointer;
int btext_draw_flag;

int select_window_special_on = 1;
int select_window_num_special_lines = 3;
int select_window_special_y;
int old_s_pointer;
int stext_draw_flag;
int sw_mouse_gone = 0;

int cs=0;
int cspx = 3;   /* color selection pallete */
int cspy = 40;
int csps = 10;
int cspf = 0;

int cbx = 220; /* current bitmap  for gui*/
int cby = 40;
int cbs = 20;
int old_px;
int old_py;

int cols;   /* number of columns for solid blocks in block editor */
int fw = 4; /* frame width for block editor */

/* counters and temp string  */
int a, b, c, d, e, f, x, y;
char msg[80];

void final_wrapup(void)
{
/*   int c;
   destroy_bitmap(l2000);
   destroy_bitmap(l400);
   destroy_bitmap(l600);
   destroy_bitmap(l700);
   destroy_bitmap(mp);
   destroy_bitmap(dtemp);
   for (c=0; c<NUM_SPRITES; c++)
      destroy_bitmap(memory_bitmap[c]);
  */

  allegro_exit();
}
int initial_setup(void)
{
   int c, x, y;
   allegro_init();
   install_keyboard();
   install_timer();
   install_mouse();

   x = get_config_int("LEVEL_EDITOR", "lsx", 640);
   y = get_config_int("LEVEL_EDITOR", "lsy", 480);

   if (set_gfx_mode(GFX_AUTODETECT, x, y, 0,0) != 0)
      {
         /* show the error */
         printf("error %s", allegro_error); /* send to stdout */
         textout_centre(screen, font, "Error setting graphics mode",SCREEN_W/2, 100, 2);
         textout_centre(screen, font, allegro_error ,SCREEN_W/2, 120, 2);
         return 0;
      }
   db = (SCREEN_H/100);
   l2000 = create_bitmap(2000,2000);
   l400 = create_bitmap(400,400);
   l600 = create_bitmap(600,600);
   l700 = create_bitmap(700,700);
   mp = create_bitmap(db*25,db*25);
   dtemp = create_bitmap(20,20);
   for (c=0; c<NUM_SPRITES; c++)
      memory_bitmap[c] = create_bitmap(20,20);
   if (!load_sprit())
      {
         textout_centre(screen, font, "Error loading sprit file...Exiting",SCREEN_W/2, 150, 2);
         return 0;
      }
   initialize_zz(); /* zero the pass counters in the animation seqs */
   load_PDE();
   text_setup(); /* item, enemy, and  menu */
   gui_fg_color = 9;
   txc = SCREEN_W - (SCREEN_W - db*100) / 2;

   select_window_x = SCREEN_W-340;
   status_window_x = SCREEN_W-340;

   /* automatically set rows to new number of lines here    */
   set_swbl(0, NUM_SPRITES, 0);  /* set swbl */
   swnbl = select_window_num_block_lines;

   draw_select_window();
   draw_status_window();

   for (c=0; c<100; c++) /* set all of l[100][100] to 0 */
      for (y=0; y<100; y++)
         l[c][y]=0;
   for (c=0; c < 500; c++) /* set all of item[500][16] to 0 */
      for (y=0; y < 16; y++)
         item[c][y]=0;
   for (c=0; c < 100; c++) /* zero enemies */
      {
         for (y=0; y < 32; y++)
            Ei[c][y] = 0;
         for (y=0; y < 16; y++)
            Ef[c][y] = 0;
      }
   return 1;
}

int main(int argument_count, char **argument_array)  /* look how small it is! */
{
   if (initial_setup())
      {
         int el = 0;
         if (argument_count == 2) el = atoi(argument_array[1]);
         edit_menu(el);
         final_wrapup();
         if ((exit_link) && (el))
            return level_num; /* for auto start play level */
         else return 0;
       }
    else
       {
          rest(3000); /* to view error message */
          return 255;
       }
}

