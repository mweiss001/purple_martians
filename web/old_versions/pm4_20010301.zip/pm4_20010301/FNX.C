/* fnx.c    other functions I don't know where else to put     */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"
#include "lift.h"

extern BITMAP *memory_bitmap[NUM_SPRITES];
extern int swbl[NUM_SPRITES][2];
extern int sa[NUM_SPRITES][2];

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

void update_animation(void);
void initialize_zz(void);

void set_xyinc_rot(int EN, int x2, int y2)
{
   extern int Ei[100][32];
   extern float Ef[100][16];
   float angle, xlen, ylen, xinc, yinc;
   int x1 = Ef[EN][0];
   int y1 = Ef[EN][1];
   float speed = Ef[EN][5];

   xlen = abs(x2 - x1);
   if (xlen == 0) xlen = .0001;
   ylen = abs(y2 - y1);
   
   angle = atan(ylen/xlen);
   xinc = cos(angle) * speed;  /* hypotenuse is the speed! */
   yinc = sin(angle) * speed;
   
   if (x2 > x1) Ef[EN][2] = +xinc;
   if (x2 <= x1) Ef[EN][2] = -xinc;
   if (y2 > y1) Ef[EN][3] = +yinc;
   if (y2 <= y1) Ef[EN][3] = -yinc;
   Ei[EN][20] = get_rot_from_xyinc(EN);
}
void set_rocket_rot(int num, int x2, int y2)
{
   char msg[80];
   extern int item[500][16];
   double angle, angle2, angle3, xlen, ylen, hypot, xinc, yinc;
   double pi = 3.14159265358979323846;
   int x1 = item[num][4];
   int y1 = item[num][5];
   xlen = abs(x2 - x1);
   ylen = abs(y2 - y1);

   if (xlen == 0) xlen = .00000000000000000001;
   angle = atan(ylen/xlen);


   if ((x2 >= x1) && (y2 <= y1)) /* QI */
      angle +=0;
   if ((x2 < x1) && (y2 <= y1)) /* QII */
      angle = pi-angle;
   if ((x2 < x1) && (y2 > y1)) /* QIII */
      angle+= pi;
   if ((x2 >= x1) && (y2 > y1)) /* QIV */
      angle = 2*pi-angle;

   angle2 = angle * (64/(pi/2));
   angle3 = angle2 + 192;

   angle3 = 256 - angle3;
   if (angle3 > 255) angle3-=256;

   if (angle3 < 0) angle3+=256;


/*   sprintf(msg,"xlen:%f ylen:%f hypot:%f ", xlen, ylen, hypot);
   textout(screen, font, msg, 10, 10, 10);
   sprintf(msg," angle:%f  angle2:%f  angle3:%f ", angle, angle2, angle3);
   textout(screen, font, msg, 10, 20, 10);
   tsw();
  */
   item[num][10] = angle3*10;

}
void set_wx(int x, int y)
{
     extern int wx;
     extern int wy;
     int d;
     wx = x - SCREEN_W/40;
     wy = y - SCREEN_H/40;

    /* check limits */
    d = 100 - (SCREEN_W/20);
    if (wx>d) wx = d;
    if (wx<0) wx = 0;

    d = 100 - (SCREEN_H/20);
    if (wy>d) wy = d;
    if (wy<0) wy = 0;
}
void set_wx_from_start_block(void)
{
   extern int item[500][16];
   int c, x, y;
   for (c=0; c<500; c++)  /* get initial wx, wy from start block */
   if (item[c][0] == 5)
      {
         x = item[c][4]/20;
         y = item[c][5]/20;
          break;
      }
   set_wx(x+4, y);
}
int get_rot_from_xyinc(int EN)
{
   extern float Ef[100][16];
   float angle, xlen, ylen;
   int rot=0;

   xlen = abs(Ef[EN][2]);
   if (xlen == 0) xlen = .001; /* to prevent divide by zero */
   ylen = abs(Ef[EN][3]);
   
   angle = atan(ylen/xlen);
   angle *= (64/1.57); /* convert from radians (0 to pi/2) to fixed (0 to 64) */
   
   if (Ef[EN][2] <= 0)    /* xinc <= 0 */
       {
          if (Ef[EN][3] <= 0) rot += 64+angle;   /* yinc <= 0 */
          if (Ef[EN][3] >  0) rot += 64-angle;   /* yinc > 0 */
       }
   if (Ef[EN][2] > 0)    /* xinc > 0 */
       {
          rot += 128;
          if (Ef[EN][3] >  0) rot += 64+angle;   /* yinc > 0 */
          if (Ef[EN][3] <= 0) rot += 64-angle;   /* yinc <= 0 */
       }
   return rot;
}

void show_big(void)
{
   extern BITMAP *l700;  /* 1024x768 */
   extern BITMAP *l600;  /*  800x600 */
   extern BITMAP *l400;  /*  640x480 */
   extern int db;

   if (db==4) blit(l400, screen, 0, 0, 0, 0, 400, 400);
   if (db==6) blit(l600, screen, 0, 0, 0, 0, 600, 600);
   if (db==7) blit(l700, screen, 0, 0, 0, 0, 700, 700);
}
void draw_big(void)
{
   extern int l[100][100];
   extern int item[500][16];
   extern int zz[20][NUM_ANS];
   extern int bmp_index; 
   extern int   Ei[100][32];
   extern float Ef[100][16];
   extern int num_lifts;
   extern BITMAP *l2000;
   extern BITMAP *l700;  /* 1024x768 */
   extern BITMAP *l600;  /*  800x600 */
   extern BITMAP *l400;  /*  640x480 */
   extern BITMAP *dtemp; /*  20x20 */
   extern int db;
   
   int a,b,c,d,x,y;
   char msg[80];
   
   clear(l2000);
   initialize_zz();
   
   for (x=0; x<100; x++)
      for (y=0; y<100; y++)
         if (l[x][y] < NUM_SPRITES) blit(memory_bitmap[l[x][y]], l2000, 0, 0, x*20, y*20, 20, 20);
   
   for (x=0; x<100; x++)
      if (Ei[x][0])
         {
            draw_enemy_shape_l2000(x);

         }
   for (x=0; x<500; x++)
      if (item[x][0])
         {
            int a, b;
            int ex = item[x][4];
            int ey = item[x][5];
            b = item[x][1]; /* bmp or ans */
            if (b > 1000) b = zz[0][b-1000]; /* ans */
            if (item[x][0] == 11) rotate_sprite(l2000, memory_bitmap[b], ex, ey, itofix(item[x][10]/10));
            else draw_sprite(l2000, memory_bitmap[b], ex, ey);
         }
   for (d=0; d<num_lifts; d++)
         {
            int color = lifts[d]->color;
            int x1 = lifts[d]->x1;
            int y1 = lifts[d]->y1;
            int x2 = lifts[d]->x1 + (lifts[d]->width  * 20)-1;
            int y2 = lifts[d]->y1 + (lifts[d]->height * 20)-1;
    
            int tx = ((x1+x2)/2) ;
            int ty = ((y1+y2)/2) -2;
    
            for (a=0; a<10; a++)
               rect(l2000, x1+a, y1+a, x2-a, y2-a, color+((9-a)*16) );
            rectfill(l2000, x1+a, y1+a, x2-a, y2-a, color);

            text_mode(-1);
            textout_centre(l2000, font, lifts[d]->lift_name, tx, ty, color+160);
            text_mode(0);
         }
   
   /* draw lift lines */
   for (a=0; a<num_lifts; a++)  /* cycle lifts */
         {
            int col = lifts[a]->color+128;
            int sx = lift_steps[a][0] -> x + lifts[a]->width *10;
            int sy = lift_steps[a][0] -> y + lifts[a]->height*10;
            int px = sx;
            int py = sy;
            int nx;
            int ny;
   
            for (b=0; b<lifts[a] -> num_steps; b++)  /* cycle step*/
               if (lift_steps[a][b] -> type == 1) /* look for move step */
                  {
                     nx = lift_steps[a][b] -> x + lifts[a]->width *10;
                     ny = lift_steps[a][b] -> y + lifts[a]->height*10;;
                     for (c=3; c>=0; c--)
                        circlefill (l2000, nx, ny, c,  (col-96)+c*48 );
                     line (l2000, px, py, nx, ny, col);
                     px = nx;
                     py = ny;
                  }
               line (l2000, sx, sy, nx, ny, col);
         }
      switch (db)
         {
            case 7:
               clear(l700);
               stretch_blit(l2000, l700, 0, 0, 2000, 2000, 0, 0, 700, 700);
            case 6:
               clear(l600);
               stretch_blit(l2000, l600, 0, 0, 2000, 2000, 0, 0, 600, 600);
            break;
            case 4:
               clear(l400);
               stretch_blit(l2000, l400, 0, 0, 2000, 2000, 0, 0, 400, 400);
            break;
      }
}
void draw_bs(int cc)
{
   BITMAP *jtemp;

   extern BITMAP *l2000;
   extern int db;
   extern int txc;
   int dx, dy, ex, ey, mx, my, ssz, ccz;
   char msg[80];
   int xy_display_on = 1;

   /* get mouse pos */
   dx = mouse_x/db;
   dy = mouse_y/db;

   /* set bulls eye map size */
   if (db == 7) ssz = 300;
   if (db == 4) ssz = 220;
   if (db == 6) ssz = 180;

   ccz = (((ssz/20)-1)/2); /* 7 = 3, 5 = 2, 3 = 1 */

   mx = -ssz/2 + (db*100) + (SCREEN_W-(db*100)) / 2;
   my = (db*100)-ssz-2;

   ex = dx*20 - (ssz/2-10);
   ey = dy*20 - (ssz/2-10);

   show_mouse(NULL);
   if ((dx<100) && (dy < 100))
      {
         /* get background from l2000 for bullseye map sized ssz x ssz */
         jtemp = create_bitmap(ssz, ssz);
         blit(l2000, jtemp, ex, ey, 0, 0, ssz, ssz);

         /* clear edges if neccesary */
         if (dx < ccz)    rectfill  (jtemp,  0,   0,  ((ccz-dx)*20)-1,    ssz-1,   0);
         if (dy < ccz)    rectfill  (jtemp,  0,   0,   ssz-1,   ((ccz-dy)*20)-1,   0);
         
         if (dx > 99-ccz) rectfill  (jtemp,  ssz-(ccz-(99-dx))*20,  0,  ssz-1,  ssz-1,   0);
         if (dy > 99-ccz) rectfill  (jtemp,  0,  ssz-(ccz-(99-dy))*20,  ssz-1,  ssz-1,   0);

         /* draw red bullseye */
         line(jtemp,        0,   ssz/2-10,     ssz-1,  ssz/2-10,  10);
         line(jtemp,        0,   ssz/2+10,     ssz-1,  ssz/2+10,  10);
         
         line(jtemp, ssz/2+10,          0,  ssz/2+10,     ssz-1,  10);
         line(jtemp, ssz/2-10,          0,  ssz/2-10,     ssz-1,  10);

         /* blit bullseye to screen */
         blit(jtemp, screen, 0, 0, mx+1, my+1, ssz-1, ssz-1);

         destroy_bitmap(jtemp);

         /* frame bullseye */
         rect(screen, mx, my, mx+ssz, my+ssz, 10);

         if (xy_display_on)
            {
               sprintf(msg," x=%-2d     y=%-2d ", dx, dy);
               textout_centre(screen, font, msg, txc, my-9, 15);
            }
      }
   else
      {
         if (xy_display_on)
            {
               sprintf(msg,"  mouse off map  ");
               textout_centre(screen, font, msg, txc, my-9, 14);
            }
         /* erase bullseye map */
         rectfill(screen, mx, my, mx+ssz, my+ssz, 0);
      }


   set_clip(screen, 1, 1, db*100-2, db*100-2);
   show_big();
   set_clip(screen, 0, 0, SCREEN_W-1, SCREEN_H-1);

   show_mouse(screen);
   rest(20);

}
int getbox(char *txt)
{
    extern int bx1, by1, bx2, by2;
    extern int db;
    extern int txc;

    int bs_on = 1;
    int quit = 0;

   /* wait for release */
   while (mouse_b & 1);
   show_mouse(NULL);
   draw_big();

   /* erase right panel */
   rectfill(screen, db*100, 52, SCREEN_W-2, SCREEN_H-2, 0 );
   /* erase bottom panel */
   rectfill(screen, 0, db*100, SCREEN_W-1, SCREEN_H-1, 0 );
   /* frame all */
   rect(screen, 0, 0, SCREEN_W-1, db*100-1, 13 );
   /* frame right */
   rect(screen, db*100-1, 0, SCREEN_W-1, db*100-1, 13 );

   /* show text line */
   textout_centre(screen, font, "Draw a new", txc, 72, 9);
   textout_centre(screen, font, txt, txc, 80, 10);
   textout_centre(screen, font, "by clicking and", txc, 88, 9);
   textout_centre(screen, font, "dragging with the", txc, 96, 9);
   textout_centre(screen, font, "left mouse button", txc, 104, 9);

   textout_centre(screen, font, "Cancel with <ESC> or", txc, 130, 14);
   textout_centre(screen, font, "the right mouse button", txc, 138, 9);

   while (!quit)
      {
         int dx = mouse_x/db;
         int dy = mouse_y/db;

         if (bs_on) draw_bs(15);

         /* block cursor */
         if ((dx<100) && (dy < 100))
            {
               /* show which block is selected */
               show_mouse(NULL);
               rect(screen, dx*db, dy*db, (dx+1)*db-1, (dy+1)*db-1, 127-32);
               show_mouse(screen);
            }
         if (mouse_b & 1)
            {
               quit = 1;
               bx1 = mouse_x/db;
               by1 = mouse_y/db;
               while (mouse_b & 1) /* trap it while b1 is held */
                  {
                     bx2 = (mouse_x/db)+1;
                     by2 = (mouse_y/db)+1;

                     if (bs_on) draw_bs(15);

                     /* show selection rectangle */
                     set_clip(screen, 0, 0, db*100-1, db*100-1);
                     rect(screen, (bx1)*db, (by1)*db, (bx2)*db, (by2)*db, 15);
                     set_clip(screen, 0, 0, SCREEN_W-1, SCREEN_H-1);

                  }
           
               /* limits */
               if (bx1<0) bx1 = 0;
               if (bx2<0) bx2 = 0;
               if (by1<0) by1 = 0;
               if (by2<0) by2 = 0;

               if (bx1>99) bx1 = 99;
               if (bx2>99) bx2 = 99;
               if (by1>99) by1 = 99;
               if (by2>99) by2 = 99;
           
               /* ensure top-right, bottom left format */
               if (bx1 > bx2)
                  {
                     int btemp = bx2;
                     bx2 = bx1;
                     bx1= btemp;
                  }
               if (by1 > by2)
                  {
                     int btemp = by2;
                     by2 = by1;
                     by1= btemp;
                  }
            }
         if  (mouse_b & 2)
             {
                while (mouse_b & 2); /* wait for release */
                return 0;
             }
         if (key[KEY_ESC])
             {
                 return 0;
             }
      } /* end of while not quit */
   show_mouse(screen);
  return 1;
}
int getxy(char *txt, int obj_type, int sub_type, int num )
{
   extern int item[500][16];
   extern int   Ei[100][32];
   extern int db;
   extern int txc;
   extern int get100_x, get100_y;
   int dx, dy;

   int bs_on = 1;
   int retval;
   int quit=0;

   show_mouse(NULL);
   show_big();

   title_obj(obj_type, sub_type, num);

   /* erase right panel */
   rectfill(screen, db*100, 52, SCREEN_W-2, SCREEN_H-2, 0 );
   /* erase bottom panel */
   rectfill(screen, 0, db*100, SCREEN_W-1, SCREEN_H-1, 0 );

   /* frame all */
   rect(screen, 0, 0, SCREEN_W-1, db*100-1, 13 );

   /* frame right */
   rect(screen, db*100-1, 0, SCREEN_W-1, db*100-1, 13 );


   while (mouse_b & 1); /* wait for release */

   /* show text line */
   textout_centre(screen, font, txt, txc, 80, 10);
   textout_centre(screen, font, "with left mouse button", txc, 88, 9);
   textout_centre(screen, font, "Cancel", txc, 120, 14);
   textout_centre(screen, font, "with right mouse button", txc, 128, 9);

   while(!quit)
      {
         dx = mouse_x/db;
         dy = mouse_y/db;

         if (bs_on) draw_bs(14);  /* show bullseye map */
         if ((dx<100) && (dy < 100)) /* show cursor */
            {
                set_clip(screen, 1, 1, db*100-2, db*100-2);
                switch (obj_type)
                   {
                       /* show draw_item */

                       case 2: /* show item */
                       case 3: /* show enem */

                       /* draw box to show cursor */
                       rect(screen, dx*db, dy*db, (dx+1)*db-1, (dy+1)*db-1, 127-32); break;

                       break;

                       case 4: /* show lift */
                          {
                             extern int current_lift;
                             extern BITMAP *mp;
                             int col = lifts[current_lift]->color;
                             int w = lifts[current_lift]->width;
                             int h = lifts[current_lift]->height;

                             int np=0;
                             int npp[20][2];
                             int x;

                             draw_lift_mp(); /* draw current lift on mp */
                             draw_sprite(screen, mp, dx*db, dy*db);

                             /* draw lift lines */
                             for (x=0; x<20; x++)
                                 if (lift_steps[current_lift][x] -> type == 1)
                                    {
                                       if (x == num)
                                          {
                                             npp[np][0] = dx*db + w*db/2;
                                             npp[np][1] = dy*db + h*db/2;
                                             np++;
                                          }
                                       else
                                          {
                                             npp[np][0] = ((lift_steps[current_lift][x] -> x + w*10) *db)/20;
                                             npp[np][1] = ((lift_steps[current_lift][x] -> y + h*10) *db)/20;
                                             np++;
                                          }
                                    }
                             /* draw array of lines */
                             for (x=0; x<np-1; x++)
                                line (screen, npp[x][0], npp[x][1], npp[x+1][0], npp[x+1][1], col);
                             /* draw last line */
                             line (screen, npp[np-1][0], npp[np-1][1], npp[0][0], npp[0][1], col);
                          }
                       break;
                   }
                set_clip(screen, 0, 0, SCREEN_W-1, SCREEN_H-1);

             }
         rest(10);
         show_mouse(screen);
         rest(10);
         show_mouse(NULL);


          if  (mouse_b & 1)
             {
                while (mouse_b & 1); /* wait for release */
                quit =1;
                retval = 1;  /* b1 xy */
             }
         if  (mouse_b & 2)
             {
                while (mouse_b & 2); /* wait for release */
                quit =1;
                retval = 2;  /* b2 xy */
             }
         if (key[KEY_ESC])
             {
                 quit = 1;
                 retval = 0;  /* ignore xy */
             }
      } /* end of while(!quit);   */
   if (dx > 99) dx = 99;
   get100_x = dx;
   if (dy > 99) dy = 99;
   get100_y = dy;
   return retval;
}



int edit_float(int x, int y)
{
   extern float edit_float_retval;
   extern float finitial, fxinc, fyinc, flv, fuv;  /* I used to pass these but now it dont work */
   int imx = mouse_x; /* initial mouse position */
   int imy = mouse_y;
   int quit_mode=0, retval, quit=0;
   int old_mouse_x, old_mouse_y;
   char msg[80];
   show_mouse(NULL);
   if (mouse_b & 1) quit_mode = 1;   /* set mouse exit mode if b1 pressed on enter */
   while (!quit)
      {
         sprintf(msg,"%-4.3f",finitial);
         textout(screen, font, msg, x, y, 10);
   
         if ((quit_mode == 1) && (!(mouse_b & 1)) )     /* wait for b1 release */
            {
               clear_keybuf();
               sprintf(msg,"%-4.3f",finitial);
               textout(screen, font, msg, x, y, 11);
               edit_float_retval = finitial;
               retval = 1;
               quit = 1;
            }
         if ((quit_mode == 0) && (key[KEY_ENTER]))
            {
               clear_keybuf();
               sprintf(msg,"%f  ",finitial);
               textout(screen, font, msg, x, y, 10);
               edit_float_retval = finitial;
               retval = 1;
               quit = 1;
            }
         if (key[KEY_0]) finitial = 0;
         if (key[KEY_1]) finitial = 1;
         if (key[KEY_2]) finitial = 2;
         if (key[KEY_3]) finitial = 3;
         if (key[KEY_4]) finitial = 4;
         if (key[KEY_5]) finitial = 5;
         if (key[KEY_6]) finitial = 6;
         if (key[KEY_7]) finitial = 7;
         if (key[KEY_8]) finitial = 8;
         if (key[KEY_9]) finitial = 9;
         if ((key[KEY_ESC]) || (mouse_b & 2))
            {
               retval = 0;
               quit = 1;
            }

         position_mouse(160,100);
         old_mouse_x = mouse_x;
         old_mouse_y = mouse_y;
         rest(20); /* this wait is crucial to get mouse movement */
     
         finitial += (mouse_x - old_mouse_x) * fxinc;
         finitial += (mouse_y - old_mouse_y) * fyinc;

         /* check and enforce limits */
         if (finitial > fuv) finitial = fuv;
         if (finitial < flv) finitial = flv;
      }
   position_mouse(imx, imy); /* set original mouse position */
   show_mouse(screen);

   return retval;
}

int edit_int(int x, int y, int initial, int inc, int lv, int uv)
{
   extern int edit_int_retval;
   int imx = mouse_x;
   int imy = mouse_y;
   int quit_mode = 0, retval, quit=0, old_mouse;
   char msg[80];
   
   if (mouse_b & 1) quit_mode = 1;   /* set mouse exit mode if b1 pressed on enter */
   clear_keybuf();
   show_mouse(NULL);
   while (!quit)
      {
         position_mouse(160, 100);
         old_mouse = mouse_y;
         sprintf(msg,"%d ",initial);
         textout(screen, font, msg, x, y, 10);
         rest(10);

         initial = initial - ((mouse_y - old_mouse) * inc);

         if (initial > uv) initial = uv;
         if (initial < lv) initial = lv;

         if (key[KEY_UP])
            {
               clear_keybuf();
               rest(5);
               initial += inc;
            }
         if (key[KEY_DOWN])
            {
               clear_keybuf();
               rest(5);
               initial -= inc;
            }
         if (quit_mode == 1)
            {
               if (!(mouse_b & 1))
                  {
                     clear_keybuf();
                     sprintf(msg,"%d  ",initial);
                     textout(screen, font, msg, x, y, 11);
                     edit_int_retval = initial;
                     retval = 1;
                     quit = 1;
                  }
            }
         if (quit_mode == 0)
            {
               if ((key[KEY_ENTER]) || (mouse_b & 1))
                  {
                     clear_keybuf();
                     sprintf(msg,"%d  ",initial);
                     textout(screen, font, msg, x, y, 11);
                     edit_int_retval = initial;
                     retval = 1;
                     quit = 1;
                  }
            }
         if ((key[KEY_ESC]) || (mouse_b & 2))
            {
               clear_keybuf();
               retval = 0;
               quit = 1;
            }
      } /* end of  while (!quit); */
   position_mouse(imx, imy);
   return retval;
}
void initialize_zz(void)
{
   extern int passcount;
   extern int zz[20][NUM_ANS];
   int c;
   for (c=0; c<NUM_ANS; c++)
      zz[2][c]=0;  /* reset the passcount */
   passcount = 0;

   for (c=0; c<NUM_ANS; c++)
      zz[0][c]=zz[5][c];  /* set shape one */
}

void update_animation(void)
{
   extern int passcount;
   extern int zz[20][NUM_ANS];
   int y;
   passcount++;   /* animation update */
   for (y=0; y<NUM_ANS; y++)
      if (zz[4][y] != 0)
         if ((passcount - zz[2][y]) > zz[3][y])
            {
               zz[1][y]++;     /* next bitmap */
               zz[2][y] = passcount;      /* set counter */
               if (zz[1][y] > zz[4][y]) zz[1][y] = 0;    /* is bitmap past end? */
               zz[0][y] = zz[ 5 + zz[1][y] ] [y];      /* put shape in 0 */
            }
}

void set_swbl(int start_shape, int end_shape, int mt)
{
   /* set swbl */
   extern int swbn;
   extern int cols;
   extern int fw;
   extern int select_window_num_block_lines;
   int c;

   if (mt) cols = (SCREEN_W / (20 + (fw*2)));
   else cols = 16;
   for (c=0; c<NUM_SPRITES; c++)
      {
         swbl[c][0] = 0;
         swbl[c][1] = 0;
      }
   swbn = 0; /* set number of blocks to zero initially */
   for (c=start_shape; c<=end_shape; c++)
      if ((sa[c][0] == 1) && (sa[c][1] == 1)) /* if block and locked */
            swbl[swbn++][0] = c;   /* put shape # in list and inc counter */
   for (c=start_shape; c<=end_shape; c++)
      if ((sa[c][0] == 1) && (sa[c][1] == 0)) /* if block and unlocked */
            swbl[swbn++][0] = c;   /* put shape # in list and inc counter */
   if (mt)
      {
         int tswbn = swbn;
         for (c=start_shape; c<=end_shape; c++)
            if ((sa[c][0] == 0) && (sa[c][1] == 0)) /* if empty and unlocked */
                  swbl[tswbn++][0] = c;   /* put shape # in list and inc counter */

      }
   select_window_num_block_lines = ((swbn-1)/cols) + 1; /* initial number of lines */

   if (mt) if (swbn % cols == 0) select_window_num_block_lines++;
}
int draw_framed_shape(int x, int y, int shape, int frame_width, int ci)
{
   int a, b, cc;
   int vv;
   if (sa[shape][0] == 0) cc = 11; /* green empty */
   if (sa[shape][0] == 1) cc = 12; /* blue unlocked block */
   if (sa[shape][1] == 1) cc = 10; /* red locked */

   vv = cc;

   for (a=0; a<frame_width; a++)
      {
         b = (frame_width*2) - a ;
         rect(screen, x+a, y+a, x+19+b, y+19+b, cc);
         cc +=ci;
      }

   blit(memory_bitmap[shape], screen, 0, 0, x+frame_width, y+frame_width, 20, 20 );
   return vv;
}
