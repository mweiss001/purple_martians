#include "pm.h"

void press_any()
{
   extern int joy_key;
   clear_keybuf();
     if (joy_key) /* joystick control */
        {

           do {
                poll_joystick();
              } while ((joy_b1) || (joy_b2));  /* wait for release */
           do {
                poll_joystick();

              } while ((!joy_b1) && (!keypressed()) && (!joy_b2));  /* wait for press */
        }
     else readkey();
}

extern BITMAP *memory_bitmap[NUM_SPRITES];

void frame_and_title(void)
{
    BITMAP *pm_title;
    BITMAP *temp_title;
    int x,y;

    pm_title = create_bitmap(280,20);
    temp_title = create_bitmap(140,8);
    clear(pm_title);
    clear(temp_title);


      textout_centre(temp_title, font, "Purple Martians!", 70,0,200);
      for (x=0; x<5; x++)
         for (y=0; y<5; y++)
            stretch_sprite(pm_title, temp_title, x,y,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,136);
      stretch_sprite(pm_title, temp_title, 1,1,280,16);
      stretch_sprite(pm_title, temp_title, 1,3,280,16);
      stretch_sprite(pm_title, temp_title, 3,1,280,16);
      stretch_sprite(pm_title, temp_title, 3,3,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,8);
      stretch_sprite(pm_title, temp_title, 2,2,280,16);


   for (x=0;x<16;x++)
      rect(screen, x,x, SCREEN_W-1-x, SCREEN_H-1-x, 8+(x*16) );

   blit(pm_title, screen,0,0,(SCREEN_W/2)-140,20,280,20);

   blit(memory_bitmap[32], screen, 0, 0, 30, 70, 20, 20);
   blit(memory_bitmap[32], screen, 0, 0, SCREEN_W-50, 70, 20, 20);

   draw_sprite(screen, memory_bitmap[401], 28, 50);
   draw_sprite_h_flip(screen, memory_bitmap[401], SCREEN_W-48, 50);

   text_mode(-1);

#ifdef MV
   textout_centre(screen, font, "Michael's Version x.x", SCREEN_W/2,SCREEN_H-9, 15);
#else
   textout_centre(screen, font, "Version 4.01", SCREEN_W/2,SCREEN_H-9,15);
#endif
   destroy_bitmap(pm_title);
   destroy_bitmap(temp_title);
   text_mode(0);
}

void mtextout(BITMAP *dbmp, char *txt1, int x, int y, float x_scale, float y_scale, int col)
{
   /*
      this function will
      determine the size of bitmap needed by the length of the string
      determine the size of the destination
      create the bitmap
      draw text on it
      stretch blit to screen
   */
      BITMAP *temp;
      int sw = strlen(txt1) * 8;
      int sh = 8;
      int dw = sw * x_scale;
      int dh = sh * y_scale;

      temp = create_bitmap(sw,sh);
      clear(temp);
      textout(temp, font, txt1, 0, 0, col);
   /*   stretch_blit(temp, dbmp, 0, 0, sw, sh, x, y, dw, dh); */
      stretch_sprite(dbmp, temp, x, y, dw, dh);

      destroy_bitmap(temp);
}
void mtextout_centre(BITMAP *dbmp, char *txt1, int x, int y, float x_scale, float y_scale, int col)
{
   /*
      this function will
      determine the size of bitmap needed by the length of the string
      determine the size of the destination
      create the bitmap
      draw text on it
      stretch blit to screen
   */
      BITMAP *temp;
      int sw = strlen(txt1) * 8;
      int sh = 8;
      int dw = sw * x_scale;
      int dh = sh * y_scale;
      char msg[80];

      temp = create_bitmap(sw,sh);
      clear(temp);
      textout(temp, font, txt1, 0, 0, col);
   /*   stretch_blit(temp, dbmp, 0, 0, sw, sh, x, y, dw, dh); */
      stretch_sprite(dbmp, temp, x-dw/2, y, dw, dh);

      destroy_bitmap(temp);
}
void stretch_text(char *txt1, char* txt2, int col)
{
      BITMAP *btemp;
      BITMAP *stemp;

      int ns = 8; /* num of shadows */
      int so = 1; /* shadow offset */
      int ci = 16; /* color inc  */
      int st = 6;  /* skip step between 1st and 2nd color  */
      int a;

      int bxw, bxh, x_double, y_double;
      int border_x, border_y, final_x, final_y;

      int num_lines = 2;
      int llen;
      int pressline;


      if (strlen(txt2)==0) num_lines = 1;

      if ( strlen(txt2) > strlen(txt1) )
         llen = strlen(txt2);
      else
         llen = strlen(txt1);

      bxw = llen*8;
      bxh = num_lines*8; /* only one line for now */

      x_double = SCREEN_W/bxw;

      x_double /=2;

      y_double = x_double*2;

      border_x = (SCREEN_W-(bxw*x_double))/2;
      border_y = (SCREEN_H-(bxh*y_double))/2;

      final_x = SCREEN_W-border_x*2;
      final_y = SCREEN_H-border_y*2;

      btemp = create_bitmap(bxw, bxh);
      clear(btemp);

      for (a = ns; a >= 0; a--)
         {
            int b = col+a*ci;
            if (a) b = col+( (a+st) * ci); /* not first color */
            textout_centre(btemp, font, txt1, bxw/2, 0, b);
            textout_centre(btemp, font, txt2, bxw/2, 8, b);
            stretch_sprite(screen, btemp, border_x+a, border_y+a, final_x, final_y);
         }
      destroy_bitmap(btemp);

      btemp = create_bitmap(248, 8);
      clear(btemp);
      textout(btemp, font, "...press any key to continue...", 0, 0, 5);

      x_double = SCREEN_W/248;
      if (x_double < 1) x_double = 1;
      y_double = x_double;

      stretch_sprite(screen, btemp, (SCREEN_W-(x_double*248))/2, SCREEN_H-border_y+10, x_double*248, y_double*8);

      destroy_bitmap(btemp);
      press_any();


}
extern BITMAP *level_2000, *scrn_buffer;
extern BITMAP *map100_bmp, *map100_bkg;
extern int zz[20][NUM_ANS];
extern int l[100][100];    /* level */

extern float PX, PY;
extern int WX, WY;
extern int game_map_on;

extern int map_double; /* game map double */
extern int map100_x, map100_y;
extern int game_map_on, top_display_on;
extern int top_display_x, top_display_y, top_display_color;
extern int bottom_display_y, bottom_display_color;

extern int map_solid_color, map_semi_color;
extern int map_break_color, map_empty_color;
extern int map_enemy_color , map_bullet_color;
extern int map_item_color, map_player_color;

extern int md; /* menu map double */
extern int mx;
extern int my;


void next_map_mode()
{
   if (game_map_on)
      {
         game_map_on = 0;
         if (map100_x < 40) map100_x = SCREEN_W - map_double*100;
         else map100_x = 0;
         if (map100_y < 40) map100_y = SCREEN_H - map_double*100;
         else map100_y = 0;
         if ((SCREEN_W == 320) && (map100_y < 20))
            map100_y = 20;
      }
   else game_map_on = 1;
}
void draw_map()
{
   if ( (PX-WX) < SCREEN_W/2 - 20) map100_x = SCREEN_W - map_double*100;
   if ( (PX-WX) > SCREEN_W/2 + 20) map100_x = 0;
   if ( (PY-WY) < SCREEN_H/2 - 20) map100_y = SCREEN_H - map_double*100;
   if ( (PY-WY) > SCREEN_H/2 + 20) map100_y = 0;
   if ((SCREEN_W == 320) && (map100_y < 20))
      map100_y = 20;


      stretch_sprite(scrn_buffer, map100_bmp, map100_x, map100_y, map_double*100, map_double*100);
   blit(map100_bkg, map100_bmp, 0,0,0,0,100,100);
}
void draw_top_display(void)
   {
      int ho = 69;
      char msg[80];
      extern int level_time;
      extern int num_bullets;
      extern int play_level;
      extern float LIFE;
      extern int LIVES;
      sprintf(msg,"Level:%-3d",play_level) ;
      textout(scrn_buffer, font, msg, top_display_x + 2, top_display_y + 2, top_display_color);
      sprintf(msg,"Lives:%-1d",LIVES) ;
      textout(scrn_buffer, font, msg, top_display_x + 2, top_display_y + 11, top_display_color);
      sprintf(msg,"Health") ;
      textout(scrn_buffer, font, msg, top_display_x + ho+2, top_display_y + 2, top_display_color);
      rectfill (scrn_buffer, top_display_x+ho, top_display_y + 10, top_display_x + ho+50, top_display_y +17, 10); /*  red   */
      rectfill (scrn_buffer, top_display_x+ho, top_display_y + 10, top_display_x + ho+(LIFE/2), top_display_y +17, 11); /*  green */

      sprintf(msg,"Time:%-3d",level_time/50);
      textout(scrn_buffer, font, msg, top_display_x + 124, top_display_y + 2, top_display_color);
      sprintf(msg,"Shot:%-3d",num_bullets);
      textout(scrn_buffer, font, msg, top_display_x + 124, top_display_y + 11, top_display_color);
   }
extern float steps;
void stamp(void)   /* stretch map animated shrinkage of play screen to map */
{

       add_eilp_to_l2000();
       WX = PX - (SCREEN_W/2)-10; /* set window from PX,PY */
       WY = PY - (SCREEN_H/2)-10;
       if (WX < 0) WX = 0;
       if (WX > 1999 - SCREEN_W) WX = 1999 - SCREEN_W;
       if (WY > 1999 - SCREEN_H) WY = 1999 - SCREEN_H;
       if (WY < 0) WY = 0;
   
      if (1)
         {
            int x, y;
            float inc1 = (0-WX)/steps;
            float inc2 = (0-WY)/steps;
            float inc3 = (2000-SCREEN_W)/steps;
            float inc4 = (2000-SCREEN_H)/steps;
            float inc5 = (mx-0)/steps;
            float inc6 = (my-0)/steps;
            float inc7 = (md*100-SCREEN_W)/steps;
            float inc8 = (md*100-SCREEN_H)/steps;


            float s1 = WX;
            float s2 = WY;
            float s3 = SCREEN_W;
            float s4 = SCREEN_H;
            float s5 = 0;
            float s6 = 0;
            float s7 = SCREEN_W;
            float s8 = SCREEN_H;
            BITMAP *ht;

            ht = create_bitmap(SCREEN_W, SCREEN_H);

            for (x = 0; x<=steps; x++)
               {

                  stretch_blit(level_2000, ht,s1,s2,s3,s4,s5,s6,s7,s8);

                  rectfill(ht,s5-inc5, s6     , s5-inc5+s7-inc7, s6-inc6,         0);
                  rectfill(ht,s5-inc5, s6+s8  , s5-inc5+s7-inc7, s6-inc6+s8-inc8, 0);

                  rectfill(ht,s5-inc5, s6-inc6, s5,              s6-inc6+s8-inc8, 0);
                  rectfill(ht,s5+s7  , s6-inc6, s5-inc5+s7-inc7, s6-inc6+s8-inc8, 0);

                  blit(ht, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

               /*   rest(x/steps*5); */

                  s1+=inc1;
                  s2+=inc2;
                  s3+=inc3;
                  s4+=inc4;
                  s5+=inc5;
                  s6+=inc6;
                  s7+=inc7;
                  s8+=inc8;


               }

       }
}
void stimp(void)   /* stretch map animated growage of map to play screen */
{
       add_eilp_to_l2000();
       WX = PX - (SCREEN_W/2)-10; /* set window from PX,PY */
       WY = PY - (SCREEN_H/2)-10;
       if (WX < 0) WX = 0;
       if (WX > 1999 - SCREEN_W) WX = 1999 - SCREEN_W;
       if (WY > 1999 - SCREEN_H) WY = 1999 - SCREEN_H;
       if (WY < 0) WY = 0;
   
      if (1)
         {
            int x, y;

            float inc1 = (0-WX)/steps;
            float inc2 = (0-WY)/steps;
            float inc3 = (2000-SCREEN_W)/steps;
            float inc4 = (2000-SCREEN_H)/steps;
            float inc5 = (mx-0)/steps;
            float inc6 = (my-0)/steps;
            float inc7 = (md*100-SCREEN_W)/steps;
            float inc8 = (md*100-SCREEN_H)/steps;


            float s1 = 0;
            float s2 = 0;
            float s3 = 2000;
            float s4 = 2000;
            float s5 = mx;
            float s6 = my;
            float s7 = md*100;
            float s8 = md*100;
            BITMAP *ht;

            ht = create_bitmap(SCREEN_W, SCREEN_H);

            blit(screen, ht, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

            for (x = 0; x<=steps; x++)
               {
                  stretch_blit(level_2000, ht,s1,s2,s3,s4,s5,s6,s7,s8);

                  blit(ht, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                  rest(x/steps*5);

                  s1-=inc1;
                  s2-=inc2;
                  s3-=inc3;
                  s4-=inc4;
                  s5-=inc5;
                  s6-=inc6;
                  s7-=inc7;
                  s8-=inc8;

               }
       }
    restore_l2000();
}
void get_new_background()
{
    WX = PX - (SCREEN_W/2)-10; /* set window from PX,PY */
    WY = PY - (SCREEN_H/2)-10;
    if (WX < 0) WX = 0;
    if (WX > 1999 - SCREEN_W) WX = 1999 - SCREEN_W;
    if (WY > 1999 - SCREEN_H) WY = 1999 - SCREEN_H;
    if (WY < 0) WY = 0;
    blit(level_2000, scrn_buffer, WX, WY, 0, 0, SCREEN_W, SCREEN_H);
}
void draw_pop_msg()
{
   extern int item[500][16];
   extern char *pmsg[500];
   extern int pop_msg;

   int c = pop_msg-1;
   int x = SCREEN_W/2;
   int y = 40;

   int len = strlen(pmsg[c]);
   char msg[80];
   char dt[20][80];
   int row = 0, col = 0;
   int longest_line_len = 1; /* default */
   int num_lines = 0;
   int xpos_c = x;
   int ypos = y;
   int xw;
   int a;
   int tc = item[c][8];
   int fc = item[c][9];
   int px, py, px2, py2;

   for (a=0; a<len+1; a++)
      {
          if (pmsg[c][a] == 13) /* line break */
            {
               row++;
               col=0;
               dt[row][col] = NULL; /* in case len = 0 */
            }
         else  /* regular char */
            {
               dt[row][col] = pmsg[c][a];
               if (col > longest_line_len) longest_line_len = col;
               col++;
               dt[row][col] = NULL;
            }
      }
   num_lines = row;

   xw = (longest_line_len+1)*4;
   px  = xpos_c-xw-2-8;
   py  = ypos-2-8;
   px2 = xpos_c+xw+8;
   py2 = ypos+(num_lines+1)*8+8;

   a = 7;  /* erase */
   rectfill(scrn_buffer, px+a,py+a,px2-a,py2-a,0);

   for (a=0; a<8; a++) /* frame */
      rect(scrn_buffer, px+a,py+a,px2-a,py2-a,fc+a*16);

   for (row=0; row<=num_lines; row++) /* text */
      textout_centre(scrn_buffer, font, dt[row], xpos_c, ypos+row*8, tc);
}

