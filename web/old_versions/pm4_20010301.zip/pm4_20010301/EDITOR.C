#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"
#include "lift.h"

extern int num_lifts;
extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

extern BITMAP *memory_bitmap[NUM_SPRITES];



void tsw(void)
{
   clear_keybuf();
   while (!keypressed());
   clear_keybuf();
}

void draw_enemy_shape_l2000(int e)
{
   extern int Ei[100][32];
   extern float Ef[100][16];
   extern BITMAP *l2000;
   extern BITMAP *dtemp;
   int x = Ef[e][0];
   int y = Ef[e][1];

   clear(dtemp);
   /* put shape in dtemp and process flips */
   if (Ei[e][2] == 0)  draw_sprite_h_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   if (Ei[e][2] == 1)         draw_sprite(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   if (Ei[e][2] == 2)  draw_sprite_v_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   if (Ei[e][2] == 3) draw_sprite_vh_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   /* process rotation */
   if (Ei[e][20])
      rotate_sprite(l2000, dtemp, x, y, itofix(Ei[e][20]) );
   else draw_sprite(l2000, dtemp, x, y);
}
void draw_item_shape(int num, int x, int y)
{
   extern int item[500][16];
   extern int zz[20][NUM_ANS];
   extern BITMAP *dtemp;
   int shape = item[num][1]; /* bmp or ans */
   if (shape > 999) shape = zz[0][shape-1000]; /* ans */
   clear(dtemp);
   if (item[num][0] == 11)
      rotate_sprite(dtemp, memory_bitmap[shape], 0, 0, itofix(item[num][10]/10));
   else draw_sprite(dtemp, memory_bitmap[shape], 0, 0);
   blit(dtemp, screen, 0, 0, x, y, 20, 20);
}
void draw_enemy_shape(int e, int x, int y)
{
   extern int Ei[100][32];
   extern BITMAP *dtemp;
   clear(dtemp);
   /* put shape in dtemp and process flips */
   if (Ei[e][2] == 0)  draw_sprite_h_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   if (Ei[e][2] == 1)         draw_sprite(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   if (Ei[e][2] == 2)  draw_sprite_v_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   if (Ei[e][2] == 3) draw_sprite_vh_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
   set_clip(screen, x, y, x+19, y+19);
   /* process rotation */
   if (Ei[e][20])
      rotate_sprite(screen, dtemp, x, y, itofix(Ei[e][20]) );
   else draw_sprite(screen, dtemp, x, y);
   set_clip(screen, 0, 0, SCREEN_W-1, SCREEN_H-1);
}


void show_draw_item_cursor(void)
{
   extern int item[500][16];
   extern int PDEi[100][32];
   extern int zz[20][NUM_ANS];
   extern int Ei[100][32];
   extern BITMAP *dtemp;
   extern BITMAP *gtemp;
   extern BITMAP *gtemp2;
   extern BITMAP *gtemp3;
   extern int wx, wy;
   extern int draw_item_type;
   extern int draw_item_num;
   int x100, y100, x, y, a, gbmp = 0;

   x100 = mouse_x/20 + wx;
   y100 = mouse_y/20 + wy;

   if (x100>99) x100 = 99;
   if (y100>99) y100 = 99;

   x = (x100-wx)*20;
   y = (y100-wy)*20;


   /* show where draw item would go */
   clear(gtemp3);
   show_mouse(NULL);
   /* get background */
   blit (screen, gtemp, x, y, 0, 0, 20, 20);
   /* show draw item */
   switch (draw_item_type)
      {
         case 1: gbmp = draw_item_num; break;
         case 2: draw_item_shape(draw_item_num, x, y); break;
         case 3: draw_enemy_shape(draw_item_num, x, y); break;
         case 4: gbmp=0; break; /* should never have lift as draw item */
         case 5:
            a = PDEi[draw_item_num][1]; /* bmp or ans */
            if (a < NUM_SPRITES) gbmp = a; /* bmp */
            if (a > 999) gbmp = zz[5][a-1000]; /* ans */
         break;
      }
   if ((draw_item_type != 2) && (draw_item_type != 3))
      {
         blit (memory_bitmap[gbmp], gtemp2, 0, 0, 0, 0, 20, 20);
         draw_sprite(gtemp3, gtemp2, 0, 0);
         blit(gtemp3, screen, 0, 0, x, y, 20, 20);
      }
   rest(10);
   /* restore background */
   blit (gtemp, screen, 0, 0, x, y, 20, 20);
   show_mouse(screen);
   rest(5);
}

void set_block_range(void)
{
   extern int l[100][100];
   extern int bx1, bx2, by1, by2;
   extern int draw_item_num;
   int a, b;
   for (a = bx1; a < bx2; a++)       /* cycle the range */
      for (b = by1; b < by2; b++)
         {
            if ( (bx2-bx1==1) && (by2-by1==1) ) /*single */
               l[a][b] = draw_item_num;
            if ( (bx2-bx1>1) && (by2-by1>1) ) /* box shape with corners */
               {
                  if ((draw_item_num >= 161) && (draw_item_num <= 163))  /* lined platform shape draw special */
                     {
                        l[a][b] = 162; /* default */
                        if (a == bx1)   l[a][b] = 161;
                        if (a == bx2-1) l[a][b] = 163;
                     }
                  else if ( (draw_item_num >= 33) && (draw_item_num <= 35) ) /* semi solid screen draw special */
                     {
                        l[a][b] = 34; /* default */
                        if (b == by1)   l[a][b] = 33;
                        if (b == by2-1) l[a][b] = 35;
                     }
                  else if ((draw_item_num >= 177) && (draw_item_num <= 179))  /* brown brick shape draw special */
                     {
                        l[a][b] = 178; /* default */
                        if (a == bx1)   l[a][b] = 177;
                        if (a == bx2-1) l[a][b] = 179;
                     }
                  else if ((draw_item_num >= 576) && (draw_item_num <= 592)) /* purple pipe box with corners */
                     {
                         if (b == by1  ) l[a][b] = 582; /* horizontal through */
                         if (b == by2-1) l[a][b] = 582; /* horizontal through */
                         if (a == bx1)
                            {
                               if (b == by1) l[a][b] = 576; /* up-right corner */
                               else if (b == by2-1) l[a][b] = 578; /* left-up corner */
                               else l[a][b] = 580; /* vertical through */
                            }
                         if (a == bx2-1)
                            {
                               if (b == by1) l[a][b] = 577; /* right-down corner */
                               else if (b == by2-1) l[a][b] = 579; /* down-left corner */
                               else l[a][b] = 580; /*  vertical through */
                            }
                      }
                  else if ((draw_item_num >= 576+32) && (draw_item_num <= 592+32)) /* wires box with corners */
                     {
                         if (b == by1  ) l[a][b] = 582+32; /* horizontal through */
                         if (b == by2-1) l[a][b] = 582+32; /* horizontal through */
                         if (a == bx1)
                            {
                               if (b == by1) l[a][b] = 576+32; /* up-right corner */
                               else if (b == by2-1) l[a][b] = 578+32; /* left-up corner */
                               else l[a][b] = 580+32; /* vertical through */
                            }
                         if (a == bx2-1)
                            {
                               if (b == by1) l[a][b] = 577+32; /* right-down corner */
                               else if (b == by2-1) l[a][b] = 579+32; /* down-left corner */
                               else l[a][b] = 580+32; /*  vertical through */
                            }
                      }
                  else if ((draw_item_num >= 576+64) && (draw_item_num <= 592+64)) /* bricks with corners */
                     {
                         l[a][b] = 592+64; /* center */
                         if (b == by1  ) l[a][b] = 582+64; /* horizontal through */
                         if (b == by2-1) l[a][b] = 583+64; /* horizontal through */
                         if (a == bx1)
                            {
                               if (b == by1) l[a][b] = 576+64; /* up-right corner */
                               else if (b == by2-1) l[a][b] = 578+64; /* left-up corner */
                               else l[a][b] = 580+64; /* vertical through */
                            }
                         if (a == bx2-1)
                            {
                               if (b == by1) l[a][b] = 577+64; /* right-down corner */
                               else if (b == by2-1) l[a][b] = 579+64; /* down-left corner */
                               else l[a][b] = 581+64; /*  vertical through */
                            }
                      }
                  else l[a][b] = draw_item_num;
                }
            if ( (bx2-bx1>1) && (by2-by1==1) ) /* horizontal line with end caps */
               {
                  l[a][b] = draw_item_num;
                  if ((draw_item_num >= 161)
                    && (draw_item_num <= 163))  /* lined platform shape draw special */
                     {
                        l[a][b] = 162; /* default */
                        if (a == bx1)   l[a][b] = 161;
                        if (a == bx2-1) l[a][b] = 163;
                     }
                  if ((draw_item_num >= 177)
                        && (draw_item_num <= 179)) /* wires box with corners */                  if ((draw_item_num >= 177) && (draw_item_num <= 179))  /* brown brick shape draw special */
                     {
                        l[a][b] = 178; /* default */
                        if (a == bx1)   l[a][b] = 177;
                        if (a == bx2-1) l[a][b] = 179;
                     }
                  if ((draw_item_num == 582)
                        || (draw_item_num == 583)
                        || (draw_item_num == 590)
                        || (draw_item_num == 588)) /* purple pipes */
                     {
                        l[a][b] = 582; /* horizontal through */
                        if (a == bx1) l[a][b] = 590; /* left end cap */
                        if (a == bx2-1) l[a][b] = 588; /* right end cap */
                     }
                  if ((draw_item_num == 582+32)
                        || (draw_item_num == 583+32)
                        || (draw_item_num == 590+32)
                        || (draw_item_num == 588+32)) /* wires */
                     {
                        l[a][b] = 582+32; /* horizontal through */
                        if (a == bx1) l[a][b] = 590+32; /* left end cap */
                        if (a == bx2-1) l[a][b] = 588+32; /* right end cap */
                     }

               }

            if ( (bx2-bx1==1) && (by2-by1>1) ) /* vertical line with end caps */
               {
                  l[a][b] = draw_item_num;
                  if ( (draw_item_num >= 33)
                    && (draw_item_num <= 35) ) /* semi solid screen draw special */
                     {
                        l[a][b] = 34; /* default */
                        if (b == by1)   l[a][b] = 33;
                        if (b == by2-1) l[a][b] = 35;
                     }
                  if ((draw_item_num == 580)
                        || (draw_item_num == 581)
                        || (draw_item_num == 589)
                        || (draw_item_num == 590)) /* purple pipes */
                     {
                        l[a][b] = 580; /* vertical through */
                        if (b == by1) l[a][b] = 591; /* up end cap */
                        if (b == by2-1) l[a][b] = 589; /* down end cap */
                     }
                  if ((draw_item_num == 580+32)
                        || (draw_item_num == 581+32)
                        || (draw_item_num == 589+32)
                        || (draw_item_num == 590+32)) /* wires */
                     {
                        l[a][b] = 580+32; /* vertical through */
                        if (b == by1) l[a][b] = 591+32; /* up end cap */
                        if (b == by2-1) l[a][b] = 589+32; /* down end cap */
                     }
               }
         }
}
void update(void)
{
   extern BITMAP *l2000;
   extern int wx, wy;
   show_mouse(NULL);
   blit(l2000, screen, wx*20, wy*20, 0, 0, (SCREEN_W/20)*20, (SCREEN_H/20)*20);
   show_mouse(screen);
}

int get_new_box(void) /* gotta keep the mouse !! */
{
   extern int bx1, by1, bx2, by2; /* return values */
   extern int wx, wy;
   int retval = 1;
   int x1, y1, x2, y2;

   bx2 = bx1; /* set all three to intial */
   by2 = by1;
   x1 = bx1;
   y1 = by1;
   x2 = bx2;
   y2 = by2;

   while (mouse_b & 1)
      {
         if (process_scrolledge()) update();
         show_mouse(screen);
         bx2 = (mouse_x)/20+wx; /* set both with mouse pointer */
         by2 = (mouse_y)/20+wy;

         x2 = bx2;  /* set with mouse */
         y2 = by2;

         x1 = bx1; /* get inital in case it was swapped */
         y1 = by1;

         /* swap x1 and x2 if neccesary */
         if (x1 > x2) { int z = x1; x1 = x2; x2 = z; }
         if (x1 == x2++);
      
         if (y1 > y2) { int z = y1; y1 = y2; y2 = z;}
         if (y1 == y2++);
     
         if (x1>99) x1 = 99;
         if (y1>99) y1 = 99;
         if (x2>100) x2 = 100;
         if (y2>100) y2 = 100;

         show_mouse(NULL);
         /* show the selection rectangle */
 
         xor_mode(TRUE);
         rect(screen, (x1-wx)*20, (y1-wy)*20, (x2-wx)*20-1, (y2-wy)*20-1, 127);
         rest(10);
         rect(screen, (x1-wx)*20, (y1-wy)*20, (x2-wx)*20-1, (y2-wy)*20-1, 127);
         show_mouse(screen);
         rest(4);
         xor_mode(FALSE);
/*
            {
               char msg[80];
               sprintf(msg," x1:%2d   y1:%2d ", x1, y1);
               textout_centre(screen, font, msg, 100, 20, 9);
               sprintf(msg," bx1:%2d  by1:%2d ", bx1, by1);
               textout_centre(screen, font, msg, 100, 28, 9);
               sprintf(msg," x2:%2d   y2:%2d ", x2, y2);
               textout_centre(screen, font, msg, 100, 40, 13);
               sprintf(msg," bx2:%2d  by2:%2d ", bx2, by2);
               textout_centre(screen, font, msg, 100, 48, 13);
               sprintf(msg," width:%2d  height:%2d ", x2-x1, y2-y1);
               textout_centre(screen, font, msg, 100, 60, 4);
            }
 */
      }
  /* swap bx1 and bx2 if neccesary */
  if (bx1 > bx2) { int z = bx1; bx1 = bx2; bx2 = z; }
  if (bx1 == bx2++);

  if (by1 > by2) { int z = by1; by1 = by2; by2 = z;}
  if (by1 == by2++);
  return retval;
}
int process_scrolledge(void)
{
   extern int wx, wy;
   int scrolledge=4, move = 0;
   if (mouse_y < scrolledge)  /* scroll up */
      {
         if (--wy<0) wy = 0;
         else move++;
      }
   if  (mouse_y > SCREEN_H-scrolledge)  /* scroll down */
      {
         int ry = 100 - (SCREEN_H/20);
         if (++wy > ry) wy = ry;
         else move++;
      }
   if (mouse_x < scrolledge) /* scroll left */
      {
          if (--wx < 0) wx = 0;
          else move++;
      }
   if (mouse_x > SCREEN_W-scrolledge) /* scroll right */
      {
         int rx = 100 - (SCREEN_W/20);
         if (++wx>rx) wx = rx;
         else move++;
      }
   if (move) update;
   return move;
}
void pointer_text(x1, y1, tx, ty)
{
   extern int Ei[100][32];
   extern float Ef[100][16];
   extern int item[500][16];
   extern int stx, sty, sux, suy;
   extern int txc;
   char msg[80];
   int b, c, d, x, y;
   int sey = -20;

   int x5=sux-stx;
   int y5=suy-sty;

   int rx1 = stx *20;    /* source x */
   int ry1 = sty *20;    /* source y */
   int rx2 = sux *20;    /* sizes */
   int ry2 = suy *20;
   int eib=0;
   int iib=0;
   int lib=0;

          /* count enemies in box */
          for (b=0; b<100; b++) /* check for enemies in box */
            if (Ei[b][0])     /* if active */
               if (Ef[b][0] > rx1)
                  if (Ef[b][0] < rx2)
                     if (Ef[b][1] > ry1)
                        if (Ef[b][1] < ry2)
                           eib++;

         /* count items in box */
         for (b=0; b<500; b++) /* check for items in box */
            if (item[b][0])     /* if active */
               if (item[b][4] > rx1)
                  if (item[b][4] < rx2)
                     if (item[b][5] > ry1)
                        if (item[b][5] < ry2)
                           iib++;
         /* count lifts in box */
         for (d=0; d<num_lifts; d++)
               if (lifts[d]->x1 > rx1)
                  if (lifts[d]->x1 < rx2)
                     if (lifts[d]->y1 > ry1)
                        if (lifts[d]->y1 < ry2)
                           lib++;

   rect(screen, txc-70, ty+sey, txc+70, ty+sey+10,14);
   rect(screen, txc-70, ty+sey, txc+70, ty+sey+36,14);
   rect(screen, txc-70, ty+sey, txc+70, ty+sey+62,14);

   textout_centre(screen, font, "Selection", txc, ty+sey+2, 14);
   sprintf(msg," x:%2d  y:%2d ", stx, sty);
   textout_centre(screen, font, msg, txc, ty+sey+12, 6);
   sprintf(msg," height:%d ", suy-sty);
   textout_centre(screen, font, msg, txc, ty+sey+20, 6);
   sprintf(msg," width:%d ", sux-stx);
   textout_centre(screen, font, msg, txc, ty+sey+28, 6);

   sprintf(msg," %d Enemies ", eib);
   textout_centre(screen, font, msg, txc, ty+sey+38, 7);
   sprintf(msg," %d Items ", iib);
   textout_centre(screen, font, msg, txc, ty+sey+46, 7);
   sprintf(msg," %d Lifts ", lib);
   textout_centre(screen, font, msg, txc, ty+sey+54, 7);
}
do_brf(int x, int y)
{
   extern int l[100][100];
   extern int lc;
   extern int draw_item_type;
   extern int draw_item_num;
   extern int lines[500][5];

   int a;
   int b;
   int c;

   int tx;
   int ty;
   int rq;
   int uc=0;

   int rb = l[x][y]; /* replace block */

   lc = 0; /* line counter */
 
   for (a=0; a<500; a++) /* clear array */
      for (b=0; b<5; b++)
         lines[a][b] = 0;

   if (draw_item_type == 1)   /* block only */
      if (draw_item_num != rb) /* not same block */
         {


               /* look right */
               tx = x;
               rq = 0;

               while (!rq)
                  {
                     if (l[tx][y] != rb)
                        {
                           lines[lc][2] = tx - 1;  /* set x2 */
                           rq = 1;  /* quit */
                        }
                     if (tx < 99) tx ++;
                     else rq = 1;

                  }
               /* look left */
               tx = x;
               rq = 0;

               while (!rq)
                  {
                     if (l[tx][y] != rb)
                        {
                           lines[lc][1] = tx + 1;  /* set x1 */
                           rq = 1;  /* quit */
                        }
                     if (tx > 0) tx --;
                     else rq = 1;

                  }
               lines[lc][0] = y; /* first line only */

               /* start looking up */
               look_up(0, rb);

               /* start looking down */
               look_down(0, rb);

               do
                   {
                     uc = lc;
                     /* check for missed ups */
                     for (a=0; a<=lc; a++)
                        if (!lines[a][3]) look_up(a, rb);
      
                     /* check for missed downs */
                     for (a=0; a<=lc; a++)
                        if (!lines[a][4]) look_down(a, rb);

                   } while (uc != lc);

      
                     /* draw list */
      
                     for (a=0; a<=lc; a++)
                        for (tx=lines[a][1]; tx<=lines[a][2]; tx++) /* set line */
                           {
                              l[tx][lines[a][0]] = draw_item_num;
                           }


         }
   draw_big();

}

look_up(int tlc, int rb)   /* adds lines to list - pass it line # to start */
{
   extern int lines[500][5];
   extern int l[100][100];
   extern int lc;
   int uc; /* loop until no more lines are added */
   int a;
   int b;
   int c;
   int tx;
   int ty;

   /* first time through variables */

   lines[tlc][3] = 1;    /* set looked up flag */
   ty = lines[tlc][0]-1; /* 1 up from starting line */
   a = lines[tlc][1];
   b = lines[tlc][2];

   if (--a <0) a = 0;
   if (++b >99) b = 99;

   do
      {
         uc = lc;  /* new line counter */
         for (tx = a; tx <= b; tx++)
            {
               if (l[tx][ty] == rb)  /* found rb */
                  {
                     int ttx = tx;   /* check for earliest rb */
                     int dup = 0;
                     while (l[ttx--][ty] == rb);
                     ttx +=2; /* first */

                     /* does line already exist and been looked up ? */
                     for (c=0; c<=lc; c++)
                        if (lines[c][0] == ty)       /* same y */
                           if (lines[c][1] == ttx) /* same x1 */
                              if (lines[c][3] == 1) /* all ready looked up */
                                 dup = 1;

                     if (dup)
                        {
                           /* tx = lines[c][2]+1; /* skip to next blank */
                           while (l[tx++][ty] == rb);
                           tx -=2;
                        }
                     else
                        {
                           lc++; /* new line */
                           lines[lc][0] = ty; /* set y */

                           while (l[tx--][ty] == rb);
                           tx +=2;
                           lines[lc][1] = tx; /* set x1 */


                           while (l[tx++][ty] == rb);
                           lines[lc][2] = tx-2; /* set x2 */
                        }
                  }
            }

         /* 2nd time variables  only if needed */

         lines[lc][3] = 1;   /* set looked up flag */
         ty = lines[lc][0]-1; /* 1 up from starting line */
         a = lines[lc][1];
         b = lines[lc][2];
 
         if (--a <0) a = 0;
         if (++b >99) b = 99;

     } while (uc != lc);


}
look_down(int tlc, int rb)   /* adds lines to list - pass it line # to start */
{
   extern int lines[500][5];
   extern int l[100][100];
   extern int lc;
   int uc; /* loop until no more lines are added */
   int a;
   int b;
   int c;
   int tx;
   int ty;

   /* first time through variables */

   lines[tlc][4] = 1;    /* set looked dn flag */
   ty = lines[tlc][0]+1; /* 1 dn from starting line */
   a = lines[tlc][1];
   b = lines[tlc][2];

   if (--a <0) a = 0;
   if (++b >99) b = 99;

   do
      {
         uc = lc;  /* new line counter */
         for (tx = a; tx <= b; tx++)
            {
               if (l[tx][ty] == rb)  /* found rb */
                  {
                     int ttx = tx;   /* check for earliest rb */
                     int dup = 0;
                     while (l[ttx--][ty] == rb);
                     ttx +=2; /* first */

                     /* does line already exist and been looked dn ? */
                     for (c=0; c<=lc; c++)
                        if (lines[c][0] == ty)       /* same y */
                           if (lines[c][1] == ttx) /* same x1 */
                              if (lines[c][4] == 1) /* all ready looked dn */
                                 dup = 1;

                     if (dup)
                        {
                           while (l[tx++][ty] == rb);
                           tx -=2;
                        }
                     else
                        {
                           lc++; /* new line */
                           lines[lc][0] = ty; /* set y */

                           while (l[tx--][ty] == rb);
                           tx +=2;
                           lines[lc][1] = tx; /* set x1 */


                           while (l[tx++][ty] == rb);
                           lines[lc][2] = tx-2; /* set x2 */
                        }
                  }
            }

         /* 2nd time variables  only if needed */

         lines[lc][4] = 1;   /* set looked dn flag */
         ty = lines[lc][0]+1; /* 1 dn from starting line */
         a = lines[lc][1];
         b = lines[lc][2];
 
         if (--a <0) a = 0;
         if (++b >99) b = 99;

     } while (uc != lc);


}
int zoom_full_screen(int wx, int wy, int draw_item)
{
   extern BITMAP *l700;  /* 1024x768 */
   extern BITMAP *l600;  /*  800x600 */
   extern BITMAP *l400;  /*  640x480 */
   extern int draw_item_type;
   extern int draw_item_num;
   extern int txc;
   extern int ft_level_header[20];
   extern char sel_filename[80];
   
   extern int stx, sty, sux, suy;
   int jh;
   extern int copy_mode;
   extern int fcopy_mode;
   extern int brf_mode;
   
   
   extern int copy_blocks;
   extern int copy_enemies;
   extern int copy_items;
   extern int copy_lifts;
   
   int tx = (SCREEN_H/100)*100+20;
   int ty = 60;
   int x1, y1, x2, y2, x3, y3;
   extern int db;
   extern int txc;
   int mop;
   
   char msg[80];
   int x,y;
   int exit =0;
   
   copy_mode = 0;
   fcopy_mode = 0;
   brf_mode = 0;
   
   draw_big();

   switch (SCREEN_H)
      {
         case 768:
                   x3=51; y3=38;
                   x1 = wx;
                   if (x1>100-x3) x1 = 100-x3;
                   x2 = x1 + x3;
                   y1 = wy;
                   if (y1>100-y3) y1 = 100-y3;
                   y2 = y1 + y3;
                   position_mouse( x1*7, y1*7 );
         break;
         case 600:
                   x3=40; y3=30;
                   x1 = wx;
                   if (x1>100-x3) x1 = 100-x3;
                   x2 = x1 + x3;
                   y1 = wy;
                   if (y1>100-y3) y1 = 100-y3;
                   y2 = y1 + y3;
                   position_mouse( x1*6, y1*6 );
         break;
         case 480:
                   x3=32; y3=24;
                   x1 = wx;
                   if (x1>100-x3) x1 = 100-x3;
                   x2 = x1 + x3;
                   y1 = wy;
                   if (y1>100-y3) y1 = 100-y3;
                   y2 = y1 + y3;
                   position_mouse( x1*4, y1*4 );
          break;
      }
   for (x = 0; x < 15; x++)
      hline(screen, db*100, x, SCREEN_W, 13+(x*16));
   
   text_mode(-1);
   textout_centre(screen, font, "Zoom Full Screen", (db*100)+(SCREEN_W-(db*100))/2, 3, 15);
   text_mode(0);
   while (!exit)
      {
         /* menu and buttons */
         int bc1 = 10;
         int bc0 = 9;

         show_mouse(NULL);
         jh=4;
         if (copy_blocks)
            {
               x = bc1;
               sprintf(msg,"Blocks On ");
            }
         else
            {
               x = bc0;
               sprintf(msg,"Blocks Off");
            }
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, x);
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, x);

         jh=5;
         if (copy_enemies)
            {
               x = bc1;
               sprintf(msg,"Enemies On ");
            }
         else
            {
               x = bc0;
               sprintf(msg,"Enemies Off");
            }
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, x);
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, x);
         jh=6;
         if (copy_items)
            {
               x = bc1;
               sprintf(msg,"Items On ");
            }
         else
            {
               x = bc0;
               sprintf(msg,"Items Off");
            }
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, x);
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, x);

         jh=7;
         if (copy_lifts)
            {
               x = bc1;
               sprintf(msg,"Lifts On ");
            }
         else
            {
               x = bc0;
               sprintf(msg,"Lifts Off");
            }
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, x);
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, x);


         jh=9;
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, 9);
         sprintf(msg,"Clear Selection");
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 9);

         jh=10;
         sprintf(msg,"Paste Selection");
         if (copy_mode) x = 10; else x = 9;
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, x);
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, x);

         jh=11;
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, 9);
         sprintf(msg,"Save Selection");
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 9);

         jh=12;
         sprintf(msg,"Paste From Disk");
         if (fcopy_mode) x = 10; else x = 9;
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, x);
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, x);


         jh=14;
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, 13);
         sprintf(msg,"Block Fill");
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);

         jh=15;
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, 13);
         sprintf(msg,"Block Frame");
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);

         jh=16;
         if (brf_mode) x = 10; else x = 13;
         rect(screen, txc-70, ty+(jh*12), txc+70, ty+(jh*12)+10, x);
         sprintf(msg,"Block Floodfill");
         textout_centre(screen, font, msg, txc, ty+(jh*12)+2, x);
         show_mouse(screen);
   
         if ((mouse_b & 1) && (mouse_x > txc-70) && (mouse_x < txc + 70) && (mouse_y > ty) && (mouse_y < ty+(17*12)) )
            {
               int mb = (mouse_y - ty) / 12;
               while (mouse_b & 1); /* wait for release */
               switch(mb)
                  {
                     case 4:  copy_blocks  = !copy_blocks;  break;
                     case 5:  copy_enemies = !copy_enemies; break;
                     case 6:  copy_items   = !copy_items; break;
                     case 7:  copy_lifts   = !copy_lifts; break;
                     case 9: /* Clear */
                              do_clear();
                              draw_big();
                     break;
                     case 10: copy_mode = !copy_mode;
                              fcopy_mode = 0;
                     break;
                     case 11:
                              save_selection();
                              show_mouse(NULL);
                              clear(screen);
                              text_mode(0);
                              draw_big();
                     break;
                     case 12:
                               if (fcopy_mode)
                                  fcopy_mode = 0;
                               else if (load_selection())
                                  {
                                     draw_fsel();
                                     fcopy_mode = 1;
                                     copy_mode =0;
                                     text_mode(0);
                                     show_mouse(NULL);
                                     clear(screen);
                                     draw_big();
                                  }
                               else /* load cancelled */
                                  {
                                     fcopy_mode =0;
                                     copy_mode =0;
                                     text_mode(0);
                                     show_mouse(NULL);
                                     clear(screen);
                                     draw_big();

                                  }

                     break;
                     case 14: /* Block Fill */
                     if (draw_item_type == 1)
                        {
                           int x, y;
                           extern int l[100][100];

                           for (x=stx; x<sux; x++)
                              for (y=sty; y<suy; y++)
                                 l[x][y] = draw_item_num;
                           draw_big();
                         }
                     break;
                     case 15: /* Block Outline */
                     if (draw_item_type == 1)
                        {
                           int x, y;
                           extern int l[100][100];

                           for (x=stx; x<sux; x++)
                              {
                                 l[x][sty] = draw_item_num;
                                 l[x][suy-1] = draw_item_num;
                              }
                           for (y=sty; y<suy; y++)
                              {
                                 l[stx][y] = draw_item_num;
                                 l[sux-1][y] = draw_item_num;
                              }
                           draw_big();
                         }
                     break;
                     case 16: /* Block Replace/Floodfill */
                     if (draw_item_type = 1)
                        {
                           brf_mode = !brf_mode;

                        }
                     break;
                  } /* end of switch button */
            } /* end of mouse pressed on menu */
         if ( (mouse_x < (SCREEN_H/100)*100) && (mouse_y < (SCREEN_H/100)*100) )
            mop = 1;
         else mop = 0;
         if (mop)
            {
               textout_centre(screen, font, "Pointer", txc, ty-40, 15);
               sprintf(msg,"  x:%d    y:%d ", mouse_x/db, mouse_y/db);
               textout_centre(screen, font, msg, txc, ty-32, 15);
            }
         else rectfill(screen, txc-80, ty-40, txc+80, ty-24, 0);
   
         if (sux < stx) /* swap if wrong order */
            {
               int temp = sux;
               sux = stx;
               stx = temp;
            }
         if (suy < sty)
            {
               int temp = suy;
               suy = sty;
               sty = temp;
            }
   
         show_mouse(NULL);
         switch (SCREEN_H)
            {
               case 768: blit(l700, screen, 0, 0, 0, 0, 700, 700); break;
               case 600: blit(l600, screen, 0, 0, 0, 0, 600, 600); break;
               case 480: blit(l400, screen, 0, 0, 0, 0, 400, 400); break;
            }
         /* selection  */
         set_clip(screen, 0, 0, (SCREEN_H/100)*100-1, (SCREEN_H/100)*100-1 );
         rect(screen, stx*db, sty*db, (sux*db)-1, (suy*db)-1, 14);
         textout(screen, font, "selection", stx*db+2, sty*db-10, 14);
         set_clip(screen, 0, 0, SCREEN_W, SCREEN_H);
         /* mouse exit outline window */
         if ((mop) && (!copy_mode) && (!fcopy_mode) && (!brf_mode))
            {
               x1 = mouse_x/db;
               if (x1>100-x3) x1 = 100-x3;
               x2 = x1 + x3;
   
               y1 = mouse_y/db;
               if (y1>100-y3) y1 = 100-y3;
               y2 = y1 + y3;
   
               set_clip(screen, 0, 0, (SCREEN_H/100)*100-1, (SCREEN_H/100)*100-1 );
               textout(screen, font, "exit window", x1*db+2, y1*db-10, 15);
               rect(screen, x1*db, y1*db, (x2*db)-1, (y2*db)-1, 15);
               set_clip(screen, 0, 0, SCREEN_W, SCREEN_H);
            }
        /* mouse copy outline window */
         if ((mop) && (copy_mode))
            {
               x1 = mouse_x/db;
               x2 = x1 + (sux-stx);
   
               y1 = mouse_y/db;
               y2 = y1 + (suy-sty);
               if (x2 > 100) x2 = 100;
               if (y2 > 100) y2 = 100;
   
               set_clip(screen, 0, 0, (SCREEN_H/100)*100-1, (SCREEN_H/100)*100-1 );
               textout(screen, font, "paste selection", x1*db+2, y1*db-10, 10);
               rect(screen, x1*db, y1*db, x2*db-1, y2*db-1, 10);
               set_clip(screen, 0, 0, SCREEN_W, SCREEN_H);
            }
         if ((mop) && (fcopy_mode))
            {
               extern BITMAP *ft_bmp;
               char tm[80];
   
   
               x1 = mouse_x/db;
               x2 = x1 + ft_level_header[8];
   
               y1 = mouse_y/db;
               y2 = y1 + ft_level_header[9];
               if (x2 > 100) x2 = 100;
               if (y2 > 100) y2 = 100;
   
               set_clip(screen, 0, 0, (SCREEN_H/100)*100-1, (SCREEN_H/100)*100-1 );
   
               strcpy(tm, get_filename(sel_filename) );
               sprintf(msg,"paste from disk: %s",tm);
               textout(screen, font, msg,  x1*db+2, y1*db-10, 42);
               draw_sprite(screen, ft_bmp, x1*db, y1*db);
               rect(screen, x1*db, y1*db, x2*db-1, y2*db-1, 10);
   
               set_clip(screen, 0, 0, SCREEN_W, SCREEN_H);
            }
         pointer_text(x1, y1, tx, ty);
         show_mouse(screen);
         rest(20);
   
         x1 = mouse_x/db;
         if (x1>100-x3) x1 = 100-x3;
         x2 = x1 + x3;
   
         y1 = mouse_y/db;
         if (y1>100-y3) y1 = 100-y3;
         y2 = y1 + y3;
   
         if (mouse_b & 2) exit = 1;
         if ((mouse_b & 1) && (mop))
            {
               x1 = mouse_x/db;
               if (x1>100) x1 = 100;
   
               y1 = mouse_y/db;
               if (y1>100) y1 = 100;
               if (copy_mode) do_copy(x1, y1);
               if (fcopy_mode) do_fcopy(x1, y1);
               if (brf_mode) do_brf(x1, y1);
   
               if ((!copy_mode) && (!fcopy_mode) && (!brf_mode))
                  {
                     /* get top */
                     stx = x1;
                     sty = y1;
                     while (mouse_b & 1)
                        {
                           show_mouse(NULL);
                           switch (SCREEN_H)
                              {
                                 case 768: blit(l700, screen, 0, 0, 0, 0, 700, 700); break;
                                 case 600: blit(l600, screen, 0, 0, 0, 0, 600, 600); break;
                                 case 480: blit(l400, screen, 0, 0, 0, 0, 400, 400); break;
                              }
   
                           /* selection  */
                           rect(screen, stx*db, sty*db, (x1*db)-1, (y1*db)-1, 14);
                           show_mouse(screen);
                           rest(80);
   
                           x1 = (mouse_x/db)+1;
                           if (x1 > 100) x1 = 100;
                           y1 = (mouse_y/db)+1;
                           if (y1 > 100) y1 = 100;
                        }
                      /* get bottom */
                     sux = x1;
                     suy = y1;
                  }
            }
      } /* end of while (!quit) */
   while (mouse_b & 2);
   while (key[KEY_ESC]);
   return (y1*100)+x1;
}
void draw_item_info(int x, int y, int color, int type, int num)
{
   extern int num_lifts;
   extern int zz[20][NUM_ANS];
   extern int item[500][16];
   extern int Ei[100][32];
   extern int e_first_num[50];
   extern int e_num_of_type[50];
   extern int item_first_num[20];
   extern int item_num_of_type[20];
   extern char PDEt[100][20][40];
   extern int PDEi[100][32];
   
   extern char item_desc[20][40];
   extern char eitype_desc[50][32][40];
   
   int a, b;
   char msg[80];
   set_clip(screen, x,y,x+150,y+20);
   rectfill(screen, x,y,x+150,y+20,0 );
   switch (type)
      {
         case 1:
                  blit (memory_bitmap[num], screen, 0, 0, x, y, 20, 20);
                  sprintf(msg,"Block #%d",num);
                  textout(screen, font, msg, x+22, y+2, color);
                  sprintf(msg, "Solid");  /* default */
                  if (num < 32) sprintf(msg, "Empty");
                  if ((num > 31) && (num < 64)) sprintf(msg, "Semi-Solid ");
                  if ((num > 63) && (num < 96)) sprintf(msg, "Bombable");
                  if ((num > 95) && (num < 128)) sprintf(msg, "Breakable");
                  if (num == 169) sprintf(msg, "Map Translucent");
                  textout(screen, font, msg, x+22, y+12, color);
         break;
         case 2:
                  a = item[num][1]; /* bmp or ans */
                  if (a > 999) a = zz[0][a-1000]; /* ans */
                  if (item[num][0] == 11)
                     rotate_sprite(screen, memory_bitmap[a], x, y, itofix(item[num][10]/10));
                  else blit (memory_bitmap[a], screen, 0, 0, x, y, 20, 20);
                  a = item[num][0]; /* type */
                  sprintf(msg,"%s", item_desc[a]);
                  textout(screen, font, msg, x+22, y+2, color);
                  sprintf(msg,"%d of %d", 1+num - item_first_num[a],item_num_of_type[a]);
                  textout(screen, font, msg, x+22, y+12, color);
                 break;
         case 3:
                  draw_enemy_shape(num, x, y);
                  a = Ei[num][0]; /* type */
                  sprintf(msg,"%s", eitype_desc[a][0]);
                  textout(screen, font, msg, x+22, y+2, color);
                  sprintf(msg,"%d of %d", 1+num - e_first_num[a],e_num_of_type[a]);
                  textout(screen, font, msg, x+22, y+12, color);
         break;
         case 4:
                {
                  int col = lifts[num] -> color;
                  int width = lifts[num] -> width;
                  if (width > 7) width = 7;
                  for (a=0; a<10; a++)
                     rect(screen, x+a, y+a, x+(width*20)-1-a, y+19-a, col+((9-a)*16) );
                  text_mode(-1);
                  textout_centre(screen, font, lifts[num]->lift_name, x+(width*10), y+6 ,col+160);
                  text_mode(0);
                }
         break;
         case 5:
                  a = PDEi[num][1]; /* bmp or ans */
                  if (a < NUM_SPRITES) b = a; /* bmp */
                  if (a > 999) b = zz[5][a-1000]; /* ans */
                  blit (memory_bitmap[b], screen, 0, 0, x, y, 20, 20);
                  a = Ei[num][0]; /* type */
                  sprintf(msg,"Special Item");
                  textout(screen, font, msg, x+22, y+2, color);
                  sprintf(msg,"%s", PDEt[num][1]);
                  textout(screen, font, msg, x+22, y+12, color);
         break;
      } /* end of switch */
   set_clip(screen, 0, 0, SCREEN_W, SCREEN_H);
}
void edit_menu(int el)
{
   extern BITMAP *l2000;
   extern int l[100][100];
   extern int item[500][16];
   
   extern int PDEi[100][32];
   extern float PDEf[100][16];
   extern char PDEt[100][20][40];
   
   extern int bmp_index;
   extern int zz[20][NUM_ANS];
   extern int Ei[100][32];
   extern float Ef[100][16];
   extern char item_desc[20][40];
   
   extern int status_window_active;
   extern int status_window_redraw;
   
   extern int status_window_x;
   extern int status_window_y;
   extern int status_window_w;
   extern int status_window_h;
   
   extern int draw_item_type;
   extern int draw_item_num;
   extern int point_item_type;
   extern int point_item_num;

   extern int select_window_active;
   extern int select_window_redraw;
   extern int select_window_x;
   extern int select_window_y;
   extern int select_window_w;
   extern int select_window_h;

   extern int select_window_num_block_lines;
   extern int swnbl;

   extern int zzindx; /* to pass to animation() */
   extern int bmp_index;
   extern int level_num;
   int em_WX, em_WY;
   
   char msg[80]; /* temp printing string  */
   
   int mpow;

   int em_redraw = 1;
   int em_quit = 0;
   extern int wx;
   extern int wy;
   
   int x100, y100, x2000, y2000;
   int a, b, c, d, e, x, y;
   int gx;
   int gy;
   int gbmp;
   extern BITMAP *gtemp;
   extern BITMAP *gtemp2;
   extern BITMAP *gtemp3;

   gtemp = create_bitmap(20,20);
   gtemp2 = create_bitmap(20,20);
   gtemp3 = create_bitmap(20,20);

   while (mouse_b & 1); /* if pressed wait for release */
   while (key[KEY_ENTER]); /* wait for release */

   show_mouse(NULL);
   clear(screen);

   if (!el) load(); /* load prompt */
   else load_level(el, 0); /* blind load */

   sort_enemy();
   item_sort();

   draw_item_type = 1;
   draw_item_num  = 16;
   
   initialize_zz();
   em_redraw=1;
   draw_big();
   set_wx_from_start_block();

   do
      {
         mpow = 0;  /* is mouse pointer on a window? */
         if ((mouse_x > status_window_x) && (mouse_x < status_window_x+status_window_w))
            if ((mouse_y > status_window_y-12) && (mouse_y < status_window_y+status_window_h))
               if (status_window_active)  mpow = 1;
         
         if ((mouse_x > select_window_x) && (mouse_x < select_window_x + select_window_w))
            if ((mouse_y > select_window_y) && (mouse_y < select_window_y + select_window_h))
               if (select_window_active) mpow = 1;

         if (mpow)
            {
                show_mouse(screen);
                rest(10);
             }

         if (!mpow)  /* find point item */
            {
               x100 = mouse_x/20 + wx;
               y100 = mouse_y/20 + wy;

               x2000 = mouse_x + wx*20;
               y2000 = mouse_y + wy*20;

               if (x100>99) x100 = 99;
               if (y100>99) y100 = 99;

               /* block by default */
               point_item_type = 1;
               point_item_num = l[x100][y100];

               for (d=0; d<500; d++) /* check for item */
                  if (item[d][0]) /* if active  */
                     {
                        a = item[d][4];
                        b = item[d][5];
                        if ( (x2000 > a) && (x2000 < (a+18)) && (y2000 > b+4) && (y2000 < (b+16)) )
                           {   /* mouse is on item d */
                               point_item_type = 2;
                               point_item_num = d;
                           }
                     }
               for (e=0; e<100; e++) /* check for enemy */
                  if (Ei[e][0]) /* if enemy active  */
                     {
                        a = Ef[e][0];
                        b = Ef[e][1];
                        if ( (x2000 > (a+2)) && (x2000 < (a+18)) && (y2000 > (b+2)) && (y2000 < (b+18)) )
                           {   /* mouse is on enemy e */
                               point_item_type = 3;
                               point_item_num = e;
                           }
                     }
               for (d=0; d<num_lifts; d++) /* check for lifts */
                     {
                        a = lifts[d]->x1;
                        b = lifts[d]->y1;
                        if ( (x2000 > a) && (x2000 < (a+10)) && (y2000 > b) && (y2000 < (b+10)) )
                           {   /* mouse is on lift e */
                               point_item_type = 4;
                               point_item_num = d;
                           }
                     }


               show_draw_item_cursor();


             } /* end of if !mpow find and show draw item */

         if ((mouse_b & 1) && (!mpow))  /* put draw item */
            {
               update();
               x100 = mouse_x/20 + wx;
               y100 = mouse_y/20 + wy;

               x2000 = mouse_x + wx*20;
               y2000 = mouse_y + wy*20;

               if (x100>99) x100 = 99;
               if (y100>99) y100 = 99;

               em_redraw = 1;
               switch (draw_item_type)
                  {
                     case 1:  /* block */
                        {
                           extern int bx1, by1, bx2, by2;
                           bx1 = x100;
                           by1 = y100;
                           get_new_box(); /* this keeps the mouse */
                           set_block_range();
                           draw_big();
                           em_redraw=1;
                        }
                     break;
                     case 2:  /* item */
                              while (mouse_b & 1) /* wait for release */
                                 {
                                    show_draw_item_cursor();
                                    process_scrolledge();
                                    update();
                                 }
                              x100 = mouse_x/20 + wx;
                              y100 = mouse_y/20 + wy;

                              for (c=0; c<500; c++) /* find empty item */
                                if (item[c][0] == 0)
                                   {
                                      for (b=0; b<16; b++) /* copy from draw item  */
                                         item[c][b] = item[draw_item_num][b];
                                      item[c][4]= x100*20; /* get x */
                                      item[c][5]= y100*20; /* get y */

                                      if (item[draw_item_num][0] == 1) /* door) */
                                         if (alert("Move the door's", "destination also?","","Move", "Leave", 'M', 'L')==1)
                                            {
                                               item[c][6] = item[draw_item_num][6] + x100 - item[draw_item_num][4]/20; /* move x */
                                               item[c][7] = item[draw_item_num][7] + y100 - item[draw_item_num][5]/20;
                                            }

                                      if (item[draw_item_num][0] == 4) /* key ) */
                                         if (alert("Move the key's", "block range also?","","Move", "Leave", 'M', 'L')==1)
                                            {
                                               item[c][6] = item[draw_item_num][6] + x100 - item[draw_item_num][4]/20; /* move x */
                                               item[c][7] = item[draw_item_num][7] + y100 - item[draw_item_num][5]/20;
                                               item[c][8] = item[draw_item_num][8] + x100 - item[draw_item_num][4]/20;
                                               item[c][9] = item[draw_item_num][9] + y100 - item[draw_item_num][5]/20;
                                            }
                                      if (item[draw_item_num][0] == 10) /* msg) */
                                         {
                                            extern char* pmsg[500];
                                            free (pmsg[c]);
                                            pmsg[c] = (char*) malloc (strlen(pmsg[draw_item_num])+1);
                                            strcpy(pmsg[c], pmsg[draw_item_num]);
                                         }

                                      c=500; /* quit loop  */
                                   }
                               item_sort();
                               draw_big();

                               em_redraw=1;

                     break;
                     case 3:    /* enemy */
                        {
                           int num_empty = 0;
                           int first_empty;

                           while (mouse_b & 1) /* wait for release */
                              {
                                 show_draw_item_cursor();
                                 process_scrolledge();
                                 update();
                              }
                           x100 = mouse_x/20 + wx;
                           y100 = mouse_y/20 + wy;

                           for (c=0; c<100; c++) /* find empty and num of empty */
                              if (Ei[c][0] == 0)
                                 {
                                    num_empty++;
                                    if (num_empty == 1) first_empty = c;
                                 }
                           for (x=0; x<32; x++) /* copy enemy  */
                              Ei[first_empty][x] = Ei[draw_item_num][x];
                           for (x=0; x<16; x++) /* copy enemy  */
                              Ef[first_empty][x] = Ef[draw_item_num][x];
                           Ef[first_empty][0] = x100*20;  /* set new x,y */
                           Ef[first_empty][1] = y100*20;
                           if (Ei[draw_item_num][0] == 7) /* podzilla */
                              {
                                 d = alert3("Move podzilla's", "extended position too?", NULL, "Move", "Get New", "Leave", 'M', 'G', 'L');
                                 if (d == 1) /* move with location */
                                    {
                                       Ef[first_empty][5] = Ef[draw_item_num][5] + 20*(x100 - (Ef[draw_item_num][0]/20)) ; /* move x */
                                       Ef[first_empty][6] = Ef[draw_item_num][6] + 20*(y100 - (Ef[draw_item_num][1]/20)) ;
                                    }
                                 if (d == 2) move_pod_extended(first_empty);/* get new */
                                 d = alert3("Move Podzilla's", "trigger box too?", NULL, "Move", "Get New", "Leave", 'M', 'G', 'L');
                                 if (d==1)
                                    {
                                       Ei[first_empty][11] = Ei[draw_item_num][11] + x100 - Ef[draw_item_num][0]/20 ; /* move x */
                                       Ei[first_empty][12] = Ei[draw_item_num][12] + y100 - Ef[draw_item_num][1]/20 ; /* move x */
                                       Ei[first_empty][13] = Ei[draw_item_num][13] + x100 - Ef[draw_item_num][0]/20 ; /* move x */
                                       Ei[first_empty][14] = Ei[draw_item_num][14] + y100 - Ef[draw_item_num][1]/20 ; /* move x */
                                    }
                                 if (d==2) move_trigger_box(first_empty); /* get new */
                                 recalc_pod(first_empty);
                              }
                           if (Ei[draw_item_num][0] == 9) /* cloner */
                              if (alert("Move cloner boxes?", NULL, NULL, "Move", "Leave", 'M', 'L')==1)
                                 {
                                    Ef[first_empty][6] = Ef[draw_item_num][6] + 20*(x100 - Ef[draw_item_num][0]/20); /* move x */
                                    Ef[first_empty][7] = Ef[draw_item_num][7] + 20*(y100 - Ef[draw_item_num][1]/20); /* move x */
                                    Ef[first_empty][8] = Ef[draw_item_num][8] + 20*(x100 - Ef[draw_item_num][0]/20); /* move x */
                                    Ef[first_empty][9] = Ef[draw_item_num][9] + 20*(y100 - Ef[draw_item_num][1]/20); /* move x */
                                 }
                           sort_enemy();
                           draw_big();
                           em_redraw = 1;
                           while (mouse_b & 1); /* wait for release */
                        }
                     break;
                     case 5:    /* Special */
                          while (mouse_b & 1) /* wait for release */
                             {
                                show_draw_item_cursor();
                                process_scrolledge();
                                update();
                             }
                          x100 = mouse_x/20 + wx;
                          y100 = mouse_y/20 + wy;

                           if ((PDEi[draw_item_num][0] > 99) && (PDEi[draw_item_num][0] < 200)) /* PUT ITEM */
                              {
                                 extern int item[500][16];
            
                                 int num_empty;
                                 int first_empty;
                                 int c=0, d, x;
            
                                       num_empty = 0;
                                       item_sort();
                                       for (d=499; d >= 0; d--)  /* find empty item */
                                          if (item[d][0] == 0)
                                                {
                                                   first_empty = d;
                                                   num_empty++;
                                                }
                                       if (num_empty < 1)
                                          {
                                             textout(screen, font, " item list full ", 20, 20, 1);
                                             rest(2000);
                                             break;
                                          }
                                       else /* copy from pde */
                                          {
                                             for (x=0; x<16; x++) /* item */
                                                item[first_empty][x] = PDEi[draw_item_num][x];
                                             item[first_empty][0] -= 100;
                                             item[first_empty][4] = x100*20;
                                             item[first_empty][5] = y100*20;
                                             item_sort();
                                             em_redraw=1;
                                             draw_big();
                                          }
                               }
                           if (PDEi[draw_item_num][0] < 99) /* PUT ENEMY */
                              {
                                 extern float Ef[100][16];
                                 extern int Ei[100][32];
                                 int d, x, y;
                                 int num_empty = 0;
                                 int first_empty;

                                 for (d=0; d<100; d++) /* find empty and num of empty */
                                    if (Ei[d][0] == 0)
                                       {
                                          num_empty++;
                                          if (num_empty == 1) first_empty = d;
                                       }
                         
                                 for (x=0; x<32; x++) /* put enemy  */
                                    Ei[first_empty][x] = PDEi[draw_item_num][x];
                                 for (x=0; x<16; x++) /* put enemy  */
                                    Ef[first_empty][x] = PDEf[draw_item_num][x];
            
            
                                 Ef[first_empty][0] = x100*20;  /* set new x,y */
                                 Ef[first_empty][1] = y100*20;
            
                                 sort_enemy();
                                 em_redraw=1;
                                 draw_big();
                              }
                     break;
                  } /* end of switch case */
            } /* end of put draw item */

         if (key[KEY_S])
            {
               show_all_lifts();
               em_redraw = 1;
            }
         if ((mouse_b & 2) && (!mpow))  /* pop up menu */
            {
               extern int item_first_num[20];
               extern int item_num_of_type[20];
               extern int e_first_num[50];
               extern int e_num_of_type[50];
               extern char eitype_desc[50][32][40];
               extern int select_window_active;
               extern int db;
               extern int txc;
         
               int pop_menu_selection = 999;
               int temp_mouse_x, temp_mouse_y;
               extern char global_string[20][25][80]; /* menu.c */
         
               switch (point_item_type)
                  {
                     case 1:
                     sprintf(global_string[9][2], "Copy Block    ");
                     sprintf(global_string[9][3], "              ");
                     sprintf(global_string[9][4], "                ");
                     break;
                     case 2:
         
                     sprintf(global_string[9][2], "Copy %s  ", item_desc[ item[point_item_num][0] ]);
                     sprintf(global_string[9][3], "View %s  ", item_desc[ item[point_item_num][0] ]);
                     sprintf(global_string[9][4], "Delete %s ", item_desc[ item[point_item_num][0] ]);
                     break;
                     case 3:
         
                     sprintf(global_string[9][2], "Copy %s  ", eitype_desc[ Ei[point_item_num][0]]);
                     sprintf(global_string[9][3], "View %s  ", eitype_desc[ Ei[point_item_num][0]]);
                     sprintf(global_string[9][4], "Delete %s ", eitype_desc[ Ei[point_item_num][0]]);
                     break;
                     case 4:
                     sprintf(global_string[9][2], "              ");
                     sprintf(global_string[9][3], "View Lift '%s'", lifts[point_item_num]->lift_name);
                     sprintf(global_string[9][4], "Delete Lift '%s'", lifts[point_item_num]->lift_name);
                     break;
         
                   }
               temp_mouse_x = mouse_x;
               temp_mouse_y = mouse_y;
         
               show_mouse(NULL);
         
               pop_menu_selection = pmenu(9); /* call the pop up menu */
         
               position_mouse(temp_mouse_x, temp_mouse_y);
         
               switch (pop_menu_selection)
                  {
                     case 2:  /* COPY */
                              if (point_item_type < 4)
                                 {
                                    draw_item_type = point_item_type;
                                    draw_item_num  = point_item_num;
                                 }
                     break;
                     case 3:  /* VIEW */
                              switch (point_item_type)
                                 {
                                     case 1: /* view  select block */
                                            select_window_active = 1;
                                     break;
                                     case 2: /* view item */
                                            edit_item(0, point_item_num);
                                     break;
                                     case 3: /* view enemy */
                                            edit_item(1, point_item_num);
                                     break;
                                     case 4: /* view lift */
                                            lift_editor(point_item_num);
                                     break;
                                 }
                     break;
                     case 4:  /* DELETE */
                              x = wx + (mouse_x / 20);
                              y = wy + (mouse_y / 20);
                              switch (point_item_type)
                                 {
                                     case 1: /* DELETE block */
                                             l[x][y] = 0;
                                     break;
                                     case 2: /* zero item */

                                             /* are you deleting the draw item */
                                             if ((draw_item_type == 2) && (draw_item_num == point_item_num))
                                                {
                                                   draw_item_type = 1;
                                                   draw_item_num = 16;
                                                }

                                             for (a=0; a<16; a++)
                                                item [point_item_num][a] = 0;
                                             l[x][y] = 0;
                                             item_sort();

                                     break;
                                     case 3: /* zero enemy */

                                          /* are you deleting the draw item */
                                          if ((draw_item_type == 3) && (draw_item_num == point_item_num))
                                                {
                                                   draw_item_type = 1;
                                                   draw_item_num = 16;
                                                }


                                             for (a=0; a<10; a++)
                                                {
                                                   Ei[point_item_num][a] = 0;
                                                   Ef[point_item_num][a] = 0;
                                                }
                                             sort_enemy();
                                     break;
                                     case 4: /* zero lift */
                                             erase_lift(point_item_num);
                                     break;
                             
                                 }
                             draw_big();
                             em_redraw = 1;
                     break;

                     case 5:   /* menu divider */ break;
         
                     case 6:   /* zoom full screen */
                          {
                               int draw_item;
                               int rx, ry;
                               if (draw_item_type == 1) draw_item = draw_item_num;
                               else draw_item = 0;
                               show_mouse(NULL);
                               clear(screen);
                               c = zoom_full_screen(wx, wy, draw_item);
         
                               /* for mouse and window pos */
                               wy = (c / 100);
                               ry = 100 - (SCREEN_H/20);
                               if (wy>ry) wy = ry;
         
                               c = c - (wy * 100);
                               wx = c;
                               rx = 100 - (SCREEN_W/20);
                               if (wx>rx) wx = rx;
                        }
                     break;
         
                     case 7: status_window_active = 1; break;
                     case 8: select_window_active = 1; break;
         
                     case 9:   /* 640  */
                                if (set_gfx_mode(GFX_AUTODETECT,  640, 480, 0, 0) == 0)
                                   {
                                      set_config_int("LEVEL_EDITOR", "lsx", 640);
                                      set_config_int("LEVEL_EDITOR", "lsy", 480);
                                      db = (SCREEN_H/100);
                                      txc = SCREEN_W - (SCREEN_W - db*100) / 2;
                                      load_sprit();
                                      select_window_x = SCREEN_W-340;
                                      status_window_x = SCREEN_W-340;
                                      if (wx > 75) wx = 75;
                                      if (wy > 91) wy = 91;
                                      draw_big();
                                      em_redraw =1;
                                   }
                     break;
                     case 10:   /* 800  */
                                if (set_gfx_mode(GFX_AUTODETECT,  800, 600, 0, 0) == 0)
                                   {
                                      set_config_int("LEVEL_EDITOR", "lsx", 800);
                                      set_config_int("LEVEL_EDITOR", "lsy", 600);
                                      db = (SCREEN_H/100);
                                      txc = SCREEN_W - (SCREEN_W - db*100) / 2;
                                      load_sprit();
                                      select_window_x = SCREEN_W-340;
                                      status_window_x = SCREEN_W-340;
                                      if (wx > 60) wx = 60;
                                      if (wy > 70) wy = 70;
                                      draw_big();
                                      em_redraw =1;
                                   }
                      break;
                     case 11:   /* 1024  */
                                if (set_gfx_mode(GFX_AUTODETECT,  1024, 768, 0, 0) == 0)
                                set_config_int("LEVEL_EDITOR", "lsx", 1024);
                                set_config_int("LEVEL_EDITOR", "lsy", 768);
                                db = (SCREEN_H/100);
                                txc = SCREEN_W - (SCREEN_W - db*100) / 2;
                                load_sprit();
                                select_window_x = SCREEN_W-340;
                                status_window_x = SCREEN_W-340;
                                if (wx > 49) wx = 49;
                                if (wy > 62) wy = 62;
                                draw_big();
                                em_redraw =1;
                     break;
                     case 12:   /* LOAD */
                                   show_mouse(NULL);
                                   load();
                                   set_wx_from_start_block();
                                   sort_enemy();
                                   item_sort();

                                   draw_big();
                                   draw_status_window(); /* to update level num */
                     break;
                     case 13:   /* SAVE */
                                   show_mouse(NULL);
                                   save();
                                   draw_status_window();  /* in case level num changes */
                     break;
                     case 14:   /* SAVE AND EXIT LEVEL EDITOR */
                          {
                                extern int exit_link;
                                show_mouse(NULL);
                                clear(screen);
                                if (save())
                                   em_quit=1;
                                exit_link = 1;
                           }
                     break;
                     case 15:   /* HELP SCREENS */
                                help("Level Editor Basics");
                     break;
                     case 16:   /* EXIT LEVEL EDITOR */
                                em_quit=1;
                     break;
#ifdef MV
                     case 18:
                              bitmap_main();
                              draw_big();
                     break;

                     case 19:
                        select_block_proc();
                        /* automatically set rows to new number of lines here    */
                        set_swbl(0, NUM_SPRITES, 0);  /* set swbl */
                        swnbl = select_window_num_block_lines;
                        draw_select_window();
                      break;

                     case 20: predefined_enemies(); break;
                     case 21: global_level(); break;
#endif
                  } /* end of switch case */
               position_mouse(temp_mouse_x, temp_mouse_y);
               clear(screen);
               em_redraw = 1;

            } /* end of pop up menu processing */
         if (process_scrolledge())
            {
               em_redraw = 1;
            }
         else /* only process menus if not scrolling */
            {
               if (status_window_active)
                  {
                     d = process_status_window();
                     if (d == 1001) em_redraw = 1;
                  }
               if (select_window_active)
                   {
                      d = process_select_window();
                      if (d < 999) /* block */
                         {
                            draw_item_num = d;
                            draw_item_type = 1;
                         }
                      if (d >= 3000) /* pd */
                         {
                            draw_item_num = d-3000;
                            draw_item_type = 5;
                         }
                      if (d == 1001) em_redraw = 1;
                   }
            }
         if (em_redraw)
            {
               em_redraw = 0;
               select_window_redraw = 1;
               status_window_redraw = 1;
               update();

            }


          if (key[KEY_ESC])  /* trap here 1st */
             {
                 int g;
                 extern int gui_fg_color, gui_bg_color;
                 gui_fg_color = 14;
                 gui_bg_color = 14+224;
                 g = alert3("Are you sure", "you want to quit","the Level Editor?","Yes","Help", "No", 'Y', 'H', 'N');
                 gui_fg_color = 9;
                 gui_bg_color = 0;
                 text_mode(0);

                 if (g == 1) em_quit = 1;
                 if (g == 2)
                    {
                       em_quit = 0;
                       em_redraw = 1;
                       help("Level Editor Basics");
                    }
                 if (g == 3) em_quit = 0;


             }
      } while (!em_quit);
 
   show_mouse(NULL);
   clear(screen);
   textout_centre(screen, font, "Exiting Level Editor", SCREEN_W/2,SCREEN_H-50, 10);
   rest(500);
   destroy_bitmap(gtemp);
   destroy_bitmap(gtemp2);
   destroy_bitmap(gtemp3);

   clear_keybuf();
}   /* end of editor menu  */

