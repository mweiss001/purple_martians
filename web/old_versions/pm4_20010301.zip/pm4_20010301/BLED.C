/* Brand New Block Editor Feb, 2000  */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"

#ifdef MV


extern BITMAP *memory_bitmap[NUM_SPRITES];
extern int bcmt[NUM_SPRITES];
extern int sa[NUM_SPRITES][2];
extern int swbl[NUM_SPRITES][2];


int show_draw_mode(int msg, DIALOG *d, int c) /* show draw mode */
{
   extern int line_draw_mode;
   extern int old_line_draw_mode;

   switch (msg) {
      case MSG_IDLE:

           if (line_draw_mode != old_line_draw_mode)
             {
                     old_line_draw_mode = line_draw_mode;
                     show_mouse(NULL);
                     SEND_MESSAGE(d, MSG_DRAW, 0);
                     show_mouse(screen);
             }


      break;

      case MSG_DRAW:
          {
               char fmsg[80];

               /* clear old */
               sprintf(fmsg,"                    ");
               textout(screen, font, fmsg, 5, 230, 11);

               /* find mode */
               if (line_draw_mode == 0) sprintf(fmsg,"Point Draw");
               if (line_draw_mode == 1) sprintf(fmsg,"Line Draw");
               if (line_draw_mode == 2) sprintf(fmsg,"Framed Rectangle");
               if (line_draw_mode == 3) sprintf(fmsg,"Filled Rectangle");
               if (line_draw_mode == 4) sprintf(fmsg,"Framed Circle");
               if (line_draw_mode == 5) sprintf(fmsg,"Filled Circle");
               if (line_draw_mode == 6) sprintf(fmsg,"Flood Fill");
               if (line_draw_mode == 7) sprintf(fmsg,"Replace Color");
               if (line_draw_mode == 8) sprintf(fmsg,"New Selection");

               /* draw it on screen */

               if (1)
                  {

                      int tl = (strlen(fmsg)*8);

                      int x1 = 83-tl/2;
                      int x2 = 83+tl/2 + 2;

                      int y1 = 220;
                      int y2 = y1+18;
                      int color = 9;

                      /* erase */
                      rect(screen, 3, y1, 160, y2, 0);

                      rect(screen, x1, y1, x2, y2, 14);
                      textout_centre(screen, font, "Draw Mode", 83+2, y1+2, 14);
                      textout_centre(screen, font, fmsg, 83+2, y1+10, 9);


                  }
           }
      break;
   } /* end of switch case */
   return D_O_K;
}
int draw_current_bitmap(int msg, DIALOG *d, int c)
{
   extern int old_px;
   extern int old_py;
   extern int bmp_index;
   extern int cbx, cby, cbs;
   extern int slx0, sly0, slx1, sly1;

   extern int b1_color;
   extern int grid_flag;
   char tmsg[80];
   int x, y;
   switch (msg) {
      case MSG_IDLE:

      if ((mouse_x > cbx) && (mouse_x < cbx + (20 * cbs)) &&
         (mouse_y > cby) && (mouse_y < cby + (20 * cbs)))
            {
               x = ((mouse_x-cbx)/cbs);
               y = ((mouse_y-cby)/cbs);
               if ((old_px != x) || (old_py != y)) /* not same as last */
                  {
                     old_px = x;
                     old_py = y;
                     show_mouse(NULL);
                     SEND_MESSAGE(d, MSG_DRAW, 0);
                     show_mouse(screen);
                  }
            }

      break;
      case MSG_DRAW:

      if ((mouse_x > cbx) && (mouse_x < cbx + (20 * cbs)) &&
         (mouse_y > cby) && (mouse_y < cby + (20 * cbs)))
            {
               x = ((mouse_x-cbx)/cbs);
               y = ((mouse_y-cby)/cbs);

               /* clear old */
               rectfill(screen, cbx, cby+(20*cbs)+1, cbx+180, cby+(20*cbs)+8, 0);

               sprintf(tmsg,"x:%-2d ",x);
               textout(screen, font, tmsg, cbx+1, cby+(20*cbs)+2, 15);
               sprintf(tmsg,"y:%-2d ",y);
               textout(screen, font, tmsg, cbx+40, cby+(20*cbs)+2, 15);
               c = getpixel(memory_bitmap[bmp_index], x, y);
               sprintf(tmsg,"color:%-2d ",c);
               textout(screen, font, tmsg, cbx+80, cby+(20*cbs)+2, 15);

               /* show color */
               rectfill(screen, cbx+156, cby+(20*cbs)+1, cbx+195, cby+(20*cbs)+10, c);

               /* frame all */
               rect(screen, cbx-1, cby+(20*cbs), cbx+196, cby+(20*cbs)+10, 15);

            }
      else rectfill(screen, cbx-1, cby+(20*cbs)+1, cbx+180, cby+(20*cbs)+11, 0);

      c = bcmt[bmp_index];
      sprintf(tmsg,"map color:%-2d ",c);
      textout(screen, font, tmsg, cbx+252, cby+(20*cbs)+2, 15);

      /* show color */
      rectfill(screen, cbx+360, cby+(20*cbs)+1, cbx+399, cby+(20*cbs)+10, c);

      /* frame all */
      rect(screen, cbx+250, cby+(20*cbs), cbx+400, cby+(20*cbs)+10, 15);


      /* title and frame */
      sprintf(tmsg,"Bitmap # %-3d ",bmp_index);
      textout(screen, font, tmsg, cbx+1,cby-9, 15);
      rect(screen, cbx+100, cby-11, cbx-1, cby-1, 15);


      rect(screen, cbx-1, cby-1, cbx+(20*cbs), cby+(20*cbs), 15);
      for (y=0; y<20; y++)  /* draw the big image */
         for (x=0; x<20; x++)
            {
               rectfill(screen,((x*cbs)+cbx),(y*cbs)+cby,((x*cbs)+cbx+cbs-1),((y*cbs)+cby+cbs-1),getpixel(memory_bitmap[bmp_index],x,y));
               if (grid_flag) rect(screen,((x*cbs)+cbx),(y*cbs)+cby,((x*cbs)+cbx+cbs),((y*cbs)+cby+cbs),15+128 );
            }
      /* show selection */
      for (c=0; c<4; c++)
         rect(screen, cbx+(slx0*cbs)+c, cby+(sly0*cbs)+c, cbx+(slx1*cbs)-1-c, cby+(sly1*cbs)-1-c, 14+(c*32));

      break;

      case MSG_CLICK:

         x = ((mouse_x-cbx)/cbs);
         y = ((mouse_y-cby)/cbs);

         if (mouse_b & 1)
            {
               extern int line_draw_mode;
               extern int zz[20][NUM_ANS];
               extern int zzindx;

               BITMAP *temp;
               extern int cbx;
               extern int cby;
               extern int cbs;
               int omx, omy;
               int x1, y1, x2, y2;

               if ((y>19) && (x>16))  /* map color */
                  {
                     bcmt[bmp_index] = b1_color;
                     return D_REDRAW;
                  }

               temp = create_bitmap(20,20);
               clear(temp);
               omx = mouse_x;
               omy = mouse_y;

               x1 = x; x2 = x;
               y1 = y; y2 = y;

               while (mouse_b  & 1)
                  {
                     int x4, y4;

                     x2 = x1 - (omx - mouse_x)/cbs;
                     y2 = y1 - (omy - mouse_y)/cbs;
                     clear(temp);

                     switch (line_draw_mode)
                        {
                           case 1: line       (temp, x1, y1, x2, y2, b1_color); break;
                           case 2: rect       (temp, x1, y1, x2, y2, b1_color); break;
                           case 3: rectfill   (temp, x1, y1, x2, y2, b1_color); break;
                           case 4: circle     (temp, x2, y1, y2-y1, b1_color); break;
                           case 5: circlefill (temp, x2, y1, y2-y1, b1_color); break;
                        }
                     show_mouse(NULL);

                       /* draw original on screen */
                           for (x4=0; x4<20; x4++)
                              for (y4=0; y4<20; y4++)
                                 rectfill(screen,((x4*cbs)+cbx), (y4*cbs)+cby, (x4*cbs)+cbx+cbs-1, (y4*cbs)+cby+cbs-1, getpixel(memory_bitmap[bmp_index],x4,y4) );

                     /* draw original on screen */
                     for (x4=0; x4<20; x4++)
                        for (y4=0; y4<20; y4++)
                           rectfill(screen,((x4*cbs)+cbx), (y4*cbs)+cby, (x4*cbs)+cbx+cbs-1, (y4*cbs)+cby+cbs-1, getpixel(memory_bitmap[bmp_index],x4,y4) );

                     if (line_draw_mode != 8)
                        {
                           /* draw temp on screen */
                           for (x4=0; x4<20; x4++)
                              for (y4=0; y4<20; y4++)
                                 if (getpixel(temp,x4,y4)) rectfill(screen,((x4*cbs)+cbx), (y4*cbs)+cby, (x4*cbs)+cbx+cbs-1, (y4*cbs)+cby+cbs-1, getpixel(temp,x4,y4) );
                           show_mouse(screen);
                        }

                     if (line_draw_mode == 8)
                        {
                                if (x1>19) x1 = 19;
                                if (y1>19) y1 = 19;
                                if (x2>19) x2 = 19;
                                if (y2>19) y2 = 19;
                                if (x1<0) x1 = 0;
                                if (y1<0) y1 = 0;
                                if (x2<0) x2 = 0;
                                if (y2<0) y2 = 0;
                 /* show selection */
                           for (c=0; c<4; c++)
                              rect(screen, cbx+(x1*cbs)+c, cby+(y1*cbs)+c, cbx+((x2+1)*cbs)-1-c, cby+((y2+1)*cbs)-1-c, 14+(c*32));
                           rest(100);
                        }


                     if ((mouse_b & 2) || (key[KEY_ESC]))
                        {

                               destroy_bitmap(temp);
                               return D_REDRAW;
                        }

                  }
               switch (line_draw_mode)
                  {
                     case 0: putpixel  (memory_bitmap[bmp_index], x, y, b1_color); break;
                     case 1: line      (memory_bitmap[bmp_index], x1, y1, x2, y2, b1_color); break;
                     case 2: rect      (memory_bitmap[bmp_index], x1, y1, x2, y2, b1_color); break;
                     case 3: rectfill  (memory_bitmap[bmp_index], x1, y1, x2, y2, b1_color); break;
                     case 4: circle    (memory_bitmap[bmp_index], x2, y1, y2-y1, b1_color); break;
                     case 5: circlefill(memory_bitmap[bmp_index], x2, y1, y2-y1, b1_color); break;
                     case 6: floodfill (memory_bitmap[bmp_index], x1, y1, b1_color); break;
                     case 8: /* new selection */
                             {
                                if (x1>x2)
                                   {
                                      int ti = x2;
                                      x2 = x1;
                                      x1 = ti;
                                   }
                                if (y1>y2)
                                   {
                                      int ti = y2;
                                      y2 = y1;
                                      y1 = ti;
                                   }

                                if (x1>19) x1 = 19;
                                if (y1>19) y1 = 19;
                                if (x2>19) x2 = 19;
                                if (y2>19) y2 = 19;
                                if (x1<0) x1 = 0;
                                if (y1<0) y1 = 0;
                                if (x2<0) x2 = 0;
                                if (y2<0) y2 = 0;


                                slx0 = x1;
                                sly0 = y1;
                                slx1 = x2+1;
                                sly1 = y2+1;

                             }
                     break;
                     case 7: /* replace color */
                             {
                                int rc, xx, yy, azz, bzz;
                                rc = getpixel(memory_bitmap[bmp_index], x, y);
                                line_draw_mode = 0;
                                for (bzz=0; bzz<16; bzz++)
                                   if ((zz[4][zzindx]) > (bzz - 1))  /* is shape in seq? */
                                      {
                                         azz=zz[ 5+bzz][zzindx];
                                         for (yy=0; yy<20; yy++)
                                            for (xx=0; xx<20; xx++)
                                               if (getpixel(memory_bitmap[azz], xx, yy) == rc)
                                                   putpixel(memory_bitmap[azz], xx, yy, b1_color);
                                      }
                                for (yy=0; yy<20; yy++) /* do the current in case its not in seq */
                                   for (xx=0; xx<20; xx++)
                                      if (getpixel(memory_bitmap[bmp_index], xx, yy) == rc)
                                            putpixel(memory_bitmap[bmp_index], xx, yy, b1_color);
                                while (mouse_b  & 1); /* wait for release */
                                return D_REDRAW;
                             }
                     break;
                  } /* end of switch (line_draw_mode) */
               destroy_bitmap(temp);
               return D_REDRAW;
            }  /* end of if (mouse_b & 1) */
         if (mouse_b & 2)
            {
               while (mouse_b  & 2); /* wait for release */
               b1_color = getpixel(memory_bitmap[bmp_index], x, y);
               return D_REDRAW;
            }
      break; /* end of case MSG_CLICK /*/
   }
return D_O_K;
}
int new_draw_csp(int msg, DIALOG *d, int c)
{
     extern int cspx, cspy, csps;
     extern int b1_color;
     char tmsg[80];
     int x,y;
     switch (msg) {
        case MSG_DRAW:
           for (y=0; y<16; y++)
               for (x=0; x<16; x++)
                   rectfill(screen, cspx+(x*csps), cspy+(y*csps), cspx+((x+1)*csps), cspy+((y+1)*csps), (y*16)+x);
           rect(screen, cspx-1, cspy-1, cspx+(16*csps), cspy+(16*csps),15);
           rect(screen, cspx-1, cspy-1, cspx+(16*csps), cspy+(16*csps)+18,15);

           rect(screen, cspx+60, cspy-11, cspx-1, cspy-1, 15);
           textout(screen, font, "Pallete", cspx+1,cspy-9, 15);

           sprintf(tmsg,"Color=%-3d",b1_color);
           text_mode(0);
           textout(screen, font, tmsg, cspx+1, cspy+(16*csps)+2, b1_color);
           text_mode(15);
           hline(screen, cspx-1, cspy+(16*csps)+10, cspx+(8*10),15);
           vline(screen, cspx, cspy+(16*csps)+10, cspy+(16*csps)+18,15);

           textout(screen, font, tmsg, cspx+1, cspy+(16*csps)+11, b1_color);
           text_mode(0);

           rectfill(screen, cspx+(8*9), cspy+(16*csps)+1,cspx+(16*csps)-1, cspy+(16*csps)+17, b1_color);
      break;

        case MSG_CLICK:
           b1_color = ((mouse_x-cspx) / csps) + ((mouse_y - cspy) / csps) * 16;
           while (mouse_b & 1); /* wait for release */
           return D_REDRAW;
        break;

     }
 return D_O_K;
}
int select_block_proc()
{
   extern int swbn;
   extern int bmp_index;
   extern int select_window_num_block_lines;

   int p;
   int bb, cc, dd, ee, ff;

   int tw = 70;
   int tx = 300;
   int txc = tx+tw;
   int ty = 40;
   int jh;

   int aby = 184; /* solid blocks */

   int lgx = 500;
   int lgy = 2; /* legend */

   int cpx = 466;
   int cpy = 58;

   int mpx = 474;
   int mpy = 100;

   int tix = 315;
   int tiy = 20;
   int tixsize = 110;

   int sby = -18; /* special blocks */

   int vv;
   extern int fw;
   int ci = 64;
   int sw=20+fw*2;
   int abx = fw+2;

   extern int cols;

   int copy_item = 0;

   int copy_mode = 0;
   int edit_mode = 1;
   int clear_mode = 0;
   int redraw = 1;

   int c, x, y;
   int quit = 0;
   char msg[80];
   char msg1[80];

      set_swbl(32,NUM_SPRITES,1);
      show_mouse(NULL);
      text_mode(0);

      do
         {

            if (redraw)
               {
                  redraw = 0;
                  show_mouse(NULL);
                  clear(screen);
      
                  sprintf(msg,"Block Editor");
                  textout_centre(screen, font, msg, txc, 1, 9);

                  sprintf(msg,"Solid Blocks");
                  textout_centre(screen, font, msg, abx+fw+(cols/2*sw), aby-11, 9);
      
                  for (ff=0; ff<fw; ff++)
                     rect(screen, abx-ff, aby-ff, 1+abx+(cols*sw)+ff, 1+aby+(select_window_num_block_lines)*sw+ff, 9+(ff*ci));

                  for (c=0; c<cols*select_window_num_block_lines; c++)
                    draw_framed_shape(1+abx+(c-((c/cols)*cols) )*sw, 1+aby+(c/cols*sw), swbl[c][0], fw, ci);

                  /* do some counting */
                  dd=0;
                  ee=0;
                  for (c=32; c<NUM_SPRITES; c++)
                     {
                        if (sa[c][0] == 0) dd++;   /* empty */
                        if (sa[c][0] == 1) ee++;   /* solid blocks */
                     }
      
                  sprintf(msg,"%d solid blocks  -  %d empty", ee, dd);
                  textout_centre(screen, font, msg, abx+(cols/2*sw), 6+aby+select_window_num_block_lines*sw, 9);
      
                  textout_centre(screen, font, "Legend", lgx+30, lgy+2, 9);
                  textout_centre(screen, font, "Locked", lgx+30, lgy+16, 10);
                  textout_centre(screen, font, "Empty", lgx+30, lgy+24, 11);
                  textout_centre(screen, font, "User", lgx+30, lgy+32, 12);

                  /* frame legend */
                  for (ff=0; ff<fw; ff++)
                     rect(screen, lgx-ff, lgy+14-ff, lgx+60+ff,  lgy+40+ff, 9 + (ff*ci) );

                  sprintf(msg,"Special Blocks");
                  textout_centre(screen, font, msg, abx+fw+(4*sw), sby+22-fw, 9);

                  /* frame special blocks */
                  for (ff=0; ff<fw; ff++)
                     rect(screen, abx-ff, sby-ff+30, abx+(8*sw)+ff, sby+182+fw+fw+ff, 9 + (ff*ci) );

                  bb = 0;
                  for (ee=0; ee<25; ee+=8)
                     {
                        /* draw empty 8*/
                        bb +=40; /* space them every 40 */
            
                        switch (ee) {
            
                           case 0:  sprintf(msg1,"Empty");      break;
                           case 8:  sprintf(msg1,"Semi-Solid"); break;
                           case 16: sprintf(msg1,"Bomb-Proof"); break;
                           case 24: sprintf(msg1,"Breakable"); break;
            
                        }
            
                        rect(screen, abx, sby+bb, abx+1+(8*sw), sby+bb+sw+1, 9);

                        dd=0;
                        for (c=0; c<8; c++)
                           {
                              if (sa[c+ee][0] == 0) dd++;
                              draw_framed_shape(1+abx+(c*sw), 1+sby+bb, c+ee, fw, ci);
                              sprintf(msg,"%s  -   %d empty", msg1, dd);
                              textout_centre(screen, font, msg, abx+(4*sw), sby-4-fw+bb, 9);
                           }
                     }
                  if (clear_mode)
                     {
                       rectfill(screen, tix-fw, tiy-fw-4, tix+tixsize+fw, tiy+26+fw, 0);
                       for (ff=0; ff<fw; ff++)
                          rect(screen, tix-ff, tiy-ff, tix+tixsize+ff, tiy+18+ff, 9+(ff*ci));
                       textout_centre(screen, font, " Clear Mode ", tix+(tixsize/2), tiy+2,  13);
                       textout_centre(screen, font, " b1 Clear ", tix+(tixsize/2), tiy+10,  9);
                       if (sa[p][1]) textout_centre(screen, font, "  Locked  ", tix+(tixsize/2), tiy+10,  10);
      
                     }
                  if (edit_mode)
                     {
                       rectfill(screen, tix-fw, tiy-fw-4, tix+tixsize+fw, tiy+26+fw, 0);
                       for (ff=0; ff<fw; ff++)
                          rect(screen, tix-ff, tiy-ff, tix+tixsize+ff, tiy+18+ff, 9+(ff*ci));
                       textout_centre(screen, font, " Edit Mode ", tix+(tixsize/2), tiy+2,  13);
                       textout_centre(screen, font, " b1 Edit ", tix+(tixsize/2), tiy+10,  9);
                       if (sa[p][1]) textout_centre(screen, font, "  Locked  ", tix+(tixsize/2), tiy+10, 10);
                     }
                  if (copy_mode)
                    {
                       int ttiy = tiy - 4;
                       rectfill(screen, tix-fw, ttiy-fw, tix+tixsize+fw, ttiy+26+fw, 0);
                       for (ff=0; ff<fw; ff++)
                          rect(screen, tix-ff, ttiy-ff, tix+tixsize+ff, ttiy+26+ff, 9+(ff*ci));
                       textout_centre(screen, font, " Copy Mode ", tix+(tixsize/2), ttiy+2,  13);
                       textout_centre(screen, font, " b1 Paste ", tix+(tixsize/2), ttiy+10,  9);
                       textout_centre(screen, font, " b2 Copy ", tix+(tixsize/2), ttiy+18,  9);
                       if (sa[p][1]) textout_centre(screen, font, "  Locked  ", tix+(tixsize/2), ttiy+10,  10);
                     }
               }

            show_mouse(screen);
            rest (10);
            p = 999;
            /* check for mouse on special blocks */
            if ((mouse_x > abx) && (mouse_x < abx+(sw*8)))
               {
                  if ((mouse_y > sby+40-2) && (mouse_y < sby+40+22))
                     p = (mouse_x-abx+2)/sw;

                  if ((mouse_y > sby+40+38) && (mouse_y < sby+40+62))
                     p = 8 + (mouse_x-abx+2)/sw;

                  if ((mouse_y > sby+40+78) && (mouse_y < sby+40+102))
                     p = 16 + (mouse_x-abx+2)/sw;

                  if ((mouse_y > sby+40+118) && (mouse_y < sby+40+142))
                     p = 24 + (mouse_x-abx+2)/sw;
               }
            /* check for mouse on solid blocks */
            if ((mouse_y > aby) && (mouse_y < aby+(select_window_num_block_lines+1)*sw) && (mouse_x < abx+1+(sw*cols)) && (mouse_x > abx))
               {
                  p = swbl[((mouse_x-abx-1)/sw) + ((mouse_y-aby-1)/sw) * cols][0];
               }

            show_mouse(NULL);
            if (p == 999) /* not valid pointer */
               {
                  if (clear_mode)
                     textout_centre(screen, font, " b1 Clear ", tix+(tixsize/2), tiy+10,  9);
                  if (edit_mode)
                     textout_centre(screen, font, " b1 Edit ", tix+(tixsize/2), tiy+10,  9);
                  if (copy_mode)
                     {
                       int ttiy = tiy - 4;
                       textout_centre(screen, font, " b1 Paste ", tix+(tixsize/2), ttiy+10,  9);
                     }
                  rectfill(screen, mpx-fw, mpy-fw, mpx+116+fw+fw ,mpy+22+fw, 0 ); /* erase pointer */
               }
            else
               {

                  if (clear_mode)
                     {
                       if (sa[p][1]) textout_centre(screen, font, "  Locked  ", tix+(tixsize/2), tiy+10,  10);
                       else textout_centre(screen, font, " b1 Clear ", tix+(tixsize/2), tiy+10,  9);
      
                     }
                  if (edit_mode)
                     {
                       if (sa[p][1]) textout_centre(screen, font, "  Locked  ", tix+(tixsize/2), tiy+10,  10);
                       else textout_centre(screen, font, " b1 Edit ", tix+(tixsize/2), tiy+10,  9);
      
                     }
            
                  if (copy_mode)
                    {
                       int ttiy = tiy - 4;
                       if (sa[p][1]) textout_centre(screen, font, "  Locked  ", tix+(tixsize/2), ttiy+10,  10);
                       else textout_centre(screen, font, " b1 Paste ", tix+(tixsize/2), ttiy+10,  9);
                    }


                  sprintf(msg,"Pointer %-2d  ", p );
                  textout(screen, font, msg, mpx+4, mpy+7, 15);

                  if (sa[p][0] == 0) vv = 11; /* green empty */
                  if (sa[p][0] == 1) vv = 12; /* blue user  */
                  if (sa[p][1] == 1) vv = 10; /* red locked */

                  blit(memory_bitmap[p], screen, 0, 0, mpx+95+fw, mpy+1, 20, 20);

                  for (ff=0; ff<fw; ff++)
                     rect(screen, mpx-ff, mpy-ff, mpx+91+ff+sw ,mpy+21+ff, vv+(ff*ci) );
                  rest(5);
                  show_mouse(screen);
 
                  if ((mouse_b & 1) && (edit_mode))
                       {
                          while (mouse_b & 1);
                          if (sa[p][1] ==  0)  /* not locked ; editable */
                             {
                                bmp_index = p;
                                sa[p][0] = 1; /* set as block */
                                block_editor_proc();
                                show_mouse(NULL);
                                clear(screen);
                                set_swbl(32,NUM_SPRITES,1);
                                redraw = 1;
                             }

                       }
                  if ((mouse_b & 1) && (clear_mode))
                       {
                           while (mouse_b & 1);
                           if (sa[p][1] ==  0)  /* not locked ; clear it! */
                             {
                                 clear(memory_bitmap[p]);
                                 sa[p][0] = 0; /* set as empty */
                                 bcmt[p] = 0;
                                 set_swbl(32, NUM_SPRITES, 1);
                                 redraw = 1;
                             }

                       }
                  if ((mouse_b & 1) && (copy_mode))
                       {
                          while (mouse_b & 1);
                          if (sa[p][1] ==  0)  /* not locked  */
                             {
                                 blit(memory_bitmap[copy_item],memory_bitmap[p],0,0,0,0,20,20);
                                 sa[p][0] = 1; /* set as block */
                                 bcmt[p] = bcmt[copy_item];
                                 set_swbl(32, NUM_SPRITES, 1);
                                 redraw = 1;
                             }

                       }
                  if ((mouse_b & 2) && (copy_mode)) copy_item = p;
               }

            if (copy_mode)
              {

                 /* show copy item */
                 sprintf(msg,"Copy Item %d  ", copy_item );
                 textout(screen, font, msg, cpx+4, cpy+7, 15);

                  if (sa[copy_item][0] == 0) vv = 11; /* green empty */
                  if (sa[copy_item][0] == 1) vv = 12; /* blue user  */
                  if (sa[copy_item][1] == 1) vv = 10; /* red locked */

                 blit(memory_bitmap[copy_item], screen, 0, 0, cpx+110+fw, cpy+1, 20, 20);

                 for (ff=0; ff<fw; ff++)
                    rect(screen, cpx-ff, cpy-ff, cpx+130+ff+fw, cpy+21+ff, vv+(ff*ci));

               }
           else
              {
                 rectfill(screen, cpx-fw, cpy-fw, cpx+130+fw+fw, cpy+sw+fw, 0); /* erase copy item */

              }


            jh = 1; /* button 1 */
            if (edit_mode)
               {
                  sprintf(msg,"Edit Mode:On ");
                  c = 10;
               }
            else
               {
                  sprintf(msg,"Edit Mode:Off");
                  c = 9;
               }
            rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, c);
            textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);

            jh = 2; /* button 2 */
            if (copy_mode)
               {
                  sprintf(msg,"Copy Mode:On ");
                  c = 10;
               }
            else
               {
                  sprintf(msg,"Copy Mode:Off");
                  c = 9;
               }
            rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, c);
            textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);

            jh = 3; /* button 3 */
            if (clear_mode)
               {
                  sprintf(msg,"Clear Mode:On ");
                  c = 10;
               }
            else
               {
                  sprintf(msg,"Clear Mode:Off");
                  c = 9;
               }
            rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, c);
            textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);



            jh = 5; /* button 5 */
            sprintf(msg,"Load Blocks");
            rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, 14);
            textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);

            jh = 6; /* button 6 */
            sprintf(msg,"Save Blocks");
            rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, 14);
            textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);


            jh = 8; /* button 7 */
            sprintf(msg,"Help");
            rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, 11);
            textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);

            jh = 9; /* button 8 */
            sprintf(msg,"Quit");
            rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, 11);
            textout_centre(screen, font, msg, txc, ty+(jh*12)+2, 13);

            if ((mouse_b & 1) && (mouse_x > txc-tw) && (mouse_x < txc+tw) && (mouse_y > ty) && (mouse_y < ty+(10*12)) )
               {
                  int mb = (mouse_y - ty) / 12;
                  switch(mb)
                     {
                        case 1:
                           while (mouse_b & 1);
                           edit_mode = 1;
                           copy_mode = 0;
                           clear_mode = 0;
                           redraw = 1;
                        break;
                        case 2:
                           while (mouse_b & 1);
                           copy_mode = 1;
                           edit_mode = 0;
                           clear_mode = 0;
                           redraw = 1;

                        break;
                        case 3:
                           while (mouse_b & 1);
                           clear_mode = 1;
                           edit_mode = 0;
                           copy_mode = 0;
                           redraw = 1;
                        break;


                        case 5:
                           while (mouse_b & 1);
                              jh = 5; /* button 5 */
                              rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, 10);
                              rest(500);

                           load_sprit();
                           redraw = 1;
                        break;

                        case 6:
                           while (mouse_b & 1);

                              jh = 6; /* button 6 */
                              rect(screen, txc-tw, ty+(jh*12), txc+tw, ty+(jh*12)+10, 10);
                              rest(500);
                           save_sprit();
                           redraw = 1;

                        break;

                        case 8:
                           while (mouse_b & 1);
                           help("Block Editor");
                           redraw = 1;
                        break;

                        case 9:
                           while (mouse_b & 1);
                           quit = 1;
                        break;
                     }
               }

            if (key[KEY_ESC]) quit = 1;

            if ((mouse_b & 2) && (!copy_mode)) quit = 1;

         } while (!quit);
    show_mouse(NULL);
    draw_select_window();
    return D_REDRAW;
}
MENU draw_mode_menu[] =
{
   { "Line Draw",             line_draw_proc,         NULL },
   { "-------------",         NULL,                   NULL },
   { "Rectangle Draw",        rect_draw_proc,         NULL },
   { "Filled Rectangle",      rectfill_draw_proc,     NULL },
   { "-------------",         NULL,                   NULL },
   { "Circle Draw",           circle_draw_proc,       NULL },
   { "Filled Circle",         circlefill_draw_proc,   NULL },
   { "-------------",         NULL,                   NULL },
   { "Replace Color",         replace_color_proc,     NULL },
   { "Floodfill",             floodfill_draw_proc,    NULL },
   { "-------------",         NULL,                   NULL },
   { "New Selection",         new_selection_proc,     NULL },
   { "Gridlines on/off",      gridlines_proc,         NULL },
   { NULL,                    NULL,                   NULL }
};
MENU effects_menu[] =
{
   { "Flip X",                bm_flip_x_axis_proc,    NULL },
   { "Flip Y",                bm_flip_y_axis_proc,    NULL },
   { "Scroll Up",             bm_scroll_up_proc,      NULL },
   { "Scroll Down",           bm_scroll_down_proc,    NULL },
   { "Scroll Left",           bm_scroll_left_proc,    NULL },
   { "Scroll Right",          bm_scroll_right_proc,   NULL },
   { NULL,                    NULL,                   NULL }
};
MENU block_editor_menu[] =
{
   { "&Draw Mode",                NULL,             draw_mode_menu },
   { "&Effects",                  NULL,             effects_menu },
   { "&Quit",                    quit_proc,         NULL },
   { NULL,                       NULL,              NULL }
};
DIALOG block_editor_dialog[] =
{
   /* (dialog proc)       (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)  (d2)  (dp) */
   { d_clear_proc,        0,     0,   0,     0,    0,  0,    0,    0,       0,    0,    NULL },
   { d_ctext_proc,      320,     0,   0,     0,    10, 0,    0,    0,       0,    0,    " Block Editor" },
   { d_menu_proc,         1,    10,   0,     0,    9,  0,    0,    0,       0,    0,    block_editor_menu },
   { show_draw_mode,      3,   220,  160,  160,    9,  0,    0,    0,       0,    0,    NULL },


   { rb1_proc,           20,   244,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Point Draw" },
   { rb2_proc,           20,   256,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Line Draw" },
   { rb3_proc,           15,   268,  130,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Framed Rectangle" },
   { rb4_proc,           15,   280,  130,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Filled Rectangle" },
   { rb5_proc,           20,   292,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Framed Circle" },
   { rb6_proc,           20,   304,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Filled Circle" },

   { ar1_proc,           20,   345,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Up" },
   { ar2_proc,           20,   360,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Down" },
   { ar3_proc,           20,   375,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Left" },
   { ar4_proc,           20,   390,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Right" },
   { ar5_proc,           20,   405,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Mirror X Axis" },
   { ar6_proc,           20,   420,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Mirror Y Axis" },

   { new_draw_csp,           3,     40,  160,  160,  9,  0,    0,    0,       0,    0,    NULL },
   { draw_current_bitmap,  220,     40,  400,  410,  9,  0,    0,    0,       0,    0,    NULL },
   { NULL,                   0,      0,    0,    0,  0,  0,    0,    0,       0,    0,    NULL }
};
int block_editor_proc()
{
   do_dialog(block_editor_dialog, -1);
   text_mode(0);
   return D_REDRAW;
}

#endif
