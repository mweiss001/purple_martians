#include "pm.h"
#include "lift.h"

extern int num_lifts;
extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

FILE *filepntr;
extern char level_filename[80];
extern int level_header[20];
extern int l[100][100];
extern int item[500][16];
extern char *pmsg[500];
extern float itemf[500][4];
extern int Ei[100][32];
extern float Ef[100][16];


void smake_filename(int x)
{
   char temp[30];
   extern char level_filename[80];
   char msg[80];
   
   strcpy( temp, "LEVELS/LEVEL");

   if (x < 10) sprintf(msg,"00%-1d", x);
   if ((x  > 9) && (x  < 100)) sprintf(msg,"0%-2d", x);
   if (x > 99) sprintf(msg,"%-3d", x);

   strcat( temp, msg);
   strcat( temp, ".PML");
   strcpy(level_filename, temp);
}
void make_filename(int x)
{
   char temp[20];
   extern char level_filename[80];
   char msg[80];
   
   strcpy( temp, "LEVEL");

   if (x < 10) sprintf(msg,"00%-1d", x);
   if (x  > 9) sprintf(msg,"0%-2d", x);

   strcat( temp, msg);
   strcat( temp, ".PML");
   strcpy(level_filename, temp);
}

int load()
{
   extern char level_filename[80];
   char msg[80];
   char g[10];
   int len;
   int num;
   gui_fg_color = 13;
   gui_bg_color = 13+224;
   text_mode(0);
   if (file_select("Load Level", level_filename, "PML"))
      {
         text_mode(0);
         len = strlen(level_filename);
         g[0] = level_filename[len-7];
         g[1] = level_filename[len-6];
         g[2] = level_filename[len-5];
         g[3] = NULL;

         num = atoi(g);
         load_level(num+1000,0);
      }
   gui_fg_color = 13;
   gui_bg_color = 0;
   text_mode(0);
}
int save()
{
   extern int level_header[20];
   extern char level_filename[80];
   char msg[80];
   char g[10];
   char title[80];
   int len;
   int num;

   len = strlen(level_filename);

   g[0] = level_filename[len-7];
   g[1] = level_filename[len-6];
   g[2] = level_filename[len-5];
   g[3] = NULL;

   num = atoi(g);
   sprintf(title,"Save Level %d ",num);
   text_mode(0);
   gui_fg_color = 10;
   gui_bg_color = 10+224;

   if (file_select(title, level_filename, "PML"))
      {

         len = strlen(level_filename);

         g[0] = level_filename[len-7];
         g[1] = level_filename[len-6];
         g[2] = level_filename[len-5];
         g[3] = NULL;

         num = atoi(g);

         level_header[3] = item_sort(); /* num_of_items   */
         level_header[4] = sort_enemy(); /* num_of_enemies   */
         level_header[5] = num_lifts;

         save_level(num+1000);

         text_mode(0);
         gui_fg_color = 9;
         gui_bg_color = 0;
         return 1;
      }
   else
      {
         text_mode(0);
         gui_fg_color = 9;
         return 0; /* user pressed cancel */
      }
}
#ifdef MV

int save_sprit(void)
{
   FILE *filepntr;
   char sprit_filename[20] = "sprit001.pm";
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern PALLETE pallete;
   extern int zz[20][NUM_ANS];
   extern int sa[NUM_SPRITES][2];
   extern int bcmt[NUM_SPRITES];
   int sprit_load_error = 0;
   int c, x, y;
   char msg[80];
   for (c=0; c<NUM_ANS; c++)    /* set all to initial */
      if (zz[4][c] != 0)
         {
            zz[0][c]=zz[5][c];
            zz[1][c]=0;
            zz[2][c]=0;
         }
   filepntr = fopen( sprit_filename,"wb");
   for (c=0; c<NUM_SPRITES; c++)
      for (y=0; y<20; y++)
         for (x=0; x<20; x++)
            fputc(getpixel(memory_bitmap[c],x,y), filepntr);
   for (c=0; c<256; c++)
      {
         fputc(pallete[c].r, filepntr);
         fputc(pallete[c].g, filepntr);
         fputc(pallete[c].b, filepntr);
      }
   for (c=0; c<NUM_ANS; c++) /* put animation sequences */
      for (y=0; y<20; y++)
         {
            int ho = (zz[y][c] / 256);
            int lo = zz[y][c] - (ho*256);
            fputc(ho, filepntr);
            fputc(lo, filepntr);
         }
   for (c=0; c<NUM_SPRITES; c++)  /* shape attributes sa[512][2] */
      for (y=0; y<2; y++)
         fputc(sa[c][y], filepntr);
   for (c=0; c<NUM_SPRITES; c++)  /* block color map table bcmt[512]  */
      fputc(bcmt[c], filepntr);
   fclose(filepntr);
}
#endif
int load_sprit(void)
{
   char sprit_filename[20] = "sprit001.pm";
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern PALLETE pallete;
   extern int zz[20][NUM_ANS];
   extern int bcmt[NUM_SPRITES];
   extern int sa[NUM_SPRITES][2];

   int sprit_load_error = 0;
   int c, x, y;
   int dsp = 0;
   char msg[80];

   if (dsp) textout(screen, font, "Loading shapes...", SCREEN_W/2, (SCREEN_H*3)/4, 1);
   sprit_load_error = 0;
   if (exists(sprit_filename) == 0) /* does file exist? */
      {
         sprintf(msg, "Can't find sprit %s ", sprit_filename);
         textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
         sprit_load_error = 1;
      }
   if (!sprit_load_error)  /* open file */
      if ((filepntr=fopen(sprit_filename,"rb")) == NULL)
         {
            sprintf(msg, "Error opening %s ", sprit_filename);
            textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
            sprit_load_error = 1;
         }
   if (!sprit_load_error)  /* file open ! */
      {
         for (c=0; c<NUM_SPRITES; c++)
            {
               if (dsp)
                  {
                     sprintf(msg,".%d ", 512-c);
                     textout(screen, font, msg, 152, 184, 1);
                  }
               for (y=0; y<20; y++)
                  for (x=0; x<20; x++)
                     putpixel(memory_bitmap[c],x,y, fgetc(filepntr));
             }
         for (c=0; c<256; c++)      /* 256 colors */
               {
                  pallete[c].r = fgetc(filepntr);
                  pallete[c].g = fgetc(filepntr);
                  pallete[c].b = fgetc(filepntr);
               }
         for (c=0; c<NUM_ANS; c++)
            for (y=0; y<20; y++)
               {
                  int ho = fgetc(filepntr);
                  int lo = fgetc(filepntr);
                  zz[y][c] = ho*256 + lo;
               }
         for (c=0; c<NUM_SPRITES; c++)
           for (y=0; y<2; y++)
              sa[c][y] = fgetc(filepntr);
         for (c=0; c<NUM_SPRITES; c++)
              bcmt[c] = fgetc(filepntr);

      } /* end of if not sprit load error */
   fclose(filepntr);
   set_pallete(pallete);
   if (sprit_load_error)
      {
         rest(2000);
         return 0;
      }
   else return 1;
}
int load_level(int level_to_load, int display)
{
   FILE *filepntr;
   extern int level_header[20];
   extern int l[100][100];
   extern int item[500][16];
   extern char *pmsg[500];
   extern int Ei[100][32];
   extern float Ef[100][16];
   extern int level_num;
   int level_load_error = 0;
   int loop, ch, c, x, y;
   char buff[2000];
   char msg[80];

   /* erase all old data */
   
   for (c=0; c<100; c++)    /* blocks */
      for (x=0; x<100; x++)
           l[c][x] = 0;
   for (c=0; c < 500; c++)  /* items */
      {
         if (item[c][0] == 10) free (pmsg[c]);
         for (x=0; x<16; x++)
            item[c][x] = 0;
      }
   for (c=0; c < 100; c++)  /* enemy floats */
       for (x=0; x<10; x++)
            Ef[c][x] = 0;
   for (c=0; c < 100; c++)  /* enemy ints */
       for (x=0; x<10; x++)
            Ei[c][x] = 0;

   for (c = 0; c < level_header[5]; c++) /* lifts - free mem if allocated */
      {
         for (x = 0; x<lifts[c] -> num_steps; x++)
            destroy_lift_step(c,x);
         destroy_lift(c);

      }
   for (x=0; x<20; x++)
      level_header[x] = 0;

   if (level_to_load < 1000)
      {
         smake_filename(level_to_load);   /* update filename */
         level_num = level_to_load;
      }
   if (level_to_load > 1000)
      {
         level_num = level_to_load-1000;
      }
   level_load_error = 0;
   if ((exists(level_filename)) == 0)
      {
         sprintf(msg, "Can't Find Level %s ", level_filename);
         textout_centre(screen, font, msg, SCREEN_W/2, SCREEN_H/2-63, 10);
         level_load_error = 1;

      }

  if ( (!level_load_error) && (display))
      {
         text_mode(0);
         rectfill(screen, 30, 176, 290, 184, 0);

         sprintf(msg, "...loading level %d...", level_num);
         textout_centre(screen, font, msg, SCREEN_W/2, SCREEN_H/2-63, 11);
         rest(300);
      }

   if (!level_load_error) /* file exists */
      {
         if ((filepntr=fopen(level_filename,"r")) == NULL)
            {
               sprintf(msg, "Error opening %s ", level_filename);
               textout(screen, font, msg, 0, 160, 10);
               level_load_error = 1;
            }
         if (!level_load_error)  /* file open ! */
            {
               for (c=0; c<20; c++) /* level header */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     level_header[c] = atoi(buff);
                     if (ch == EOF)
                        {
                           sprintf(msg, "Error reading %s ", level_filename);
                           textout(screen, font, msg, 0, 160, 10);
                           rest(3000);
                           level_load_error = 1;
                        }
                  }
               num_lifts = level_header[5];
               for (c=0; c<100; c++)  /* l[100][100] */
                  for (y=0; y<100; y++)
                     {
                        loop = 0;
                        ch = fgetc(filepntr);
                        while((ch != '\n') && (ch != EOF))
                           {
                               buff[loop] = ch;
                               loop++;
                               ch = fgetc(filepntr);
                           }
                        buff[loop] = NULL;
                        l[c][y] = atoi(buff);
                        if (ch == EOF)
                           {
                              sprintf(msg, "Error reading %s ", level_filename);
                              textout(screen, font, msg, 0, 160, 10);
                              rest(3000);
                              level_load_error = 1;
                           }
                     }
               if (!level_load_error)
                  {
                     for (c = 0; c < level_header[3]; c++)  /* read item */
                        {
                           for (x = 0; x < 16; x++)
                              {
                                 loop = 0;
                                 ch = fgetc(filepntr);
                                 while((ch != '\n') && (ch != EOF))
                                    {
                                        buff[loop] = ch;
                                        loop++;
                                        ch = fgetc(filepntr);
                                    }
                                 buff[loop] = NULL;
                                 item[c][x] = atoi(buff);
   
                                 if (ch == EOF)
                                    {
                                       sprintf(msg, "Error reading items in %s ", level_filename);
                                       textout(screen, font, msg, 0, 168, 10);
                                       rest(3000);
                                       level_load_error = 1;
                                    }
                              }
                            if (item[c][0] == 10) /* get pmsg */
                              {
                                 loop = 0;
                                 ch = fgetc(filepntr);
                                 while((ch != '\n') && (ch != EOF))
                                    {
                                        if (ch == 126) ch = 13;
                                        buff[loop] = ch;
                                        loop++;
                                        ch = fgetc(filepntr);
                                    }
                                 buff[loop] = NULL;
                                 pmsg[c] = (char*) malloc (strlen(buff)+1);
                                 strcpy(pmsg[c], buff);
                              }
                        }

                  }
               if (!level_load_error)
                  {
                     for (c=0; c<level_header[4]; c++) /* read enemy floats */
                        for (x=0; x<16; x++)
                           {
                              loop = 0;
                              ch = fgetc(filepntr);
                              while((ch != '\n') && (ch != EOF))
                                 {
                                    buff[loop] = ch;
                                    loop++;
                                    ch = fgetc(filepntr);
                                 }
                              buff[loop] = NULL;
                              Ef[c][x] = atof(buff);
                              if (ch == EOF)
                                 {
                                    sprintf(msg, "Error reading Ef in %s ", level_filename);
                                    textout(screen, font, msg, 0, 176, 10);
                                    rest(3000);
                                    level_load_error = 1;
                                 }
                           }

                     for (c=0; c < level_header[4]; c++)  /* enemy ints */
                        for (x=0; x<32; x++)
                           {
                              loop = 0;
                              ch = fgetc(filepntr);
                              while((ch != '\n') && (ch != EOF))
                                 {
                                     buff[loop] = ch;
                                     loop++;
                                     ch = fgetc(filepntr);
                                 }
                              buff[loop] = NULL;
                              Ei[c][x] = atoi(buff);
                              if (ch == EOF)
                                 {
                                    sprintf(msg, "Error reading Ei in %s ", level_filename);
                                    textout(screen, font, msg, 0, 176, 10);
                                    rest(3000);
                                    level_load_error = 1;
                                 }

                           }
                  }
               if (!level_load_error)
                  {
                     for (c=0; c<num_lifts; c++) /* read lifts */
                        {
                           int tr[5];
                           char tmsg[80];
                           for (x=0; x<5; x++) /* lift data */
                              {
                                 loop = 0;
                                 ch = fgetc(filepntr);
                                 while((ch != '\n') && (ch != EOF))
                                    {
                                        buff[loop] = ch;
                                        loop++;
                                        ch = fgetc(filepntr);
                                    }
                                 buff[loop] = NULL;
                                 if (x == 0) strcpy(tmsg, buff); /* get lift name */
                                 else tr[x] = atoi(buff); /* get int */
                              }
                           construct_lift(c, tmsg, tr[1],tr[2],tr[3],tr[4]);

                           for (x=0; x<lifts[c] -> num_steps; x++) /* step data */
                              {
                                 int tr[4];
                                 for (y=0; y<4; y++) /* read 4 */
                                    {
                                       loop = 0;
                                       ch = fgetc(filepntr);
                                       while((ch != '\n') && (ch != EOF))
                                          {
                                             buff[loop] = ch;
                                             loop++;
                                             ch = fgetc(filepntr);
                                          }
                                       buff[loop] = NULL;
                                       tr[y] = atoi(buff);
                                    }
                                 construct_lift_step(c, x, tr[0], tr[1], tr[2], tr[3]);
                              }
                           set_lift_initial_not_in_file(c);
                        }
                  }
               fclose(filepntr);
            } /* end of file open */
      } /* end of if exists */
   if (level_load_error)
      {
         if (display) rest(1000);
         return 0;
      }
   else return 1;

}

int save_level(level_to_save)
{
   FILE *filepntr;
   char buff[20];
   extern int level_header[20];
   extern int l[100][100];
   extern int item[500][16];
   extern char *pmsg[500];
   extern int Ei[100][32];
   extern float Ef[100][16];
   int c, x, y;

   if (level_to_save > 1000) level_to_save -= 1000;
   else smake_filename(level_to_save);   /* update filename */

   filepntr = fopen(level_filename,"w");
   
   for (x=0; x<20; x++)
      fprintf(filepntr,"%d\n",level_header[x]);
   
   for (c=0; c<100; c++)  /* level */
      for (x=0; x<100; x++)
         fprintf(filepntr,"%d\n",l[c][x]);
   
   for (c=0; c < level_header[3]; c++) /* item */
      {
         for (x=0; x<16; x++)
            fprintf(filepntr,"%d\n",item[c][x]);

         if (item[c][0] == 10) /* pmsg */
            {
               y = 0;
               while (pmsg[c][y] != NULL)
                  {
                     if (pmsg[c][y] == 13)
                        fprintf(filepntr,"%c",126);
                     else
                        fprintf(filepntr,"%c",pmsg[c][y]);
                     y++ ;
                  }
               fprintf(filepntr,"\n");
            }

      }
   for (c=0; c < level_header[4]; c++)  /* enemy float */
      for (x=0; x<16; x++)
         fprintf(filepntr,"%f\n",Ef[c][x]);

   for (c=0; c < level_header[4]; c++) /* enemy int */
      for (x=0; x<32; x++)
         fprintf(filepntr,"%d\n",Ei[c][x]);
   
   for (c=0; c < level_header[5]; c++)   /* lifts */
      {
         fprintf(filepntr,"%s\n",lifts[c] -> lift_name);
         fprintf(filepntr,"%d\n",lifts[c] -> width);
         fprintf(filepntr,"%d\n",lifts[c] -> height);
         fprintf(filepntr,"%d\n",lifts[c] -> color);
         fprintf(filepntr,"%d\n",lifts[c] -> num_steps);

         for (x=0; x<lifts[c]->num_steps; x++)  /* steps */
            {
               fprintf(filepntr,"%d\n",lift_steps[c][x] -> x);
               fprintf(filepntr,"%d\n",lift_steps[c][x] -> y);
               fprintf(filepntr,"%d\n",lift_steps[c][x] -> val);
               fprintf(filepntr,"%d\n",lift_steps[c][x] -> type);
            }
      }

   fclose(filepntr);
}

#ifdef OLDFNXSTORAGE

int game_load_level(int level_to_load, int display)
{
   int loop, ch, c, d, x, y;
   char buff[2000];
   char msg[80];
   make_filename(level_to_load);   /* update filename */
   if (display)
      {
         sprintf(msg, "...loading level %d...", level_to_load);
         textout_centre(screen, font, msg, SCREEN_W/2, (SCREEN_H)/2+8, 10);
      }
   if ((exists(level_filename)) == 0)
      {
         if (display)
            {
               sprintf(msg, "Can't Find Level %s ", level_filename);
               textout_centre(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 10);
               rest(3000);
            }
         return 0;
      }
   /* erase all old data */
   for (c=0; c<100; c++)  /* level */
      for (x=0; x<100; x++)
         l[c][x] = 0;
   for (c=0; c < 500; c++)  /* items */
      {
         if (item[c][0] == 10) free (pmsg[c]);
         for (x=0; x<16; x++)
            item[c][x] = 0;
      }
   for (c=0; c < 100; c++)  /* enemy float */
      for (x=0; x<16; x++)
         Ef[c][x] = 0;

   for (c=0; c < 100; c++) /* enemy int */
      for (x=0; x<32; x++)
         Ei[c][x] = 0;

   for (c = 0; c < level_header[5]; c++) /* lifts - free mem if allocated */
      {
         for (x = 0; x<lifts[c] -> num_steps; x++)
            destroy_lift_step(c,x);
         destroy_lift(c);

      }
   for (x=0; x<20; x++)
      level_header[x] = 0;

   if ((filepntr=fopen(level_filename,"r")) == NULL)
      {
         sprintf(msg, "Error opening %s ", level_filename);
         textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
         rest(3000);
         return 0;
      }

   for (c=0; c<20; c++) /* level header */
      {
         loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
            {
               buff[loop] = ch;
               loop++;
               ch = fgetc(filepntr);
            }
         buff[loop] = NULL;
         level_header[c] = atoi(buff);
         if (ch == EOF)
            {
               sprintf(msg, "Error reading %s ", level_filename);
               textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
               rest(3000);
               return 0;
            }
      }
   for (c=0; c<100; c++)  /* l[100][100] */
      for (y=0; y<100; y++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                   buff[loop] = ch;
                   loop++;
                   ch = fgetc(filepntr);
               }
            buff[loop] = NULL;
            l[c][y] = atoi(buff);
            if (ch == EOF)
               {
                  sprintf(msg, "Error reading %s ", level_filename);
                  textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                  rest(3000);
                  return 0;
               }
         }
   for (c = 0; c < level_header[3]; c++)  /* read item */
      {
         for (x = 0; x < 16; x++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                      buff[loop] = ch;
                      loop++;
                      ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               item[c][x] = atoi(buff);
               if (ch == EOF)
                  {
                     sprintf(msg, "Error reading items in %s ", level_filename);
                     textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                     rest(3000);
                     return 0;
                  }
            }
         itemf[c][0] = item[c][4]; /* set them here */
         itemf[c][1] = item[c][5];
         if (item[c][0] == 10) /* get pmsg */
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                      if (ch == 126) ch = 13;
                      buff[loop] = ch;
                      loop++;
                      ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               pmsg[c] = (char*) malloc (strlen(buff)+1);
               strcpy(pmsg[c], buff);
            }
      }
   for (c=0; c<level_header[4]; c++) /* read enemy floats */
      for (x=0; x<16; x++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                  buff[loop] = ch;
                  loop++;
                  ch = fgetc(filepntr);
               }
            buff[loop] = NULL;
            Ef[c][x] = atof(buff);
            if (ch == EOF)
               {
                  sprintf(msg, "Error reading Ef in %s ", level_filename);
                  textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                  rest(3000);
                  return 0;
               }
         }
   for (c=0; c < level_header[4]; c++)  /* enemy ints */
      for (x=0; x<32; x++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                   buff[loop] = ch;
                   loop++;
                   ch = fgetc(filepntr);
               }
            buff[loop] = NULL;
            Ei[c][x] = atoi(buff);
            if (ch == EOF)
               {
                  sprintf(msg, "Error reading Ei in %s ", level_filename);
                  textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                  rest(3000);
                  return 0;
               }
         }
   for (c=0; c<level_header[5]; c++) /* read lifts */
      {
         int tr[5];
         char tmsg[80];
         for (x=0; x<5; x++) /* lift data */
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                      buff[loop] = ch;
                      loop++;
                      ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               if (x == 0) strcpy(tmsg, buff); /* get lift name */
               else tr[x] = atoi(buff); /* get int */
            }
         construct_lift(c,tmsg,tr[1],tr[2],tr[3],tr[4]);
         for (x=0; x<lifts[c] -> num_steps; x++) /* step data */
            {
               int tr[4];
               for (y=0; y<4; y++) /* read 4 */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     tr[y] = atoi(buff);
                  }
               construct_lift_step(c, x, tr[0], tr[1], tr[2], tr[3]);
            }
         set_lift_initial_not_in_file(c);
      }
   fclose(filepntr);
   return 1;
}
#endif
