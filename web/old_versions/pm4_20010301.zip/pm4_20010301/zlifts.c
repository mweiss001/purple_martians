#include <math.h>
#include <allegro.h>
#include "lift.h"
#include "pm.h"

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

extern BITMAP *scrn_buffer;
extern BITMAP *map100_bmp;

extern int level_header[20];
extern int game_map_on;
extern int WX, WY;
extern float PX, PY;
extern int PXint, PYint;
extern int player_ride;


int a, b, c, d, e, f, x, y;
char msg[80];


void set_lift_xyinc(int d, int step) /* used by move lift everywhere */
{
   float speed, angle, xlen, ylen, xinc, yinc;
   speed = lift_steps[d][step] -> val;
   speed /=10;
   xlen = abs( lifts[d] -> x1 - lift_steps[d][step] -> x );
   if (xlen == 0) xlen = .000001;
   ylen = abs( lifts[d] -> y1 - lift_steps[d][step] -> y );
   if (ylen == 0) ylen = .000001;
   angle = atan(ylen/xlen);
   xinc = cos(angle) * speed;
   yinc = sin(angle) * speed;
   if (xlen > ylen)
      lifts[d] -> limit_counter = abs( xlen / xinc); /* distance/speed=time! */
   if (xlen <= ylen)
      lifts[d] -> limit_counter = abs( ylen / yinc); /* distance/speed=time! */
   lifts[d] -> limit_type = 7; /* step countdown limit type 7 */
   
   if (lifts[d] -> x1  < lift_steps[d][step] -> x) lifts[d]->fxinc= +xinc;
   if (lifts[d] -> x1 == lift_steps[d][step] -> x) lifts[d]->fxinc= 0;
   if (lifts[d] -> x1  > lift_steps[d][step] -> x) lifts[d]->fxinc= -xinc;
   
   if (lifts[d] -> y1  < lift_steps[d][step] -> y) lifts[d]->fyinc= +yinc;
   if (lifts[d] -> y1 == lift_steps[d][step] -> y) lifts[d]->fyinc= 0;
   if (lifts[d] -> y1  > lift_steps[d][step] -> y) lifts[d]->fyinc= -yinc;
}

void draw_lifts()
{
#ifdef NEWLINES
   if (1) for (d=0; d<50; d++) /* draw lines */
      {
         int x1 = lines[d][2];
         int x2 = lines[d][4];
         int y1 = lines[d][3];
         int y2 = lines[d][5];
         if (lines[d][0] == 2)
            line(scrn_buffer, x1-WX, y1-WY, x2-WX, y2-WY, 15);
      }
#endif
   for (d=0; d<level_header[5]; d++)
      {
         int x1 = lifts[d]->x1;
         int x2 = lifts[d]->x2;
         int y1 = lifts[d]->y1;
         int y2 = lifts[d]->y2;
         int mode = lifts[d]->current_step;
         int color = lifts[d]->color;
         if (game_map_on)
            {
               if (y2-y1 > 20) rect(map100_bmp, x1/20, y1/20, x2/20, -1 + y2/20, color);
               else hline(map100_bmp, x1/20, y1/20, x2/20, color); /* single line */
            }
         for (a=0; a<10; a++)
            rect(scrn_buffer, x1-WX+a, y1-WY+a, x2-WX-a, y2-WY-a, color + ((9 - a)*16) );
         rectfill(scrn_buffer, x1-WX+a, y1-WY+a, x2-WX-a, y2-WY-a, color );
         textout_centre(scrn_buffer, font, lifts[d]->lift_name, ((x1+x2)/2)-WX, ((y1+y2)/2)-WY-2, color+160);



         switch (lifts[d]->limit_type) /* limit type */
            {
               case 5: /* timer wait */
                       sprintf(msg,"%d",lifts[d]->limit_counter) ;
                       textout_centre(scrn_buffer, font, msg, (lifts[d]->x1 + lifts[d]->x2)/2-WX+2, lifts[d]->y1-8-WY, color+64);
               break;
               case 6: /* prox wait */
                  {
                     int pd = lifts[d]->limit_counter; /* prox dist */
                     int bx1 = lifts[d]->x1 - pd;
                     int by1 = lifts[d]->y1 - pd;
                     int bx2 = lifts[d]->x2 + pd;
                     int by2 = lifts[d]->y2 + pd;
                     rect(scrn_buffer, bx1-WX+10, by1-WY+10, bx2-WX-10, by2-WY-10, color+128);
                  }
              break;
           }


      }  /* end of draw lift */
}

void move_lifts()
{
   for (d=0; d<level_header[5]; d++)
      {
         int color = lifts[d]->color;
         int next_mode = 0;
         lifts[d]->fx += lifts[d]->fxinc; /* xinc */
         lifts[d]->fy += lifts[d]->fyinc; /* yinc */
         if (d == player_ride-32)
            {
               PXint = PX;
               PYint = PY;
               if ((lifts[d]->fxinc > 0) && (!is_right_solid(PXint,PYint)) )
                  {
                     PX += lifts[d]->fxinc;
                     if (PX>1980) PX=1980;
                  }
               if ((lifts[d]->fxinc < 0) && (!is_left_solid(PXint,PYint)) )
                  {
                     PX += lifts[d]->fxinc;
                     if (PX<0) PX=0;
                  }
               PY = lifts[d]->fy-20; /* align with fy */
            }
         lifts[d]->x1 = lifts[d]->fx; /* put as int in x1 */
         lifts[d]->y1 = lifts[d]->fy; /* put as int in y1 */
         lifts[d]->x2 = lifts[d]->x1 + (lifts[d]->width*20)-1; /* width  */
         lifts[d]->y2 = lifts[d]->y1 + (lifts[d]->height*20)-1; /* height */

         /* limits */
         switch (lifts[d]->limit_type) /* limit type */
            {
               case 5: /* timer wait */
                       if (--lifts[d]->limit_counter < 0)
                       next_mode = 1;
               break;
               case 6: /* prox wait */
                  {
                     int pd = lifts[d]->limit_counter; /* prox dist */
                     int bx1 = lifts[d]->x1 - pd;
                     int by1 = lifts[d]->y1 - pd;
                     int bx2 = lifts[d]->x2 + pd;
                     int by2 = lifts[d]->y2 + pd;
                     if ( (PX+10 > bx1) && (PX+10 < bx2) && (PY+10 > by1) && (PY+10 < by2) )
                        next_mode = 1;
                  }
               break;
               case 7: /* step count */
                       if (--lifts[d]->limit_counter < 0)
                       next_mode = 1;
               break;
            }
         if (next_mode)
            {
               int step = ++lifts[d]->current_step;
               next_mode = 0;
               switch (lift_steps[d][step] -> type)
                  {
                     case 1: /* move */
                        set_lift_xyinc(d, step);
                     break;
                     case 2: /* wait time */
                        lifts[d]->limit_type = 5; /* wait time */
                        lifts[d]->limit_counter = lift_steps[d][step] -> val; /* limit */
                        lifts[d]->fxinc= 0; /* no xinc */
                        lifts[d]->fyinc= 0; /* no yinc */
                     break;
                     case 3: /* wait prox */
                        lifts[d]->limit_type = 6; /* wait prox */
                        lifts[d]->limit_counter = lift_steps[d][step] -> val; /* limit */
                        lifts[d]->fxinc= 0; /* no xinc */
                        lifts[d]->fyinc= 0; /* no yinc */
                     break;
                     case 4: /* move to step 0 */
                           step = lifts[d]->current_step = 0; /* set step 0 */
                           set_lift_xyinc(d, step);
                     break;
                  }
            }
      } /* end of if (active) */
}
