#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"


void draw_status_window(void) /* only at setup */
{
   extern BITMAP *status_window_bmp;
   extern int level_num;
   extern int status_window_w;
   extern int status_window_h;
   char msg[80];

   destroy_bitmap(status_window_bmp);
   status_window_bmp = create_bitmap(status_window_w, status_window_h);
   clear(status_window_bmp);

      textout(status_window_bmp, font, "Draw Item   ", 24, 14, 15);
      textout(status_window_bmp, font, "mouse", 100, 14, 14);
      textout(status_window_bmp, font, "b1", 143, 14, 14);

      textout(status_window_bmp, font, "View Item ", 184, 14, 15);
      textout(status_window_bmp, font, "mouse", 261, 14, 14);
      textout(status_window_bmp, font, "b2", 303, 14, 14);

      rect (status_window_bmp,   0, 12, 159, 42, 9);
      rect (status_window_bmp, 160, 12, 319, 42, 9);

      rectfill (status_window_bmp, 1, 0, 318, 10,  0);
      sprintf(msg,"Status Window    level:%d ",level_num);
      textout(status_window_bmp, font, msg, 2, 3, 9);
      sprintf(msg,"level:%d ",level_num);
      textout(status_window_bmp, font, msg, 2+(17*8), 3, 9);
      sprintf(msg,"%d ",level_num);
      textout(status_window_bmp, font, msg, 2+(23*8), 3, 15);

}
int process_status_window(void)
{
   extern BITMAP *status_window_bmp;
   
   extern int draw_item_num;
   extern int draw_item_type;
   extern int point_item_type;
   extern int point_item_num;
   extern int wx, wy;
   
   extern int old_draw_item_num;
   extern int old_draw_item_type;
   extern int old_point_item_type;
   extern int old_point_item_num;
   
   extern int status_window_active;
   extern int status_window_redraw;
   
   extern int status_window_x;
   extern int status_window_y;
   extern int status_window_w;
   extern int status_window_h;
   int y, x;
   char msg[80];

   show_mouse(NULL);

   if (status_window_redraw)
      {
         status_window_redraw = 0;
         blit(status_window_bmp, screen, 0, 0, status_window_x, status_window_y, status_window_w, status_window_h);
         draw_item_info(status_window_x+2,   status_window_y+21, 9, draw_item_type, draw_item_num);
      }

   if ( (old_draw_item_num != draw_item_num) || (old_draw_item_type != draw_item_type) )
      {
         old_draw_item_num = draw_item_num;
         old_draw_item_type = draw_item_type;
         draw_item_info(status_window_x+2,   status_window_y+21, 9, draw_item_type, draw_item_num);
      }
   if ( (old_point_item_num != point_item_num) || (old_point_item_type != point_item_type) )
      {
         old_point_item_num = point_item_num;
         old_point_item_type = point_item_type;
         draw_item_info(status_window_x+162, status_window_y+21, 9, point_item_type, point_item_num);
      }

   sprintf(msg, "x:%-2d y:%-2d ",mouse_x/20+wx,mouse_y/20+wy );
   textout(screen, font, msg, status_window_x+222, status_window_y+3, 15);

   textout(screen, font, "x:", status_window_x+222, status_window_y+3, 9);
   textout(screen, font, "y:", status_window_x+222+40, status_window_y+3, 9);


   if ( (mouse_x > status_window_x+310) && (mouse_x < status_window_x+320) && (mouse_y > status_window_y) && (mouse_y < status_window_y+12) )
      {
         textout(screen, font, "X", status_window_x+310, status_window_y+3, 14);
         if (mouse_b & 1)
            {
               while (mouse_b & 1);

               status_window_active = 0;
               show_mouse(NULL);
               return 1001;
            }
      }
   else textout(screen, font, "X", status_window_x+310, status_window_y+3, 9);
   if ( (mouse_x > status_window_x+296) && (mouse_x < status_window_x+304) && (mouse_y > status_window_y) && (mouse_y < status_window_y+12) )
      {
         textout(screen, font, "?", status_window_x+296, status_window_y+3, 14);
         if (mouse_b & 1)
            {
               while (mouse_b & 1);

               help("Status Window");
               show_mouse(NULL);
               return 1001;
            }
      }
   else textout(screen, font, "?", status_window_x+296, status_window_y+3, 9);
 
   if ((mouse_x > status_window_x) && (mouse_x < status_window_x+296) &&  /* title bar move */
       (mouse_y > status_window_y) && (mouse_y < status_window_y+12))
      {
         rect (screen, status_window_x,   status_window_y, status_window_x+319, status_window_y+12,  14);

            if (mouse_b & 1)
               {
                  int tx = (mouse_x-status_window_x); /* x offset */
                  int ty = (mouse_y-status_window_y); /* y offset */
                  xor_mode(TRUE);
                  while (mouse_b & 1)
                     {
                        show_mouse(NULL);
                        rect(screen, status_window_x, status_window_y, status_window_x+status_window_w-1, status_window_y+status_window_h-1, 15);
                        rest(5);
                        rect(screen, status_window_x, status_window_y, status_window_x+status_window_w-1, status_window_y+status_window_h-1, 15);
                        show_mouse(screen);
                        rest(5);
                        status_window_x = mouse_x-tx;
                        status_window_y = mouse_y-ty;
                     }
                  solid_mode();
                  return 1001;

               }
      }
   else rect (screen, status_window_x,   status_window_y, status_window_x+319, status_window_y+12,  9);

   show_mouse(screen);

}
void draw_select_window(void)
{
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern int PDEi[100][32];
   extern float PDEf[100][16];
   extern char PDEt[100][20][40];
   extern int zz[20][NUM_ANS];
   extern BITMAP *select_window_bmp;
   extern int select_window_active;
   extern int select_window_x;
   extern int select_window_y;
   extern int select_window_w;
   extern int select_window_h;

   extern int select_window_block_on;
   extern int swnbl;

   extern int select_window_block_y;
   extern int select_window_special_on;
   extern int select_window_num_special_lines;

   extern int select_window_special_y;
   extern int select_window_text_y;
   extern int swbn;
   extern int swbl[NUM_SPRITES][2];

   char msg[80];
   int x, y;
   int c, a, b=0;

   select_window_h = 200; /* for now */
   c = 13;  /* first y line of sub-windows */

   set_swbl(0, NUM_SPRITES, 0);  /* set swbl */

   /* set special start y */
   if (select_window_special_on)
      {
         select_window_special_y = c;
         c = 16 + c + select_window_num_special_lines*20;
      }

   /* set special start y */
   if (select_window_block_on)
      {
         select_window_block_y = c;
         c = 16 + c + swnbl*20;
      }
   select_window_text_y = c;
   select_window_h = select_window_text_y;

   /* set bmp size and clear */
   destroy_bitmap(select_window_bmp);
   select_window_bmp = create_bitmap(select_window_w, select_window_h);
   clear(select_window_bmp);

   /* title */
   rect(select_window_bmp, 0, 0, select_window_w-1, 12, 9);
   textout(select_window_bmp, font, "Selection Window", 2, 3, 9);
   textout(select_window_bmp, font, "Blocks  Special  X", 176, 3, 9);
   textout(select_window_bmp, font, "?", 172+128, 3, 9);

   if (select_window_special_on)
      {
         /* draw special   */
         /* title */
         rect(select_window_bmp, 0, select_window_special_y, select_window_w-1,
                                select_window_special_y + 12, 9);
         textout(select_window_bmp, font, "Special Items", 2, select_window_special_y+3, 9);
         textout(select_window_bmp, font, "+ - X", select_window_w-42, select_window_special_y+3, 9);
      
         /* special and frame */
         rect(select_window_bmp, 0, select_window_special_y+13, select_window_w-1,
                                select_window_special_y + select_window_num_special_lines*20+2+13, 9);
         for (c=0; c<16*select_window_num_special_lines; c++)
            {
               a = PDEi[c][1]; /* bmp or ans */
               if (a < NUM_SPRITES) b = a; /* bmp */
               if (a > 999) b = zz[5][a-1000]; /* ans */
               draw_sprite(select_window_bmp, memory_bitmap[b], (c-((c/16)*16) )*20+1, 14+select_window_special_y+1+(c/16*20) );
            }

      }
   if (select_window_block_on)
      {
      
         /* draw blocks */
            /* title */
         rect(select_window_bmp, 0, select_window_block_y, select_window_w-1,
                select_window_block_y + 12, 9);

         sprintf(msg, "Block Selection ");
         textout(select_window_bmp, font, msg , 2, select_window_block_y+3, 9);
         textout(select_window_bmp, font, "+ - X", select_window_w-42, select_window_block_y+3, 9);
      
         /* blocks and frame */
         rect(select_window_bmp, 0, select_window_block_y+13, select_window_w-1, select_window_block_y + swnbl*20+1+14, 9);
         for (c=0; c<16*swnbl; c++)
           draw_sprite(select_window_bmp, memory_bitmap[swbl[c][0]], (c-((c/16)*16) )*20+1, select_window_block_y+1+14+(c/16*20) );
      }

}

int process_select_window()
{
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern BITMAP *l2000;
   extern BITMAP *select_window_bmp;
   extern int PDEi[100][32];
   extern float PDEf[100][16];
   extern char PDEt[100][20][40];
   extern int zz[20][NUM_ANS];
   char msg[80];
   int x, y;
   int ret = 999;
   int quit = 0;
   extern int select_window_active;
   extern int select_window_redraw;
   
   extern int select_window_x;
   extern int select_window_y;
   extern int select_window_w;
   extern int select_window_h;
   extern int select_window_text_y;
   
   extern int select_window_block_on;
   extern int select_window_num_block_lines;
   extern int swnbl;

   extern int select_window_block_y;
   extern int old_b_pointer;
   extern int btext_draw_flag;
   
   extern int select_window_special_on;
   extern int select_window_num_special_lines;
   extern int select_window_special_y;
   extern int old_s_pointer;
   extern int stext_draw_flag;
   extern int swbl[NUM_SPRITES][2];
   extern int swbn;



   extern int wx;
   extern int wy;

   extern int draw_item_type;
   extern int draw_item_num;

   extern int sw_mouse_gone;

   if (sw_mouse_gone == 1) select_window_redraw = 1;

   if (select_window_redraw)
      {
         select_window_redraw = 0;
         show_mouse(NULL);
         blit(select_window_bmp, screen, 0, 0, select_window_x, select_window_y, select_window_w, select_window_h);
         show_mouse(screen);
      }

   /* check for mouse on whole window */
   if ((mouse_x > select_window_x) && (mouse_x < select_window_x + select_window_w)
      && (mouse_y > select_window_y) && (mouse_y < select_window_y + select_window_h))
         {

            int sys = select_window_y + select_window_special_y;
            int syb = select_window_y + select_window_block_y;
            int syt = select_window_y + select_window_text_y;
            int sxw = select_window_x + select_window_w-1;
            int vx = (mouse_x-select_window_x-2)/20; /* column */

            sw_mouse_gone = 0;
            show_mouse(NULL);

            /* check for mouse on top title bar */
            if (mouse_y < 14 + select_window_y)
               {
                  rect(screen, select_window_x, select_window_y, select_window_x + select_window_w-1, select_window_y + 12, 14);
                  textout(screen, font, "Selection Window", select_window_x+2, select_window_y+3, 14);

                  if ((mouse_x > sxw-8) && (mouse_x < sxw))  /* close whole sw X */
                     {
                        textout(screen, font, "X", sxw-9, select_window_y+3, 14);
                        if (mouse_b & 1)
                           {
                              while (mouse_b & 1);  /* wait for release */
                              select_window_active = 0;
                              return 1001;
                           }
                     }
                  else textout(screen, font, "X", sxw-9, select_window_y+3, 9);
                  if ((mouse_x > sxw-21) && (mouse_x < sxw-13))
                     {
                        textout(screen, font, "?", sxw-21, select_window_y+3, 14);
                        if (mouse_b & 1)
                           {
                              while (mouse_b & 1);  /* wait for release */
                              help("Selection Window");
                              return 1001;
                           }
                     }
                  else textout(screen, font, "?", sxw-21, select_window_y+3, 9);
              
                  if ((mouse_x > sxw-81) && (mouse_x < sxw-25))  /* Special button */
                     {
                        textout(screen, font, "Special", sxw-81, select_window_y+3, 14);
                        if (mouse_b & 1)
                           {
                              while (mouse_b & 1);  /* wait for release */
                              select_window_special_on = !select_window_special_on;
                              draw_select_window();
                              return 1001;
                           }
                     }
                  else textout(screen, font, "Special", sxw-81, select_window_y+3, 9);

                  if ((mouse_x > sxw-144) && (mouse_x < sxw-88))  /* Block button */
                     {
                        textout(screen, font, "Blocks", sxw-145, select_window_y+3, 14);
                        if (mouse_b & 1)
                           {
                              while (mouse_b & 1);  /* wait for release */
                              select_window_block_on = !select_window_block_on;
                              draw_select_window();
                              return 1001;
                           }
                     }

                  else textout(screen, font, "Blocks", sxw-145, select_window_y+3, 9);

                  /* title bar drag move! */

                  if (mouse_b & 1)
                     {
       
                          int tx = (mouse_x-select_window_x); /* x offset */
                          int ty = (mouse_y-select_window_y); /* y offset */
                          xor_mode(TRUE);
                          while (mouse_b & 1)
                            {
                                  show_mouse(NULL);
                                  rect(screen, select_window_x, select_window_y, select_window_x + select_window_w,select_window_y + select_window_h, 9);
                                  rest(5);
                                  rect(screen, select_window_x, select_window_y, select_window_x + select_window_w,select_window_y + select_window_h, 9);
                              /*  textout(screen, font, "Selection Window", select_window_x+2, select_window_y+3, 9);
                            */    show_mouse(screen);
                                  rest(5);
                                  select_window_x = mouse_x-tx;
                                  select_window_y = mouse_y-ty;
                             }
                          solid_mode();
                          draw_select_window();
                          return 1001;

                     }

               } /* end of if mouse on title bar */
            else
               {
                   rect(screen, select_window_x, select_window_y, select_window_x + select_window_w-1, select_window_y + 12, 9);
                   textout(screen, font, "Selection Window", select_window_x+2, select_window_y+3, 9);
                   textout(screen, font, "Blocks  Special  X", sxw - 145, select_window_y+3, 9);
                   textout(screen, font, "?", sxw - 145+124, select_window_y+3, 9);
               }


            /* check for mouse on special window title bar*/
            if (select_window_special_on)
               {
                  if ((mouse_y > sys) && (mouse_y < 14 + sys)) /* on s title bar */
                     {
                        rect(screen, select_window_x, sys, sxw, sys + 12, 14);
                        textout(screen, font, "Special Items", select_window_x+2, sys+3, 14);

                        if ((mouse_x > sxw-8) && (mouse_x < sxw))  /* close special sub window */
                           {
                              textout(screen, font, "X", sxw-9, sys+3, 14);
                              if (mouse_b & 1)
                                 {
                                    while (mouse_b & 1);  /* wait for release */
                                    select_window_special_on = 0;
                                    draw_select_window();
                                    return 1001;
                                 }
                           }
                        else textout(screen, font, "X", sxw-9, sys+3, 9);
                    
                        if ((mouse_x > sxw-25) && (mouse_x < sxw-17))  /* Special button */
                           {
                              textout(screen, font, "-", sxw-25, sys+3, 14);
                              if (mouse_b & 1)
                                 {
                                    while (mouse_b & 1);  /* wait for release */
                                    if (--select_window_num_special_lines < 1 )
                                       {
                                          select_window_num_special_lines++;
                                          select_window_special_on = 0;
                                       }
                                    draw_select_window();
                                    return 1001;
                                 }
                           }
                        else textout(screen, font, "-", sxw-25, sys+3, 9);
                        if ((mouse_x > sxw-41) && (mouse_x < sxw-33))  /* Special button */
                           {
                              textout(screen, font, "+", sxw-41, sys+3, 14);
                              if (mouse_b & 1)
                                 {
                                    while (mouse_b & 1);  /* wait for release */
                                    if (++select_window_num_special_lines > 4 )
                                          select_window_num_special_lines = 4;
                                    draw_select_window();
                                    return 1001;
                                 }
                           }
                        else textout(screen, font, "+", sxw-41, sys+3, 9);


                     }
                  else /* not on s title bar */
                     {
                         rect(screen, select_window_x, sys, sxw, sys + 12, 9);
                         textout(screen, font, "Special Items", select_window_x+2, sys+3, 9);
                     }
               }
            /* check for mouse on block window title bar*/
            if (select_window_block_on)
               {
                  if ( (mouse_y > syb) && (mouse_y < 14 + syb) ) /* on title bar */
                     {
                        rect(screen, select_window_x, syb, sxw, syb + 12, 14);
                        textout(screen, font, "Block Selection", select_window_x+2, syb+3, 14);
                        if ((mouse_x > sxw-8) && (mouse_x < sxw))  /* close special sub window */
                           {
                              textout(screen, font, "X", sxw-9, syb+3, 14);
                              if (mouse_b & 1)
                                 {
                                    while (mouse_b & 1);  /* wait for release */
                                    select_window_block_on = 0;
                                    draw_select_window();
                                    return 1001;
                                 }
                           }
                        else textout(screen, font, "X", sxw-9, syb+3, 9);
                        if ((mouse_x > sxw-25) && (mouse_x < sxw-17))  /* - button */
                           {
                              textout(screen, font, "-", sxw-25, syb+3, 14);
                              if (mouse_b & 1)
                                 {
                                    while (mouse_b & 1);  /* wait for release */
                                    if (--swnbl < 1 )
                                       {
                                          swnbl++;
                                          select_window_block_on = 0;
                                       }
                                    draw_select_window();
                                    return 1001;
                                 }
                           }
                        else textout(screen, font, "-", sxw-25, syb+3, 9);
                        if ((mouse_x > sxw-41) && (mouse_x < sxw-33))  /* + button */
                           {
                              textout(screen, font, "+", sxw-41, syb+3, 14);
                              if (mouse_b & 1)
                                 {
                                    while (mouse_b & 1);  /* wait for release */
                                    if (++swnbl > select_window_num_block_lines )
                                          swnbl = select_window_num_block_lines;
                                    draw_select_window();
                                    return 1001;
                                 }
                           }
                        else textout(screen, font, "+", sxw-41, syb+3, 9);




                     }
                  else   /* not on title bar */
                     {
                         rect(screen, select_window_x, syb, sxw, syb + 12, 9);
                         textout(screen, font, "Block Selection", select_window_x+2, syb+3, 9);
                     }
               }

            /* check for mouse on special window */
            if ( (select_window_special_on) && (mouse_y > 15 + sys) && (mouse_y < 16 + sys + select_window_num_special_lines * 20) )
               {
                  int vy = (mouse_y-sys-15)/20; /* row */
                  int ret = vy*16+vx;
                  int tl = 0; /* text lines */
                  extern BITMAP *l2000;

                  if (ret != old_s_pointer)  /* only draw if not same as before */
                     {
                        old_s_pointer = ret;

                        /* set  tl */

                        for (x=0; x<20; x++)
                           if (strcmp(PDEt[ret][x],"<end>") == 0) tl = x;

                        if (tl<5) tl = 5;

                        /* restore area underneath */

                        blit(l2000, screen, (wx*20)+select_window_x, (wy*20)+syt,
                              select_window_x, syt, sxw-select_window_x+1, 200);


                        /* erase and frame */
                        rectfill(screen, select_window_x, syt, sxw, 12+syt+3+(8*tl), 0);
                            rect(screen, select_window_x, syt, sxw, 12+syt+3+(8*tl), 9);

                        /* title and frame */
                        rect(screen, select_window_x, syt, sxw, syt+12, 9);


                          sprintf(msg, "Description " );
                          textout(screen, font, msg,select_window_x+2, syt+3, 9);


                        /* draw text for this pde */
                        stext_draw_flag=1;
                        for (x=0; x<tl; x++)
                           textout(screen, font, PDEt[ret][x], select_window_x+2, select_window_y + select_window_text_y+14+(x*8), 15);
                     }
                  if (mouse_b & 1)
                     {
                        while (mouse_b & 1); /* wait for release */
   
                        if (PDEi[ret][0] < 200) /* PUT ITEM OR ENEMY */
                           {
                              return 3000+ret;
   
                           }
                        if (PDEi[ret][0] > 199) /* Creator */
                           {
                              switch (PDEi[ret][0]-199)
                                 {
                                    case 1: /* type 200 */
                                    create_obj(2, 1, NULL); /* door creator */
                                    break;
                                    case 2: /* type 201 */
                                    create_obj(2, 5, NULL); /* start */
                                    break;
                                    case 3: /* type 202 */
                                    create_obj(2, 3, NULL); /* normal exit */
                                    break;
                                    case 4: /* type 203 */
                                    create_obj(2, 4, NULL); /* key */
                                    break;
                                    case 5: /* type 204 */
                                    create_obj(3, 7, NULL); /* pod  */
                                    break;
                                    case 7: /* type 206 */
                                    create_obj(2,10, NULL); /* pop up message */
                                    break;
                                    case 8: /* type 207 */
                                    create_obj(3, 9, NULL); /* cloner */
                                    break;
                                    case 9: /* type 208 */
                                    create_lift();
                                    break;
                                 }
                             draw_big();
                             return 1001;
                           }
                     } /* end of if (mouse_b & 1)  */

               }  /* end of mouse on special */
            else /* mouse not on special */
               {
                  if (stext_draw_flag)
                     {
                        stext_draw_flag = 0;
                        old_s_pointer = -1;
                         return 1001;
                     }
               }

            /* check for mouse on block window */
            if ( (select_window_block_on) && (mouse_y > 14 + syb) && (mouse_y < 14 + syb + swnbl * 20))
               {
                  int vy = (mouse_y-syb-14)/20; /* row */
                  int ret = vy*16+vx;
                  int tl = 3; /* text lines */

                  ret = swbl[ret][0];

                  if (ret != old_b_pointer)  /* only draw if not same as before */
                     {
                        char t[80];
                        old_b_pointer = ret;

                        /* erase and frame */
                        rectfill(screen, select_window_x, syt, sxw, 12+syt+3+(8*tl), 0);
                            rect(screen, select_window_x, syt, sxw, 12+syt+3+(8*tl), 9);

                        /* title and frame */
                        rect(screen, select_window_x, syt, sxw, syt+12, 9);
                        textout(screen, font, "Description",select_window_x+2, syt+3, 9);

                        /* draw text for this pde */
                        btext_draw_flag=1;
                        if ((ret > 127 ) && (ret < NUM_SPRITES ))
                           sprintf(t,"solid");
                        if ((ret > 95 ) && (ret < 128 ))
                           sprintf(t,"breakable");
                        if ((ret > 63 ) && (ret < 96 ))
                           sprintf(t,"bombable");
                        if ((ret > 31  ) && (ret < 64 ))
                           sprintf(t,"semi-solid ");
                        if (ret < 32 )
                           sprintf(t,"empty");
                        if (ret == 169 )
                           sprintf(t,"map translucent");

                        sprintf(msg,"Block %d - %s ", ret, t);
                        textout(screen, font, msg, select_window_x+2, select_window_y + select_window_text_y+14+(1*8), 15);

                        textout(screen, font, "-----------------------",select_window_x+2, select_window_y + select_window_text_y+14+(0*8), 15);
                        textout(screen, font, "-----------------------",select_window_x+2, select_window_y + select_window_text_y+14+(2*8), 15);
                     }

                  if (mouse_b & 1)
                     {
                        while (mouse_b & 1); /* wait for release */
                        return ret;
                     }
               } /* end of mouse on block */
            else /* mouse not on block */
               {
                  if (btext_draw_flag)
                     {
                        btext_draw_flag = 0;
                        old_b_pointer = -1;
                         return 1001;
                     }
               }

         } /* end of if mouse on whole window */
      else
         {

            sw_mouse_gone++;

            if (stext_draw_flag)
               {
                  stext_draw_flag = 0;
                  old_s_pointer = -1;
                   return 1001;
               }
            if (btext_draw_flag)
               {
                  btext_draw_flag = 0;
                  old_b_pointer = -1;
                   return 1001;
               }
         }
return 999;
}

