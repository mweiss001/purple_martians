/* sliders.c   all slider functions   */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"
#include "lift.h"

extern int item[500][16];
extern int Ei[100][32];
extern float Ef[100][16];
extern int e_num_of_type[50];   /* sort results */
extern int e_first_num[50];
extern int item_num_of_type[20];   /* sort results */
extern int item_first_num[20];
extern char item_desc[20][40];
extern int rits;
extern int db;
extern int bts;

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];
extern int num_lifts;
extern int current_lift;


char smsg[80];
int bw = 4; /* button width */

void update_var(int bn, int num, float f)
{
   if (bn == 1) item[num][7] = f;
   if (bn == 2) item[num][8] = f;
   if (bn == 3) item[num][9] = f;
   if (bn == 4) item[num][7] = f;
   if (bn == 5) item[num][9] = f;
   if (bn == 6) item[num][9] = f;
   if (bn == 7) item[num][8] = f;
   if (bn == 8) item[num][6] = f;
   if (bn == 9) item[num][6] = f;
   if (bn == 10) item[num][7] = f;
   if (bn == 11) item[num][8] = f;
   if (bn == 12)
      {
         Ef[num][6] = f;
         if (Ei[num][2])
            Ef[num][2] = Ef[num][6];
         else
            Ef[num][2] = -Ef[num][6];
      }

   if (bn == 13) Ef[num][3] = f;
 
   if (bn == 15) Ei[num][6] = f;
   if (bn == 16) Ei[num][7] = f;
   if (bn == 17) Ei[num][12] = f;
   if (bn == 18) Ei[num][11] = f;
   if (bn == 19) Ef[num][7] = f;
   if (bn == 20) Ei[num][17] = f;
   if (bn == 21) Ei[num][15] = f;

   if (bn == 22) /* scale bouncer speed */
      {
         float ratio, old_speed = Ef[num][5];
         Ef[num][5] = f;
         ratio = Ef[num][5]/old_speed;
         Ef[num][2] *= ratio;
         Ef[num][3] *= ratio;
      }

   if (bn == 23) Ei[num][8] = f;
   if (bn == 24) Ei[num][29] = f;
   if (bn == 25) Ef[num][4] = f;
   if (bn == 26) bts = f;
   if (bn == 27) item[num][8] = f;
   if (bn == 28) item[num][8] = f;
   if (bn == 29)
      {
         Ef[num][9] = f;
         recalc_pod(num);
      }
   if (bn == 30) Ei[num][9] = f;
   if (bn == 33) Ef[num][2] = f;
   if (bn == 34)
      {
         Ei[num][6] = f;
         Ei[num][7] = f;
      }
   if (bn == 35) Ei[num][28] = f;
   if (bn == 36) Ef[num][3] = f;
   if (bn == 38) Ei[num][17] = f;
   if (bn == 39) Ei[num][18] = f;
   if (bn == 40) Ei[num][19] = f;
   if (bn == 41) Ei[num][24] = f;
   if (bn == 42) Ei[num][25] = f;

   if (bn == 43) lifts[num] -> width = (int) f; /* LIFT WIDTH */
   if (bn == 44) lifts[num] -> height = (int) f; /* LIFT HEIGTH */

   if (bn == 45) Ef[num][2] = f; /* trakbot x speed  */
   if (bn == 46) Ef[num][3] = f; /* trakbot y speed  */

   rits = 1;
}
void fill_smsg(int bn, int num)
{
     if (bn == 1) sprintf(smsg, "Health Bonus:%d", item[num][7]);
     if (bn == 2) sprintf(smsg, "Bullet Bonus:%d", item[num][8]);
     if (bn == 3) sprintf(smsg, "Timer Bonus:%d",  item[num][9]);
     if (bn == 4) sprintf(smsg, "Damage Range:%d", item[num][7]);
     if (bn == 5) sprintf(smsg, "Fuse Length:%d",  item[num][9]);
     if (bn == 6) sprintf(smsg, "Acceleration:%d", item[num][9]);
     if (bn == 7) sprintf(smsg, "Maximum Speed:%d",item[num][8]);
     if (bn == 8) sprintf(smsg, "Steerability:%d", item[num][6]);
     if (bn == 9 ) sprintf(smsg, "Jump Length:%d", item[num][6]);
     if (bn == 10) sprintf(smsg, "Jump Speed:%d", item[num][7]);
     if (bn == 11) sprintf(smsg, "Mine Damage:%d", item[num][8]);

     if (bn == 12) sprintf(smsg, "X-Speed:%-1.2f", Ef[num][6]);
     if (bn == 13) sprintf(smsg, "Y-Speed:%-1.2f", Ef[num][3]);

     if (bn == 15)
        {
           if (Ei[num][6]) sprintf(smsg, "Jump Wait Count:%d",  Ei[num][6]);
           else sprintf(smsg, "Jump Wait Count:Off");
        }
     if (bn == 16)
        {
           if (Ei[num][7]) sprintf(smsg, "Jump Under Width:%d",  Ei[num][7]);
           else sprintf(smsg, "Jump Under Width:Off");
        }
     if (bn == 17)
        {
           if (Ei[num][12]) sprintf(smsg, "Jump Before Wall:%d",  Ei[num][12]);
           else sprintf(smsg, "Jump Before Wall:Off");
        }
     if (bn == 18)
        {
           if (Ei[num][11]) sprintf(smsg, "Jump Before Hole:%d",  Ei[num][11]);
           else sprintf(smsg, "Jump Before Hole:Off");
        }
     if (bn == 19) sprintf(smsg, "Bullet Speed:%-1.2f", Ef[num][7]);
     if (bn == 20) sprintf(smsg, "Bullet Proximity:%d", Ei[num][17]);
     if (bn == 21) sprintf(smsg, "Bullet Retrigger Time:%d", Ei[num][15]);
     if (bn == 22) sprintf(smsg, "Speed:%-1.3f", Ef[num][5]);
     if (bn == 23) sprintf(smsg, "Seek Count:%d", Ei[num][8]);
     if (bn == 24) sprintf(smsg, "Collision Box:%d", Ei[num][29]);
     if (bn == 25) sprintf(smsg, "Health Decrement:%-1.3f", Ef[num][4]);
     if (bn == 26) sprintf(smsg, "" ); /* button height */
     if (bn == 27) sprintf(smsg, "Initial Time:%d", item[num][8]);
     if (bn == 28) sprintf(smsg, "Warp Level:%d", item[num][8]);
     if (bn == 29) sprintf(smsg, "Speed:%-2.1f", Ef[num][9]);
     if (bn == 30) sprintf(smsg, "Pause:%d", Ei[num][9]);
     if (bn == 33) sprintf(smsg, "X-Speed:%-1.2f", Ef[num][2]);
     if (bn == 34) sprintf(smsg, "Create Delay:%d", Ei[num][6]);
     if (bn == 35) sprintf(smsg, "Extra Hits to Kill:%d", Ei[num][28]);
     if (bn == 36) sprintf(smsg, "Y-Speed:%f", Ef[num][3]);
     if (bn == 38) sprintf(smsg, "Trigger Box Width:%d", Ei[num][17]);
     if (bn == 39) sprintf(smsg, "Trigger Box Height:%d", Ei[num][18]);
     if (bn == 40) sprintf(smsg, "Trigger Box Depth:%d", Ei[num][19]);

     if (bn == 41) sprintf(smsg, "Bullet Bonus:%d", Ei[num][24]);
     if (bn == 42) sprintf(smsg, "Health Bonus:%d", Ei[num][25]);

     if (bn == 43) sprintf(smsg, "Lift Width:%d",lifts[num] -> width);
     if (bn == 44) sprintf(smsg, "Lift Height:%d",lifts[num] -> height);

     if (bn == 45) sprintf(smsg, "X-speed:%-1.2f",Ef[num][2]);
     if (bn == 46) sprintf(smsg, "Y-Speed:%-1.2f",Ef[num][3]);

}
float draw_slider(float sdx, float sul, float sll,int x1, int y1, int x2, int y2, int dm, int col)
{
   float a, b, c;
   float d, e, f;
   int aa, bb, cc;

   int ts, rounder;

   char msg[80];
   /* get slider position */
   a = sdx-sll; /* relative postion */
   b = sul-sll; /* range */
   c = a/b; /* ratio */

   d = x2-x1;  /* range */
   e = d * c;  /* range * old ratio */
   f = e + x1; /* add offset */

   /* draw bar */

   if (dm == 1)
      {
         rectfill(screen, f-bw, y1+1, f+bw, y2-1, 0);
         for (aa=0; aa<bw+1; aa++)
            rect(screen, f-bw+aa, y1+aa, f+bw-aa, y2-aa, col+208-(aa*32) );

      }
   if (dm == 2)
      {
         for (aa=0; aa<bw+1; aa++)
            rect(screen, f-bw+aa, y1+aa, f+bw-aa, y2-aa, col+128-(aa*32) );
      }
   return f;
}
void color_selector(int x1, int y1, int x2, int y2, int bn, int num,
              int type, int obt, int q0, int q1, int q2, int q3, int q4, int q5, int q6, int q7 )
{

     float a, b, c, d, e, f;

     if (bn == 2) sprintf(smsg, "Select Text Color");
     if (bn == 3) sprintf(smsg, "Select Frame Color");
     if (bn == 4) sprintf(smsg, "Select Lift Color");

   /* erase */
   rectfill(screen, x1, y1, x2, y2, 0);

   /* draw colors (1-15) */
     a = x2-x1; /* range */
     b = a/15; /* color swatch width */
     if (b<2) b = 2; /* min width */

     for (c=0; c<15; c++)
        rectfill(screen, x1+c*b, y1, b + x1+c*b, y2, c+1 );
   /* outline */
   rect(screen, x1, y1, x2, y2, 15);

   /* draw text */
   text_mode(-1);
   textout_centre(screen ,font, smsg, (x2+x1)/2, (y2+y1)/2-3, 0);
   text_mode(0);

   if ((mouse_x > x1) && (mouse_x < x2))
      if ((mouse_y > y1) && (mouse_y < y2))
         if (mouse_b & 1)
            {
                int color;
                color = 1+(mouse_x-x1)/b;

                while (mouse_b & 1);
                rits = 1;

                if (bn == 2) /* pmsg text */
                   item[num][8] = color;
                if (bn == 3) /* pmsg frame */
                   item[num][9] = color;
                if (bn == 4) /* lift color */
                   lifts[num] -> color = color;
            }
}
int new_button(int x1, int y1, int x2, int y2, int bn, int num,
                int type, int obt, int q0, int q1, int q2, int q3, int q4, int q5, int q6, int q7 )
{
extern int get100_x, get100_y;
extern int bx1, by1, bx2, by2;
int a, b, c, d = y2-y1;
     if (bn == 2)
        {
           if (item[num][3]) sprintf(smsg, "Fall:On");
           else sprintf(smsg, "Fall:Off");
        }
     if (bn == 3)
        {
           if (item[num][8]) sprintf(smsg, "All Dead:On");
           else sprintf(smsg, "All Dead:Off");
        }
     if (bn == 4) sprintf(smsg, "Get New Destination");
     if (bn == 5) sprintf(smsg, "Get New Block Range");
     if (bn == 6) sprintf(smsg, "Set New Direction"); /* rocket direction */
     if (bn == 7) sprintf(smsg, "Edit Message");
     if (bn == 8) /* archwag direction */
        {
           if (Ei[num][2]) sprintf(smsg, "Direction:Right");
           else sprintf(smsg, "Direction:Left");
        }
     if (bn == 9) /* archwag and walker */
        {
           if (Ei[num][8]) sprintf(smsg, "Bounce Mode");
           else sprintf(smsg, "Follow Mode");
        }
     if (bn == 10) sprintf(smsg, "Set New Direction"); /* bouncer direction */
     if (bn == 11) /* trakbot direction */
        {
           if (Ei[num][5] == 0)
               sprintf(smsg, "Direction:Right");
           else if (Ei[num][5] == 4)
               sprintf(smsg, "Direction:Left");
        }
     if (bn == 12) /* trakbot drop mode */
        {
           if (Ei[num][7] == 0)
              sprintf(smsg, "Drop Mode:Off");

           else
              sprintf(smsg, "Drop Mode:On");
        }

   if (bn == 13) sprintf(smsg, "Main Shape");
   if (bn == 14) sprintf(smsg, "Seek Shape");
   if (bn == 15) sprintf(smsg, "Move Extended Position");
   if (bn == 16) sprintf(smsg, "Move Trigger Box");
   if (bn == 17) sprintf(smsg, "Set Source Area");
   if (bn == 18) sprintf(smsg, "Set Destination");

   if (bn == 19) sprintf(smsg, "Move");
   if (bn == 20) sprintf(smsg, "Create");
   if (bn == 21) sprintf(smsg, "Delete");
   if (bn == 22) sprintf(smsg, "Next");
   if (bn == 23) sprintf(smsg, "Previous");
   if (bn == 24) sprintf(smsg, "Copy to Draw Item");
   if (bn == 25) sprintf(smsg, "Help");
   if (bn == 26)
      {
           if (item[num][3] == 0) sprintf(smsg, "Stationary");
           if (item[num][3] == 1) sprintf(smsg, "Fall");
           if (item[num][3] == -1) sprintf(smsg, "Carry");
      }
   if (bn == 27) /* cloner trigger type */
        {
           if (Ei[num][8] == 0)
               sprintf(smsg, "Normal");
           if (Ei[num][8] == 1)
               sprintf(smsg, "Reset on Trigger");
           if (Ei[num][8] == 2)
               sprintf(smsg, "Immediate on Trigger");
        }
   if (bn == 28) sprintf(smsg, "Run Lifts");
   if (bn == 29) sprintf(smsg, "Name:%s", lifts[num] -> lift_name);

   /* erase */
   rectfill(screen, x1, y1, x2, y2, q0);
   /* outline */
   for (c=0; c<d/2+1; c++)
      {
         a = (c*32); /* color increment */
         if (a>224) a = 224;
         b = q1 + a;
         rect(screen, x1+c, y1+c, x2-c, y2-c, b );

      }

   /* draw text */
   text_mode(-1);
   textout_centre(screen ,font, smsg, (x2+x1)/2, (y2+y1)/2-3, q2);
   text_mode(0);

   if (bn == 13)
      {
         extern BITMAP *memory_bitmap[NUM_SPRITES];
         extern int zz[20][NUM_ANS];
         blit (memory_bitmap[zz[0][Ei[num][5]]], screen, 0, 0, (x2+x1)/2+60, (y2+y1)/2-10, 20, 20);
      }
   if (bn == 14)
      {
         extern BITMAP *memory_bitmap[NUM_SPRITES];
         extern int zz[20][NUM_ANS];
         blit (memory_bitmap[zz[0][Ei[num][6]]], screen, 0, 0, (x2+x1)/2+60, (y2+y1)/2-10, 20, 20);
      }



   if ((mouse_x > x1) && (mouse_x < x2))
      if ((mouse_y > y1) && (mouse_y < y2))
         if (mouse_b & 1) /* is mouse pressed on button ? */
            {
                while (mouse_b & 1);
                rits = 1;

                if (bn == 2) /* fall */
                   item[num][3] = !item[num][3];
                if (bn == 3) /* All Dead */
                   item[num][8] = !item[num][8];
                if (bn == 4)
                   if (getxy("Set New Destination", 2, 1, num) == 1)
                      {
                         item[num][6] = get100_x;
                         item[num][7] = get100_y;
                      }
                if (bn == 5) /* Get New Block Range */
                   if (getbox( "Key Block Range") == 1)
                      {
                          if (--bx2 < bx1) bx2++;
                          if (--by2 < by1) by2++;
                          item[num][6] = bx1;
                          item[num][7] = by1;
                          item[num][8] = bx2;
                          item[num][9] = by2;
                          draw_big();
                       }
                 if (bn == 6)
                   if (getxy("Set New Direction", 2, 11, num) == 1)
                      {
                         set_rocket_rot(num, get100_x*20, get100_y*20);
                         draw_big();
                      }

                if (bn == 7) /*  sprintf(smsg, "Edit Message*/
                     create_pmsg(num, 0);

                if (bn == 8) /* initial direction */
                   {
                      Ei[num][2] = !Ei[num][2];

                      if (Ei[num][2])
                         Ef[num][2] = Ef[num][6];
                      else
                         Ef[num][2] = -Ef[num][6];
                      draw_big();

                   }
                if (bn == 9) /* follow/bounce */
                   Ei[num][8] = !Ei[num][8];

                if (bn == 10) /* set new direction */
                   if (getxy("Set New Direction", 3, 4, num) == 1)
                      {
                          extern int get100_x, get100_y;
                          set_xyinc_rot(num, get100_x*20, get100_y*20);
                          draw_big();
                      }
                if (bn == 11) /* trakbot direction */
                   {
                      if (Ei[num][5] == 0)
                         {
                             Ei[num][5] = 4;
                             Ei[num][2] = 0;
                             draw_big();
                             sprintf(smsg, "Direction:Left");
                         }
                      else if (Ei[num][5] == 4)
                         {
                             Ei[num][2] = 1;
                             Ei[num][5] = 0;
                             draw_big();
                             sprintf(smsg, "Direction:Right");
                         }
                   }
               if (bn == 12) /* trakbot drop mode */  Ei[num][7] = !Ei[num][7];
                if (bn == 13) /* main ans */
                   {
                         int main_ans = Ei[num][5];
                         extern int zz[20][NUM_ANS];
                         if (main_ans == 31) main_ans = 14;
                         else
                           {
                              if (main_ans == 29) main_ans = 31;
                              if (main_ans == 14) main_ans = 29;
                           }
                         Ei[num][5] = main_ans;
                         Ei[num][3] = main_ans;
                         Ei[num][1] = zz[5][main_ans];
                     }
                if (bn == 14) /* seek ans */

                   {
                      extern int zz[20][NUM_ANS];
                      int seek_ans = Ei[num][6];
                      if (seek_ans == 31) seek_ans = 14;
                      else
                        {
                           if (seek_ans == 29) seek_ans = 31;
                           if (seek_ans == 14) seek_ans = 29;
                        }
                      Ei[num][6] = seek_ans;
                   }
                if (bn == 15) move_pod_extended(num);
                if (bn == 16) move_trigger_box(num);

                if (bn == 17)
                   if (getbox("Cloner Source Area"))
                      {
                          Ef[num][6] = bx1*20;
                          Ef[num][7] = by1*20;
                          Ef[num][2] = (bx2-bx1)*20;
                          Ef[num][3] = (by2-by1)*20;
                          draw_big();
                      }
                if (bn == 18)
                    if (getxy("Set Cloner Destination", 3, 9, num) == 1)
                       {
                          Ef[num][8] = get100_x*20;
                          Ef[num][9] = get100_y*20;
                          draw_big();
                       }
              if (bn == 19)   return 1;
              if (bn == 20)   return 1;
              if (bn == 21)   return 1;
              if (bn == 22)   return 1;
              if (bn == 23)   return 1;
              if (bn == 24)   return 1;
              if (bn == 25)   return 1;
              if (bn == 26)
                 {
                      item[num][3]++;
                      if (item[num][3] > 1) item[num][3] = -1;
                 }
              if (bn == 27)
                 {
                      Ei[num][8]++;
                      if (Ei[num][8] > 2) Ei[num][8] = 0;
                 }
              if (bn == 28)   return 1;
              if (bn == 29)   return 1;



            } /* end of mouse pressed on button */
   return 0;
}
int edit_int_slider(int x1, int y1, int x2, int y2, int bn, int num,
                 int type, int obt, int q0, int q1, int q2, int q3, int q4, int q5, int q6, int q7 )
{
   float sdx, sul, sll, sinc;
   float dsx, old_pos;
   int cc, dd = y2-y1;
   int ret = 0; /* default - nothing happened */
   switch (bn)
      {
         case 1:  sul=100;  sll=2;  sinc=1; sdx=item[num][7]; break; /* health bonus */
         case 2:  sul=200;  sll=2;  sinc=1; sdx=item[num][8]; break; /* bullet bonus*/
         case 3:  sul=400;  sll=5;  sinc=1; sdx=item[num][9]; break; /* timer bonus */
         case 4:  sul=400;  sll=20; sinc=1; sdx=item[num][7]; break; /* blast size */
         case 5:  sul=100;  sll=1;  sinc=1; sdx=item[num][9]; break; /* fuse length */
         case 6:  sul=200;  sll=1;  sinc=1; sdx=item[num][9]; break; /* accel */
         case 7:  sul=20;   sll=1;  sinc=1; sdx=item[num][8]; break; /* max speed */
         case 8:  sul=50;   sll=1;  sinc=1; sdx=item[num][6]; break; /* steerabaility */
         case 9:  sul=7;    sll=1;  sinc=1; sdx=item[num][6]; break; /* jump length */
         case 10: sul=40;   sll=3;  sinc=1; sdx=item[num][7]; break; /* speed */
         case 11: sul=20;   sll=1;  sinc=1; sdx=item[num][8]; break; /* mine damage */
      
         case 12: sul=9;  sll=.7; sinc=100; sdx=Ef[num][6]; break;  /* x speed */
         case 13: sul=9;  sll=.7; sinc=100; sdx=Ef[num][3]; break;  /* y speed */

         case 15: sul=500;  sll=0;  sinc=1; sdx=Ei[num][6]; break;   /* jump wait count */
         case 16: sul=600;  sll=0;  sinc=1; sdx=Ei[num][7]; break;   /* jump under width */
         case 17: sul=100;  sll=0;  sinc=1; sdx=Ei[num][12]; break;  /* Jump b4 wall */
         case 18: sul=40;   sll=0;  sinc=1; sdx=Ei[num][11]; break;  /* Jump b4 hole */
      
         case 19: sul=20;   sll=.8; sinc=10; sdx=Ef[num][7]; break;  /* bullet speed */
         case 20: sul=600;  sll=20; sinc=1; sdx=Ei[num][17]; break;  /* bullet prox */
         case 21: sul=200;  sll=1;  sinc=1; sdx=Ei[num][15]; break;  /* retrigger time */

         case 22: sul=12; sll=0; sinc=100;  sdx=Ef[num][5]; break;  /* cannon speed */
         case 23: sul=200; sll=0;  sinc=1;  sdx=Ei[num][8]; break;  /* seek count */

         case 24: sul=20;   sll=0;   sinc=1;   sdx=Ei[num][29];   break;  /* collision box  */
         case 25: sul=10;   sll=0;   sinc=100; sdx=Ef[num][4];   break;  /* life dec */
         case 26: sul=40;   sll=10;  sinc=1;   sdx=bts;          break;  /* button height */
         case 27: sul=800;  sll=10;  sinc=1;   sdx=item[num][8]; break;  /* initial time */
         case 28: sul=100;  sll=1;   sinc=1;   sdx=item[num][8]; break;  /* warp level */
         case 29: sul=30;   sll=.5;  sinc=10;  sdx=Ef[num][9];   break;  /* pod speed */
         case 30: sul=40;   sll=0;   sinc=1;   sdx=Ei[num][9];   break;  /* pod wait time */
         case 33: sul=5;    sll=.7;  sinc=100; sdx=Ef[num][2];   break;  /* trakbot x speed */
         case 34: sul=1000; sll=20;  sinc=1;   sdx=Ei[num][6];   break;  /* create delay */
         case 35: sul=8;    sll=0;   sinc=1;   sdx=Ei[num][28];  break;  /* cannon hits */
         case 36: sul=3;    sll=0;   sinc=100; sdx=Ef[num][3];   break;  /* cannon hits */
         case 38: sul=500;  sll=20;  sinc=1;   sdx=Ei[num][17];  break;  /* width */
         case 39: sul=200;  sll=1;   sinc=1;   sdx=Ei[num][18];  break;  /* y1 */
         case 40: sul=200;  sll=1;   sinc=1;   sdx=Ei[num][19];  break;  /* y2 */
         case 41: sul=50;   sll=0;   sinc=1;   sdx=Ei[num][24];  break;  /* dead enemy bullet bonus  */
         case 42: sul=50;   sll=0;   sinc=1;   sdx=Ei[num][25];  break;  /* dead enemy health bonus  */

         case 43: sul=99;   sll=1;   sinc=1;   sdx=lifts[num] -> width;  break;  /* lift width */
         case 44: sul=99;   sll=1;   sinc=1;   sdx=lifts[num] -> height;  break;  /* lift heigth */

         case 45: sul=4;  sll=.5; sinc=100; sdx=Ef[num][2]; break;  /* trakbot x speed */
         case 46: sul=4;  sll=.5; sinc=100; sdx=Ef[num][3]; break;  /* trakbot y speed */

         }

   fill_smsg(bn, num);

   /* erase */
   rectfill(screen, x1, y1, x2, y2, q0);

   /* outline */
   for (cc=0; cc<dd/2+1; cc++)
      {
         int aa;
         aa = (cc*32); /* color increment */
         if (aa>224) aa = 224;
         aa = q1 + 224 - aa;
         rect(screen, x1+cc, y1+cc, x2-cc, y2-cc, aa );
      }

   dsx = draw_slider(sdx, sul, sll, x1+bw+1, y1, x2-bw-1, y2, 1, q3);

   /* draw text */
   text_mode(-1);
   textout_centre(screen ,font, smsg, (x2+x1)/2, (y2+y1)/2-3, q2);
   text_mode(0);

   /* is mouse on bar */
   if ((mouse_x > dsx-bw) && (mouse_x < dsx+bw))
      if ((mouse_y > y1) && (mouse_y < y2))
         {
            dsx = draw_slider(sdx, sul, sll, x1+bw+1, y1, x2-bw-1, y2, 2, q3); /* draw slider over text */

            if (mouse_b & 1)
               {
                  while (mouse_b & 1)
                     {
                          float my = mouse_y;
                          float mx = mouse_x;
                          float a, b, c, d, e, f;
                          int g, h;

                         /* enforce limits */
                          if (my<y1) my = y1;
                          if (mx<x1) mx = x1;
                          if (my>y2) my = y2;
                          if (mx>x2) mx = x2;
   
                         /* deconvert */
                          /* get slider position */
                          a = mx-x1; /* relative postion */
                          b = x2-x1; /* range */
                          c = a/b; /* ratio */
   
                          d = sul-sll; /* new range */
                          e = d * c;
                          f = e + sll;

                          g = sinc; /* rounder */
                          h = f * g;
                          f = (float)h / (float)g;

                          update_var(bn, num, f);

                         if (old_pos != f)
                             {
                                rectfill(screen, x1, y1, x2, y2, q0);
                                ret = 1; /* f changed  */
                                for (cc=0; cc<dd/2+1; cc++)
                                   {
                                      int aa;
                                      aa = (cc*32); /* color increment */
                                      if (aa>224) aa = 224;
                                      aa = q1 + 224 - aa;
                                      rect(screen, x1+cc, y1+cc, x2-cc, y2-cc, aa );
                             
                                   }
                             
                                draw_slider(f, sul, sll, x1+bw+1, y1, x2-bw-1, y2, 1, q3);
                             
                                /* draw text */
                                fill_smsg(bn, num);
                                text_mode(-1);
                                textout_centre(screen ,font, smsg, (x2+x1)/2, (y2+y1)/2-3, q2);
                                text_mode(0);

                                show_mouse(screen);
                                rest(10);
                                show_mouse(NULL);
                                old_pos = f;
                             }
                     }
   
                }
         }
   return ret;
}
