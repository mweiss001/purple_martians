/*  sel.c   selection crap  */
#include "pm.h"
#include "lift.h"

extern int num_lifts;
extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

extern int copy_blocks;
extern int copy_enemies;
extern int copy_items;
extern int copy_lifts;

extern int l[100][100];
extern int item[500][16];
extern char *pmsg[500];
extern int Ei[100][32];
extern float Ef[100][16];

extern int ft_level_header[20];
extern int ft_l[100][100];
extern int ft_item[500][16];
extern char *ft_pmsg[500];

extern int ft_Ei[100][32];
extern float ft_Ef[100][16];
extern char ft_ln[20][80];
extern int ft_lift[20][4];
extern int ft_ls[20][20][4];

int load_selection(void)
{
   FILE *filepntr;
   extern char sel_filename[80];
   int temp_item[16];
   int temp_Ei[32];
   float temp_Ef[16];

   extern int level_num;
   extern int stx, sty;

   int dx = stx;
   int dy = sty;

   int loop, ch, c, d, x, y;
   int vx, vy;

   int lim=0;
   char buff[2000];
   char msg[80];

   sprintf(sel_filename,"default.sel");

   if (file_select("Load Selection", sel_filename, "SEL"))
      {
         text_mode(0);

         /* erase temp variables */
         for (c=0; c<500; c++) /* items */
            {
               free (pmsg[c]);
               for (x=0; x<16; x++)
                  ft_item[c][x]=0;
            }
         for (x=0; x<100; x++) /* blocks */
            for (y=0; y<100; y++)
               ft_l[x][y] = 0;
         for (c=0; c<100; c++)  /* enemys */
            {
               for (x=0; x<32; x++)
                  ft_Ei[c][x] = 0;
               for (x=0; x<16; x++)
                  ft_Ef[c][x] = 0;
            }
         if (exists(sel_filename)==NULL)
            {
               sprintf(msg, "Can't Find %s ", sel_filename);
               textout_centre(screen, font, msg, SCREEN_W/2, 160, 10);
               rest(5000);
               return 0;
            }
         if ((filepntr=fopen(sel_filename,"r")) == NULL)
            {
               sprintf(msg, "Error opening %s ", sel_filename);
               textout(screen, font, msg, 0, 160, 10);
               rest(5000);
               return 0;
            }
         for (c=0; c<20; c++) /* level header */
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                     buff[loop] = ch;
                     loop++;
                     ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               ft_level_header[c] = atoi(buff);
            }

         for (c=0; c<ft_level_header[8]; c++)  /* l[100][100] */
            for (y=0; y<ft_level_header[9]; y++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                         buff[loop] = ch;
                         loop++;
                         ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  ft_l[c][y] = atoi(buff);
               }
         for (c=0; c<ft_level_header[3]; c++)  /* read item */
            {
               for (x = 0; x < 16; x++)
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                            buff[loop] = ch;
                            loop++;
                            ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     ft_item[c][x] = atoi(buff);
                  }
               if (ft_item[c][0] == 10) /* get pmsg */
                 {
                    loop = 0;
                    ch = fgetc(filepntr);
                    while((ch != '\n') && (ch != EOF))
                       {
                           if (ch == 126) ch = 13;
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                       }
                    buff[loop] = NULL;
                    ft_pmsg[c] = (char*) malloc (strlen(buff)+1);
                    strcpy(ft_pmsg[c], buff);
                 }
            }
         for (c=0; c < ft_level_header[4]; c++)  /* enemy ints and floats */
            {
               for (x=0; x<32; x++)  /* first 32 ints */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                            buff[loop] = ch;
                            loop++;
                            ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     ft_Ei[c][x] = atoi(buff);
                  }
               for (x=0; x<16; x++)  /* then 16 floats */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     ft_Ef[c][x] = atof(buff);
                  }
            }
         for (c=0; c<ft_level_header[5]; c++) /* lifts */
            {
               /* get lift name */
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                      buff[loop] = ch;
                      loop++;
                      ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               strcpy(ft_ln[c], buff);

               /* get lift data   four ints */
               for (y=0; y<4; y++)
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                            buff[loop] = ch;
                            loop++;
                            ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     ft_lift[c][y] = atoi(buff);
                  }
               for (x=0; x<ft_lift[c][3]; x++) /* get step data */
                  for (y=0; y<4; y++)
                     {
                        loop = 0;
                        ch = fgetc(filepntr);
                        while((ch != '\n') && (ch != EOF))
                           {
                               buff[loop] = ch;
                               loop++;
                               ch = fgetc(filepntr);
                           }
                        buff[loop] = NULL;
                        ft_ls[c][x][y] = atoi(buff);
                     }
            } /* next lift */
         fclose(filepntr);
      } /* end of file select */
   else return 0; /* cancel pressed */
   return 1;
}
int save_selection(void)
{
   FILE *filepntr;
   char buff[20];
   extern int stx, sty, sux, suy;
   int b, c, d, x, y;
   int eib=0;
   int iib=0;
   int lib=0;
   int x1 = stx * 20;    /* source x */
   int y1 = sty * 20;    /* source y */
   int x2 = sux * 20;    /* sizes */
   int y2 = suy * 20;
   extern char sel_filename[80];

   if (copy_blocks)
      for (x=0; x<(sux-stx); x++)
         for (y=0; y<(suy-sty); y++)
            if ( (x >= 0) && (x < 100) && (y >= 0) && (y < 100) && (stx+x >= 0) && (stx+x < 100) && (sty+y >= 0) && (sty+y < 100) )
               ft_l[x][y] = l[stx+x][sty+y];

   if (copy_items)
      for (b=0; b<500; b++) /* check for items in box */
         if ((item[b][0]) && (item[b][4] >= x1) && (item[b][4] < x2) && (item[b][5] >= y1) && (item[b][5] < y2))
            {
               int lim = 0;
               int vx, vy;
               /* copy all 16 variables */
               c = iib++;
               for (y=0; y<16; y++)
                   ft_item[c][y] = item[b][y];

               /* set new x, y, */
               vx = item[b][4] - x1;
               vy = item[b][5] - y1;
               if ((vx<0) || (vx > 2000)) lim = 1;
               if ((vy<0) || (vy > 2000)) lim = 1;
               ft_item[c][4] = vx;
               ft_item[c][5] = vy;

               if (item[b][0] == 1) /* door */
                  {   /* set new destination */
                     vx = ((item[b][6]*20) - x1)/20;
                     vy = ((item[b][7]*20) - y1)/20;
                     if ((vx<0) || (vx > 99)) lim = 1;
                     if ((vy<0) || (vy > 99)) lim = 1;
                     ft_item[c][6] = vx;
                     ft_item[c][7] = vy;
                  }
               if (item[b][0] == 4) /* key */
                  {   /* set new destination */
                     vx = ((item[b][6]*20) - x1)/20;
                     vy = ((item[b][7]*20) - y1)/20;
                     if ((vx<0) || (vx > 99)) lim = 1;
                     if ((vy<0) || (vy > 99)) lim = 1;
                     ft_item[c][6] = vx;
                     ft_item[c][7] = vy;

                     vx = ((item[b][8]*20) - x1)/20;
                     vy = ((item[b][9]*20) - y1)/20;
                     if ((vx<0) || (vx > 99)) lim = 1;
                     if ((vy<0) || (vy > 99)) lim = 1;
                     ft_item[c][8] = vx;
                     ft_item[c][9] = vy;
                  }
               if (item[b][0] == 10) /* message */
                  {
                     free (ft_pmsg[c]);
                     ft_pmsg[c] = (char*) malloc (strlen(pmsg[b])+1);
                     strcpy(ft_pmsg[c], pmsg[b]);
                  }
               if (lim)  /* erase limits exceeded */
                  {
                     iib--;
                     for (y=0; y<16; y++)
                        ft_item[c][y] = 0;
                  }
            }
   if (copy_enemies)
      for (b=0; b<100; b++) /* check for enemies in box */
         if ((Ei[b][0]) && (Ef[b][0] > x1) && (Ef[b][0] < x2) && (Ef[b][1] > y1) && (Ef[b][1] < y2))
            {
               int lim = 0;
               int vx, vy;
               c = eib++;
               for (y=0; y<32; y++)
                  ft_Ei[c][y] = Ei[b][y];
               for (y=0; y<16; y++)
                  ft_Ef[c][y] = Ef[b][y];

               vx = ft_Ef[c][0]-= x1;
               vy = ft_Ef[c][1]-= y1;
               if ((vx<0) || (vx > 2000)) lim = 1;
               if ((vy<0) || (vy > 2000)) lim = 1;

               if (ft_Ei[c][0] == 7 ) /* podzilla */
                  {
                     ft_Ei[c][11]-= x1/20;
                     ft_Ei[c][12]-= y1/20;
                     ft_Ei[c][13]-= x1/20;
                     ft_Ei[c][14]-= y1/20;
                  }
               if (ft_Ei[c][0] == 9 ) /* cloner */
                  {
                     ft_Ef[c][6]-= x1;
                     ft_Ef[c][7]-= y1;
                     ft_Ef[c][8]-= x1;
                     ft_Ef[c][9]-= y1;
                  }
               if (lim)
                  {
                     eib--;
                     for (y=0; y<32; y++)
                        ft_Ei[c][y] = 0;
                     for (y=0; y<16; y++)
                        ft_Ef[c][y] = 0;
                  }
            }

   if (copy_lifts)
      for (b=0; b<num_lifts; b++) /* source, if in selection */
         if ((lifts[b]->x1 > x1) && (lifts[b]->x1 < x2) && (lifts[b]->y1 > y1) && (lifts[b]->y1 < y2))
            {
               int lim = 0;
               int vx, vy;
               c = lib++; /* destination */

               strcpy(ft_ln[c], lifts[b]->lift_name);

               ft_lift[c][0] = lifts[b]->width;
               ft_lift[c][1] = lifts[b]->height;
               ft_lift[c][2] = lifts[b]->color;
               ft_lift[c][3] = lifts[b]->num_steps;

               for (y=0; y<lifts[c]->num_steps; y++) /* copy steps */
                  {
                     if (lift_steps[b][y] -> type == 1) /* shift move steps */
                        {
                           vx = lift_steps[b][y]-> x - x1;
                           vy = lift_steps[b][y]-> y - y1;
                           if ((vx<0) || (vx > 2000)) lim = 1;
                           if ((vy<0) || (vy > 2000)) lim = 1;
                        }
                     else vx = vy = 0;

                     ft_ls[c][y][0] = vx;
                     ft_ls[c][y][1] = vy;
                     ft_ls[c][y][2] = lift_steps[b][y] -> val;
                     ft_ls[c][y][3] = lift_steps[b][y] -> type;
                  }
               if (lim) lib--; /* erase ft_lift  */
            }

   ft_level_header[3] = iib; /* num_of_items    */
   ft_level_header[4] = eib; /* num_of_enemies  */
   ft_level_header[5] = lib; /* num_of_lifts   */

   ft_level_header[8] =  sux-stx; /* width */
   ft_level_header[9] =  suy-sty; /* height */

   c = 0;
   d = 0;
   while (!d)
      {
         sprintf(sel_filename, "sel%d.sel", c);
         if (!exists(sel_filename))
            d = 1; /* to quit */

         else c++;
         if (c > 20) d = 1;
      }

   if (file_select("Save Selection", sel_filename, "SEL"))
      {   /* only if good exit */
         text_mode(0);
         filepntr = fopen(sel_filename,"w");
         for (x=0; x<20; x++)
            fprintf(filepntr,"%d\n",ft_level_header[x]);
         for (c=0; c<(sux-stx); c++)  /* selection of blocks */
            for (x=0; x<(suy-sty); x++)
                 fprintf(filepntr,"%d\n",ft_l[c][x]);
         for (c=0; c < ft_level_header[3]; c++) /* items */
            {
               for (x=0; x<16; x++)
                  fprintf(filepntr,"%d\n",ft_item[c][x]);

               if (ft_item[c][0] == 10) /* pmsg */
                  {
                     y = 0;
                     while (ft_pmsg[c][y] != NULL)
                        {
                           if (ft_pmsg[c][y] == 13)
                              fprintf(filepntr,"%c",126);
                           else
                              fprintf(filepntr,"%c",ft_pmsg[c][y]);
                           y++ ;
                        }
                     fprintf(filepntr,"\n");
                  }
            }
         for (c=0; c < ft_level_header[4]; c++) /* enemy int and float*/
            {
               for (x=0; x<32; x++)
                  fprintf(filepntr,"%d\n",ft_Ei[c][x]);
               for (x=0; x<16; x++)
                  fprintf(filepntr,"%f\n",ft_Ef[c][x]);
            }
         for (c=0; c < ft_level_header[5]; c++) /* lifts */
            {
               fprintf(filepntr,"%s\n",ft_ln[c]);
               for (x=0; x<4; x++)
                  fprintf(filepntr,"%d\n",ft_lift[c][x]);
               for (x=0; x<ft_lift[c][3]; x++)
                  for (y=0; y<4; y++)
                     fprintf(filepntr,"%d\n",ft_ls[c][x][y]);
            }
         fclose(filepntr);
      }
}
void do_copy(int qx1, int qy1)
{
   extern int stx, sty, sux, suy;
   int b, c, d, x, y;

   int x5=sux-stx;
   int y5=suy-sty;

   int x1 = stx *20;    /* source x */
   int y1 = sty *20;    /* source y */
   int x2 = sux *20;    /* sizes */
   int y2 = suy *20;

   int x3 = qx1*20;         /* dest x */
   int y3 = qy1*20;         /* dest y */
   int x4 = (qx1+x5)*20;    /* sizes */
   int y4 = (qy1+y5)*20;

   if (copy_blocks)
      for (x=0; x<x5; x++)
         for (y=0; y<y5; y++)
            if ( (qx1+x >= 0) && (qx1+x < 100) )
               if ( (qy1+y >= 0) && (qy1+y < 100) )
                  if ( (stx+x >= 0) && (stx+x < 100) )
                     if ( (sty+y >= 0) && (sty+y < 100) )
                        l[qx1+x][qy1+y] = l[stx+x][sty+y];

   if (copy_lifts)
      for (b=0; b<num_lifts; b++) /* source, if in selection */
         if ((lifts[b]->x1 > x1) && (lifts[b]->x1 < x2) && (lifts[b]->y1 > y1) && (lifts[b]->y1 < y2))
            if (num_lifts < 19)   /* while still empty lifts left */
               {
                  int lim = 0;
                  int vx, vy;
                  c = num_lifts++; /* dest lift */
                  construct_lift(c, lifts[b]->lift_name, lifts[b]->width, lifts[b]->height, lifts[b]->color, lifts[b]->num_steps);
                  for (y=0; y<lifts[b]->num_steps; y++) /* copy steps */
                     {
                        if (lift_steps[b][y] -> type == 1) /* shift  move steps */
                           {
                              vx = lift_steps[b][y]->x + x3-x1;
                              vy = lift_steps[b][y]->y + y3-y1;
                              if ((vx<0) || (vx > 2000)) lim = 1;
                              if ((vy<0) || (vy > 2000)) lim = 1;
                           }
                        else vx = vy = 0;
                        construct_lift_step(c, y, vx, vy, lift_steps[b][y]->val, lift_steps[b][y]->type);
                     }
                  set_lift_initial_not_in_file(c);
                  if (lim) erase_lift(c);
               }
   if (copy_enemies)
      for (b=0; b<100; b++) /* check for enemies in box */
         if ((Ei[b][0]) && (Ef[b][0] > x1) && (Ef[b][0] < x2) && (Ef[b][1] > y1) && (Ef[b][1] < y2))
            for (c=0; c<100; c++)
               if (Ei[c][0] == 0)  /* find empty  (c) */
                  {
                     int lim = 0;
                     int vx, vy;
                     /* copy all */
                     for (y=0; y<32; y++)
                        Ei[c][y] = Ei[b][y];
                     for (y=0; y<16; y++)
                        Ef[c][y] = Ef[b][y];
                     /* move location */
                     vx = Ef[b][0] + x3-x1;
                     vy = Ef[b][1] + y3-y1;
                     if ((vx<0) || (vx > 2000)) lim = 1;
                     if ((vy<0) || (vy > 2000)) lim = 1;
                     Ef[c][0]= vx;
                     Ef[c][1]= vy;

                     if (Ei[c][0] == 7 ) /* podzilla trigger box */
                        {
                           Ei[c][11]+= (x3-x1)/20;
                           Ei[c][12]+= (y3-y1)/20;
                           Ei[c][13]+= (x3-x1)/20;
                           Ei[c][14]+= (y3-y1)/20;
                        }
                     if (Ei[b][0] == 9 ) /* cloner */
                        {
                           Ef[c][6]+= x3-x1;
                           Ef[c][7]+= y3-y1;
                           Ef[c][8]+= x3-x1;
                           Ef[c][9]+= y3-y1;
                        }
                     if (lim)
                        for (y=0; y<10; y++)
                           {
                              Ei[c][y] = 0;
                              Ef[c][y] = 0;
                           }
                     c = 100; /* end inner loop */
                  }
               sort_enemy();

   if (copy_items)
      {
         for (b=0; b<500; b++) /* check for items in box */
            if (item[b][0])     /* if active */
               if (item[b][4] >= x1)
                  if (item[b][4] < x2)
                     if (item[b][5] >= y1)
                        if (item[b][5] < y2)
                           {
                              /* copy to dest box */
                              /* find empty */
                              for (c=0; c<500; c++)
                                 if (item[c][0] == 0)
                                    {
                                       int lim = 0;
                                       int vx, vy;
                                       /* copy all 16 variables */
                                       for (y=0; y<16; y++)
                                             item[c][y] = item[b][y];

                                       /* set new x, y, */
                                       vx = item[b][4] + x3-x1;
                                       vy = item[b][5] + y3-y1;
                                       if ((vx<0) || (vx > 2000)) lim = 1;
                                       if ((vy<0) || (vy > 2000)) lim = 1;
                                       item[c][4] = vx;
                                       item[c][5] = vy;

                                       if (item[b][0] == 1) /* door */
                                          {   /* set new destination */
                                             vx = ((item[b][6]*20) + x3-x1)/20;
                                             vy = ((item[b][7]*20) + y3-y1)/20;
                                             if ((vx<0) || (vx > 99)) lim = 1;
                                             if ((vy<0) || (vy > 99)) lim = 1;
                                             item[c][6] = vx;
                                             item[c][7] = vy;
                                          }
                                       if (item[b][0] == 4) /* key */
                                          {   /* set new destination */
                                             vx = ((item[b][6]*20) + x3-x1)/20;
                                             vy = ((item[b][7]*20) + y3-y1)/20;
                                             if ((vx<0) || (vx > 99)) lim = 1;
                                             if ((vy<0) || (vy > 99)) lim = 1;
                                             item[c][6] = vx;
                                             item[c][7] = vy;

                                             vx = ((item[b][8]*20) + x3-x1)/20;
                                             vy = ((item[b][9]*20) + y3-y1)/20;
                                             if ((vx<0) || (vx > 99)) lim = 1;
                                             if ((vy<0) || (vy > 99)) lim = 1;
                                             item[c][8] = vx;
                                             item[c][9] = vy;
                                          }

                                      if (item[b][0] == 10) /* msg) */
                                         {
                                            free (pmsg[c]);
                                            pmsg[c] = (char*) malloc (strlen(pmsg[b])+1);
                                            strcpy(pmsg[c], pmsg[b]);
                                         }

                                       if (lim)  /* erase limits exceeded */
                                          for (y=0; y<16; y++)
                                             item[c][y] = 0;

                                       c = 500; /* end loop */
                                    }
                           }
         item_sort();
      }
   draw_big();
}
void do_fcopy(int qx1, int qy1)
{
   extern int stx, sty, sux, suy;
   int b, c, d, x, y;

   int x5 = ft_level_header[8];
   int y5 = ft_level_header[9];

   int x1 = stx *20;    /* source x */
   int y1 = sty *20;    /* source y */
   int x2 = sux *20;    /* sizes */
   int y2 = suy *20;

   int x3 = qx1*20;         /* dest x */
   int y3 = qy1*20;         /* dest y */
   int x4 = (qx1+x5)*20;    /* sizes */
   int y4 = (qy1+y5)*20;

   if (copy_blocks)
      for (x=0; x<x5; x++)
         for (y=0; y<y5; y++)
            if ( (qx1+x >= 0) && (qx1+x < 100) )
               if ( (qy1+y >= 0) && (qy1+y < 100) )
                  l[qx1+x][qy1+y] = ft_l[x][y];

   if (copy_lifts)
      for (b=0; b<ft_level_header[5]; b++)
         if (num_lifts < 19)
            {
               int vx, vy, lim = 0;
               c = num_lifts++; /* dest lift */
               construct_lift(c, ft_ln[b], ft_lift[b][0], ft_lift[b][1], ft_lift[b][2], ft_lift[b][3]);
               for (y=0; y<ft_lift[b][3]; y++) /* copy steps */
                  {
                     if (ft_ls[b][y][3] == 1) /* shift  move steps */
                        {
                           vx = ft_ls[b][y][0] + x3;
                           vy = ft_ls[b][y][1] + y3;
                           if ((vx<0) || (vx > 2000)) lim = 1;
                           if ((vy<0) || (vy > 2000)) lim = 1;
                        }
                     else vx = vy = 0;
                     construct_lift_step(c, y, vx, vy, ft_ls[b][y][2], ft_ls[b][y][3]);
                  }
               set_lift_initial_not_in_file(c);
               if (lim) erase_lift(c);
            }

   if (copy_enemies)
      for (b=0; b<100; b++)
         if (ft_Ei[b][0])
            for (c=0; c<100; c++)
               if (Ei[c][0] == 0) /* find empty */
                  {
                     int lim = 0;
                     int vx, vy;

                     for (y=0; y<32; y++)        /* copy 32 ints */
                        Ei[c][y] = ft_Ei[b][y];
                     for (y=0; y<16; y++)        /* copy 16 floats */
                        Ef[c][y] = ft_Ef[b][y];

                     vx = Ef[c][0]+= x3;  /* shift x and y for all */
                     vy = Ef[c][1]+= y3;
                     if ((vx<0) || (vx > 2000)) lim = 1;
                     if ((vy<0) || (vy > 2000)) lim = 1;


                     if (Ei[c][0] == 7 ) /* podzilla trigger box */
                        {
                           Ei[c][11]+= x3/20;
                           Ei[c][12]+= y3/20;
                           Ei[c][13]+= x3/20;
                           Ei[c][14]+= y3/20;
                        }
                     if (Ei[c][0] == 9 ) /* cloner */
                        {
                           Ef[c][6]+=x3;
                           Ef[c][7]+=y3;
                           Ef[c][8]+=x3;
                           Ef[c][9]+=y3;
                        }
                     if (lim)
                        {
                           for (y=0; y<32; y++)
                              Ei[c][y] = 0;
                           for (y=0; y<16; y++)
                              Ef[c][y] = 0;
                        }
                     c = 100; /* end loop */
                  }

   if (copy_items)
      for (b=0; b<500; b++) /* check for items in box */
         if (ft_item[b][0])     /* if active */
            for (c=0; c<500; c++)
               if (item[c][0] == 0)
                  {
                     int lim = 0;
                     int vx, vy;
                     /* copy all 16 variables */
                     for (y=0; y<16; y++)
                           item[c][y] = ft_item[b][y];

                     /* set new x, y, */
                     vx = item[c][4] + x3;
                     vy = item[c][5] + y3;
                     if ((vx<0) || (vx > 2000)) lim = 1;
                     if ((vy<0) || (vy > 2000)) lim = 1;
                     item[c][4] = vx;
                     item[c][5] = vy;

                     if (item[c][0] == 1) /* door */
                        {   /* set new destination */
                           vx = ((item[c][6]*20) + x3)/20;
                           vy = ((item[c][7]*20) + y3)/20;
                           if ((vx<0) || (vx > 99)) lim = 1;
                           if ((vy<0) || (vy > 99)) lim = 1;
                           item[c][6] = vx;
                           item[c][7] = vy;
                        }
                     if (item[c][0] == 4) /* key */
                        {   /* set new destination */
                           vx = ((item[c][6]*20) + x3)/20;
                           vy = ((item[c][7]*20) + y3)/20;
                           if ((vx<0) || (vx > 99)) lim = 1;
                           if ((vy<0) || (vy > 99)) lim = 1;
                           item[c][6] = vx;
                           item[c][7] = vy;

                           vx = ((item[c][8]*20) + x3)/20;
                           vy = ((item[c][9]*20) + y3)/20;
                           if ((vx<0) || (vx > 99)) lim = 1;
                           if ((vy<0) || (vy > 99)) lim = 1;
                           item[c][8] = vx;
                           item[c][9] = vy;
                        }
                     if (item[c][0] == 10) /* message */
                        {
                           free (pmsg[c]);
                           pmsg[c] = (char*) malloc (strlen(ft_pmsg[b])+1);
                           strcpy(pmsg[c], ft_pmsg[b]);
                        }
                     if (lim)  /* erase limits exceeded */
                        for (y=0; y<16; y++)
                           item[c][y] = 0;
                     c = 500; /* end loop */
                  }
   sort_enemy();
   item_sort();
   draw_big();
}
void do_clear(void)
{
   extern int stx, sty, sux, suy;
   int b, c, x, y;

   int x5=sux-stx;
   int y5=suy-sty;
   
   int x1 = stx *20;    /* source x */
   int y1 = sty *20;    /* source y */
   int x2 = sux *20;    /* sizes */
   int y2 = suy *20;

   if (copy_blocks) /* erase */
      for (x=0; x<x5; x++)
         for (y=0; y<y5; y++)
            if ( (stx+x >= 0) && (stx+x < 100) )
               if ( (sty+y >= 0) && (sty+y < 100) )
                  l[stx+x][sty+y]=0;

   if (copy_lifts)
      for (b=0; b<num_lifts; b++)
         if (lifts[b]->x1 > x1)
            if (lifts[b]->x1 < x2)
               if (lifts[b]->y1 > y1)
                  if (lifts[b]->y1 < y2)
                     erase_lift(b);

  if (copy_enemies)  /* erase */
      {
         for (b=0; b<100; b++) /* check for enemies in box */
            if (Ei[b][0])     /* if active */
               if (Ef[b][0] > x1)
                  if (Ef[b][0] < x2)
                     if (Ef[b][1] > y1)
                        if (Ef[b][1] < y2)
                           {
                              for (y=0; y<32; y++)
                                 Ei[b][y] = 0;
                              for (y=0; y<16; y++)
                                 Ef[b][y] = 0;
                           }


         sort_enemy();
      }
   if (copy_items)  /* erase */
      {
         for (b=0; b<500; b++) /* check for items in box */
            if (item[b][0])     /* if active */
               if (item[b][4] > x1)
                  if (item[b][4] < x2)
                     if (item[b][5] > y1)
                        if (item[b][5] < y2) erase_item(b);
         item_sort();
      }
   draw_big();
}

void draw_fsel(void)
{
   extern BITMAP *memory_bitmap[NUM_SPRITES];
   extern int zz[20][NUM_ANS];
   extern BITMAP *ft_bmp;

   int db = (SCREEN_H/100);

   int ft_w = ft_level_header[8]*db;
   int ft_h = ft_level_header[9]*db;
   int t_w = ft_level_header[8]*20;
   int t_h = ft_level_header[9]*20;

   BITMAP *temp;
   int a,d,x,y;
   char msg[80];

   temp = create_bitmap(t_w, t_h);
   ft_bmp = create_bitmap( ft_w, ft_h);
   clear(ft_bmp);
   
   for (x=0; x<ft_level_header[8]; x++)
      for (y=0; y<ft_level_header[9]; y++)
         if (ft_l[x][y] < NUM_SPRITES)
            blit(memory_bitmap[ft_l[x][y]], temp, 0, 0, x*20, y*20, 20, 20);
   
   for (x=0; x<100; x++)
      if (ft_Ei[x][0])
         {
            int a, b;
            int ex = ft_Ef[x][0];
            int ey = ft_Ef[x][1];
   
            a = ft_Ei[x][1]; /* bmp or ans */
            if (a < NUM_SPRITES) b = a; /* bmp */
            if (a > 999) b = zz[5][a-1000]; /* ans */
            blit(memory_bitmap[b], temp, 0, 0, ex, ey, 20, 20);
         }
   for (x=0; x<500; x++)
      if (ft_item[x][0])
         {
            int a, b;
            int ex = ft_item[x][4];
            int ey = ft_item[x][5];
            b = ft_item[x][1]; /* bmp or ans */
            if (b > 1000) b = zz[0][b-1000]; /* ans */
            blit (memory_bitmap[b], temp, 0, 0, ex, ey, 20, 20);
         }
   for (d=0; d<ft_level_header[5]; d++)
        {
           int color = ft_lift[d][2];
           int x1 = ft_ls[d][0][0];
           int y1 = ft_ls[d][0][1];
           int x2 = ft_ls[d][0][0] + (ft_lift[d][0] * 20)-1;
           int y2 = ft_ls[d][0][1] + (ft_lift[d][1] * 20)-1;
   
           int tx = ((x1+x2)/2) ;
           int ty = ((y1+y2)/2) -2;



           for (a=0; a<10; a++)
              rect(temp, x1+a, y1+a, x2-a, y2-a, color+((9-a)*16) );
           rectfill(temp, x1+a, y1+a, x2-a, y2-a, color);
   
           text_mode(-1);
           textout_centre(temp, font, ft_ln[d], tx, ty, color+160);
           text_mode(0);
        } /* end of if active */
      switch (db) {
         case (7): stretch_blit(temp, ft_bmp, 0, 0, t_w, t_h, 0, 0, ft_w, ft_h); break;
         case (6): stretch_blit(temp, ft_bmp, 0, 0, t_w, t_h, 0, 0, ft_w, ft_h); break;
         case (4): stretch_blit(temp, ft_bmp, 0, 0, t_w, t_h, 0, 0, ft_w, ft_h); break;
      }
}

