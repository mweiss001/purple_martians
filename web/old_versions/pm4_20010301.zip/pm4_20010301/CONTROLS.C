#include "pm.h"

   extern char global_string[20][25][80]; /* menu.c */


/* controls.c  */
   extern char scantext[127][80];

   extern int joy_key;
   extern int joy_buttons;
   extern int joy_jump;
   extern int joy_fire;
   extern int joy_map;
   extern int joy_menu;
   extern int job[5];

   extern int right_key;
   extern int left_key;
   extern int up_key;
   extern int down_key;
   extern int jump_key;
   extern int fire_key;
   extern int map_key;
   extern int menu_key;

   extern int jump;
   extern int fire;
   extern int up;
   extern int down;
   extern int right;
   extern int left;
   extern int resume_allowed;
   extern int fire_held;
   extern int map_held;
   extern int game_exit;

   extern int comp_move;
   extern int old_comp_move;
   extern int autoplay[5000][2];
   extern int ap_mode;
   extern int api;
   extern int game_map_on;
   extern int passcount;

void scan_to_text()
{
   strcpy(scantext[1], "ESC");
   strcpy(scantext[2], "1");
   strcpy(scantext[3], "2");
   strcpy(scantext[4], "3");
   strcpy(scantext[5], "4");
   strcpy(scantext[6], "5");
   strcpy(scantext[7], "6");
   strcpy(scantext[8], "7");
   strcpy(scantext[9], "8");
   strcpy(scantext[10], "9");
   strcpy(scantext[11], "0");
   strcpy(scantext[12], "MINUS");
   strcpy(scantext[13], "EQUALS");
   strcpy(scantext[14], "BACKSPACE");
   strcpy(scantext[15], "TAB");
   strcpy(scantext[16], "Q");
   strcpy(scantext[17], "W");
   strcpy(scantext[18], "E");
   strcpy(scantext[19], "R");
   strcpy(scantext[20], "T");
   strcpy(scantext[21], "Y");
   strcpy(scantext[22], "U");
   strcpy(scantext[23], "I");
   strcpy(scantext[24], "O");
   strcpy(scantext[25], "P");
   strcpy(scantext[26], "OPENBRACE");
   strcpy(scantext[27], "CLOSEBRACE");
   strcpy(scantext[28], "ENTER");
   strcpy(scantext[29], "CONTROL");
   strcpy(scantext[29], "LCONTROL");
   strcpy(scantext[30], "A");
   strcpy(scantext[31], "S");
   strcpy(scantext[32], "D");
   strcpy(scantext[33], "F");
   strcpy(scantext[34], "G");
   strcpy(scantext[35], "H");
   strcpy(scantext[36], "J");
   strcpy(scantext[37], "K");
   strcpy(scantext[38], "L");
   strcpy(scantext[39], "COLON");
   strcpy(scantext[40], "QUOTE");
   strcpy(scantext[41], "TILDE");
   strcpy(scantext[42], "LSHIFT");
   strcpy(scantext[43], "BACKSLASH");
   strcpy(scantext[44], "Z");
   strcpy(scantext[45], "X");
   strcpy(scantext[46], "C");
   strcpy(scantext[47], "V");
   strcpy(scantext[48], "B");
   strcpy(scantext[49], "N");
   strcpy(scantext[50], "M");
   strcpy(scantext[51], "COMMA");
   strcpy(scantext[52], "STOP");
   strcpy(scantext[53], "SLASH");
   strcpy(scantext[54], "RSHIFT");
   strcpy(scantext[55], "ASTERISK");
   strcpy(scantext[56], "ALT");
   strcpy(scantext[57], "SPACE");
   strcpy(scantext[58], "CAPSLOCK");
   strcpy(scantext[59], "F1");
   strcpy(scantext[60], "F2");
   strcpy(scantext[61], "F3");
   strcpy(scantext[62], "F4");
   strcpy(scantext[63], "F5");
   strcpy(scantext[64], "F6");
   strcpy(scantext[65], "F7");
   strcpy(scantext[66], "F8");
   strcpy(scantext[67], "F9");
   strcpy(scantext[68], "F10");
   strcpy(scantext[69], "NUMLOCK");
   strcpy(scantext[70], "SCRLOCK");
   strcpy(scantext[71], "HOME");
   strcpy(scantext[72], "UP");
   strcpy(scantext[73], "PGUP");
   strcpy(scantext[74], "MINUS_PAD");
   strcpy(scantext[75], "LEFT");
   strcpy(scantext[76], "5_PAD");
   strcpy(scantext[77], "RIGHT");
   strcpy(scantext[78], "PLUS_PAD");
   strcpy(scantext[79], "END");
   strcpy(scantext[80], "DOWN");
   strcpy(scantext[81], "PGDN");
   strcpy(scantext[82], "INSERT");
   strcpy(scantext[83], "DEL");
   strcpy(scantext[84], "PRTSCR");
   strcpy(scantext[87], "F11");
   strcpy(scantext[88], "F12");
   strcpy(scantext[91], "LWIN");
   strcpy(scantext[92], "RWIN");
   strcpy(scantext[93], "MENU");
   strcpy(scantext[100], "PAD");
   strcpy(scantext[120], "RCONTROL");
   strcpy(scantext[121], "ALTGR");
   strcpy(scantext[122], "SLASH2");
   strcpy(scantext[123], "PAUSE");
}



int get_joy_button(void)
{
   do {
         poll_joystick();
      } while ((joy_b1) || (joy_b2) || (joy_b3) || (joy_b4));
      rest(10);
 
   do {
         poll_joystick();
      } while ((!joy_b1) && (!joy_b2) && (!joy_b3) && (!joy_b4));
if (joy_b1) return 1;
if (joy_b2) return 2;
if (joy_b3) return 3;
if (joy_b4) return 4;
}

int my_readkey(void)
{

        int quit = 0;
        int ret = 0;
        int c;

        if (key[KEY_ENTER]) while (key[KEY_ENTER]);

        textout_centre(screen, font, "...Press New Key...", SCREEN_W/2, SCREEN_H/2, 10);
        while (!quit)
           {

              for (c=0; c<128; c++)
                 if ((key[c]) && (!key[KEY_ENTER]))
                    {
                        while (key[c]);
                        ret = c;
                        quit = 1;
      
                    }
           }
        textout_centre(screen, font, "                    ", SCREEN_W/2, SCREEN_H/2, 10);
        return ret;
}



void load_keys()
{

   up_key    = get_config_int("GAMECONTROLS", "up_key",    KEY_UP);
   down_key  = get_config_int("GAMECONTROLS", "down_key",  KEY_DOWN);
   right_key = get_config_int("GAMECONTROLS", "right_key", KEY_RIGHT);
   left_key  = get_config_int("GAMECONTROLS", "left_key",  KEY_LEFT);

   jump_key  = get_config_int("GAMECONTROLS", "jump_key",  KEY_SPACE);
   fire_key  = get_config_int("GAMECONTROLS", "fire_key",  KEY_C);
   map_key   = get_config_int("GAMECONTROLS", "map_key",   KEY_M);
   menu_key  = get_config_int("GAMECONTROLS", "menu_key",  KEY_ESC);

   joy_key  = get_config_int("GAMECONTROLS", "joy_key",     -1);
   joy_jump = get_config_int("GAMECONTROLS", "joy_jump",    -2);
   joy_fire = get_config_int("GAMECONTROLS", "joy_fire",    -3);
   joy_map  = get_config_int("GAMECONTROLS", "joy_map",     -4);
   joy_menu = get_config_int("GAMECONTROLS", "joy_menu",    -5);
}
void save_keys()
{

   set_config_int("GAMECONTROLS", "up_key",    up_key);
   set_config_int("GAMECONTROLS", "down_key",  down_key);
   set_config_int("GAMECONTROLS", "right_key", right_key);
   set_config_int("GAMECONTROLS", "left_key",  left_key);

   set_config_int("GAMECONTROLS", "jump_key",  jump_key);
   set_config_int("GAMECONTROLS", "fire_key",  fire_key);
   set_config_int("GAMECONTROLS", "map_key",   map_key);
   set_config_int("GAMECONTROLS", "menu_key",  menu_key);

   set_config_int("GAMECONTROLS", "joy_key",    joy_key);
   set_config_int("GAMECONTROLS", "joy_jump",   joy_jump);
   set_config_int("GAMECONTROLS", "joy_fire",   joy_fire);
   set_config_int("GAMECONTROLS", "joy_map",    joy_map);
   set_config_int("GAMECONTROLS", "joy_menu",   joy_menu);
}

void get_keys(void)
{
   int a;
   int cc = 12;
   int dd = 11;
   int ee = 10;

   int key_sel;

   scan_to_text();
   clear(screen);
   clear_keybuf();
   rest(100);

   do
      {
         sprintf(global_string[5][2], "   Up ----- %s",  scantext[   up_key]);
         sprintf(global_string[5][3], "   Down --- %s",  scantext[ down_key]);
         sprintf(global_string[5][4], "   Right -- %s",  scantext[right_key]);
         sprintf(global_string[5][5], "   Left --- %s",  scantext[ left_key]);
         sprintf(global_string[5][6], "   Jump --- %s",  scantext[ jump_key]);
         sprintf(global_string[5][7], "   Fire --- %s",  scantext[ fire_key]);
         sprintf(global_string[5][8], "   Map ---- %s",  scantext[  map_key]);
         sprintf(global_string[5][9], "   Menu --- %s",  scantext[ menu_key]);



         for (a=2; a<10; a++)
            while (strlen(global_string[5][a]) < 20)
               {
                  strcat(global_string[5][a], " ");

               }


         key_sel = zmenu(5, key_sel, 50);


         switch (key_sel)
            {

               case 2: up_key    =  my_readkey(); break;
               case 3: down_key  =  my_readkey(); break;
               case 4: right_key =  my_readkey(); break;
               case 5: left_key  =  my_readkey(); break;
               case 6: jump_key  =  my_readkey(); break;
               case 7: fire_key  =  my_readkey(); break;
               case 8: map_key   =  my_readkey(); break;
               case 9: menu_key  =  my_readkey(); break;

            }
       }  while (key_sel != 11); /* end of key menu */
   joy_key = 0;
   save_keys();
   clear(screen);
}
int controller_setup(void)
{

   switch (alert3("Select Joystick Type", NULL, NULL,
		  "None", "Standard", "4-Button", 0, 0, 0))
      {
         case 1:
            return 0;
         break;
         case 2:
   	 joy_type = JOY_TYPE_STANDARD;
   	 if (initialise_joystick()) /* standard found! */
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, SCREEN_H/2, 13);
                  rest(1500);
                  return 0;
               }
            else return 1;
         break;
         case 3:
   	 joy_type = JOY_TYPE_4BUTTON;
            if (initialise_joystick()) /* found! */
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, SCREEN_H/2, 13);
                  rest(1500);
                  return 0;
               }
            else return 4;
         break;
      }

}
void set_start_level(int s)
{
   extern char global_string[20][25][80]; /* menu.c */
   extern int start_level;
   start_level = s;
   sprintf(global_string[7][2], "Start Level  (%d)",start_level);
}
void set_dif(void)
{
   extern int pm_bullet_collision_box;
   extern int enemy_bullet_colision_window;
   extern int dif;
   switch (dif)
     {
      case 1:
           sprintf(global_string[8][5], "Difficulty:Easy");
           pm_bullet_collision_box = 10;
           enemy_bullet_colision_window = 4;
      break;
      case 2:
           sprintf(global_string[8][5], "Difficulty:Normal");
           pm_bullet_collision_box = 8;
           enemy_bullet_colision_window = 5;
      break;
      case 3:
           sprintf(global_string[8][5], "Difficulty:Hard");
           pm_bullet_collision_box = 6;
           enemy_bullet_colision_window = 6;
      break;
   
     }
   set_config_int("GAMECONTROLS", "dif", dif);
}
void set_speed(void)
{
   extern int frame_speed;
   extern int speed;
   switch (speed)
      {
         case 1:
              sprintf(global_string[8][6],"Speed:Slow   ");
              frame_speed = 50;
         break;
         case 2:
              sprintf(global_string[8][6],"Speed:Normal ");
              frame_speed = 30;
         break;
         case 3:
              sprintf(global_string[8][6],"Speed:Fast   ");
              frame_speed = 20;
         break;
         case 4:
              sprintf(global_string[8][6],"Speed:Faster ");
              frame_speed = 10;
         break;
         case 5:
              sprintf(global_string[8][6],"Speed:Fastest");
              frame_speed = 0;
         break;
      }
   set_config_int("GAMECONTROLS", "speed", speed);
}
set_map_var()
{
   extern int tmx, tmy; /* menu pos */
   extern int tmtx, tmty; /* text position */
   extern int mx;
   extern int my;
   extern int md;         /* menu map double */
   extern int map_double; /* game map double */
   extern float steps;
   extern int map100_x, map100_y;

   md = 1; /* defaults */
   steps = 20;
   my = 40+(10*8);
   tmy = 26;
   tmx = SCREEN_W/2;
   my = tmy + 100;
   tmty = my-16; /* text */

   if (SCREEN_W == 1600)  /* never tested */
      {
         map_double = 6;
         md = 12;
         steps = 4;
      }
   if (SCREEN_W == 1280)
      {
         map_double = 4;
         md = 8;
         steps = 8;
      }
   if (SCREEN_W == 1024)
      {
         map_double = 3;
         md = 5;
         steps = 12;
      }
   if (SCREEN_W == 800)
      {
         map_double = 2;
         md = 4;
         steps = 20;
      }
   if ((SCREEN_W == 640) && (SCREEN_H == 480))
      {
         map_double = 2;
         md = 3;
         steps = 24;
      }
   if ((SCREEN_W == 640) && (SCREEN_H == 400))
      {
         map_double = 2;
         md = 2;
         steps = 40;
      }

   mx = SCREEN_W/2-(md*50);
   tmtx = mx+(md*50); /* text pos */

   /* 320 sets its own or uses these ones !! */

   if (SCREEN_W == 320)
      {
         map_double = 1;
         if (map100_y < 20)
            map100_y = 20;
         md = 1;
         if (SCREEN_H == 240)
            {
               my = 124; /* flush with bottom of screen */
               tmty = my-16;
               steps = 100;
            }
         if (SCREEN_H == 200)
            {
               mx = 28 + 16; /* 28 + flush with right of screen */
               my = 84; /* flush with bottom of screen */
               tmx = SCREEN_W/2 + 39;  /* move menu over */

               tmtx = mx+(md*50);
               tmty = my-16;
               steps = 120;
            }
      }
   if (map100_x > SCREEN_W - map_double*100)
      map100_x = SCREEN_W - map_double*100;
   if (map100_y > SCREEN_H - map_double*100)
      map100_y = SCREEN_H - map_double*100;

}
void cal_joy(void)
{
   clear(screen);
   clear_keybuf();
   
   rest(500);
   joy_key = controller_setup();
   rest(500);
   
   text_mode(0);
   
   if (joy_key == 1) /* standard */
      {
         joy_key = 1; /* enable joystick control for the game */
   
         textout_centre(screen, font, "Joystick Calibration", SCREEN_W/2, 40, 9);
         textout_centre(screen, font, "Centre the joystick", SCREEN_W/2, SCREEN_H/2-8, 15);
         textout_centre(screen, font, "and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);
   
         rest(10);
         do {
            poll_joystick();
         } while ((!joy_b1) && (!joy_b2));
   
   
         rest(10);
         do {
            poll_joystick();
         } while ((joy_b1) || (joy_b2));
      
         clear(screen);
         textout_centre(screen, font, "Move the joystick to the top", SCREEN_W/2, SCREEN_H/2-8, 15);
         textout_centre(screen, font, "left corner and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);
      
         rest(10);
         do {
            poll_joystick();
         } while ((!joy_b1) && (!joy_b2));
   
         calibrate_joystick_tl();
      
         rest(10);
         do {
            poll_joystick();
         } while ((joy_b1) || (joy_b2));
      
         clear(screen);
         textout_centre(screen, font, "Move the joystick to the bottom", SCREEN_W/2, SCREEN_H/2-8, 15);
         textout_centre(screen, font, "right corner and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);
      
         rest(10);
         do {
            poll_joystick();
         } while ((!joy_b1) && (!joy_b2));
      
         calibrate_joystick_br();
   
         joy_menu = 0;
         joy_map = 0;
   
      }  /* end of standard only */
   
   
   if (joy_key) /* standard and 4 button */
      {
         clear(screen);
         textout(screen, font, "Press the button to jump", 10, 60, 9);
         joy_jump = get_joy_button();
         rest (500);
         clear(screen);
         textout(screen, font, "Press the button to shoot", 10, 60, 9);
         joy_fire = get_joy_button();
         rest (500);
      }
   if (joy_key == 4) /* 4 button only */
      {
         clear(screen);
         textout(screen, font, "Press the map button", 10, 60, 9);
         joy_map = get_joy_button();
   
         rest (500);
         clear(screen);
         textout(screen, font, "Press the menu button", 10, 60, 9);
         joy_menu = get_joy_button();
   
         rest(500);
      }
   save_keys();
   clear(screen);
}

void proc_controllers()
{
    jump=0;
    fire=0;
    left=0;
    right=0;
    up=0;
    down=0;

    if ((key[up_key])    || (joy_up))    up = 1;
    if ((key[down_key])  || (joy_down))  down = 1;
    if ((key[left_key])  || (joy_left))  left = 1;
    if ((key[right_key]) || (joy_right)) right = 1;

    if ((key[KEY_ESC]) || (key[menu_key]) || (mouse_b & 2))
         {
            resume_allowed = 1;
            game_exit = 1;
         }

    switch (joy_key)
       {
          case 0: /* keyboard */
             if (key[fire_key]) fire = 1;
             else fire_held = 0;
             if (key[jump_key]) jump = 1;


#ifdef ALTL

          if ((key[KEY_ALT]) && (key[KEY_L]))
             {
                int l, l2 = play_level;
                char fname[20];
                final_wrapup();
                sprintf(fname, "pmfle.exe %d", l2);
                l = system(fname); /* set level num from level editor */
   
                if ((l == 0) || (l == 255))
                   {
                      initial_setup();
                      set_start_level(l2); /* original start level */
                      slow_load_and_draw_level(l2);
                      game_exit  = 1;
                      resume_allowed = 0;
                      top_menu_sel = 3;
                   }
                else /* immediately start playing the returned level */
                   {
                      initial_setup();
                      if (load_level(l,0))
                         {
                            set_start_level(l);
                            play_level=start_level;
                            set_zz(0);
                            maps_and_background_fill();
                            for (c=0; c<500; c++)  /* get start and time */
                               if (item[c][0] == 5)
                                  {
                                     PX = itemf[c][0];
                                     PY = itemf[c][1];
                                     level_time = item[c][8] * 50;
                                     stimp();
                                     break;
                                  }
                            for (c=0; c<8; c++)
                               sample_delay[c] = passcount;
      
                            player_carry = 0;
                            player_ride = 0;
                            level_done = 0;
                            bottom_msg=0;
                            pop_msg_count=0;
                            right_speed = left_speed = 0;
                            jump_count = fall_count = 0;
                            clear_keybuf();
                            start_mode = 0;
                            game_exit = 0;
                            num_bullets = 200;
                            LIVES = 5;
                            LIFE = 100;

                         }
                      else
                         {
                            game_exit = 1;
                            resume_allowed = 0;
                         }
                   }
             }

#endif
#ifdef PRTSCR
          if ((key[KEY_CONTROL]) && (key[KEY_PRTSCR]))
             {
                FILE *filepntr;
                char fname[80];

                BITMAP *ss_bmp;
                PALETTE ss_pal;
          
                get_palette(ss_pal);
                ss_bmp = create_sub_bitmap(screen, 0, 0, SCREEN_W, SCREEN_H);

                text_mode(0);
                gui_fg_color = 10;
                sprintf(fname,"scrndump.bmp");
             
                if (file_select("Save Screen Dump as...", fname, "BMP"))
                   {
                       save_bitmap("dump.bmp", ss_bmp, ss_pal);
                       destroy_bitmap(ss_bmp);
                   }
                text_mode(0);
                gui_fg_color = 9;

             }
#endif

          if ((key[map_key]) && (!map_held))
             {
                next_map_mode();
                map_held = 1;
             }
          if ((!key[map_key]) && (map_held))
             map_held = 0;

          break;
          case 1: /* standard joystick control */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;

             if ((key[map_key]) && (!map_held)) /* key map */
                {
                   next_map_mode();
                   map_held = 1;
                }
             if ((!key[map_key]) && (map_held))
                map_held = 0;
          break;
          case 4: /* 4 button joystick */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             job[3] = joy_b3;
             job[4] = joy_b4;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;
             if ((job[joy_map]) && (!map_held))
                {
                   next_map_mode();
                   map_held = 1;
                }
             if ((!job[joy_map]) && (map_held))
                map_held = 0;
             if (job[joy_menu])
                {
                   resume_allowed = 1;
                   game_exit = 1;
                }
          break;
     }
}

#ifdef MV
void rec_ap_control()
{
    int map=0;
    int menu=0;

    jump=0;
    fire=0;
    left=0;
    right=0;
    up=0;
    down=0;

    if ((key[up_key])    || (joy_up))    up = 1;
    if ((key[down_key])  || (joy_down))  down = 1;
    if ((key[left_key])  || (joy_left))  left = 1;
    if ((key[right_key]) || (joy_right)) right = 1;

    if ((key[KEY_ESC]) || (key[menu_key]))
         {
            menu = 1;

            resume_allowed = 1;
            game_exit = 1;
         }

    switch (joy_key)
       {
          case 0: /* keyboard */
             if (key[fire_key]) fire = 1;
             else fire_held = 0;
             if (key[jump_key]) jump = 1;

          if ((key[map_key]) && (!map_held))
             {
                next_map_mode();
                map = 1;
                map_held = 1;
             }
          if ((!key[map_key]) && (map_held))
             map_held = 0;

          break;
          case 1: /* standard joystick control */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;

             if ((key[map_key]) && (!map_held)) /* key map */
                {
                   next_map_mode();
                   map = 1;
                   map_held = 1;
                }
             if ((!key[map_key]) && (map_held))
                map_held = 0;
          break;
          case 4: /* 4 button joystick */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             job[3] = joy_b3;
             job[4] = joy_b4;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;
             if ((job[joy_map]) && (!map_held))
                {
                   next_map_mode();
                   map = 1;
                   map_held = 1;
                }
             if ((!job[joy_map]) && (map_held))
                map_held = 0;
             if (job[joy_menu])
                {
                   resume_allowed = 1;
                   menu = 1;
                   game_exit = 1;
                }
          break;
      }



      /* make comp */
      comp_move = 0;
      if (left)  comp_move += 1;
      if (right) comp_move += 2;
      if (up)    comp_move += 4;
      if (down)  comp_move += 8;
      if (jump)  comp_move += 16;
      if (fire)  comp_move += 32;
      if (game_map_on) comp_move += 64;
      if (menu)  comp_move += 128;

      if (comp_move != old_comp_move)
         {
            old_comp_move = comp_move;
            autoplay[api][0] = passcount;
            autoplay[api][1] = comp_move;
            if (comp_move > 127)
               {
                  save_apl();

               }
            api++;

         }

}
#endif MV

void proc_ap_control()
{
   if ((passcount > 20) && (keypressed()))
     {
        resume_allowed = 1;
        game_exit = 1;
     }

   if (passcount >= autoplay[api][0])  /* if passcounter = next line in array */
   
      {
         int t = autoplay[api][1];
         fire = 0;
         jump = 0;
         up = 0;
         down = 0;
         left = 0;
         right = 0;


         if (t > 127)
            {
                t -= 128;
                resume_allowed = 0;
                game_exit = 1;
             }
         if (t > 63)
            {
                t -= 64;
                game_map_on = 1;
            }
         else game_map_on = 0;
         if (t > 31)
            {
                t -= 32;
                fire = 1;
            }
         else fire_held = 0;
         if (t > 15)
            {
                t -= 16;
                jump = 1;
            }
         if (t > 7) /* down */
            {
                t -= 8;
                down=1;
            }
         if (t > 3) /* up */
            {
                t -= 4;
                up = 1;
            }
         if (t > 1) /* right */
            {
                t -= 2;
                right = 1;
            }
         if (t > 0) /* left */
            {
               t -= 0;
               left = 1;
            }
         api++;
      }
}

