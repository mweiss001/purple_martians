
/* this file will have the bitmap shit from ect for now
   and maybe the bm stuff later */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "pm.h"

#ifdef MV

extern BITMAP *memory_bitmap[NUM_SPRITES];


/* fnx prototypes */
int draw_current_bitmap(int msg, DIALOG *d, int c);
int new_draw_csp(int msg, DIALOG *d, int c);
int show_draw_mode(int msg, DIALOG *d, int c);

int draw_animation(int msg, DIALOG *d, int c)
{
   extern int zz[20][NUM_ANS];
   extern int zzindx;
   extern int bmp_index;
   char tmsg[80];
   int e;
   switch (msg) {
      case MSG_DRAW:
         sprintf(tmsg,"Animation Sequence # %-2d ",zzindx);
         textout(screen, font, tmsg, 4,446, 15);
         rect(screen, 190, 443, 2, 454, 15);
         rect(screen, 2, 454, 323, 476, 15);
            for (e = 0; e < 16; e++)   /* show current seq shapes */
              {
                  if ((zz[4][zzindx]) > (e - 1))  /* is shape in seq? */
                     blit(memory_bitmap[zz[ 5+e][zzindx]],screen,0,0,3+e*20,456,20,20);
              }
      break;
      case MSG_CLICK:
         bmp_index = zz[5 + ((mouse_x-3)/20)][zzindx];
         return D_REDRAW;
      break;
   }
   return D_O_K;
}
int color_bars(int msg, DIALOG *d, int c)
{
     extern PALLETE pallete;
     extern int b1_color;
     char tmsg[80];
     int e, x, y;
     switch (msg) {

        case MSG_DRAW:
           pallete[252].r = pallete[b1_color].r; /* set temp color to red value */
           pallete[252].g = 0;
           pallete[252].b = 0;
           pallete[253].r = 0;
           pallete[253].g = pallete[b1_color].g; /* set temp color to green value */
           pallete[253].b = 0;
           pallete[254].r = 0;
           pallete[254].g = 0;
           pallete[254].b = pallete[b1_color].b; /* set temp color to blue value */

           set_pallete(pallete);
  
           rectfill(screen, 320, 60,  639, 99,  252);
           rect    (screen, 320, 60,  639, 99,  15 );

           rectfill(screen, 320, 100, 639, 139, 253);
           rect    (screen, 320, 100, 639, 139, 15 );

           rectfill(screen, 320, 140, 639, 179, 254);
           rect    (screen, 320, 140, 639, 179, 15 );

           sprintf(tmsg,"Red   = %-2d",pallete[b1_color].r);
           textout(screen, font, tmsg, 220, 75, 15);
           e = (pallete[b1_color].r * 5) + 320;
           rectfill(screen, e, 60, e+3, 99, 15);


           sprintf(tmsg,"Green = %-2d",pallete[b1_color].g);
           textout(screen, font, tmsg, 220, 115, 15);
           e = (pallete[b1_color].g * 5) + 320;
           rectfill(screen, e, 100, e+3, 139, 15);


           sprintf(tmsg,"Blue  = %-2d",pallete[b1_color].b);
           textout(screen, font, tmsg, 220, 155, 15);
           e = (pallete[b1_color].b * 5) + 320;
           rectfill(screen, e, 140, e+3, 179, 15);

           rectfill (screen, 320, 200, 639, 380, b1_color);

        break;

        case MSG_CLICK:
/* get rid of bars */
           rectfill(screen, 320, 60,  639, 99,  252);
           rect    (screen, 320, 60,  639, 99,  15 );

           rectfill(screen, 320, 100, 639, 139, 253);
           rect    (screen, 320, 100, 639, 139, 15 );

           rectfill(screen, 320, 140, 639, 179, 254);
           rect    (screen, 320, 140, 639, 179, 15 );


        while (mouse_b & 1)
              {
                 if ((mouse_y >  60) && (mouse_y < 100) ) pallete[b1_color].r = ((mouse_x - 320) / 5 );/* red bar */
                 if ((mouse_y > 100) && (mouse_y < 140) ) pallete[b1_color].g = ((mouse_x - 320) / 5 );/* green bar */
                 if ((mouse_y > 140) && (mouse_y < 180) ) pallete[b1_color].b = ((mouse_x - 320) / 5 );/* blue bar */

                 if (pallete[b1_color].r > 63) pallete[b1_color].r = 63;
                 if (pallete[b1_color].g > 63) pallete[b1_color].g = 63;
                 if (pallete[b1_color].b > 63) pallete[b1_color].b = 63;
                 show_mouse(NULL);

                 sprintf(tmsg,"Red   = %-2d",pallete[b1_color].r);
                 textout(screen, font, tmsg, 220, 75, 15);

                 xor_mode(TRUE);
                 e = (pallete[b1_color].r * 5) + 320;
                 rectfill(screen, e, 60, e+3, 99, 127);
                 rest(10);
                 e = (pallete[b1_color].r * 5) + 320;
                 rectfill(screen, e, 60, e+3, 99, 127);
                 xor_mode(FALSE);


                 sprintf(tmsg,"Green = %-2d",pallete[b1_color].g);
                 textout(screen, font, tmsg, 220, 115, 15);

                 xor_mode(TRUE);
                 e = (pallete[b1_color].g * 5) + 320;
                 rectfill(screen, e, 100, e+3, 139, 127);
                 rest(10);
                 e = (pallete[b1_color].g * 5) + 320;
                 rectfill(screen, e, 100, e+3, 139, 127);
                 xor_mode(FALSE);


                 sprintf(tmsg,"Blue  = %-2d",pallete[b1_color].b);
                 textout(screen, font, tmsg, 220, 155, 15);

                 xor_mode(TRUE);
                 e = (pallete[b1_color].b * 5) + 320;
                 rectfill(screen, e, 140, e+3, 179, 127);
                 rest(10);
                 e = (pallete[b1_color].b * 5) + 320;
                 rectfill(screen, e, 140, e+3, 179, 127);
                 xor_mode(FALSE);

                 show_mouse(screen);


                 pallete[252].r = pallete[b1_color].r; /* set temp color to red value */
                 pallete[252].g = 0;
                 pallete[252].b = 0;
                 pallete[253].r = 0;
                 pallete[253].g = pallete[b1_color].g; /* set temp color to green value */
                 pallete[253].b = 0;
                 pallete[254].r = 0;
                 pallete[254].g = 0;
                 pallete[254].b = pallete[b1_color].b; /* set temp color to blue value */


                 set_pallete(pallete);
               }
           return D_REDRAW;
        break;


     }
 return D_O_K;
}
int fade_proc(int msg, DIALOG *d, int c)
{
   extern int b1_color;
   extern PALLETE pallete;
   int ret;
   ret =  d_button_proc(msg, d, c);

   if (ret == D_CLOSE)
      {
         if (b1_color < 16)
            {
              int x;
              int cn = b1_color;
              float ns = 15;

              for (x=0; x<ns; x++)
                 {
                    pallete[cn+(x*16)].r = pallete[cn].r * (1 - (x/ns)) ;
                    pallete[cn+(x*16)].g = pallete[cn].g * (1 - (x/ns)) ;
                    pallete[cn+(x*16)].b = pallete[cn].b * (1 - (x/ns)) ;
                 }
              set_pallete(pallete);
            }
         return D_REDRAW;
      }
   return ret;
}
int select_bitmap_ans()
{
   extern int bmp_index;
   int x, y;
   int button_x1 = 400;
   int button_x2 = 639;
   int button_xc = 520;
   int button_y = 330;
   int jh;

   int offset = 0;
   char msg[80];

   show_mouse(NULL);
   text_mode(0);
   textout(screen, font, "Select a Bitmap with b1 ", 0, 380,  9);
   textout(screen, font, "b2 to exit              ", 0, 390,  9);
   do
      {
         /* this is to draw 32x16 bitmaps  */
         for (y = 0; y < 16; y++)
            for (x = 0; x < 32; x++)
               blit(memory_bitmap[offset+x+(y*32)], screen, 0, 0, (x*20), (y*20), 20, 20);
         show_mouse(screen);
         rest (10);
         show_mouse(NULL);
         if ((mouse_y < 320) && (mouse_x < 640))
            {
               int pointer = offset+(mouse_x/20) + (mouse_y/20) * 32 ;
               sprintf(msg,"pointer %-2d  ", pointer );
               textout(screen, font, msg, 0, 360, 4);
               blit (memory_bitmap[pointer], screen, 0, 0, 95, 351, 20, 20);

               if (mouse_b & 1)
                  {
                     bmp_index = pointer;
                     return 1;
                  }
            }
         jh=3;
         rect(screen, button_x1, button_y+(jh*12), button_x2, button_y+(jh*12)+10, 15);
         if (offset == 0)   sprintf(msg,"  Shapes 0-511   ");
         if (offset == 512) sprintf(msg," Shapes 512-1023 ");
         textout_centre(screen, font, msg, button_xc, button_y+(jh*12)+2, 13);
      
         if (mouse_b & 1) /* process buttons */
            if (mouse_x > button_x1)
               if (mouse_x < button_x2)
                  if (mouse_y > button_y)
                     if (mouse_y < button_y+(4*12) )
                        {
                           int mb = (mouse_y - button_y) / 12;
                           switch(mb)
                              {
                                 case 3: /* toggle b2 mode */
                                    while (mouse_b & 1); /* wait for release */
                                    if (offset == 512) offset = 0;
                                    else offset = 512;
                                 break;
                      
                              }

                        }



         else rectfill(screen, 0, 351, 115, 371, 0);
         if (mouse_b & 2) return 0;
      } while (!key[KEY_ESC]);
    return -1;
}
int animation_proc()
{
   extern int zz[20][NUM_ANS];
   extern int zzindx;
   extern int passcount;
   extern int bmp_index;
   extern int edit_int_retval;
   int pointer = zzindx;
   int as_quit = 0;
   int c, x, y;
   float fx, fy;
   char msg[80];
   show_mouse(NULL);
   clear(screen);
   text_mode(0);
   while ((!key[KEY_ESC]) && (!(mouse_b & 2)) )
      {
         show_mouse(screen);
         rest(20);
         show_mouse(NULL);
         sprintf(msg,"Animation Sequence Editor");
         textout_centre(screen, font, msg, 320, 20, 10);
         sprintf(msg,"Get New Shapes");
         textout(screen, font, msg, 0, 260, 10);
         sprintf(msg,"Passcount Delay %d  ",zz[3][zzindx]);
         textout(screen, font, msg, 0, 280, 9);
         if (key[KEY_DEL])
            {
               for (c=0;c<20;c++)
                  zz[c][zzindx] = 0;
               clear(screen);
            }
         if ((mouse_y < 190)  && (mouse_x < 642))
            {
               pointer = (mouse_x-2) / 20 + (mouse_y-30) / 20 * 32;
               if (pointer < 0) pointer = 0;
               if (pointer > NUM_ANS-1) pointer = NUM_ANS-1;
            }

         if (mouse_b & 1)
            {
               if ((mouse_y < 190)  && (mouse_x < 642))
                  {
                     zzindx = pointer;
                     clear(screen);
                  }
               /* edit delay */
               if ( (mouse_y > 280) && (mouse_y < 288) && (mouse_x < 150) )
                  if (edit_int(128, 280, zz[3][zzindx], 1, 0, 100))
                     zz[3][zzindx] = edit_int_retval;
   
               if ( (mouse_y > 260) && (mouse_y < 268) && (mouse_x < 120) )
                  {   /* get new shapes  */
                     int temp_zzindx = zz[4][zzindx];
                     zz[4][zzindx] = 0;
                     as_quit = 0;
                     rest(200);
                     while (!as_quit)
                        {
                           clear(screen);
                           sprintf(msg, "Get Shape #%d ", zz[4][zzindx] );
                           textout(screen, font, msg, 0, 620, 10);
                           x = select_bitmap_ans();
                           if (x == 1) /* good return b1 */
                              {
                                 zz[5 + zz[4][zzindx]][zzindx] = bmp_index;
                                 rest(300); /* to prevent repeat */
                                 zz[4][zzindx]++; /* set last shape to point at next */
                              }
                           if (x == 0)  /* done  b2 */
                              {
                                 zz[4][zzindx]--;
                                 as_quit=1;
                              }
                           if (x == -1)  /* abort esc */
                              {
                                 if (zz[4][zzindx] == 0) zz[4][zzindx] = temp_zzindx;
                                 as_quit=1;
                              }
                        }
                     rest(100);
                     clear_keybuf();
                     clear(screen);
                  }
            }
         for (c = 0; c < zz[4][zzindx] + 1; c++)   /* show current seq shapes */
            if (( zz[5+c][zzindx] < NUM_SPRITES) && (zz[5+c][zzindx] > 0))
               blit(memory_bitmap[ zz[5+c][zzindx] ], screen, 0, 0, c*20, 220, 20, 20);
         sprintf(msg,"Current Sequence %d  ",zzindx);
         textout(screen, font, msg, 0, 210, 13);
         sprintf(msg,"Pointer %d  ",pointer );
         textout(screen, font, msg, 0, 194, 9);
         rect(screen, 0, 219, 322, 240, 13);

         rect(screen, 0, 29, 642, 190, 9);

         for (c=0; c < 32; c++)   /* draw 32x8 */
            for (x=0; x < 8; x++)
               if (zz[4][c + (x * 32)] != 0)
                  if ((zz[0][c + (x * 32)] < NUM_SPRITES) && (zz[0][c + (x * 32)] > 0 ))
                     blit(memory_bitmap[zz[0][c + (x * 32)]], screen, 0, 0, 2+c*20, 30+x*20, 20, 20);
         update_animation();
      }
   show_mouse(screen);
   return D_REDRAW;
}
int select_bitmap_proc()
{
   extern int sa[NUM_SPRITES][2];
   extern int bmp_index;
   int offset;
   int x, y;
   int quit = 0;
   char msg[80];
   int view_attrib = 0;
   int button_x1 = 400;
   int button_x2 = 639;
   int button_xc = 520;
   int button_y = 330;
   int jh;
   int b2mode = 0;

   show_mouse(NULL);
   text_mode(0);
   clear(screen);
   textout(screen, font, "Select a Bitmap with b1 ", 0, 380,  9);

   while (!quit)
      {
         /* this is to draw 32x16 bitmaps  */
         for (y = 0; y < 16; y++)
            for (x = 0; x < 32; x++)
               {
                  int color = 240; /* normal color = white */
                  blit(memory_bitmap[offset+x+(y*32)], screen, 0, 0, (x*20), (y*20), 20, 20);
                  if (view_attrib)
                     {
                        if (sa[offset+x+(y*32)][1]) color = 10; /* locked color = red */
                        if (sa[offset+x+(y*32)][0] == 0) textout(screen, font, "E", (x*20)+4, (y*20)+4, color);;
                        if (sa[offset+x+(y*32)][0] == 1) textout(screen, font, "B", (x*20)+4, (y*20)+4, color);;
                        if (sa[offset+x+(y*32)][0] == 2) textout(screen, font, "S", (x*20)+4, (y*20)+4, color);;
                     }
                }
         if ((mouse_y < 320) && (mouse_x < 640))
            {
               int pointer = offset+(mouse_x/20) + (mouse_y/20) * 32 ;
               sprintf(msg,"pointer %-2d  ", pointer );
               textout(screen, font, msg, 0, 360, 4);
               blit (memory_bitmap[pointer], screen, 0, 0, 95, 351, 20, 20);
               if (mouse_b & 1)
                  {
                     if (view_attrib)
                        {
                           int bx1 = mouse_x/20;
                           int by1 = mouse_y/20;
                           int bx2 = mouse_x/20;
                           int by2 = mouse_y/20;
                           int old_mouse_x = mouse_x;
                           int old_mouse_y = mouse_y;
                           int cx;
                           int cy;
                           xor_mode(TRUE);
                           /* trap it while b1 is held */
                           while (mouse_b & 1)
                              {
                                 bx2 = bx1 + ((mouse_x - old_mouse_x)/20);
                                 by2 = by1 + ((mouse_y - old_mouse_y)/20);
                                 show_mouse(NULL);
                                 rect(screen, (bx1)*20, (by1)*20, (bx2)*20, (by2)*20, 15);
                                 rest(5);
                                 rect(screen, (bx1)*20, (by1)*20, (bx2)*20, (by2)*20, 15);
                                 show_mouse(screen);
                                 rest(5);
                              }
                           xor_mode(FALSE);
                           /* limits */
                           if (bx1>32) bx1 = 32;
                           if (bx2>32) bx2 = 32;
                           if (by1>16) by1 = 16;
                           if (by2>16) by2 = 16;
                           /* ensure top-right, bottom left format */
                           if (bx1 > bx2)
                              {
                                 int temp = bx2;
                                 bx2 = bx1;
                                 bx1= temp;
                              }
                           if (by1 > by2)
                              {
                                 int temp = by2;
                                 by2 = by1;
                                 by1= temp;
                              }
                           /* cycle the selection */
                           for (cx = bx1; cx < bx2; cx++)
                              for (cy = by1; cy < by2; cy++)
                                 {
                                    if (b2mode< 3) sa[offset+cx+(cy*32)][0] = b2mode;
                                    if ((b2mode> 2) && (b2mode < 5)) sa[offset+cx+(cy*32)][1] = b2mode-3;
                                 }
                        }
                     if (!view_attrib)  /* old b1 behaviour */
                        {
                           bmp_index = offset + (mouse_x/20) + (mouse_y/20) * 32;
                           quit = 1;
                        }
                  }

            }
         else rectfill(screen, 0, 351, 115, 371, 0);
         if (key[KEY_S])
            {
               BITMAP *ss_bmp;
               PALETTE ss_pal;
               get_palette(ss_pal);
               ss_bmp = create_sub_bitmap(screen, 0, 0, SCREEN_W, SCREEN_H);
               save_bitmap("spritdmp.bmp", ss_bmp, ss_pal);
               destroy_bitmap(ss_bmp);
            }
         jh=1;
         rect(screen, button_x1, button_y+(jh*12), button_x2, button_y+(jh*12)+10, 15);
         if (view_attrib) sprintf(msg,"View Attributes:ON ");
         else sprintf(msg,"View Attributes:OFF");
         textout_centre(screen, font, msg, button_xc, button_y+(jh*12)+2, 13);
         jh=2;
         rect(screen, button_x1, button_y+(jh*12), button_x2, button_y+(jh*12)+10, 15);
         if (b2mode == 0) sprintf(msg,"  Empty  ");
         if (b2mode == 1) sprintf(msg,"  Block  ");
         if (b2mode == 2) sprintf(msg," Special ");
         if (b2mode == 3) sprintf(msg," Unlock ");
         if (b2mode == 4) sprintf(msg,"  Lock  ");
         textout_centre(screen, font, msg, button_xc, button_y+(jh*12)+2, 13);

         jh=3;
         rect(screen, button_x1, button_y+(jh*12), button_x2, button_y+(jh*12)+10, 15);
         if (offset == 0)   sprintf(msg,"  Shapes 0-511   ");
         if (offset == 512) sprintf(msg," Shapes 512-1023 ");
         textout_centre(screen, font, msg, button_xc, button_y+(jh*12)+2, 13);
      
         if (mouse_b & 1) /* process buttons */
            if (mouse_x > button_x1)
               if (mouse_x < button_x2)
                  if (mouse_y > button_y)
                     if (mouse_y < button_y+(4*12) )
                        {
                           int mb = (mouse_y - button_y) / 12;
                           switch(mb)
                              {
                                 case 1: /* toggle view_attrib */
                                    while (mouse_b & 1); /* wait for release */
                                    view_attrib = !view_attrib;
                                 break;
                                 case 2: /* toggle b2 mode */
                                    while (mouse_b & 1); /* wait for release */
                                    if (++b2mode>4) b2mode = 0;
                                 break;
                                 case 3: /* toggle b2 mode */
                                    while (mouse_b & 1); /* wait for release */
                                    if (offset == 512) offset = 0;
                                    else offset = 512;
                                 break;
                              }
                        }
         show_mouse(screen);
         rest(10);
         show_mouse(NULL);
      }
   show_mouse(screen);
   return D_REDRAW;
}
int copy_bitmap_proc()
{
   extern int bmp_index;
   int x, y;

   int button_x1 = 400;
   int button_x2 = 639;
   int button_xc = 520;
   int button_y = 330;
   int jh;

   int quit = 0;
   int offset = 0;
   char msg[80];

   show_mouse(NULL);
   text_mode(0);
   clear(screen);
   textout(screen, font, "Copy Bitmap with b1 ", 0, 380,  9);
   textout(screen, font, "b2 to quit ",          0, 390,  9);

   while (!quit)
      {
         /* this is to draw 32x16 bitmaps  */
         for (y = 0; y < 16; y++)
            for (x = 0; x < 32; x++)
               blit(memory_bitmap[offset+x+(y*32)], screen, 0, 0, (x*20), (y*20), 20, 20);
         if ((mouse_y < 320) && (mouse_x < 640))
            {
               int pointer = offset+(mouse_x/20) + (mouse_y/20) * 32 ;
               sprintf(msg,"pointer %-2d  ", pointer );
               textout(screen, font, msg, 0, 360, 4);
               blit (memory_bitmap[pointer], screen, 0, 0, 95, 351, 20, 20);
               if ((key[KEY_CONTROL]) && (mouse_b & 1))
                  bmp_index = pointer;
               else if (mouse_b & 1) blit (memory_bitmap[bmp_index], memory_bitmap[pointer], 0, 0, 0, 0, 20, 20);

            }
         else rectfill(screen, 0, 351, 115, 371, 0);

         jh=3;
         rect(screen, button_x1, button_y+(jh*12), button_x2, button_y+(jh*12)+10, 15);
         if (offset == 0)   sprintf(msg,"  Shapes 0-511   ");
         if (offset == 512) sprintf(msg," Shapes 512-1023 ");
         textout_centre(screen, font, msg, button_xc, button_y+(jh*12)+2, 13);
      
         if (mouse_b & 1) /* process buttons */
            if (mouse_x > button_x1)
               if (mouse_x < button_x2)
                  if (mouse_y > button_y)
                     if (mouse_y < button_y+(4*12) )
                        {
                           int mb = (mouse_y - button_y) / 12;
                           switch(mb)
                              {
                                 case 3: /* toggle b2 mode */
                                    while (mouse_b & 1); /* wait for release */
                                    if (offset == 512) offset = 0;
                                    else offset = 512;
                                 break;
                      
                              }

                        }





         if (mouse_b & 2) quit = 1;
         show_mouse(screen);
         rest(10);
         show_mouse(NULL);
      }
   show_mouse(screen);
   return D_REDRAW;
}
DIALOG edit_pallete_dialog[] =
{
   /* (dialog proc)     (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)  (d2)  (dp) */
   { d_clear_proc,      0,    0,    192,  172,  255,  0,    0,    0,       0,    0,    NULL },
   { d_ctext_proc,      320,  1,   0,     0,    10,   0,    0,    0,       0,    0,    "Pallete Editor" },
   { new_draw_csp,      3,     40,  160,  160,  9,    0,    0,    0,       0,    0,    NULL },
   { color_bars,        320,   60,  320,  120,  9,    0,    0,    0,       0,    0,    NULL },
   { fade_proc,         180,  400,  160,  48,   9,    0,    0,    D_EXIT,  0,    0,    "Fade" },
   { d_button_proc,     360,  400,  160,  48,   9,    0,    0,    D_EXIT,  0,    0,    "Exit" },
   { NULL,              0,    0,    0,    0,    0,    0,    0,    0,       0,    0,    NULL }
};

int edit_pallete_proc()
{
   do_dialog(edit_pallete_dialog, -1);
   text_mode(0);
   return D_REDRAW;
}


MENU next_bitmap_menu[] =
{
   { "Select Bitmap",         select_bitmap_proc,     NULL },
   { "Copy Bitmap",           copy_bitmap_proc,       NULL },
   { NULL,                       NULL,                  NULL }
};

MENU modify_selection_menu[] =
{
   { "Mirror X",                bm_flip_x_axis_proc,    NULL },
   { "Mirror Y",                bm_flip_y_axis_proc,    NULL },
   { "Scroll Up",               bm_scroll_up_proc,      NULL },
   { "Scroll Down",             bm_scroll_down_proc,    NULL },
   { "Scroll Left",             bm_scroll_left_proc,    NULL },
   { "Scroll Right",            bm_scroll_right_proc,   NULL },
   { "Rotate 90 deg",           bm_rot_proc,            NULL },
   { NULL,                      NULL,                   NULL }
};
MENU bitmap_file_menu[] =
{
   { "&Load Sprit File",         load_sprit_proc,     NULL },
   { "&Save Sprit File",         save_sprit_proc,     NULL },
   { "&Palette",                 edit_pallete_proc,   NULL },
   { "&Animation",               animation_proc,      NULL },
   { NULL,                       NULL,                NULL }
};
MENU selection_menu[] =
{
   { "New Selection",         new_selection_proc,    NULL },
   { "Select All",            select_all_proc,       NULL },
   { "Gridlines",             gridlines_proc,         NULL },
   { NULL,                       NULL,                NULL }
};
MENU draw_mode_menu1[] =
{
   { "Replace Color",         replace_color_proc,     NULL },
   { "Line Draw",             line_draw_proc,         NULL },
   { "Rectangle Draw",        rect_draw_proc,         NULL },
   { "Filled Rectangle",      rectfill_draw_proc,     NULL },
   { "Circle Draw",           circle_draw_proc,       NULL },
   { "Filled Circle",         circlefill_draw_proc,   NULL },
   { "Floodfill",             floodfill_draw_proc,    NULL },

   { NULL,                       NULL,                NULL }
};
MENU top_bitmap_menu[] =
{
   { "&File",                    NULL,              bitmap_file_menu },
   { "&Bitmap"  ,                NULL,              next_bitmap_menu },
   { "&Draw Mode"  ,             NULL,              draw_mode_menu1 },
   { "&Selection"  ,             NULL,              selection_menu },
   { "&Modify Selection"  ,      NULL,              modify_selection_menu },
   { "&Quit",                    quit_proc,         NULL },
   { NULL,                       NULL,              NULL }
};
DIALOG bitmap_dialog[] =
{
   /* (dialog proc)       (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)  (d2)  (dp) */
   { d_clear_proc,        0,     0,   0,     0,    0,  0,    0,    0,       0,    0,    NULL },
   { d_ctext_proc,      320,     0,   0,     0,    10, 0,    0,    0,       0,    0,    " Bitmap Editor" },
   { d_menu_proc,         1,    10,   0,     0,    9,  0,    0,    0,       0,    0,    top_bitmap_menu },

   { show_draw_mode,      3,   220,  160,  160,    9,  0,    0,    0,       0,    0,    NULL },


   { rb1_proc,           20,   244,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Point Draw" },
   { rb2_proc,           20,   256,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Line Draw" },
   { rb3_proc,           15,   268,  130,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Framed Rectangle" },
   { rb4_proc,           15,   280,  130,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Filled Rectangle" },
   { rb5_proc,           20,   292,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Framed Circle" },
   { rb6_proc,           20,   304,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    "Filled Circle" },

   { ar1_proc,           20,   345,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Up" },
   { ar2_proc,           20,   360,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Down" },
   { ar3_proc,           20,   375,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Left" },
   { ar4_proc,           20,   390,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Scroll Right" },
   { ar5_proc,           20,   405,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Mirror X Axis" },
   { ar6_proc,           20,   420,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    "Mirror Y Axis" },

   { new_draw_csp,           3,     40,  160,  160,  9,  0,    0,    0,       0,    0,    NULL },

   { draw_current_bitmap,  220,     40,  400,  400,  9,  0,    0,    0,       0,    0,    NULL },
   { draw_animation,         3,    456,  320,   20,  9,  0,    0,    0,       0,    0,    NULL },

   { NULL,                   0,      0,    0,    0,  0,  0,    0,    0,       0,    0,    NULL }
};
void bitmap_main(void)
{
   do_dialog(bitmap_dialog, -1);
   text_mode(0);
}

#endif


