#include "pm.h"

void press_any()
{
   extern int joy_key;
   clear_keybuf();
     if (joy_key) /* joystick control */
        {

           do {
                poll_joystick();
              } while ((joy_b1) || (joy_b2));  /* wait for release */
           do {
                poll_joystick();

              } while ((!joy_b1) && (!keypressed()) && (!joy_b2));  /* wait for press */
        }
     else readkey();
}

extern BITMAP *memory_bitmap[512];

void frame_and_title(void)
{
    BITMAP *pm_title;
    BITMAP *temp_title;
    int x,y;

    pm_title = create_bitmap(280,20);
    temp_title = create_bitmap(140,8);
    clear(pm_title);
    clear(temp_title);


      textout_centre(temp_title, font, "Purple Martians!", 70,0,200);
      for (x=0; x<5; x++)
         for (y=0; y<5; y++)
            stretch_sprite(pm_title, temp_title, x,y,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,136);
      stretch_sprite(pm_title, temp_title, 1,1,280,16);
      stretch_sprite(pm_title, temp_title, 1,3,280,16);
      stretch_sprite(pm_title, temp_title, 3,1,280,16);
      stretch_sprite(pm_title, temp_title, 3,3,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,8);
      stretch_sprite(pm_title, temp_title, 2,2,280,16);


   for (x=0;x<16;x++)
      rect(screen, x,x, SCREEN_W-1-x, SCREEN_H-1-x, 8+(x*16) );

   blit(pm_title, screen,0,0,(SCREEN_W/2)-140,20,280,20);

   blit(memory_bitmap[8], screen, 0, 0, 30, 70, 20, 20);
   blit(memory_bitmap[8], screen, 0, 0, SCREEN_W-50, 70, 20, 20);

   draw_sprite(screen, memory_bitmap[401], 28, 50);
   draw_sprite_h_flip(screen, memory_bitmap[401], SCREEN_W-48, 50);

   text_mode(-1);

#ifdef MV
   textout_centre(screen, font, "Michael's Version 7.x", SCREEN_W/2,SCREEN_H-9, 15);
#else
   textout_centre(screen, font, "Version 3.01", SCREEN_W/2,SCREEN_H-9,15);
#endif
   destroy_bitmap(pm_title);
   destroy_bitmap(temp_title);
   text_mode(0);
}
void stretch_text(char *txt1, char* txt2, int col)
{
      BITMAP *btemp;
      BITMAP *stemp;

      int ns = 8; /* num of shadows */
      int so = 1; /* shadow offset */
      int ci = 16; /* color inc  */
      int st = 6;  /* skip step between 1st and 2nd color  */
      int a;

      int bxw, bxh, x_double, y_double;
      int border_x, border_y, final_x, final_y;

      int num_lines = 2;
      int llen;
      int pressline;


      if (strlen(txt2)==0) num_lines = 1;

      if ( strlen(txt2) > strlen(txt1) )
         llen = strlen(txt2);
      else
         llen = strlen(txt1);

      bxw = llen*8;
      bxh = num_lines*8; /* only one line for now */

      x_double = SCREEN_W/bxw;

      x_double /=2;

      y_double = x_double*2;

      border_x = (SCREEN_W-(bxw*x_double))/2;
      border_y = (SCREEN_H-(bxh*y_double))/2;

      final_x = SCREEN_W-border_x*2;
      final_y = SCREEN_H-border_y*2;

      btemp = create_bitmap(bxw, bxh);
      clear(btemp);

      for (a = ns; a >= 0; a--)
         {
            int b = col+a*ci;
            if (a) b = col+( (a+st) * ci); /* not first color */
            textout_centre(btemp, font, txt1, bxw/2, 0, b);
            textout_centre(btemp, font, txt2, bxw/2, 8, b);
            stretch_sprite(screen, btemp, border_x+a, border_y+a, final_x, final_y);
         }
      destroy_bitmap(btemp);

      btemp = create_bitmap(248, 8);
      clear(btemp);
      textout(btemp, font, "...press any key to continue...", 0, 0, 5);

      x_double = SCREEN_W/248;
      if (x_double < 1) x_double = 1;
      y_double = x_double;

      stretch_sprite(screen, btemp, (SCREEN_W-(x_double*248))/2, SCREEN_H-border_y+10, x_double*248, y_double*8);

      destroy_bitmap(btemp);
      press_any();


}


