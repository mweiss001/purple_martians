#include "pm.h"
#include "lift.h"

extern char global_string[20][25][80]; /* menu.c */

struct lift *lifts[20];
struct lift_step *lift_steps[20][20];

char fnlst[50][80]; /* for autoplay */
int fn = 0;

/* global variables  */
BITMAP *memory_bitmap[512];
BITMAP *level_2000, *scrn_buffer;
BITMAP *map100_bmp, *map100_bkg;
BITMAP *dtemp; /* temp draw */
PALLETE pallete;
SAMPLE *snd[20];

int tmy; /* menu pos */
int tmx;

int tmtx, tmty; /* text position */

int mx;
int my;
int md;         /* game map double */
int map_double; /* menu map double */
float steps;

int num_sounds;
int lit_item;
int fuse_loop_playing;
int sample_delay[8];

int bcmt[512];

int sx=640;
int sy=480; /* for screen size */

int comp_move = 0;
int old_comp_move = 0;
int api = 0;
int autoplay[5000][2];
int ap_mode = 0;

int up;
int down;
int left;
int right;

int level_num;
char level_filename[20];

int old_tf;
int oac;

int level_header[20];
int l[100][100];    /* level */
int item[500][16];  /* items */
char *pmsg[500];
int Ei[100][32];    /* enemies */
float Ef[100][16];  /* enemies */

int zz[20][64];
int passcount;

/* timer variables  */
volatile int msec_timer = 0;

/* new x move stuff */
float right_speed=0, left_speed=0;
float initial_x_speed =1.15, max_x_speed=3;
float p_xmove=0;
float accel=.06, de_accel=.3;
float jump_sinc=.05, fall_sinc = 0.1;
float pmovey = 5;

int joy_key = 1;
int joy_buttons = 1;
int joy_jump;
int joy_fire;
int joy_map;
int joy_menu;
int job[5];
int right_key = 38;
int left_key = 36;
int up_key = 23;
int down_key = 37;
int jump_key = 57;
int fire_key = 46;
int map_key = 15;
int menu_key = 41;

int jump;
int fire;
int speed;

int play_level;
int start_mode;

int resume_allowed=0;
int top_menu_sel = 3;
int dif = 2;
int level_time;
float LIFE;
int LIVES;

int start_level=1;
int WX, WY; /* the 16x10 window */
int sound_on = 0;
int frame_speed = 20;


float PX, PY;
int PXint, PYint;
int num_bullets = 100;
float fps;

int max_bullets = 200;

int pbullet[50][6];
int bullet_wait_counter=0, request_bullet = 0;
int bullet_wait = 1, bullet_speed = 12;
int pm_bullet_collision_box = 8;

int e_bullet_active[50], e_bullet_shape[50];
int enemy_bullet_colision_window = 2;
float e_bullet_x[50], e_bullet_y[50], e_bullet_xinc[50], e_bullet_yinc[50];

int bomb[20][5];

float itemf[500][4];

int player_ride;

int player_carry=0;
int fire_held = 0;
int map_held = 0;

int left_right=0;
float jump_count=0, fall_count=0;

int map_on=0;

int level_done = 0;
int game_exit = 0;
int num_enemy;

/* counters and temp string  */
int a, b, c, d, e, f, x, y;
char msg[80];
char b_msg[80];
int bottom_msg=0;
int pop_msg=0;
int pop_msg_count;

int map100_x = 0, map100_y = 20;
int game_map_on=0, top_display_on = 1;
int top_display_x, top_display_y=0, top_display_color=240;
int bottom_display_y=186, bottom_display_color=240;

int map_solid_color = 240, map_semi_color = 3;
int map_break_color = 12, map_empty_color = 241;
int map_enemy_color=5 , map_bullet_color= 14;
int map_item_color=11, map_player_color = 8;

int edit_int_retval;

char scantext[127][80];


void inc_msec_timer()
{
   msec_timer++;
}
END_OF_FUNCTION(inc_msec_timer);


void maps_and_background_fill()
{
   clear(map100_bmp);
   clear(map100_bkg);
   clear(scrn_buffer);

   for (c=0; c < 500; c++) /* set all of itemf[500][4] to 0 */
      for(y=0; y<4; y++)
         itemf[c][y] = 0;

   for (x=0; x<500; x++)
      if (item[x][0]) /* only if active set float x y */
      {
         itemf[x][0] = item[x][4];
         itemf[x][1] = item[x][5];
      }

   for (x = 0; x < 20; x++)
      for (y = 0; y < 5; y++)
         bomb[x][y] = 0;


   for (d=0; d<level_header[5]; d++)
      {
         lifts[d]->fx = lift_steps[d][0] -> x; /* set float x */
         lifts[d]->fy = lift_steps[d][0] -> y; /* set float y */
         lifts[d]->fxinc = 0; /* set float xinc */
         lifts[d]->fyinc = 0; /* set float yinc */

         lifts[d]->current_step = 0;  /* mode 0  */
         lifts[d]->limit_type = 5;  /* type wait for time   */
         lifts[d]->limit_counter = 0;  /* 0 = no wait! immediate next mode  */
      }

   for (x=0; x<100; x++) /* fill maps and background */
      for (y=0; y<100; y++)
         {
            c = l[x][y];
            if (c<512) blit(memory_bitmap[c], level_2000, 0, 0, x*20, y*20, 20, 20);
            if (c == 169) blit(memory_bitmap[0], level_2000, 0, 0, x*20, y*20, 20, 20);
         }

   stretch_blit(level_2000, map100_bkg, 0, 0, 2000, 2000, 0, 0, 100, 100);
   draw_lift_lines();

   for (x=0; x<100; x++) /* finish map */
      for (y=0; y<100; y++)
         {
            c = l[x][y];

            putpixel(map100_bkg, x, y, bcmt[c]);

            if (c == 169)
               putpixel(map100_bkg, x, y, 0 ); /* masked */

            if (c == 0)
               putpixel(map100_bkg, x, y, 241 ); /* empty not masked */

         }

   jump_count=0; fall_count=0;

   for (c = 0; c < 50; c++)
      {
         e_bullet_xinc[c] = 0;
         e_bullet_yinc[c] = 0;
         e_bullet_y[c] = 0;
         e_bullet_x[c] = 0;
         e_bullet_active[c] = 0;
         e_bullet_shape[c] = 0;
         pbullet[c][0] = 0;
         pbullet[c][1] = 0;
         pbullet[c][2] = 0;
         pbullet[c][3] = 0;
         pbullet[c][4] = 0;
         pbullet[c][5] = 0;
      }
}
int sc_setup(void) /* screen change final wrap up and initial setup */
{
   int c;
   top_display_x = (SCREEN_W/2)-95;

   /* clean up old bitmaps */
   for (c=0; c<512; c++)
      destroy_bitmap(memory_bitmap[c]);
   destroy_bitmap(map100_bmp);
   destroy_bitmap(map100_bkg);
   destroy_bitmap(level_2000);
   destroy_bitmap(scrn_buffer);

   /* create new bitmaps  */
   for (c=0; c<512; c++)
      memory_bitmap[c] = create_bitmap(20,20);
   scrn_buffer = create_bitmap(SCREEN_W,SCREEN_H);
   level_2000 = create_bitmap(2000,2000);
   map100_bkg = create_bitmap(100,100);
   map100_bmp = create_bitmap(100,100);

   load_sprit();

   /* zero the pass counters in the animation seqs */
   initialize_zz(passcount);


      for (x=0; x<100; x++) /* fill maps and background */
      for (y=0; y<100; y++)
         {
            c = l[x][y];
            if (c<512) blit(memory_bitmap[c], level_2000, 0, 0, x*20, y*20, 20, 20);
            if (c == 169) blit(memory_bitmap[0], level_2000, 0, 0, x*20, y*20, 20, 20);


         }

   stretch_blit(level_2000, map100_bkg, 0, 0, 2000, 2000, 0, 0, 100, 100);
   set_map_var();

   draw_lift_lines();

   for (x=0; x<100; x++) /* finish map */
      for (y=0; y<100; y++)
         {
            c = l[x][y];

            putpixel(map100_bkg, x, y, bcmt[c]);

            if (c == 169)
               putpixel(map100_bkg, x, y, 0 ); /* masked */

            if (c == 0)
               putpixel(map100_bkg, x, y, 241 ); /* empty not masked */

         }

}
void final_wrapup(void)
{
   int c;
   bad_load_exit: /* jumps here if bad load */
   for (c=0; c<512; c++)
      destroy_bitmap(memory_bitmap[c]);
   destroy_bitmap(map100_bmp);
   destroy_bitmap(map100_bkg);
   destroy_bitmap(level_2000);
   destroy_bitmap(scrn_buffer);
   destroy_bitmap(dtemp);

   for (c=0; c<num_sounds; c++)
      destroy_sample(snd[c]);
   allegro_exit();
}
int initial_setup(void)
{
   int c, x, y;

   allegro_init();
   install_keyboard();
   install_timer();
   install_mouse();
   srandom(time(NULL));  /* random seed from timer */
   menu_setup(); /* load a bunch of text */

   /* get screen size */
   sx = get_config_int("GAME", "sx", 640);
   sy = get_config_int("GAME", "sy", 480);
   sprintf(global_string[8][8], "Screen Mode:%dx%d",sx, sy);
   set_gfx_mode(GFX_AUTODETECT, sx, sy, 0,0);
   top_display_x = (SCREEN_W/2)-95;
   show_mouse(NULL);
   set_map_var();


   /* get sound status */
   sound_on = get_config_int("GAMECONTROLS", "sound_on", 0);
   if (sound_on)
      load_sound(); /*  normal load */
   /* get dif */
   dif = get_config_int("GAMECONTROLS", "dif", 2);
   set_dif();

   /* get speed */
   speed = get_config_int("GAMECONTROLS", "speed", 2);
   set_speed();
   set_start_level(start_level);

   /* get keys */
   load_keys();

   if (joy_key == 1) joy_type = JOY_TYPE_STANDARD;
   if (joy_key == 4) joy_type = JOY_TYPE_4BUTTON;
   if (joy_key)
      if (initialise_joystick())
         {
            textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, SCREEN_H/2, 13);
            joy_key=0;
            rest(1500);
         }


   /* timer stuff */
   LOCK_VARIABLE(msec_timer);
   LOCK_FUNCTION(inc_msec_timer);
   install_int(inc_msec_timer,1);

   for (x=0; x<20; x++)
      for (c=0; c<64; c++)   /* animation initial zeroing */
         zz[x][c] = 0;

   for (c=0; c < 100; c++) /* zero enemies */
      for (y=0; y < 10; y++)
         {
            Ef[c][y] = 0;
            Ei[c][y] = 0;
         }
   for (c=0; c<100; c++) /* set all of l[100][100] to 0 */
      for (y=0; y<100; y++)
         l[c][y]=0;

   for (c=0; c < 500; c++) /* set all of itemf[500][4] to 0 */
      for(y=0; y<4; y++)
         itemf[c][y] = 0;
   for (c=0; c < 500; c++) /* set all of item[500][16] to 0 */
      for (y=0; y < 16; y++)
         item[c][y]=0;

   for (c = 0; c < 512; c++)
      bcmt[c] = 0;

   for (c = 0; c < 5000; c++)
      for (d = 0; d < 2; d++)
         autoplay[c][d] = 0;

   for (c=0; c<512; c++)
      {
         memory_bitmap[c] = create_bitmap(20,20);
         clear(memory_bitmap[c]);
      }
   level_2000 = create_bitmap(2000,2000);
   scrn_buffer = create_bitmap(SCREEN_W,SCREEN_H);
   map100_bkg = create_bitmap(100,100);
   map100_bmp = create_bitmap(100,100);
   dtemp = create_bitmap(20,20);

   if (!load_sprit())
      {
         textout_centre(screen, font, "Error loading sprit file...Exiting",SCREEN_W/2, (SCREEN_H/2)-10, 2);
         rest(1000);
         return 0;
      }
   initialize_zz(0); /* zero the pass counters in the animation seqs */
   maps_and_background_fill();
   clear(screen);
   return 1;
}
int main(int argument_count, char **argument_array)
   {

      if (initial_setup())
         {
            int quit = 0;
            if (argument_count == 2)
               start_level = atoi(argument_array[1]);
            else
               start_level = 1;
            slow_load_and_draw_level(start_level);
            set_start_level(start_level);
            do
               {
                  frame_and_title();
                  draw_level();
                  top_menu_sel = zmenu(7, top_menu_sel, tmy);
                  if ((top_menu_sel == 4) && (resume_allowed))
                     {
                        start_mode = 0;  /* resume */
                        game_exit = 0;

                     
                        for (x=0; x<100; x++) /* fill l2000 with blocks */
                           for (y=0; y<100; y++)
                              {
                                 c = l[x][y];
                                 if (c<512) blit(memory_bitmap[c], level_2000, 0, 0, x*20, y*20, 20, 20);
                                 if (c == 169) blit(memory_bitmap[0], level_2000, 0, 0, x*20, y*20, 20, 20);
                              }
                        draw_lift_lines();

                        pm_main();
                     }
                  if (top_menu_sel == 3)
                     {
                        level_done = 0;
                        play_level = start_level;
                        num_bullets = 200;
                        LIVES = 5;
                        LIFE = 100;
                        start_mode = 1; /* load start */
                        game_exit = 0;
                        pm_main();
                     }
                  if (top_menu_sel == 5) /* load game */
                     {
                        if (load_game())
                           {
                              start_mode = 0;
                              game_exit = 0;
                              pm_main();
                           }
                       clear(screen);
                     }
                  if ((top_menu_sel == 6) && (resume_allowed))
                     {
                        save_game();
                        clear(screen);
                     }

                  if (top_menu_sel == 2) /* START LEVEL */
                     {
                        int old_mouse;
                        int old_start_level = -1;
                        int quit = 0;
                        while (key[KEY_ENTER]);
                        while (mouse_b&1);
                        while (joy_b1) poll_joystick(); /* wait for release */
                        while (!quit)
                           {
                              resume_allowed = 0;
                              if (joy_key) poll_joystick();
                              /* make it red */
                              sprintf(msg, " (%d) " ,start_level );

                              textout(screen, font, msg, -(8*(strlen(msg)-1)) + tmx + (strlen(global_string[7][2])*8) / 2, tmy+16, 10);
                              if ((key[KEY_UP]) || (key[up_key]) || (joy_up))
                                 {
                                    if (++start_level > 99) start_level=99;
                                    while ((key[KEY_UP]) || (key[up_key]));
                                    while (joy_up) poll_joystick(); /* wait for release */
                                 }
                              if ((key[KEY_DOWN]) || (key[down_key]) || (joy_down))
                                 {
                                    if (--start_level < 1) start_level=1;
                                    while ((key[KEY_DOWN]) || (key[down_key]));
                                    while (joy_down) poll_joystick(); /* wait for release */
                                 }
                              position_mouse(160,100);
                              old_mouse = mouse_y;
      
                              /* show start level here */
                              if (old_start_level != start_level)
                                 {
                                    old_start_level = start_level;
                                    slow_load_and_draw_level(start_level);
                                    old_mouse = mouse_y; /* to make it easier to stay on a certain level */
                                 }
                              else rest(10);
                              if (mouse_y > old_mouse) if (--start_level < 1) start_level=1;
                              if (mouse_y < old_mouse) if (++start_level > 99) start_level = 99;
      
                              if (key[KEY_ESC]) quit = 1;
                              if (key[KEY_ENTER]) quit = 1;
                              if ((mouse_b&1) || (mouse_b&2)) quit = 1;
                              if (joy_b1) quit = 1;
                            } /* end of while ! quit */
                            while ((key[KEY_ESC]) || (key[KEY_ENTER]));
                            while ((mouse_b&1) || (mouse_b&2));
                            while (joy_b1) poll_joystick(); /* wait for release */
                            top_menu_sel = 3; /* change to START LEVEL */
                            set_start_level(start_level);
                     }
      
                  if (top_menu_sel == 8) help(0); /* help */
                  if (top_menu_sel == 9)
                     {

                        clear_keybuf();
                        demo_mode();
                     }
                  if (top_menu_sel == 7) /* OPTIONS MENU */
                     {
                        int options_menu_sel = 2;
                        do
                           {
                              clear(screen);
                              frame_and_title();
                              options_menu_sel = zmenu(8,options_menu_sel,50);
                              if (options_menu_sel == 3)
                                 {
                                   get_keys();
                                 }

                             if (options_menu_sel == 4)
                                 {
                                    cal_joy();
                                 }
                              if (options_menu_sel == 5) /* Difficulty  */
                                 {
                                     if (++dif > 3) dif=1;
                                     set_dif();
                                 }
                              if (options_menu_sel == 6) /* Speed */
                                 {
                                    if (++speed > 5) speed = 1;

                                    set_speed();
                                 }
                              if (options_menu_sel == 7) /* Sound */
                                 {
                                    sound_setup();
                                 }
                               if (options_menu_sel == 8) /* set screen mode */
                                 {
                                    int l = start_level;
                                    int card = GFX_AUTODETECT;
                                    int w = sx;
                                    int h = sy;
                                    int color_depth = 8;
        
                                    if (gfx_mode_select_ex(&card, &w, &h, &color_depth))
                                       if (set_gfx_mode(card, w, h, 0, 0) < 0)
                                          {
                                            set_gfx_mode(GFX_AUTODETECT, sx, sy, 0, 0);
                                            sc_setup();
                                            gui_fg_color = 255;
                                            gui_mg_color = 8;
                                            gui_bg_color = 0;
                        	            alert("Error setting mode:", allegro_error, NULL, "Sorry", NULL, 13, 0);
                                          }
                                       else
                                         {
                                             sx = w;
                                             sy = h;
                                             set_config_int("GAME", "sx", sx);
                                             set_config_int("GAME", "sy", sy);
                                             sprintf(global_string[8][8], "Screen Mode:%dx%d",sx, sy);
                                             sc_setup();
                                         }
                                 }

                              if (options_menu_sel == 9) /* Level Editor */
                                 {
                                    int l, l2 = start_level;
                                    char fname[20];
                                    final_wrapup();
                                    sprintf(fname, "pmfle.exe %d", l2);
                                    l = system(fname); /* set level num from level editor */
                                    initial_setup();

/*
                                  if (l > 50)
                                     {
                                        sprintf(msg, "pmfle.exe returned %d", l);
                      	                alert(msg, NULL, NULL, "Sorry", NULL, 13, 0);
                                     }
*/
                                    if ((l == 0) || (l == 255))
                                       {
                                          set_start_level(l2); /* original start level */
                                          slow_load_and_draw_level(start_level);
                                          resume_allowed = 0;
                                          top_menu_sel = 3;

                                       }
                                    else /* immediately start playing the returned level */
                                       {
                                          set_start_level(l);
                                          play_level = l;
                                          level_done = 0;
                                          num_bullets = 200;
                                          LIVES = 5;
                                          LIFE = 100;
                                          start_mode = 1;
                                          game_exit = 0;
                                          pm_main();
                                          top_menu_sel = 4;
                                      }
                                 }
#ifdef MV

                              if (options_menu_sel == 10) /* record autoplay */
                                 {
                                    ap_mode = 2;
                                    api = 0;
                                    textout_centre(screen, font, "Record Autoplay!",SCREEN_W/2, (SCREEN_H*4)/5, 10);
                                    level_done = 0;
                                    play_level = start_level;
                                    num_bullets = 200;
                                    LIVES = 5;
                                    LIFE = 100;
                                    start_mode = 1; /* load start */
                                    game_exit = 0;
                                    pm_main();
                                    ap_mode = 0;
                  
                                 }
                              if (options_menu_sel == 11) /* run autoplay */
                                 {
                                    int l = start_level;
                                    ap_mode = 1;
                                    load_apl(0);
                                    api = 0;
                                    textout_centre(screen, font, "Autoplay!",SCREEN_W/2, (SCREEN_H*4)/5, 241);
                                    level_done = 0;
                                    num_bullets = 200;
                                    LIVES = 5;
                                    LIFE = 100;
                                    start_mode = 1; /* load start */
                                    game_exit = 0;
                                    pm_main();
                                    set_start_level(l); /* original start level */
                                    initial_setup();
                                    slow_load_and_draw_level(start_level);
                                    resume_allowed = 0;
                                    top_menu_sel = 3;
                                    ap_mode = 0;
                                 }
                  
#endif


                           }  while (options_menu_sel != 2); /* end of options menu */
                        save_keys();
                        rest(100);
                        clear(screen);
                     }

                  if (key[KEY_ESC]) quit = 1;
             }  while (top_menu_sel != 1); /* end of game menu */
         }
      show_mouse(NULL);

      /* redraw frame */
      for (x=0;x<16;x++)
         rect(screen, x,x, SCREEN_W-1-x, SCREEN_H-1-x, 8+(x*16) );

      text_mode(-1);
      textout_centre(screen, font, "Thank you for playing Purple Martians!", SCREEN_W/2,SCREEN_H-9, 15);
      text_mode(0);

      rest(1500);
      final_wrapup();
      exit(0);
   }

