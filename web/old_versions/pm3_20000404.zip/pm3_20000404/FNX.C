#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>
#include "lift.h"

/* for is_solid functions */
extern int l[100][100];
extern int level_header[20];

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

void tsw(void)
{
   clear_keybuf();
   while (!keypressed());
   clear_keybuf();
}
void set_lift_initial_not_in_file(int lift)
{
      lifts[lift] -> x1 = lift_steps[lift][0] -> x;  /* from step 0 */
      lifts[lift] -> y1 = lift_steps[lift][0] -> y;
      lifts[lift] -> x2 = lifts[lift] -> x1 + lifts[lift] -> width*20-1; /* width */
      lifts[lift] -> y2 = lifts[lift] -> y1 + lifts[lift] -> height*20-1; /* height */

      lifts[lift]->fx = lifts[lift] -> x1; /* set float x */
      lifts[lift]->fy = lifts[lift] -> y1; /* set float y */
      lifts[lift]->fxinc = 0; /* set float xinc */
      lifts[lift]->fyinc = 0; /* set float yinc */

      lifts[lift] -> current_step = 0;
      lifts[lift] -> limit_counter = 0;
      lifts[lift] -> limit_type = 5;
}
int construct_lift(int l,char* lift_name,int width,int height,int color,int num_steps)
{
   int ret = 0;/*  allocate new lift */
   if (lifts[l] = (struct lift*) malloc(sizeof(struct lift))) ret = 1;
   /* fill with passed data */
   lifts[l] -> num_steps = num_steps;
   lifts[l] -> width = width;
   lifts[l] -> height = height;
   lifts[l] -> color = color;
   /*  allocate space for string */
   lifts[l] -> lift_name = (char*) malloc(strlen(lift_name)+1);
   strcpy(lifts[l] -> lift_name, lift_name);
   return ret;
}
void destroy_lift(int lift)
{
   if (lifts[lift] != NULL) /* only free if non null pointer */
      {
         /* first free the string */
         if (lifts[lift] -> lift_name != NULL) /* only free if non null pointer */
            free(lifts[lift] -> lift_name);
         /* then free the lift structure */
         free(lifts[lift]);
      }
}
void destroy_lift_step(int lift, int step)
{
    if (lift_steps[lift][step] != NULL)
       free(lift_steps[lift][step]);
}
int construct_lift_step(int lift, int step, int x, int y, int val, int type)
{
   /*  allocate a new step */
   int ret = 0;
   if (lift_steps[lift][step] = (struct lift_step*) malloc(sizeof(struct lift_step))) ret = 1;
   lift_steps[lift][step] -> x    = x;
   lift_steps[lift][step] -> y    = y;
   lift_steps[lift][step] -> val  = val;
   lift_steps[lift][step] -> type = type;
   return ret;
}

int edit_int( int x, int y, int initial, int inc, int lv, int uv)
{
extern int edit_int_retval;
int imx = mouse_x;
int imy = mouse_y;
int quit_mode = 0, retval, quit=0, old_mouse;
char msg[80];

if (mouse_b & 1) quit_mode = 1;   /* set mouse exit mode if b1 pressed on enter */
clear_keybuf();
do
   {
      sprintf(msg,"%d  ",initial);
      textout(screen, font, msg, x, y, 1);
      if (key[KEY_UP])
         {
            clear_keybuf();
            rest(5);
            initial += inc;

         }
     if (key[KEY_DOWN])
         {
            clear_keybuf();
            rest(5);
            initial -= inc;
         }
  if (quit_mode == 1)
   {
        if (!(mouse_b & 1))
         {
            clear_keybuf();
            sprintf(msg,"%d  ",initial);
            textout(screen, font, msg, x, y, 34);
            edit_int_retval = initial;
            retval = 1;
            quit = 1;

         }
   }
if (quit_mode == 0)
   {
    if ((key[KEY_ENTER]) || (mouse_b & 1))
         {
            clear_keybuf();
            sprintf(msg,"%d  ",initial);
            textout(screen, font, msg, x, y, 34);
            edit_int_retval = initial;
            retval = 1;
            quit = 1;

         }
   }
    if ((key[KEY_ESC]) || (mouse_b & 2))
         {
            clear_keybuf();
            retval = 0;
            quit = 1;

         }
    position_mouse(160, 100);
    old_mouse = mouse_y;
    rest(10);
    initial = initial - ((mouse_y - old_mouse) * inc);
    if (initial > uv) initial = uv;
    if (initial < lv) initial = lv;
   } while (!quit);

position_mouse(imx, imy);
return retval;
}

void initialize_zz(int pc)
{
   extern int passcount;
   extern int zz[20][64];
   int c;
   for (c=0; c<64; c++)
      zz[2][c] = pc;  /* reset the passcount */
   passcount = pc;
}

void update_animation(void)
{
   extern int passcount;
   extern int zz[20][64];
   int y;
   passcount++;   /* animation update */
   for (y=0; y<64; y++)
      if (zz[4][y] != 0)
         if ((passcount - zz[2][y]) > zz[3][y])
            {
               zz[1][y]++;     /* next bitmap */
               zz[2][y] = passcount;      /* set counter */
               if (zz[1][y] > zz[4][y]) zz[1][y] = 0;    /* is bitmap past end? */
               zz[0][y] = zz[ 5 + zz[1][y] ] [y];      /* put shape in 0 */
            }
}


int get_rot_from_xyinc(int EN)
{
extern float Ef[100][16];
float angle, xlen, ylen;
int rot=0;


xlen = abs(Ef[EN][2]);
if (xlen == 0) xlen = .001; /* to prevent divide by zero */
ylen = abs(Ef[EN][3]);

angle = atan(ylen/xlen);
angle *= (64/1.57); /* convert from radians (0 to pi/2) to fixed (0 to 64) */


if (Ef[EN][2] <= 0)    /* xinc <= 0 */
    {
       if (Ef[EN][3] <= 0) rot += 64+angle;   /* yinc <= 0 */
       if (Ef[EN][3] >  0) rot += 64-angle;   /* yinc > 0 */
    }
if (Ef[EN][2] > 0)    /* xinc > 0 */
    {
       rot += 128;
       if (Ef[EN][3] >  0) rot += 64+angle;   /* yinc > 0 */
       if (Ef[EN][3] <= 0) rot += 64-angle;   /* yinc <= 0 */
    }
return rot;

}
void seek_set_xyinc(int EN, int EXint, int EYint)
{
extern float Ef[100][16];
extern int PXint, PYint;
float angle, xlen, ylen, xinc, yinc;

xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .001;
ylen = abs(PYint - EYint);

angle = atan(ylen/xlen);
xinc = cos(angle) * Ef[EN][8];  /* hypotenuse is the speed! */
yinc = sin(angle) * Ef[EN][8];

if (EXint < PXint) Ef[EN][2] = +xinc;
if (EXint > PXint) Ef[EN][2] = -xinc;
if (EYint < PYint) Ef[EN][3] = +yinc;
if (EYint > PYint) Ef[EN][3] = -yinc;
}

int get_rot_from_PXY(int EN, int EXint, int EYint)
{
extern float Ef[100][16];
extern int PXint, PYint;
float angle, xlen, ylen;
int rot=0;

xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .001; /* to prevent divide by zero */
ylen = abs(PYint - EYint);

angle = atan(ylen/xlen);
angle *= (64/1.57); /* convert from radians (0 to pi/2) to fixed (0 to 64) */

if (EXint >= PXint)
    {
       if (EYint >= PYint) rot += 64+angle;
       if (EYint <  PYint) rot += 64-angle;
    }
if (EXint < PXint)
    {
       rot += 128;
       if (EYint <= PYint) rot += 64+angle;
       if (EYint >  PYint) rot += 64-angle;
    }
return rot;
}
void fire_enemy_bulleta(int EN, int EXint, int EYint, int ans) /* animation */
{
extern int e_bullet_active[50];
extern int e_bullet_shape[50];
extern int zz[20][64];
extern float e_bullet_x[50];
extern float e_bullet_y[50];
extern float e_bullet_xinc[50];
extern float e_bullet_yinc[50];
extern float Ef[100][16];
extern int PXint, PYint;


float angle, xlen, ylen, xinc, yinc;
int z;


xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .00001;
ylen = abs(PYint - EYint);
if (ylen == 0) ylen = .00001;
angle = atan(ylen/xlen);
xinc = cos(angle) * Ef[EN][7];
yinc = sin(angle) * Ef[EN][7];

for (z=0; z<50; z++)  /* find empty e_bullet */
   if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_shape[z] = 1000+ans;
         e_bullet_x[z] = EXint;
         e_bullet_y[z] = EYint;
         if (EXint <  PXint) e_bullet_xinc[z] = +xinc;
         if (EXint >  PXint) e_bullet_xinc[z] = -xinc;
         if (EXint == PXint) e_bullet_xinc[z] = 0;
         if (EYint <  PYint) e_bullet_yinc[z] = +yinc;
         if (EYint >  PYint) e_bullet_yinc[z] = -yinc;
         if (EYint == PYint) e_bullet_yinc[z] = 0;

         switch (ans) {
            case 54: event(17); break; /* green */
            case 55: event(18); break; /* cannonball */
            case 20: event(19); break; /* twirly */

         }
         z=50;
      }
}

void fire_enemy_x_bullet(int EN, int EXint, int EYint)
{
extern int e_bullet_active[50];
extern int e_bullet_shape[50];
extern float e_bullet_x[50];
extern float e_bullet_y[50];
extern float e_bullet_xinc[50];
extern float e_bullet_yinc[50];
extern float Ef[100][16];
extern int PXint, PYint;
int x_bullet_speed = Ef[EN][7];
int z;

if ((x_bullet_speed < 1) || (x_bullet_speed > 20))  /* for old ones! */

   x_bullet_speed = abs(Ef[EN][2] * 3);  /* bullet speed fromx move */

for (z=0; z<50; z++)  /* find empty e_bullet */
   if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_yinc[z] = 0;
         e_bullet_x[z] = EXint;
         e_bullet_y[z] = EYint;
         if (EXint < PXint)
            {
               e_bullet_xinc[z] = x_bullet_speed;
               e_bullet_shape[z] = 488;
            }
         if (EXint >= PXint)
            {
               e_bullet_xinc[z] = -x_bullet_speed;
               e_bullet_shape[z] = 489;
            }
         event(16);
         z=50; /* end loop */
      }
}
int is_right_solid(int solid_x, int solid_y)
{
         int a, b, c, d;
         int xx = (solid_x / 20) + 1;
         int yy = (solid_y / 20);
         int cc = (solid_y / 20) + 1;
         a = solid_y % 20;
          for (d = 0; d<level_header[5]; d++)
               if (solid_y > lifts[d]->y1 - 18)
                  if (solid_y < lifts[d]->y2 - 2)
                     if (solid_x < lifts[d]->x1 - 8)
                        if (solid_x > lifts[d]->x1 - 18)
                           return 32+d;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][cc];
                 if ((c > 7 ) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17)) /* dual compare with ||  */
             {
                 b = l[xx][yy];
                 c = l[xx][cc];
                 if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }


         return 0;
}
 int is_left_solid(int solid_x, int solid_y)
{


         int a, b, c, d;
         int xx = (solid_x / 20);
         int yy = (solid_y / 20);
         int cc = (solid_y / 20)+1;
         a = solid_y % 20;
          for (d = 0; d<level_header[5]; d++)
               if (solid_y > lifts[d]->y1 - 18)
                  if (solid_y < lifts[d]->y2 - 2)
                     if (solid_x < lifts[d]->x2 + 2)
                        if (solid_x > lifts[d]->x2 - 8)
                           return 32+d;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][cc];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17))/* dual compare with ||  */
             {
                b = l[xx][yy];
                c = l[xx][cc];
                if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }

         return 0;
}
int is_down_solid(int solid_x, int solid_y, int lift_check)
{
   int a, b, c, d;
   int yy = (solid_y / 20)+1;
   int cc = (solid_x / 20);
   int xx = (solid_x / 20)+1;
   a = solid_x % 20;

   if (lift_check)
      for (d = 0; d<level_header[5]; d++)  /* check for mov first */
            if (solid_x > lifts[d]->x1-18)
               if (solid_x < lifts[d]->x2-2)
                  if (solid_y > lifts[d]->y1 - 25)
                     if (solid_y < lifts[d]->y1 - 10)
                         return d+32;

   if (a > 16)  /* next block only */
       {
           c = l[xx][yy];
           if ((c > 7) && (c < 256)) return 1;
       }
   if (a < 3)    /* this block only */
       {
           c = l[cc][yy];
           if ((c > 7) && (c < 256)) return 1;
       }
   if ((a > 2) && (a <17)) /* dual compare with ||  */
       {
           b = l[xx][yy];
           c = l[cc][yy];
           if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
       }

   return 0;
}

int is_up_solid(int solid_x, int solid_y, int lift_check, int semi_check)
{
         int a, b, c, d, e;
         int yy = (solid_y-2)/20;
         int cc = (solid_x / 20);
         int xx = (solid_x / 20)+1;
         if (semi_check) e = 7;
         else e = 15;
         a = solid_x % 20;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][yy];

                 if ((c > e) && (c < 512)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[cc][yy];

                 if ((c > e) && (c < 512)) return 1;
             }
         if ((a > 2) && (a < 17))/* dual compare with ||  */
             {
                 b = l[cc][yy];
                 c = l[xx][yy];
                 if ( ((b > e) && (b < 512)) || ((c > e) && (c < 512)) ) return 1;
             }
         if (lift_check)
            for (d = 0; d<level_header[5]; d++)
                  if (solid_x > lifts[d]->x1 - 18)
                     if (solid_x < lifts[d]->x2 - 2)
                        if (solid_y < lifts[d]->y2 + 2)
                           if (solid_y > lifts[d]->y2 - 10)
                              return 2;
         return 0;
}

void draw_lift_lines()
{
  extern BITMAP *level_2000;
  int x, y, c;

  for (x=0; x<level_header[5]; x++)  /* cycle lifts */
       {
          int col = lifts[x]->color+128;
          int sx = lift_steps[x][0] -> x + lifts[x]->width*10;
          int sy = lift_steps[x][0] -> y + lifts[x]->height*10;
          int px = sx;
          int py = sy;
          int nx;
          int ny;

          for (y=0; y<lifts[x]->num_steps; y++)  /* cycle step*/
             if (lift_steps[x][y] -> type == 1) /* look for move step */
                {
                   nx = lift_steps[x][y] -> x + lifts[x]->width*10;
                   ny = lift_steps[x][y] -> y + lifts[x]->height*10;;
                   line (level_2000, px, py, nx, ny, col);

                   for (c=3; c>=0; c--)
                      {
                         circlefill (level_2000, nx, ny, c,  (col-96)+c*48 );
                      }

                   px = nx;
                   py = ny;
                }
             line (level_2000, sx, sy, nx, ny, col);
       }
}



