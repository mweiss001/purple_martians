#include "pm.h"
#include "lift.h"

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];


FILE *filepntr;
extern char level_filename[20];
extern int level_header[20];
extern int l[100][100];
extern int item[500][16];
extern char *pmsg[500];
extern float itemf[500][4];
extern int Ei[100][32];
extern float Ef[100][16];

extern int mx;
extern int my;
extern int md; /*map double */

void make_filename(int x)
{
   char temp[20];
   extern char level_filename[20];
   char msg[80];
   
   strcpy( temp, "LEVEL");

   if ((x >  0) && (x < 10  )) sprintf(msg,"00%-1d", x);
   if ((x >  9) && (x < 100 )) sprintf(msg,"0%-2d", x);
   if ((x > 99) && (x < 1000)) sprintf(msg,"%-3d", x);

   strcat( temp, msg);
   strcat( temp, ".PML");
   strcpy(level_filename, temp);
}
int load_sprit(void)
{
   char sprit_filename[20] = "SPRIT001.PM";
   extern BITMAP *memory_bitmap[512];
   extern PALLETE pallete;
   extern int zz[20][64];
   extern int bcmt[512];
   
   int sprit_load_error = 0;
   int c, x, y;
   int dsp = 0;
   char msg[80];

   if (dsp) textout(screen, font, "Loading shapes...", SCREEN_W/2, (SCREEN_H*3)/4, 1);
   sprit_load_error = 0;
   if (exists(sprit_filename) == 0) /* does file exist? */
      {
         sprintf(msg, "Can't find sprit %s ", sprit_filename);
         textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
         sprit_load_error = 1;
      }
   if (!sprit_load_error)  /* open file */
      if ((filepntr=fopen(sprit_filename,"rb")) == NULL)
         {
            sprintf(msg, "Error opening %s ", sprit_filename);
            textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
            sprit_load_error = 1;
         }
   if (!sprit_load_error)  /* file open ! */
      {
         for (c=0; c<512; c++)   /* 512 bitmaps */
            {
               if (dsp)
                  {
                     sprintf(msg,".%d ", 512-c);
                     textout(screen, font, msg, 152, 184, 1);
                  }
               for (y=0; y<20; y++)
                  for (x=0; x<20; x++)
                     putpixel(memory_bitmap[c],x,y, fgetc(filepntr));
             }
         for (c=0; c<256; c++)      /* 256 colors */
               {
                  pallete[c].r = fgetc(filepntr);
                  pallete[c].g = fgetc(filepntr);
                  pallete[c].b = fgetc(filepntr);
               }
         for (c=0; c<64; c++)
            for (y=0; y<20; y++)
               {
                  x = fgetc(filepntr);
                  if (x) zz[y][c] = 256 + fgetc(filepntr);
                  else   zz[y][c] = fgetc(filepntr);
               }
         for (c=0; c<512; c++)
           for (y=0; y<2; y++)    /* fill nulls for sa not used in game */
               {
                  x = fgetc(filepntr);
               }
         for (c=0; c<512; c++)    /* get bcmt[512] */
               {
                  bcmt[c] = fgetc(filepntr);
               }
      } /* end of if not sprit load error */
   fclose(filepntr);
   set_pallete(pallete);
   if (sprit_load_error)
      {
         rest(2000);
         return 0;
      }
   else return 1;
}
int load_level(int level_to_load, int display)
{
   int loop, ch, c, d, x, y;
   char buff[2000];
   char msg[80];
   make_filename(level_to_load);   /* update filename */
   if (display)
      {
         sprintf(msg, "...loading level %d...", level_to_load);
         textout_centre(screen, font, msg, SCREEN_W/2, (SCREEN_H)/2+8, 10);
      }
   if ((exists(level_filename)) == 0)
      {
         if (display)
            {
               sprintf(msg, "Can't Find Level %s ", level_filename);
               textout_centre(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 10);
               rest(3000);
            }
         return 0;
      }
   /* erase all old data */
   for (c=0; c<100; c++)  /* level */
      for (x=0; x<100; x++)
         l[c][x] = 0;
   for (c=0; c < 500; c++)  /* items */
      {
         if (item[c][0] == 10) free (pmsg[c]);
         for (x=0; x<16; x++)
            item[c][x] = 0;
      }
   for (c=0; c < 100; c++)  /* enemy float */
      for (x=0; x<16; x++)
         Ef[c][x] = 0;

   for (c=0; c < 100; c++) /* enemy int */
      for (x=0; x<32; x++)
         Ei[c][x] = 0;

   for (c = 0; c < level_header[5]; c++) /* lifts - free mem if allocated */
      {
         for (x = 0; x<lifts[c] -> num_steps; x++)
            destroy_lift_step(c,x);
         destroy_lift(c);

      }
   for (x=0; x<20; x++)
      level_header[x] = 0;

   if ((filepntr=fopen(level_filename,"r")) == NULL)
      {
         sprintf(msg, "Error opening %s ", level_filename);
         textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
         rest(3000);
         return 0;
      }

   for (c=0; c<20; c++) /* level header */
      {
         loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
            {
               buff[loop] = ch;
               loop++;
               ch = fgetc(filepntr);
            }
         buff[loop] = NULL;
         level_header[c] = atoi(buff);
         if (ch == EOF)
            {
               sprintf(msg, "Error reading %s ", level_filename);
               textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
               rest(3000);
               return 0;
            }
      }
   for (c=0; c<100; c++)  /* l[100][100] */
      for (y=0; y<100; y++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                   buff[loop] = ch;
                   loop++;
                   ch = fgetc(filepntr);
               }
            buff[loop] = NULL;
            l[c][y] = atoi(buff);
            if (ch == EOF)
               {
                  sprintf(msg, "Error reading %s ", level_filename);
                  textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                  rest(3000);
                  return 0;
               }
         }
   for (c = 0; c < level_header[3]; c++)  /* read item */
      {
         for (x = 0; x < 16; x++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                      buff[loop] = ch;
                      loop++;
                      ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               item[c][x] = atoi(buff);
               if (ch == EOF)
                  {
                     sprintf(msg, "Error reading items in %s ", level_filename);
                     textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                     rest(3000);
                     return 0;
                  }
            }
         itemf[c][0] = item[c][4]; /* set them here */
         itemf[c][1] = item[c][5];
         if (item[c][0] == 10) /* get pmsg */
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                      if (ch == 126) ch = 13;
                      buff[loop] = ch;
                      loop++;
                      ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               pmsg[c] = (char*) malloc (strlen(buff)+1);
               strcpy(pmsg[c], buff);
            }
      }
   for (c=0; c<level_header[4]; c++) /* read enemy floats */
      for (x=0; x<16; x++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                  buff[loop] = ch;
                  loop++;
                  ch = fgetc(filepntr);
               }
            buff[loop] = NULL;
            Ef[c][x] = atof(buff);
            if (ch == EOF)
               {
                  sprintf(msg, "Error reading Ef in %s ", level_filename);
                  textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                  rest(3000);
                  return 0;
               }
         }
   for (c=0; c < level_header[4]; c++)  /* enemy ints */
      for (x=0; x<32; x++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                   buff[loop] = ch;
                   loop++;
                   ch = fgetc(filepntr);
               }
            buff[loop] = NULL;
            Ei[c][x] = atoi(buff);
            if (ch == EOF)
               {
                  sprintf(msg, "Error reading Ei in %s ", level_filename);
                  textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                  rest(3000);
                  return 0;
               }
         }
   for (c=0; c<level_header[5]; c++) /* read lifts */
      {
         int tr[5];
         char tmsg[80];
         for (x=0; x<5; x++) /* lift data */
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                      buff[loop] = ch;
                      loop++;
                      ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               if (x == 0) strcpy(tmsg, buff); /* get lift name */
               else tr[x] = atoi(buff); /* get int */
            }
         construct_lift(c,tmsg,tr[1],tr[2],tr[3],tr[4]);
         for (x=0; x<lifts[c] -> num_steps; x++) /* step data */
            {
               int tr[4];
               for (y=0; y<4; y++) /* read 4 */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     tr[y] = atoi(buff);
                  }
               construct_lift_step(c, x, tr[0], tr[1], tr[2], tr[3]);
            }
         set_lift_initial_not_in_file(c);
      }
   fclose(filepntr);
   return 1;
}

int quick_load_level(int level_to_load, int display)
{
   FILE *filepntr;
   int loop, ch, c, x, y;
   char buff[20];
   char msg[80];

   make_filename(level_to_load);   /* update filename */

   sprintf(msg, "...loading level %d...", level_to_load);
   textout_centre(screen, font, msg, SCREEN_W/2, (SCREEN_H)/2+8, 10);

   filepntr=fopen(level_filename,"r");

   for (c=0; c<20; c++) /* level header */
      {
         loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
            {
               buff[loop] = ch;
               loop++;
               ch = fgetc(filepntr);
            }
         buff[loop] = NULL;
         level_header[c] = atoi(buff);
      }
   for (c=0; c<100; c++)  /* l[100][100] */
      for (y=0; y<100; y++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                   buff[loop] = ch;
                   loop++;
                   ch = fgetc(filepntr);
               }
            buff[loop] = NULL;
            l[c][y] = atoi(buff);
         }

   fclose(filepntr);

}
void restore_l2000(void) /* used by stimp */
{
   extern BITMAP *level_2000;
   extern BITMAP *memory_bitmap[512];
   int c, x, y;
      for (x=0; x<100; x++) /* fill l2000 with blocks */
         for (y=0; y<100; y++)
            {
               c = l[x][y];
               if (c<512) blit(memory_bitmap[c], level_2000, 0, 0, x*20, y*20, 20, 20);
               if (c == 169) blit(memory_bitmap[0], level_2000, 0, 0, x*20, y*20, 20, 20);
            }
   draw_lift_lines();
}
void add_eilp_to_l2000(void)
{
   extern BITMAP *level_2000;
   extern BITMAP *memory_bitmap[512];
   extern BITMAP *dtemp;
   extern int zz[20][64];
   extern int up;
   extern int down;
   extern int PXint;
   extern int PYint;
   extern int player_ride;
   extern int left_right;
   extern float PX;
   extern float PY;
   extern float jump_count;
   extern float fall_count;
   extern float right_speed;
   extern float left_speed;
   
   int a, b, c, d, e, f, g, x, y, z;
   char msg[80];

   for (x=0; x<100; x++) /* fill l2000 with blocks */
      for (y=0; y<100; y++)
         {
            c = l[x][y];
            if (c<512) blit(memory_bitmap[c], level_2000, 0, 0, x*20, y*20, 20, 20);
            if (c == 169) blit(memory_bitmap[0], level_2000, 0, 0, x*20, y*20, 20, 20);
         }

   PXint = PX;
   PYint = PY;
   b = 9;

   if (up)   b=10;
   if (down) b=11;

   x = (PXint/4) % zz[4][b];
   if ((jump_count) || (fall_count)) x = 0;
   if ((player_ride) && (right_speed<.5) && (left_speed<.5)) x = 0;
   y = zz[x+5][b];

   if (left_right) draw_sprite(level_2000, memory_bitmap[y], PXint, PYint);
   else draw_sprite_h_flip(level_2000, memory_bitmap[y], PXint, PYint);

   for (e = 0; e < 100; e++)
      if (Ei[e][0])  /* if enemy active */
         {
            int EXint = Ef[e][0];
            int EYint = Ef[e][1];

            /* set initial cannon rot */

            if ((Ei[e][0] == 5) || (Ei[e][0] == 6))
               Ei[e][20] = get_rot_from_PXY(e, EXint, EYint);

            /* set bouncer rot */

            if ((Ei[e][0] == 4) )
               Ei[e][20] = get_rot_from_xyinc(e);


            clear(dtemp);
            /* put shape in dtemp and process flips */
            if (Ei[e][2] == 0)  draw_sprite_h_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
            if (Ei[e][2] == 1)         draw_sprite(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
            if (Ei[e][2] == 2)  draw_sprite_v_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
            if (Ei[e][2] == 3) draw_sprite_vh_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
            /* process rotation */
            if (Ei[e][20])
               rotate_sprite(level_2000, dtemp, EXint, EYint, itofix(Ei[e][20]) );
            else draw_sprite(level_2000, dtemp, EXint, EYint);
         } /* end of if active */
   for (c=0; c<500; c++) /*  items */
      if (item[c][0])   /* if not type 0  */
         {
            int shape = 255; /* default */
            x = (int) itemf[c][0];
            y = (int) itemf[c][1];

            /* get shape */
            a = item[c][1];
            if (a < 512) shape = a; /* bitmap */
            if (a > 999) shape = zz[0][a-1000]; /* ans */
            /* do draw mode */
            if (item[c][0] == 11) rotate_sprite(level_2000, memory_bitmap[shape], x, y, itofix(item[c][10]/10));
            else if (item[c][2] == 1) /* draw mode normal */
                draw_sprite(level_2000, memory_bitmap[shape], x, y);
          }
   draw_lift_lines();
   for (d=0; d<level_header[5]; d++)
      {
         int x1 = lifts[d]->x1;
         int x2 = lifts[d]->x2;
         int y1 = lifts[d]->y1;
         int y2 = lifts[d]->y2;
         int color = lifts[d]->color;

         for (a=0; a<10; a++)
            rect(level_2000, x1+a, y1+a, x2-a, y2-a, color + ((9 - a)*16) );
         rectfill(level_2000, x1+a, y1+a, x2-a, y2-a, color );
         textout_centre(level_2000, font, lifts[d]->lift_name, ((x1+x2)/2), ((y1+y2)/2)-2, color+160);
      }  /* end of draw lifts */
}
void draw_level(void) /* draws the map on the menu screen */
{
   extern int play_level, resume_allowed;
   extern BITMAP *level_2000;
   extern int tmtx, tmty;
   add_eilp_to_l2000();
   set_clip(screen, 0, 0, SCREEN_W, SCREEN_H-16);
   stretch_blit(level_2000, screen, 0,0,2000,2000,mx,my,md*100,md*100);
   if (md == 1) /* to get proper block colors */
      {
         extern int bcmt[512];
         int c, x, y;
         for (x=0; x<100; x++) /* finish map */
            for (y=0; y<100; y++)
               {
                  c = l[x][y];
                  if (c) putpixel(screen, mx+x, my+y, bcmt[c]);
               }
      }
   set_clip(screen, 0, 0, SCREEN_W, SCREEN_H);

   if (resume_allowed)
      {
         char msg1[80], msg2[80];
         sprintf(msg1, " Level %d ", play_level);
         sprintf(msg2, " (paused) ");
         textout_centre(screen, font, msg1, tmtx, tmty, 11);
         textout_centre(screen, font, msg2, tmtx, tmty+8, 14);
      }
}
int slow_load_and_draw_level(int level_to_load)
{
   extern int tmtx, tmty;
   char msg[20];
   if (load_level(level_to_load,0))
      {
         draw_level();
         sprintf(msg, " Level %d ", level_to_load);
         textout_centre(screen, font, msg, tmtx, tmty, 11);
         textout_centre(screen, font, "start level", tmtx, tmty+8, 9);
         return 1;
      }
   else
      {
         rectfill(screen, mx, my-10, mx+(md*100), my+(md*100), 0);
         sprintf(msg, " Level %d ", level_to_load);
         textout_centre(screen, font, msg, tmtx, tmty, 11);
         textout_centre(screen, font, "not found!", tmtx, tmty+8, 10);
         return 0;
      }
}
int load_game() /* 1 == good 0 == cancel */
{
   extern BITMAP *memory_bitmap[512];
   extern BITMAP *level_2000;
   extern BITMAP *map100_bkg;

   extern int bomb[20][5];

   extern int e_bullet_active[50];
   extern int e_bullet_shape[50];
   extern float e_bullet_x[50];
   extern float e_bullet_y[50];
   extern float e_bullet_xinc[50];
   extern float e_bullet_yinc[50];

   extern float pbullet[50][6];

   extern int bomb[20][5];
   extern bcmt[512];

   extern float PX, PY, LIFE;
   extern float right_speed, left_speed, p_xmove;
   extern float jump_count, fall_count;

   extern int LIVES, play_level, num_bullets;
   extern int player_ride, player_carry, fire_held;
   extern int level_time, passcount, left_right;
   extern int level_done, bottom_msg;


   FILE *filepntr;
   char buff[2000];
   char msg[80];
   int loop, ch, fexit, c, x, y;

   char fname[80];

   text_mode(0);
   gui_fg_color = 10;
   sprintf(fname,"untitled.psg");

   if (file_select("Load saved game...", fname, "PSG"))
      {

         for (c = 0; c <20; c++) /* lifts - free mem if allocated */
            {
               destroy_lift(c);
               for (x = 0; x < 20; x++)
                  destroy_lift_step(c,x);
            }

         for (c=0; c < 500; c++)      /* free pmsg text */
            free (pmsg[c]);

         filepntr = fopen(fname,"r");

         for (x=0; x<17; x++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                     buff[loop] = ch;
                     loop++;
                     ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
   
               switch (x)
                  {
                     case 0: PX = atof(buff); break;
                     case 1: PY = atof(buff); break;
                     case 2: LIFE = atof(buff); break;
                     case 3: right_speed = atof(buff); break;
                     case 4: left_speed  = atof(buff); break;
                     case 5: p_xmove  = atof(buff); break;
                     case 6: jump_count = atof(buff); break;
                     case 7: fall_count = atof(buff); break;
   
                     case 8: LIVES = atoi(buff); break;
                     case 9: play_level = atoi(buff); break;
                     case 10: num_bullets = atoi(buff); break;
                     case 11: level_time = atoi(buff); break;
                     case 12: passcount = atoi(buff); break;
                     case 13: player_ride  = atoi(buff); break;
                     case 14: player_carry = atoi(buff); break;
                     case 15: fire_held = atoi(buff); break;
                     case 16: left_right = atoi(buff); break;
                  }
            }

         for (c=0; c<20; c++) /* level header */
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                     buff[loop] = ch;
                     loop++;
                     ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               level_header[c] = atoi(buff);
               if (ch == EOF)
                  {
                     sprintf(msg, "Error reading %s ", level_filename);
                     textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                     rest(3000);
                  }
            }

         for (c=0; c<100; c++)  /* l[100][100] */
            for (y=0; y<100; y++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                         buff[loop] = ch;
                         loop++;
                         ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  l[c][y] = atoi(buff);
                  if (ch == EOF)
                     {
                        sprintf(msg, "Error reading %s ", level_filename);
                        textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                        rest(3000);
                     }
               }




         for (c = 0; c < 500; c++)  /* read item */
            {
               for (x = 0; x < 16; x++)
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                            buff[loop] = ch;
                            loop++;
                            ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     item[c][x] = atoi(buff);
                     if (ch == EOF)
                        {
                           sprintf(msg, "Error reading items in %s ", level_filename);
                           textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                           rest(3000);
                        }
                  }
               if (item[c][0] == 10) /* get pmsg */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                            if (ch == 126) ch = 13;
                            buff[loop] = ch;
                            loop++;
                            ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     pmsg[c] = (char*) malloc (strlen(buff)+1);
                     strcpy(pmsg[c], buff);
                  }
              }




         for (c=0; c<500; c++) /* read item floats */
            for (x=0; x<4; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        buff[loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  itemf[c][x] = atof(buff);
                  if (ch == EOF)
                     {
                        sprintf(msg, "Error reading itemf in %s ", level_filename);
                        textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                        rest(3000);
                     }
               }
         for (c=0; c<100; c++) /* read enemy floats */
            for (x=0; x<16; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        buff[loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  Ef[c][x] = atof(buff);
                  if (ch == EOF)
                     {
                        sprintf(msg, "Error reading Ef in %s ", level_filename);
                        textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                        rest(3000);
                     }
               }

         for (c=0; c < 100; c++)  /* enemy ints */
            for (x=0; x<32; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                         buff[loop] = ch;
                         loop++;
                         ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  Ei[c][x] = atoi(buff);
                  if (ch == EOF)
                     {
                        sprintf(msg, "Error reading Ei in %s ", level_filename);
                        textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                        rest(3000);
                     }

               }


         for (c=0; c<level_header[5]; c++) /* read lifts */
            {
               int tr[15];
               float tf[4];
               char tmsg[80];
               for (x=0; x<16; x++) /* lift data */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                            buff[loop] = ch;
                            loop++;
                            ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     if (x == 15) strcpy(tmsg, buff); /* get lift name */
                     if (x < 4) tf[x] = atof(buff);  /* get float */
                     if ((x > 3) && (x < 15)) tr[x] = atoi(buff); /* get int */
                  }
               construct_lift(c, tmsg, tr[8],tr[9],tr[10],tr[12]);

               lifts[c] -> fx = tf[0];
               lifts[c] -> fy = tf[1];
               lifts[c] -> fxinc = tf[2];
               lifts[c] -> fyinc = tf[3];
               lifts[c] -> x1 = tr[4];
               lifts[c] -> y1 = tr[5];
               lifts[c] -> x2 = tr[6];
               lifts[c] -> y2 = tr[7];
               lifts[c] -> current_step = tr[11];
               lifts[c] -> limit_counter = tr[13];
               lifts[c] -> limit_type = tr[14];

               for (x=0; x<lifts[c] -> num_steps; x++) /* step data */
                  {
                     int tr[4];
                     for (y=0; y<4; y++) /* read 4 */
                        {
                           loop = 0;
                           ch = fgetc(filepntr);
                           while((ch != '\n') && (ch != EOF))
                              {
                                 buff[loop] = ch;
                                 loop++;
                                 ch = fgetc(filepntr);
                              }
                           buff[loop] = NULL;
                           tr[y] = atoi(buff);
                        }
                     construct_lift_step(c, x, tr[0], tr[1], tr[2], tr[3]);
                  }
            }


         for (c=0; c < 20; c++)  /* bomb data */
            for (x = 0; x < 5; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                         buff[loop] = ch;
                         loop++;
                         ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  bomb[c][x] = atoi(buff);
                  if (ch == EOF)
                     {
                        sprintf(msg, "Error reading bombs in %s ", level_filename, c, x);
                        textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                        rest(3000);
                     }

               }
         for (c=0; c < 50; c++)  /* bullet data */
            for (x = 0; x < 12; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                         buff[loop] = ch;
                         loop++;
                         ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;

                  switch (x) {

                     case 0: e_bullet_active[c] = atoi(buff); break;
                     case 1: e_bullet_shape[c]  = atoi(buff); break;
                     case 2: e_bullet_x[c]      = atof(buff); break;
                     case 3: e_bullet_y[c]      = atof(buff); break;
                     case 4: e_bullet_xinc[c]   = atof(buff); break;
                     case 5: e_bullet_yinc[c]   = atof(buff); break;

                     case 6:  pbullet[c][0] = atoi(buff); break;
                     case 7:  pbullet[c][1] = atoi(buff); break;
                     case 8:  pbullet[c][2] = atoi(buff); break;
                     case 9:  pbullet[c][3] = atoi(buff); break;
                     case 10: pbullet[c][4] = atoi(buff); break;
                     case 11: pbullet[c][5] = atoi(buff); break;


                  }
                  if (ch == EOF)
                     {
                        sprintf(msg, "Error reading bullets in %s ", level_filename, c, x);
                        textout(screen, font, msg, SCREEN_W/2, ((SCREEN_H*3)/4)+10, 1);
                        rest(3000);
                     }

               }



         fclose(filepntr);
  
         for (x=0; x<100; x++) /* fill maps and background */
           for (y=0; y<100; y++)
              {
                 c = l[x][y];
                 if (c<512) blit(memory_bitmap[c], level_2000, 0, 0, x*20, y*20, 20, 20);
                 if (c == 169) blit(memory_bitmap[0], level_2000, 0, 0, x*20, y*20, 20, 20);
     
     
              }
  
         stretch_blit(level_2000, map100_bkg, 0, 0, 2000, 2000, 0, 0, 100, 100);
         draw_lift_lines();
      
         for (x=0; x<100; x++) /* finish map */
            for (y=0; y<100; y++)
               {
                  c = l[x][y];
      
                  putpixel(map100_bkg, x, y, bcmt[c]);
      
                  if (c == 169)
                     putpixel(map100_bkg, x, y, 0 ); /* masked */
      
                  if (c == 0)
                     putpixel(map100_bkg, x, y, 241 ); /* empty not masked */
                }
      
         initialize_zz(passcount);
    
         level_done=0;
         bottom_msg=0;
         return 1;
      } /* end of good file select */
   else return 0; /* cancel pressed */

}
void save_game()
{

   extern int bomb[20][5];

   extern int e_bullet_active[50];
   extern int e_bullet_shape[50];
   extern float e_bullet_x[50];
   extern float e_bullet_y[50];
   extern float e_bullet_xinc[50];
   extern float e_bullet_yinc[50];

   extern float pbullet[50][6];

   extern int bomb[20][5];
   extern bcmt[512];


   extern float PX, PY, LIFE;
   extern float right_speed, left_speed, p_xmove;
   extern float jump_count, fall_count;

   extern int LIVES, play_level, num_bullets;
   extern int player_ride, player_carry, fire_held;
   extern int level_time, passcount, left_right;
   extern int level_done, bottom_msg;

   int x, y, c;

   FILE *filepntr;
   float junkfloat = 23.3;
   int junkint = 448;
   char fname[80];

   text_mode(0);
   gui_fg_color = 10;
   sprintf(fname,"untitled.psg");

   if (file_select("Save game as...", fname, "PSG"))
      {
         filepntr = fopen(fname,"w");


         fprintf(filepntr,"%f\n",PX);
         fprintf(filepntr,"%f\n",PY);
         fprintf(filepntr,"%f\n",LIFE);
         fprintf(filepntr,"%f\n",right_speed);    /* padded for the future */
         fprintf(filepntr,"%f\n",left_speed);
         fprintf(filepntr,"%f\n",p_xmove);
         fprintf(filepntr,"%f\n",jump_count);
         fprintf(filepntr,"%f\n",fall_count);
      
         fprintf(filepntr,"%d\n",LIVES);
         fprintf(filepntr,"%d\n",play_level);
         fprintf(filepntr,"%d\n",num_bullets);
         fprintf(filepntr,"%d\n",level_time);
         fprintf(filepntr,"%d\n",passcount);
         fprintf(filepntr,"%d\n",player_ride);
         fprintf(filepntr,"%d\n",player_carry);
         fprintf(filepntr,"%d\n",fire_held);
         fprintf(filepntr,"%d\n",left_right);

         for (x=0; x<20; x++)
                fprintf(filepntr,"%d\n",level_header[x]);
      
             for (c=0; c<100; c++)  /* level */
                for (x=0; x<100; x++)
                   fprintf(filepntr,"%d\n",l[c][x]);




             for (c=0; c < 500; c++) /* item */
                {
                   for (x=0; x<16; x++)
                      fprintf(filepntr,"%d\n",item[c][x]);
                   if (item[c][0] == 10) /* save message */
                      {
                         y = 0;
                         while (pmsg[c][y] != NULL)
                            {
                               if (pmsg[c][y] == 13)
                                  fprintf(filepntr,"%c",126);
                               else
                                  fprintf(filepntr,"%c",pmsg[c][y]);
                               y++ ;
                            }
                         fprintf(filepntr,"\n");
                      }
                }


             for (c=0; c < 500; c++) /* itemf */
                for (x=0; x<4; x++)
                     fprintf(filepntr,"%f\n",itemf[c][x]);

             for (c=0; c < 100; c++)  /* enemy float */
                 for (x=0; x<16; x++)
                      fprintf(filepntr,"%f\n",Ef[c][x]);
             for (c=0; c < 100; c++) /* enemy int */
                 for (x=0; x<32; x++)
                      fprintf(filepntr,"%d\n",Ei[c][x]);

             for (c=0; c < level_header[5]; c++)   /* lifts */
                {
                   fprintf(filepntr,"%f\n",lifts[c] -> fx);
                   fprintf(filepntr,"%f\n",lifts[c] -> fy);
                   fprintf(filepntr,"%f\n",lifts[c] -> fxinc);
                   fprintf(filepntr,"%f\n",lifts[c] -> fyinc);
                   fprintf(filepntr,"%d\n",lifts[c] -> x1);
                   fprintf(filepntr,"%d\n",lifts[c] -> y1);
                   fprintf(filepntr,"%d\n",lifts[c] -> x2);
                   fprintf(filepntr,"%d\n",lifts[c] -> y2);
                   fprintf(filepntr,"%d\n",lifts[c] -> width);
                   fprintf(filepntr,"%d\n",lifts[c] -> height);
                   fprintf(filepntr,"%d\n",lifts[c] -> color);
                   fprintf(filepntr,"%d\n",lifts[c] -> current_step);
                   fprintf(filepntr,"%d\n",lifts[c] -> num_steps);
                   fprintf(filepntr,"%d\n",lifts[c] -> limit_counter);
                   fprintf(filepntr,"%d\n",lifts[c] -> limit_type);
                   fprintf(filepntr,"%s\n",lifts[c] -> lift_name);
          
                   for (x=0; x<lifts[c]->num_steps; x++)  /* steps */
                      {
                         fprintf(filepntr,"%d\n",lift_steps[c][x] -> x);
                         fprintf(filepntr,"%d\n",lift_steps[c][x] -> y);
                         fprintf(filepntr,"%d\n",lift_steps[c][x] -> val);
                         fprintf(filepntr,"%d\n",lift_steps[c][x] -> type);
                      }
                }

             for (x = 0; x < 20; x++)  /* bomb data */
                for (y = 0; y < 5; y++)
                    fprintf(filepntr,"%d\n",bomb[x][y]);
      
             for (c = 0; c < 50; c++)
                {
                   fprintf(filepntr,"%d\n",e_bullet_active[c]);
                   fprintf(filepntr,"%d\n",e_bullet_shape[c]);
                   fprintf(filepntr,"%f\n",e_bullet_x[c]);
                   fprintf(filepntr,"%f\n",e_bullet_y[c]);
                   fprintf(filepntr,"%f\n",e_bullet_xinc[c]);
                   fprintf(filepntr,"%f\n",e_bullet_yinc[c]);
                   for (x = 0; x < 6; x++)
                      fprintf(filepntr,"%d\n",pbullet[c][x]);
                }
         fclose(filepntr);
      }
}

void save_apl() /* autoplay */
{
   FILE *filepntr;
   extern int api;
   extern int play_level;
   extern int autoplay[5000][2];
   char fname[80];
   int x, y;
      
   text_mode(0);
   gui_fg_color = 10;
   sprintf(fname,"test.apl");


   if (file_select("Save Autoplay as...", fname, "APL"))
      {
         filepntr = fopen(fname,"w");
         fprintf(filepntr,"%d\n",api);
         fprintf(filepntr,"%d\n",play_level);
         for (x=0; x<=api; x++)
            for (y=0; y<2; y++)
               fprintf(filepntr,"%d\n",autoplay[x][y]);
         fclose(filepntr);
      }
}
void load_apl(int fi)
{
   FILE *filepntr;
   char buff[20];
   extern char fnlst[50][80];
   int loop, ch, c, x, y;
   extern int play_level;
   extern int api;
   extern int autoplay[5000][2];
   char fname[80];

   for (x=0; x<5000; x++) /* clear */
      for (y=0; y<2; y++)
         autoplay[x][y] = 0;

   if (fi) sprintf(fname, fnlst[fi]);
   else file_select("Load Autoplay", fname, "APL");

   if (exists(fname))
      {
         filepntr=fopen(fname, "r");
      
         loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
            {
               buff[loop] = ch;
               loop++;
               ch = fgetc(filepntr);
            }
         buff[loop] = NULL;
         api = atoi(buff);
      
         loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
            {
               buff[loop] = ch;
               loop++;
               ch = fgetc(filepntr);
            }
         buff[loop] = NULL;
         play_level = atoi(buff);

         for (x=0; x<=api; x++)
            for (y=0; y<2; y++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        buff[loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  autoplay[x][y] = atoi(buff);
               }
         fclose(filepntr);
      }
   text_mode(0);
}


/*for (c=0; c<level_header[5]; c++) /* lift floats */
  /*          {
               float tr[4];
               for (x=0; x<4; x++)
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     tr[x] = atof(buff);
                  }
               lifts[c]->fx    = tr[0];
               lifts[c]->fy    = tr[1];
               lifts[c]->fxinc = tr[2];
               lifts[c]->fyinc = tr[3];
            }
    */
