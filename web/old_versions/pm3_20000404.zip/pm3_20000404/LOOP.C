#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <allegro.h>
#include "pm.h"
#include "lift.h"

void pm_main(void);


/* global variables  */
extern int level_header[20];

extern struct lift *lifts[20];
extern struct lift_step *lift_steps[20][20];

extern BITMAP *memory_bitmap[512];
extern BITMAP *level_2000, *scrn_buffer;
extern BITMAP *map100_bmp, *map100_bkg;
extern BITMAP *dtemp;
extern BITMAP *pm_title;
extern PALLETE pallete;
extern SAMPLE *snd[20];
extern int fuse_loop_playing;
extern int phit_loop_playing;
extern int sample_delay[8];


extern int lit_item;

extern int autoplay[5000][2];
extern int ap_mode;
extern int api;
extern int comp_move;
extern int old_comp_move;
extern int up;
extern int down;
extern int left;
extern int right;

extern int level_header[20];
extern int l[100][100];    /* level */
extern int item[500][16];  /* items */
extern int Ei[100][32];    /* enemies */
extern float Ef[100][16];  /* enemies */
extern int zz[20][64];

/* timer variables  */
extern volatile int msec_timer;
extern int level_time;
extern int passcount;

/* new x move stuff */
extern float right_speed, left_speed;
extern float initial_x_speed, max_x_speed;
extern float p_xmove;
extern float accel, de_accel;
extern float jump_sinc, fall_sinc;
extern float pmovey;

extern int joy_key;
extern int joy_buttons;
extern int joy_jump;
extern int joy_fire;
extern int joy_map;
extern int joy_menu;
extern int job[5];

extern int right_key;
extern int left_key;
extern int up_key;
extern int down_key;
extern int jump_key;
extern int fire_key;
extern int map_key;
extern int menu_key;

extern int jump;
extern int fire;

extern int play_level;
extern int start_level;
extern int start_mode;
extern int resume_allowed;

extern int top_menu_sel;

extern int speed;
extern int dif;

extern float LIFE;
extern int LIVES;

extern int sound_on;
extern int frame_speed;
extern int fade_count;

extern int WX, WY;
extern float PX, PY;
extern int PXint, PYint;
extern int num_bullets;

extern float fps;  /* frames per second */

extern int max_bullets;
extern int pbullet[50][6];
extern int bullet_wait_counter, request_bullet;
extern int bullet_wait, bullet_speed;
extern int pm_bullet_collision_box;

extern int e_bullet_active[50], e_bullet_shape[50];
extern int enemy_bullet_colision_window;
extern float e_bullet_x[50], e_bullet_y[50], e_bullet_xinc[50], e_bullet_yinc[50];

extern int bomb[20][5];

extern float itemf[500][4];

extern int player_ride;
extern int player_carry;
extern int fire_held;
extern int map_held;

extern int left_right;
extern float jump_count, fall_count;

extern int level_done;
extern int game_exit;
extern int num_enemy;

/* counters and temp string  */
int a, b, c, d, e, f, x, y;
extern char msg[80];
extern char b_msg[80];
extern int bottom_msg;
extern int pop_msg;
extern int pop_msg_count;

extern int map_double; /* game map double */
extern int map100_x, map100_y;
extern int game_map_on, top_display_on;
extern int top_display_x, top_display_y, top_display_color;
extern int bottom_display_y, bottom_display_color;

extern int map_solid_color, map_semi_color;
extern int map_break_color, map_empty_color;
extern int map_enemy_color , map_bullet_color;
extern int map_item_color, map_player_color;

extern int md; /* menu map double */
extern int mx;
extern int my;
extern float steps;

void set_lift_xyinc(int d, int step) /* used by move lift everywhere */
{
   float speed, angle, xlen, ylen, xinc, yinc;
   speed = lift_steps[d][step] -> val;
   speed /=10;
   xlen = abs( lifts[d] -> x1 - lift_steps[d][step] -> x );
   if (xlen == 0) xlen = .000001;
   ylen = abs( lifts[d] -> y1 - lift_steps[d][step] -> y );
   if (ylen == 0) ylen = .000001;
   angle = atan(ylen/xlen);
   xinc = cos(angle) * speed;
   yinc = sin(angle) * speed;
   if (xlen > ylen)
      lifts[d] -> limit_counter = abs( xlen / xinc); /* distance/speed=time! */
   if (xlen <= ylen)
      lifts[d] -> limit_counter = abs( ylen / yinc); /* distance/speed=time! */
   lifts[d] -> limit_type = 7; /* step countdown limit type 7 */
   
   if (lifts[d] -> x1  < lift_steps[d][step] -> x) lifts[d]->fxinc= +xinc;
   if (lifts[d] -> x1 == lift_steps[d][step] -> x) lifts[d]->fxinc= 0;
   if (lifts[d] -> x1  > lift_steps[d][step] -> x) lifts[d]->fxinc= -xinc;
   
   if (lifts[d] -> y1  < lift_steps[d][step] -> y) lifts[d]->fyinc= +yinc;
   if (lifts[d] -> y1 == lift_steps[d][step] -> y) lifts[d]->fyinc= 0;
   if (lifts[d] -> y1  > lift_steps[d][step] -> y) lifts[d]->fyinc= -yinc;
}

void next_map_mode()
{
   if (game_map_on)
      {
         game_map_on = 0;
         if (map100_x < 40) map100_x = SCREEN_W - map_double*100;
         else map100_x = 0;
         if (map100_y < 40) map100_y = SCREEN_H - map_double*100;
         else map100_y = 0;
         if ((SCREEN_W == 320) && (map100_y < 20))
            map100_y = 20;
      }
   else game_map_on = 1;
}
void draw_map()
{
   if ( (PX-WX) < SCREEN_W/2 - 20) map100_x = SCREEN_W - map_double*100;
   if ( (PX-WX) > SCREEN_W/2 + 20) map100_x = 0;
   if ( (PY-WY) < SCREEN_H/2 - 20) map100_y = SCREEN_H - map_double*100;
   if ( (PY-WY) > SCREEN_H/2 + 20) map100_y = 0;
   if ((SCREEN_W == 320) && (map100_y < 20))
      map100_y = 20;
   stretch_sprite(scrn_buffer, map100_bmp, map100_x, map100_y, map_double*100, map_double*100);
   blit(map100_bkg, map100_bmp, 0,0,0,0,100,100);
}
void draw_top_display(void)
   {
      int ho = 69;
      sprintf(msg,"Level:%-3d",play_level) ;
      textout(scrn_buffer, font, msg, top_display_x + 2, top_display_y + 2, top_display_color);
      sprintf(msg,"Lives:%-1d",LIVES) ;
      textout(scrn_buffer, font, msg, top_display_x + 2, top_display_y + 11, top_display_color);
      sprintf(msg,"Health") ;
      textout(scrn_buffer, font, msg, top_display_x + ho+2, top_display_y + 2, top_display_color);
      rectfill (scrn_buffer, top_display_x+ho, top_display_y + 10, top_display_x + ho+50, top_display_y +17, 10); /*  red   */
      rectfill (scrn_buffer, top_display_x+ho, top_display_y + 10, top_display_x + ho+(LIFE/2), top_display_y +17, 11); /*  green */

      sprintf(msg,"Time:%-3d",level_time/50);
      textout(scrn_buffer, font, msg, top_display_x + 124, top_display_y + 2, top_display_color);
      sprintf(msg,"Shot:%-3d",num_bullets);
      textout(scrn_buffer, font, msg, top_display_x + 124, top_display_y + 11, top_display_color);

      if ((key[KEY_ALT]) && (key[KEY_F]))
        {
           sprintf(msg,"fps:%-2.1f",fps) ;
           textout(scrn_buffer, font, msg, top_display_x + 192, top_display_y + 11, top_display_color);
        }

   }
void stamp(void)   /* stretch map animated shrinkage of play screen to map */
{

       add_eilp_to_l2000();
       WX = PX - (SCREEN_W/2)-10; /* set window from PX,PY */
       WY = PY - (SCREEN_H/2)-10;
       if (WX < 0) WX = 0;
       if (WX > 1999 - SCREEN_W) WX = 1999 - SCREEN_W;
       if (WY > 1999 - SCREEN_H) WY = 1999 - SCREEN_H;
       if (WY < 0) WY = 0;
   
      if (1)
         {
            int x, y;
            float inc1 = (0-WX)/steps;
            float inc2 = (0-WY)/steps;
            float inc3 = (2000-SCREEN_W)/steps;
            float inc4 = (2000-SCREEN_H)/steps;
            float inc5 = (mx-0)/steps;
            float inc6 = (my-0)/steps;
            float inc7 = (md*100-SCREEN_W)/steps;
            float inc8 = (md*100-SCREEN_H)/steps;


            float s1 = WX;
            float s2 = WY;
            float s3 = SCREEN_W;
            float s4 = SCREEN_H;
            float s5 = 0;
            float s6 = 0;
            float s7 = SCREEN_W;
            float s8 = SCREEN_H;
            BITMAP *ht;

            ht = create_bitmap(SCREEN_W, SCREEN_H);

            for (x = 0; x<=steps; x++)
               {

                  stretch_blit(level_2000, ht,s1,s2,s3,s4,s5,s6,s7,s8);

                  rectfill(ht,s5-inc5, s6     , s5-inc5+s7-inc7, s6-inc6,         0);
                  rectfill(ht,s5-inc5, s6+s8  , s5-inc5+s7-inc7, s6-inc6+s8-inc8, 0);

                  rectfill(ht,s5-inc5, s6-inc6, s5,              s6-inc6+s8-inc8, 0);
                  rectfill(ht,s5+s7  , s6-inc6, s5-inc5+s7-inc7, s6-inc6+s8-inc8, 0);

                  blit(ht, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

               /*   rest(x/steps*5); */

                  s1+=inc1;
                  s2+=inc2;
                  s3+=inc3;
                  s4+=inc4;
                  s5+=inc5;
                  s6+=inc6;
                  s7+=inc7;
                  s8+=inc8;


               }

       }
}
void stimp(void)   /* stretch map animated growage of map to play screen */
{
       add_eilp_to_l2000();
       WX = PX - (SCREEN_W/2)-10; /* set window from PX,PY */
       WY = PY - (SCREEN_H/2)-10;
       if (WX < 0) WX = 0;
       if (WX > 1999 - SCREEN_W) WX = 1999 - SCREEN_W;
       if (WY > 1999 - SCREEN_H) WY = 1999 - SCREEN_H;
       if (WY < 0) WY = 0;
   
      if (1)
         {
            int x, y;

            float inc1 = (0-WX)/steps;
            float inc2 = (0-WY)/steps;
            float inc3 = (2000-SCREEN_W)/steps;
            float inc4 = (2000-SCREEN_H)/steps;
            float inc5 = (mx-0)/steps;
            float inc6 = (my-0)/steps;
            float inc7 = (md*100-SCREEN_W)/steps;
            float inc8 = (md*100-SCREEN_H)/steps;


            float s1 = 0;
            float s2 = 0;
            float s3 = 2000;
            float s4 = 2000;
            float s5 = mx;
            float s6 = my;
            float s7 = md*100;
            float s8 = md*100;
            BITMAP *ht;

            ht = create_bitmap(SCREEN_W, SCREEN_H);

            blit(screen, ht, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

            for (x = 0; x<=steps; x++)
               {
                  stretch_blit(level_2000, ht,s1,s2,s3,s4,s5,s6,s7,s8);

                  blit(ht, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                  rest(x/steps*5);

                  s1-=inc1;
                  s2-=inc2;
                  s3-=inc3;
                  s4-=inc4;
                  s5-=inc5;
                  s6-=inc6;
                  s7-=inc7;
                  s8-=inc8;

               }
       }
    restore_l2000();
}
void get_new_background()
{
    WX = PX - (SCREEN_W/2)-10; /* set window from PX,PY */
    WY = PY - (SCREEN_H/2)-10;
    if (WX < 0) WX = 0;
    if (WX > 1999 - SCREEN_W) WX = 1999 - SCREEN_W;
    if (WY > 1999 - SCREEN_H) WY = 1999 - SCREEN_H;
    if (WY < 0) WY = 0;
    blit(level_2000, scrn_buffer, WX, WY, 0, 0, SCREEN_W, SCREEN_H);
}
void draw_pop_msg()
{
   extern int item[500][16];
   extern char *pmsg[500];

   int c = pop_msg-1;
   int x = SCREEN_W/2;
   int y = 40;

   int len = strlen(pmsg[c]);
   char msg[80];
   char dt[20][80];
   int row = 0, col = 0;
   int longest_line_len = 1; /* default */
   int num_lines = 0;
   int xpos_c = x;
   int ypos = y;
   int xw;
   int a;
   int tc = item[c][8];
   int fc = item[c][9];
   int px, py, px2, py2;

   for (a=0; a<len+1; a++)
      {
          if (pmsg[c][a] == 13) /* line break */
            {
               row++;
               col=0;
               dt[row][col] = NULL; /* in case len = 0 */
            }
         else  /* regular char */
            {
               dt[row][col] = pmsg[c][a];
               if (col > longest_line_len) longest_line_len = col;
               col++;
               dt[row][col] = NULL;
            }
      }
   num_lines = row;

   xw = (longest_line_len+1)*4;
   px  = xpos_c-xw-2-8;
   py  = ypos-2-8;
   px2 = xpos_c+xw+8;
   py2 = ypos+(num_lines+1)*8+8;

   a = 7;  /* erase */
   rectfill(scrn_buffer, px+a,py+a,px2-a,py2-a,0);

   for (a=0; a<8; a++) /* frame */
      rect(scrn_buffer, px+a,py+a,px2-a,py2-a,fc+a*16);

   for (row=0; row<=num_lines; row++) /* text */
      textout_centre(scrn_buffer, font, dt[row], xpos_c, ypos+row*8, tc);
}

#ifdef MV
void rec_ap_control()
{
    int map=0;
    int menu=0;

    jump=0;
    fire=0;
    left=0;
    right=0;
    up=0;
    down=0;

    if ((key[up_key])    || (joy_up))    up = 1;
    if ((key[down_key])  || (joy_down))  down = 1;
    if ((key[left_key])  || (joy_left))  left = 1;
    if ((key[right_key]) || (joy_right)) right = 1;

    if ((key[KEY_ESC]) || (key[menu_key]))
         {
            menu = 1;

            resume_allowed = 1;
            game_exit = 1;
         }

    switch (joy_key)
       {
          case 0: /* keyboard */
             if (key[fire_key]) fire = 1;
             else fire_held = 0;
             if (key[jump_key]) jump = 1;

          if ((key[map_key]) && (!map_held))
             {
                next_map_mode();
                map = 1;
                map_held = 1;
             }
          if ((!key[map_key]) && (map_held))
             map_held = 0;

          break;
          case 1: /* standard joystick control */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;

             if ((key[map_key]) && (!map_held)) /* key map */
                {
                   next_map_mode();
                   map = 1;
                   map_held = 1;
                }
             if ((!key[map_key]) && (map_held))
                map_held = 0;
          break;
          case 4: /* 4 button joystick */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             job[3] = joy_b3;
             job[4] = joy_b4;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;
             if ((job[joy_map]) && (!map_held))
                {
                   next_map_mode();
                   map = 1;
                   map_held = 1;
                }
             if ((!job[joy_map]) && (map_held))
                map_held = 0;
             if (job[joy_menu])
                {
                   resume_allowed = 1;
                   menu = 1;
                   game_exit = 1;
                }
          break;
      }



      /* make comp */
      comp_move = 0;
      if (left)  comp_move += 1;
      if (right) comp_move += 2;
      if (up)    comp_move += 4;
      if (down)  comp_move += 8;
      if (jump)  comp_move += 16;
      if (fire)  comp_move += 32;
      if (game_map_on) comp_move += 64;
      if (menu)  comp_move += 128;

      if (comp_move != old_comp_move)
         {
            old_comp_move = comp_move;
            autoplay[api][0] = passcount;
            autoplay[api][1] = comp_move;
            if (comp_move > 127)
               {
                  save_apl();

               }
            api++;

         }

}
#endif MV

void proc_ap_control()
{


   if ((passcount > 20) && (keypressed()))
     {
        resume_allowed = 1;
        game_exit = 1;
     }


   if (passcount >= autoplay[api][0])  /* if passcounter = next line in array */
   
      {
         int t = autoplay[api][1];
         fire = 0;
         jump = 0;
         up = 0;
         down = 0;
         left = 0;
         right = 0;


         if (t > 127)
            {
                t -= 128;
                resume_allowed = 0;
                game_exit = 1;
             }
         if (t > 63)
            {
                t -= 64;
                game_map_on = 1;
            }
         else game_map_on = 0;
         if (t > 31)
            {
                t -= 32;
                fire = 1;
            }
         else fire_held = 0;
         if (t > 15)
            {
                t -= 16;
                jump = 1;
            }
         if (t > 7) /* down */
            {
                t -= 8;
                down=1;
            }
         if (t > 3) /* up */
            {
                t -= 4;
                up = 1;
            }
         if (t > 1) /* right */
            {
                t -= 2;
                right = 1;
            }
         if (t > 0) /* left */
            {
               t -= 0;
               left = 1;
            }
         api++;
      }
}
void proc_controllers()
{
    jump=0;
    fire=0;
    left=0;
    right=0;
    up=0;
    down=0;

    if ((key[up_key])    || (joy_up))    up = 1;
    if ((key[down_key])  || (joy_down))  down = 1;
    if ((key[left_key])  || (joy_left))  left = 1;
    if ((key[right_key]) || (joy_right)) right = 1;

    if ((key[KEY_ESC]) || (key[menu_key]) || (mouse_b & 2))
         {
            resume_allowed = 1;
            game_exit = 1;
         }

    switch (joy_key)
       {
          case 0: /* keyboard */
             if (key[fire_key]) fire = 1;
             else fire_held = 0;
             if (key[jump_key]) jump = 1;


#ifdef MV

          if ((key[KEY_ALT]) && (key[KEY_L]))
             {
                int l, l2 = play_level;
                char fname[20];
                final_wrapup();
                sprintf(fname, "pmfle.exe %d", l2);
                l = system(fname); /* set level num from level editor */
   
                if ((l == 0) || (l == 255))
                   {
                      initial_setup();
                      set_start_level(l2); /* original start level */
                      slow_load_and_draw_level(l2);
                      game_exit  = 1;
                      resume_allowed = 0;
                      top_menu_sel = 3;
                   }
                else /* immediately start playing the returned level */
                   {
                      initial_setup();
                      if (load_level(l,0))
                         {
                            set_start_level(l);
                            play_level=start_level;
                            initialize_zz(0);
                            maps_and_background_fill();
                            for (c=0; c<500; c++)  /* get start and time */
                               if (item[c][0] == 5)
                                  {
                                     PX = itemf[c][0];
                                     PY = itemf[c][1];
                                     level_time = item[c][8] * 50;
                                     stimp();
                                     break;
                                  }
                            for (c=0; c<8; c++)
                               sample_delay[c] = passcount;
      
                            player_carry = 0;
                            player_ride = 0;
                            level_done = 0;
                            bottom_msg=0;
                            pop_msg_count=0;
                            right_speed = left_speed = 0;
                            jump_count = fall_count = 0;
                            clear_keybuf();
                            start_mode = 0;
                            game_exit = 0;
                            num_bullets = 200;
                            LIVES = 5;
                            LIFE = 100;

                         }
                      else
                         {
                            game_exit = 1;
                            resume_allowed = 0;
                         }
                   }
             }

#endif

          if ((key[KEY_CONTROL]) && (key[KEY_PRTSCR]))
             {
                FILE *filepntr;
                char fname[80];

                BITMAP *ss_bmp;
                PALETTE ss_pal;
          
                get_palette(ss_pal);
                ss_bmp = create_sub_bitmap(screen, 0, 0, SCREEN_W, SCREEN_H);

                text_mode(0);
                gui_fg_color = 10;
                sprintf(fname,"scrndump.bmp");
             
                if (file_select("Save Screen Dump as...", fname, "BMP"))
                   {
                       save_bitmap("dump.bmp", ss_bmp, ss_pal);
                       destroy_bitmap(ss_bmp);
                   }
                text_mode(0);
                gui_fg_color = 9;

             }
          if ((key[map_key]) && (!map_held))
             {
                next_map_mode();
                map_held = 1;
             }
          if ((!key[map_key]) && (map_held))
             map_held = 0;

          break;
          case 1: /* standard joystick control */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;

             if ((key[map_key]) && (!map_held)) /* key map */
                {
                   next_map_mode();
                   map_held = 1;
                }
             if ((!key[map_key]) && (map_held))
                map_held = 0;
          break;
          case 4: /* 4 button joystick */
             poll_joystick();
             job[1] = joy_b1;
             job[2] = joy_b2;
             job[3] = joy_b3;
             job[4] = joy_b4;
             if (job[joy_fire]) fire = 1;
             else fire_held = 0;
             if (job[joy_jump]) jump = 1;
             if ((job[joy_map]) && (!map_held))
                {
                   next_map_mode();
                   map_held = 1;
                }
             if ((!job[joy_map]) && (map_held))
                map_held = 0;
             if (job[joy_menu])
                {
                   resume_allowed = 1;
                   game_exit = 1;
                }
          break;
     }
}

void event(int ev)
{
   extern int sample_delay[8];
   int text_on = 1;
   if (sound_on)
      {
         switch (ev) {
/*
        0 - player shoots
        1 - d'OH
        2 - bonus
        3 - hiss
        4 - la de da  door, key, exit
        5 - explosion
        6 - grunt 1 shot
        7 - grunt 2 hit
        8 - enemy killed
*/
            case  1: play_sample( snd[ 0], 180, 127,  800, 0);
            break;
            case  2: case  4: case  5:
               if (sample_delay[4]+30 < passcount)
                  {
                     sample_delay[4] = passcount;
                     play_sample(snd[4], 200, 127, 1000, 0);
                  }
            break;
            case  6: case  7:  case  8: case  9:
               if (sample_delay[2]+30 < passcount)
                  {
                     sample_delay[2] = passcount;
                     stop_sample(snd[2]); play_sample( snd[2], 200, 127, 1000, 0);
                  }
            break;
            case 11: play_sample( snd[6], 127, 127, 1000, 0); break;
            case 10: case 12:
               if (sample_delay[7]+14 < passcount)
                  {
                      sample_delay[7] = passcount;
                      stop_sample(snd[7]); play_sample( snd[7], 127, 127, 1000, 0);
                  }
            break;
            case 13: play_sample( snd[8], 200, 127, 1200, 0); break;
            case 21: play_sample( snd[1], 255, 127, 1000, 0); break;
            case 22: stop_sample(snd[5]); play_sample( snd[5], 200, 127, 1000, 0); break;
         }
      }
   if (text_on)
      {
         switch (ev) {
            case   1:/* player bullet fired */ break;
            case   2: sprintf(b_msg, "locked block(s) removed!"); bottom_msg = 120; break;
            case   3: sprintf(b_msg, "%d enemies left!", num_enemy); bottom_msg = 120; break;
            case   4: /* level_done  */ break;
            case   5: sprintf(b_msg, "teleport door!"); bottom_msg = 120; break;
            case   6: sprintf(b_msg, "health bonus! %d", item[x][7]); bottom_msg = 120; break;
            case   7: sprintf(b_msg, "bullet bonus! %d", item[x][8]); bottom_msg = 120; break;
            case   8: sprintf(b_msg, "timer bonus! %d",  item[x][9]); bottom_msg = 120; break;
            case   9: sprintf(b_msg, "wahoo! you got a free man!"); bottom_msg = 200; break;
            case  10: sprintf(b_msg,  "you hit a mine!"); bottom_msg = 120;break;
            case  11: sprintf(b_msg, "you got shot!"); bottom_msg = 120; break;
            case  12: sprintf(b_msg, "you got hit!"); bottom_msg = 120; break;
            case  13: sprintf(b_msg, "enemy killed!...%d left", num_enemy-1);  bottom_msg = 120; break;
            case  14: /* cloner cloned something */ break;
            case  15: /* jump  */ break;
            case  16: /* arrow fired */ break;
            case  17: /* green fired */ break;
            case  18: /* cannonball  */ break;
            case  19: /* twirly      */ break;
            case  20: sprintf(b_msg, "no bullets!"); bottom_msg = 120; break;
            case  21: /* you died! */ break;
            case  22: /* explosion */ break;
            case  23: sprintf(b_msg, "enemy killed by bomb!"); bottom_msg = 120; bottom_msg = 120; break;
            case  24: sprintf(b_msg, "#%d bomb with %d second fuse",item[x][7]/20, item[x][9]/10 ); bottom_msg = 120+item[x][9]; break;
            case  25: sprintf(b_msg, "rocket!"); bottom_msg = 120; break;
            case  26: sprintf(b_msg, "you already have perfect health!"); bottom_msg = 120; break;
            case  27: sprintf(b_msg, "you already have %d bullets!", num_bullets); bottom_msg = 120; break;
            case  28: /* timer full (unused)  */ break;
         }
      }
}
player_move()
{
   if (!((player_carry) && (item[player_carry-1][0] == 98)))
      {
         if (left)
            {
               left_right = 0;
               if (left_speed < initial_x_speed) left_speed = initial_x_speed;
               else
                  {
                     left_speed += accel;
                     if (left_speed > max_x_speed) left_speed = max_x_speed;
                  }
            }
         else
            {
               left_speed -= de_accel;
               if (left_speed < 0) left_speed = 0;
            }
         if (right)
            {
               left_right = 1;
               if (right_speed < initial_x_speed) right_speed = initial_x_speed;
               else
                  {
                     right_speed += accel;
                     if (right_speed > max_x_speed) right_speed = max_x_speed;
                  }
            }
         else
            {
               right_speed -= de_accel;
               if (right_speed < 0) right_speed = 0;
            }

         p_xmove = right_speed - left_speed;
         PXint = PX + p_xmove;
         PYint = PY;
         /* check for player being pushed by lift */
         a = (is_left_solid(PXint,PYint));
         if ( a > 31 )
            {
               p_xmove += lifts[a-32]->fxinc + left_speed;
               left_speed=0;
            }
         a = is_right_solid(PXint,PYint);
         if ( a > 31 )
            {
               p_xmove += lifts[a-32]->fxinc - right_speed;
               right_speed = 0;
            }
         /* check if trying to move through wall */
         if ((p_xmove > 0) && (!is_right_solid(PXint+ (int) p_xmove,PYint)) )
                  {
                     PX += p_xmove;
                     if (PX>1980) PX=1980;
                     PXint = PX;
                  }
         if ((p_xmove < 0) && (!is_left_solid(PXint+ (int) p_xmove,PYint)) )
                  {
                     PX += p_xmove;
                     if (PX<0) PX=0;
                     PXint = PX;
                  }
         /* Y MOVEMENT   */
         /* check if in the middle of a jump */
         if (jump_count)
            {
               jump_count -= jump_sinc;
               if (jump_count < .1)
                  {
                     jump_count = 0;
                     fall_count = 1.57;
                  }
               else
                  {
                     if (!jump) jump_count -= (jump_sinc*4); /* jump released */
                     if (is_up_solid(PXint, PYint, 1, 0))
                        {
                           jump_count = 0;
                           fall_count = 1.57;
                        }
                     else PY -= (sin(jump_count) * pmovey);
                  }
            }
         else   /* not jump  */
            {
               if (fall_count)
                  {
                     fall_count -= fall_sinc;
                     if (fall_count < .1) fall_count = .1;
                     PY += (sin(1.57 - fall_count) * pmovey);
                     PYint = PY;
                     a = is_down_solid(PXint,PYint, 1);
                     if (a == 1)
                        {
                           fall_count = 0;
                           PY -= fmod (PY, 20); /* align with floor */
                        }
                     if (a > 31) /* on lift */
                        {
                           fall_count = 0;
                           player_ride = a; /* lift num */
                        }
                  }
               else /* not jump or fall */
                  {
                     a = is_down_solid(PXint,PYint, 1); /* on lift? */
                     if (a > 31) /* lift below */
                        {
                           player_ride = a ; /* number of shape he's riding */
                           if (lifts[a-32]->fyinc < 0) /* yinc (up) */
                              {
                                 PYint = PY + lifts[a-32]->fyinc;
                                 if (is_up_solid(PXint, PYint, 1, 0))  /* hit ceiling? */
                                    {
                                       player_ride = 0;    /* fall off lift */
                                       fall_count = 1.57;
                                       PY += 5; /* set y so he falls*/
                                    }
                              }
                           if (lifts[a-32]->fyinc > 0) /* yinc (down)*/
                              {
                                 PYint = PY + lifts[a-32]->fyinc;
                                 if (is_down_solid(PXint, PYint, 0))  /* floor below? */
                                    {
                                       player_ride = 0;   /* off lift */
                                       fall_count = 1.57;
                                       PY -= 5; /* set y */
                                    }
                              }
                        }
                     if (a == 0)  /* start fall? */
                        {
                           player_ride = 0;
                           fall_count = 1.57;
                        }
                     if ((a) && (jump)) /* check if jump pressed  */
                        {
                           player_ride = 0;
                           jump_count=1.57;
                           event(15);
                        }
                  }
            } /* end of else not jump and end of Y_MOVE */
      } /* end of if ! ride rocket */
}
draw_player()
{
   PXint = PX;
   PYint = PY;
   b = 9;

   if (up)   b=10;
   if (down) b=11;

   x = (PXint/4) % zz[4][b];
   if ((jump_count) || (fall_count)) x = 0;
   if ((player_ride) && (right_speed<.5) && (left_speed<.5)) x = 0;
   if ((player_carry) && (item[player_carry-1][0] == 98)) x = 0;

   y = zz[x+5][b];

   if (left_right) draw_sprite(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
   else draw_sprite_h_flip(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
   if (game_map_on)
      {
        /*  rectfill(map100_bmp,((PXint+10)/20)-1, (PYint/20)-1,((PXint+10)/20)+1, (PYint/20)+1,152);
          */

         if ((passcount % 20) < 10 )
            {
               putpixel(map100_bmp,((PXint+10)/20)+1, (PYint/20),74);
               putpixel(map100_bmp,((PXint+10)/20)-1, (PYint/20),74);
               putpixel(map100_bmp,((PXint+10)/20), (PYint/20)+1,74);
               putpixel(map100_bmp,((PXint+10)/20), (PYint/20)-1,74);
            }
         if ((passcount % 20) > 9 )
            {
               putpixel(map100_bmp,((PXint+10)/20)+1, (PYint/20)+1,74);
               putpixel(map100_bmp,((PXint+10)/20)-1, (PYint/20)-1,74);
               putpixel(map100_bmp,((PXint+10)/20)+1, (PYint/20)-1,74);
               putpixel(map100_bmp,((PXint+10)/20)-1, (PYint/20)+1,74);
            }
          putpixel(map100_bmp,((PXint+10)/20), (PYint/20),10);
      }
}
move_lifts()
{
   for (d=0; d<level_header[5]; d++)
      {
         int color = lifts[d]->color;
         int next_mode = 0;
         lifts[d]->fx += lifts[d]->fxinc; /* xinc */
         lifts[d]->fy += lifts[d]->fyinc; /* yinc */
         if (d == player_ride-32)
            {
               PXint = PX;
               PYint = PY;
               if ((lifts[d]->fxinc > 0) && (!is_right_solid(PXint,PYint)) )
                  {
                     PX += lifts[d]->fxinc;
                     if (PX>1980) PX=1980;
                  }
               if ((lifts[d]->fxinc < 0) && (!is_left_solid(PXint,PYint)) )
                  {
                     PX += lifts[d]->fxinc;
                     if (PX<0) PX=0;
                  }
               PY = lifts[d]->fy-20; /* align with fy */
            }
         lifts[d]->x1 = lifts[d]->fx; /* put as int in x1 */
         lifts[d]->y1 = lifts[d]->fy; /* put as int in y1 */
         lifts[d]->x2 = lifts[d]->x1 + (lifts[d]->width*20)-1; /* width  */
         lifts[d]->y2 = lifts[d]->y1 + (lifts[d]->height*20)-1; /* height */

         /* limits */
         switch (lifts[d]->limit_type) /* limit type */
            {
               case 5: /* timer wait */
                       if (--lifts[d]->limit_counter < 0)
                       next_mode = 1;
               break;
               case 6: /* prox wait */
                  {
                     int pd = lifts[d]->limit_counter; /* prox dist */
                     int bx1 = lifts[d]->x1 - pd;
                     int by1 = lifts[d]->y1 - pd;
                     int bx2 = lifts[d]->x2 + pd;
                     int by2 = lifts[d]->y2 + pd;
                     if ( (PX+10 > bx1) && (PX+10 < bx2) && (PY+10 > by1) && (PY+10 < by2) )
                        next_mode = 1;
                  }
               break;
               case 7: /* step count */
                       if (--lifts[d]->limit_counter < 0)
                       next_mode = 1;
               break;
            }
         if (next_mode)
            {
               int step = ++lifts[d]->current_step;
               next_mode = 0;
               switch (lift_steps[d][step] -> type)
                  {
                     case 1: /* move */
                        set_lift_xyinc(d, step);
                     break;
                     case 2: /* wait time */
                        lifts[d]->limit_type = 5; /* wait time */
                        lifts[d]->limit_counter = lift_steps[d][step] -> val; /* limit */
                        lifts[d]->fxinc= 0; /* no xinc */
                        lifts[d]->fyinc= 0; /* no yinc */
                     break;
                     case 3: /* wait prox */
                        lifts[d]->limit_type = 6; /* wait prox */
                        lifts[d]->limit_counter = lift_steps[d][step] -> val; /* limit */
                        lifts[d]->fxinc= 0; /* no xinc */
                        lifts[d]->fyinc= 0; /* no yinc */
                     break;
                     case 4: /* move to step 0 */
                           step = lifts[d]->current_step = 0; /* set step 0 */
                           set_lift_xyinc(d, step);
                     break;
                  }
            }
      } /* end of if (active) */
}
draw_lifts()
{
   for (d=0; d<level_header[5]; d++)
      {
         int x1 = lifts[d]->x1;
         int x2 = lifts[d]->x2;
         int y1 = lifts[d]->y1;
         int y2 = lifts[d]->y2;
         int mode = lifts[d]->current_step;
         int color = lifts[d]->color;
         if (game_map_on)
            {
               if (y2-y1 > 20) rect(map100_bmp, x1/20, y1/20, x2/20, -1 + y2/20, color);
               else hline(map100_bmp, x1/20, y1/20, x2/20, color); /* single line */
            }
         for (a=0; a<10; a++)
            rect(scrn_buffer, x1-WX+a, y1-WY+a, x2-WX-a, y2-WY-a, color + ((9 - a)*16) );
         rectfill(scrn_buffer, x1-WX+a, y1-WY+a, x2-WX-a, y2-WY-a, color );
         textout_centre(scrn_buffer, font, lifts[d]->lift_name, ((x1+x2)/2)-WX, ((y1+y2)/2)-WY-2, color+160);



         switch (lifts[d]->limit_type) /* limit type */
            {
               case 5: /* timer wait */
                       sprintf(msg,"%d",lifts[d]->limit_counter) ;
                       textout_centre(scrn_buffer, font, msg, (lifts[d]->x1 + lifts[d]->x2)/2-WX+2, lifts[d]->y1-8-WY, color+64);
               break;
               case 6: /* prox wait */
                  {
                     int pd = lifts[d]->limit_counter; /* prox dist */
                     int bx1 = lifts[d]->x1 - pd;
                     int by1 = lifts[d]->y1 - pd;
                     int bx2 = lifts[d]->x2 + pd;
                     int by2 = lifts[d]->y2 + pd;
                     rect(scrn_buffer, bx1-WX+10, by1-WY+10, bx2-WX-10, by2-WY-10, color+128);
                  }
              break;
           }


      }  /* end of draw lift */
}
enemy_draw_and_collision(void)
{
   int nec = 0;
   for (e = 0; e < 100; e++)
      if (Ei[e][0])  /* if enemy active */
         {
            int EXint = Ef[e][0];
            int EYint = Ef[e][1];
            nec++;
            for (c=0; c<50; c++)  /* check all bullets */
               if (pbullet[c][0]) /* if active */
                {
                  a = abs(pbullet[c][4]/2) + pm_bullet_collision_box; /* bullet stretch collision box size */
                  b = abs(pbullet[c][5]/2) + pm_bullet_collision_box;
                     if (abs(pbullet[c][2] - EXint) < a)
                        if (abs(pbullet[c][3] - EYint) < b)
                                {
                                    /* enemy dies from bullet wound */

                                    if (Ei[e][0] == 11) /* H block! */
                                       {
                                          int tx = EXint/20;
                                          int ty = EYint/20;
                                          l[tx][ty] = 168;

                                          blit(memory_bitmap[168], level_2000, 0, 0, (tx*20), (ty*20), 20, 20);
                                          putpixel(map100_bkg, tx, ty, 8);


                                       }

                                    event(13);
                                    Ei[e][0] = 0; /* set to inactive */
                                    pbullet[c][0] = 0; /* bullet dies too */

                                 }
               }
            b = Ei[e][9]; /* collision box size */

            if (PXint > (EXint -b)) /* check for collision with player */
               if (PXint < (EXint +b))
                  if (PYint > (EYint -b))
                     if (PYint < (EYint +b))
                        {
                           /* player got hit;  loses some LIFE */
                           event(12);
                           LIFE -= Ef[e][4]*( (float) dif/4 );
                        }
              /* check for on screen */
              if ((EXint > WX - 20) && (EXint < WX + SCREEN_W))
                 if ((EYint > WY - 20) && (EYint < WY + SCREEN_H))
                    {
                       clear(dtemp);
                       /* put shape in dtemp and process flips */
                       if (Ei[e][2] == 0)  draw_sprite_h_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
                       if (Ei[e][2] == 1)         draw_sprite(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
                       if (Ei[e][2] == 2)  draw_sprite_v_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
                       if (Ei[e][2] == 3) draw_sprite_vh_flip(dtemp, memory_bitmap[Ei[e][1]], 0, 0);
                       /* process rotation */
                       if (Ei[e][20])
                          rotate_sprite(scrn_buffer, dtemp, EXint-WX, EYint-WY, itofix(Ei[e][20]) );
                       else draw_sprite(scrn_buffer, dtemp, EXint-WX, EYint-WY );
                     }
              if (game_map_on) putpixel(map100_bmp, (EXint/20), (EYint/20), map_enemy_color);
         } /* end of if active */
   num_enemy=nec; /* this function uses num_enemy so...*/
}
proc_pbullets()
{
   request_bullet=0;
   if ((fire) && (!fire_held) && (!bullet_wait_counter)) /* fire button pressed */
      {
         if (num_bullets > 0)
            {
               request_bullet = 1;
               bullet_wait_counter = bullet_wait;
               fire_held=1;
            }
         else event(20); /* out of bullets */

      }
   else if (--bullet_wait_counter < 0) bullet_wait_counter = 0;
   for (b = 0; b < 50; b++)
      {
         if (pbullet[b][0])  /* if bullet not active skip to next one */
            {
               pbullet[b][2] += pbullet[b][4];  /* xinc */
               pbullet[b][3] += pbullet[b][5];  /* yinc */
               if ((pbullet[b][2] < 5) || (pbullet[b][2] > 1995) || (pbullet[b][3]<5) || (pbullet[b][3] > 1995) )
                  pbullet[b][0];
               x = ( (pbullet[b][2] + 10) / 20);
               y = ( (pbullet[b][3] + 10) / 20);
               d = l[x][y];
               if ((d > 15) && (d < 256)) /* if hit solid or breakable */
                  {
                     pbullet[b][0] = 0;  /* bullet dies  */
                     if ((d > 23) && (d < 32)) /* breakable wall */
                        {
                           l[x][y] = 0; /* wall dies too */
                           blit(memory_bitmap[0], level_2000, 0, 0, (x*20), (y*20), 20, 20);
                           putpixel(map100_bkg, x, y, map_empty_color);
                        }
                  }
               draw_sprite(scrn_buffer, memory_bitmap[zz[0][4]], pbullet[b][2]-WX, pbullet[b][3]-WY);
               if (game_map_on) putpixel(map100_bmp, x, y, map_bullet_color);
            }
         else if (request_bullet)
            {
                      /* setting initial...*/
                request_bullet = 0;
                event(1);
                pbullet[b][0] = 1;
                pbullet[b][2] = PXint;
                pbullet[b][3] = PYint + 1;
                pbullet[b][4] = 0; /* xinc */
                pbullet[b][5] = 0; /* yinc */
                num_bullets--;
                if (up)
                   {
                      pbullet[b][5] = -bullet_speed;
                      pbullet[b][2] = -5 + PXint + (left_right*10);
                   }
                else if (down)
                   {
                      pbullet[b][5] = bullet_speed;
                      pbullet[b][2] = -5 + PXint + (left_right*10);
                   }
                else pbullet[b][4] = (left_right * (bullet_speed*2) ) - bullet_speed;
            }
      }
}
proc_ebullets()
{
   for (b = 0; b < 50; b++)
      if (e_bullet_active[b])  /* if bullet not active skip to next one */
         {
            int ex, ey;
            e_bullet_x[b] += e_bullet_xinc[b]; /* inc x */
            e_bullet_y[b] += e_bullet_yinc[b]; /* inc y */
            ex = e_bullet_x[b];
            ey = e_bullet_y[b];
            if ((ex<0) || (ex>2000) || (ey<0) || (ey>2000))
               e_bullet_active[b] = 0;
            x = (ex+10)/20;
            y = (ey+10)/20;
            d = l[x][y];
            if ((d > 15) && (d<256)) /* bullet hit solid or breakable wall */
               {
                  e_bullet_active[b] = 0;  /* bullet dies */
                  if ((d > 23) && (d < 32)) /* remove breakable wall */
                     {
                        l[x][y] = 0;
                        blit(memory_bitmap[0], level_2000, 0, 0, (x*20), (y*20), 20, 20);
                        putpixel(map100_bkg, x, y, map_empty_color);
                     }
               }
            if (e_bullet_shape[b] > 1000)
               {
                   d =  e_bullet_shape[b]-1000;
                   d = zz[0][d];
                   draw_sprite(scrn_buffer, memory_bitmap[d], ex-WX, ey-WY);

               }
            else draw_sprite(scrn_buffer, memory_bitmap[e_bullet_shape[b]], ex-WX, ey-WY);
            if (game_map_on) putpixel(map100_bmp, x, y, map_bullet_color);
            /* check for collision with player */
            if (ex > (PXint - enemy_bullet_colision_window ))
               if (ex < (PXint + enemy_bullet_colision_window ))
                  if (ey > (PYint - enemy_bullet_colision_window ))
                     if (ey < (PYint + enemy_bullet_colision_window ))
                              {
                                 /* player got hit ! */

                                 switch (e_bullet_shape[b])
                                    {
                                       /* arrow */
                                       case 488:  LIFE -= 5  * dif; break;
                                       case 489:  LIFE -= 5  * dif; break;
                                       /* cannon ball */
                                       case 1055:  LIFE -= 7 * dif; break;
                                       /* yellow things */
                                       case 1020:  LIFE -= 9 * dif; break;
                                       /* green ball */
                                       case 1054:  LIFE -= 10 * dif; break;
                                   
                                    }
                                 event(11);
                                 e_bullet_active[b] = 0;
                              }
         } /* end of if active */
}
proc_lit_rocket()
{
   int speed, shape;
   float angle;

   /* get these from item data */

   int accel = 12;
   int max_speed = 8000;
   int rot_inc = 12;

   for (c=0; c<500; c++)
      if (item[c][0] == 98) /* lit rocket! */
         {
            int speed = item[c][11];
            int max_speed = item[c][8]*1000;
            int accel = item[c][9];
            int rot_inc = item[c][6];
            lit_item = 1;

            if (item[c][11] < max_speed) item[c][11]+=accel; /* speed and accel */

            /* set angle and speed */
            angle = ( (float) (item[c][10]-640) / 64/10)*1.57; /* convert to radians */

            itemf[c][2] = cos(angle) * item[c][11]/1000;  /* hypotenuse is the speed! */
            itemf[c][3] = sin(angle) * item[c][11]/1000;

            x = itemf[c][0] += itemf[c][2]; /* do the increments */
            y = itemf[c][1] += itemf[c][3];

            shape = zz[0][item[c][1]-1000]; /* ans */
            rotate_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY, itofix(item[c][10]/10));
            if (game_map_on) putpixel(map100_bmp, x/20, y/20, 14);
            if (c == (player_carry-1)) /* player is riding this rocket! */
               {
                  fall_count=0;
                  PY = itemf[c][1] + itemf[c][3];
                  if (PX >= itemf[c][0]) PX = itemf[c][0] + itemf[c][2] +14;
                  if (PX < itemf[c][0])  PX = itemf[c][0] + itemf[c][2] -14;
                  PXint = PX;
                  PYint = PY;

                  if (left)  item[c][10]-=rot_inc;
                  if (right) item[c][10]+=rot_inc;

               }
            if ( ((itemf[c][3]<0) && (is_up_solid(x,y,0,0)==1)) ||
                 ((itemf[c][3]>0) && (is_down_solid(x,y,0)==1)) )
               {
                  if (c == (player_carry-1)) /* player is riding this rocket! */
                     if (is_down_solid(PXint, PYint,0)==1)
                        PY -= fmod (PY, 20); /* align with floor */

                  for (d=0; d<20; d++)  /* make boom! */
                     if (!bomb[d][0])  /* find empty */
                        {
                           itemf[c][3] = .1; /* slow down */
                           bomb[d][0] = 32 + c; /* link to item */
                           bomb[d][1] = 5; /* total fuse wait */
                           bomb[d][2] = 1; /* seq fuse wait */
                           bomb[d][3] = item[c][7]; /* damage */
                           bomb[d][4] = 1; /* for blow up */
                           item[c][0] = 99; /* change to lit bomb */
                           d = 20; /* end bomb loop */
                        }

                     if (d == 19) item[c][0] = 0; /* erase, if no space in the bomb array */
               }
         }
}
proc_player_carry()
{
   if (player_carry)  /* move with player */
      {
         int pc = player_carry-1;
         if (item[pc][0] != 98) /* not lit rocket */
            {
               itemf[pc][1] = PY - 2;
               if (!left_right) itemf[pc][0] = PX - 15;
               if (left_right) itemf[pc][0] = PX + 15;
               x = (int) itemf[pc][0];
               y = (int) itemf[pc][1];
               if (game_map_on) putpixel(map100_bmp, x/20, y/20, 7);
               if (item[pc][0] != 99) /* not lit bomb */
                     {
                       int shape;
                       a = item[pc][1]; /* get shape */
                       if (a < 512) shape = a; /* bitmap */
                       if (a > 999) shape = zz[0][a-1000]; /* ans */
                       if (item[pc][2] == 1) /* draw mode normal */
                           draw_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY);
                     }
               }
         if (!fire) /* drop */
            {
               player_carry = 0;
               if (item[pc][0] != 98) /* not lit rocket */
                  {
                     x = itemf[pc][0];
                     y = itemf[pc][1];
                     itemf[pc][2] = 0;  /* xinc = 0 */
                     if (fall_count) itemf[pc][3] = (sin(1.57-fall_count) * pmovey);
                     if (jump_count) itemf[pc][3] = (sin(jump_count) * pmovey);
  
                     if (up)
                        itemf[pc][3] = -6; /* throw up */
  
                     if (p_xmove > 0)
                        if (!is_right_solid(x,y))
                           itemf[pc][2] = p_xmove;
  
                     if (p_xmove < 0)
                        if (!is_left_solid(x,y))
                           itemf[pc][2] = p_xmove;
                  }
               else /* lit rocket */
                  {

                  }

            } /* end of if (!fire) */
      } /* end of if player carry */
}
proc_lit_bomb()
{
   for (d=0; d<20; d++)   /* lit bomb handler! */
      if (bomb[d][0])   /* bomb lit! */
         {
            lit_item = 1;
            if (--bomb[d][1] > 0)  /* dec the fuse count */
               {
                  e = bomb[d][1] / bomb[d][2]; /* shape # */
                  c = zz[16-e][25];
                  x = itemf[bomb[d][0]-32][0];
                  y = itemf[bomb[d][0]-32][1];
   
                  if (bomb[d][1] < (bomb[d][2] * 5)) /* start blow-up */
                     {
                        if (player_carry-1 == bomb[d][0]-32) player_carry = 0;
                        a = ((bomb[d][2] * 6) - bomb[d][1]); /* 50 - ticks */
                        a = 2 * a * bomb[d][3]; /* 2 times damage */
                        a = a / (bomb[d][2] * 5);  /* / 50 */
   
                        if (game_map_on)
                           {
                              rect(map100_bmp, (x/20)-(a/40), (y/20)-(a/40),(x/20)+(a/40), (y/20)+(a/40),10);
                              stretch_sprite(map100_bmp, memory_bitmap[c], (x/20) - (a/40), (y/20) - (a/40), 1 + (a/20), 1 + (a/20) );
                           }
                        stretch_sprite(scrn_buffer, memory_bitmap[c], (x-WX) - (a/2), (y-WY) - (a/2), 20 + a, 20 +a );
                     }
                  else draw_sprite(scrn_buffer, memory_bitmap[c], x-WX, y-WY);
               }
            if (bomb[d][1] < (bomb[d][2] * 6)) /* fuse done !*/
               if (bomb[d][4])  /* first time only */
                  {
                     /* check for other co-located bombs */
                     for (c=0; c<20; c++)
                        if ((bomb[c][0]) && (c != d))
                           if (x = itemf[bomb[c][0]-32][0])
                              if (y = itemf[bomb[c][0]-32][1])
                                 if (bomb[d][1] == bomb[c][1]-1)
                                    {
                                       item[ bomb[c][0]-32 ] [0] = 0;
                                       bomb[c][0] = 0;
                                    }

                     event(22);
                     bomb[d][1] = 23;  /* speed up ans */
                     bomb[d][2] = 4;
                     bomb[d][4] = 0;
                  }
            if (bomb[d][1] < (bomb[d][2] * 3)) /* do the damage! */
               {
                  c = bomb[d][3];  /* damage window */
                  x = itemf[ bomb[d][0]-32 ][0];
                  y = itemf[ bomb[d][0]-32 ][1];
   
                  for (e=0;e<100;e++) /* enemies in damage window? */
                     if (Ei[e][0])
                        if (Ef[e][0] > ((x-c)) )
                           if (Ef[e][0] < ((x+c)) )
                              if (Ef[e][1] > ((y-c)) )
                                 if (Ef[e][1] < ((y+c)) )
                                    {
                                       Ei[e][0] = 0; /* dead! */
                                       event(23);
                                    }
   
                  if (PX > (x-c)) /* is player in window?*/
                     if (PX < (x+c))
                        if (PY > (y-c))
                           if (PY < (y+c))
                              {
                                 LIFE -= 3;
                              }
                  c /= 20;  /* convert to (0-100)  */
                  x /= 20;
                  y /= 20;
   
                  for (e = (x-c); e < (x+c)+1; e++)    /* erase on the maps */
                     for (f = (y-c); f < (y+c)+1; f++)
                       if ((e>0) && (e<99) && (f>0) && (f<99)) /* if on screen */
                           if ((l[e][f] < 16) || (l[e][f] > 23)) /* if not bomb_proof */
                                 {
                                    l[e][f] = 0;
                                    putpixel(map100_bkg, e, f, map_empty_color);
                                    blit(memory_bitmap[0], level_2000, 0, 0, e*20, f*20, 20, 20);
                                 }
                  draw_lift_lines();
               } /* end of damage */
            if (bomb[d][1] < 1)  /* bomb done */
               {
                  item[ bomb[d][0]-32 ] [0] = 0;
                  bomb[d][0] = 0;  /* set to inactive */
               }
         } /* end of if lit bomb */
}
draw_items()
{
   for (c=0; c<500; c++) /* rem update items on scrn_buffer */
      if (item[c][0])   /* if not type 0  */
         {
            int shape = 255; /* default */
            x = (int) itemf[c][0];
            y = (int) itemf[c][1];
            if (game_map_on) putpixel(map100_bmp, x/20, y/20, 7);
            if ((item[c][0] != 99) && ((player_carry-1) != c) )
               if ((x > WX-20) && (x < (WX + SCREEN_W)) && (y > WY-20) && (y < (WY + SCREEN_H)))
                  {
                    /* get shape */
                    a = item[c][1];
                    if (a < 512) shape = a; /* bitmap */
                    if (a > 999) shape = zz[0][a-1000]; /* ans */
                    /* do draw mode */
                    if (item[c][0] == 11) rotate_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY, itofix(item[c][10]/10));
                    else if (item[c][2] == 1) /* draw mode normal */
                        draw_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY);
                  }
          }
}
proc_item_move()
{
   for (c=0; c<500; c++)  /* item move */
      if ((item[c][0]) && (item[c][3])) /* active and not stationary */
         if (item[c][0] != 98) /* not lit rocket */
            if (c != (player_carry-1)) /* not carrying */
               {
                  itemf[c][0] += itemf[c][2];  /* xinc */
                  itemf[c][1] += itemf[c][3];  /* yinc */
                  x = (int) itemf[c][0];
                  y = (int) itemf[c][1];
                  if (itemf[c][2] > 0) itemf[c][2] -= .01; /* slow down x move */
                  if (itemf[c][2] < 0) itemf[c][2] += .01; /* slow down x move */
   
                  if (itemf[c][2] > 0) /* right */
                     if (is_right_solid(x,y)) /* check for block right */
                        itemf[c][2] = 0;  /* stop */
   
                  if (itemf[c][2] < 0) /* left */
                     if (is_left_solid(x,y)) /* check for block left */
                        itemf[c][2] = 0;  /* stop */
   
                  if (itemf[c][3] < 0) /* rising */
                    {
                       if (!is_up_solid(x,y,0,0)) itemf[c][3] += .1; /* de-accel */
                       else itemf[c][3] = 0; /* stop y move if hit ceiling */
                    }
                 if (itemf[c][3] > 0) /* falling */
                    {
                       if (!is_down_solid(x,y, 1)) /* check for block below */
                          {
                             itemf[c][3] += .1;  /* accel */
                             if (itemf[c][3] > 3) itemf[c][3] = 3;  /* max accel */
                          }
                       else
                          {
                             if (itemf[c][2] > 0) itemf[c][2] -= .15; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .15; /* slow down x move if on ground */
   
                             itemf[c][1] = ((y/20)*20); /* align with ground */
   
                             itemf[c][3] = 0; /* stop y move if on ground */
                          }
                     }
                if (itemf[c][3] == 0) /* yinc steady */
                    {
                       a = is_down_solid(x,y,1); /* check for block below */
                       if (a==0)
                          {
                             itemf[c][3] += .1;  /* accel */
                             if (itemf[c][3] > 4) itemf[c][3] = 4;  /* max accel */
                          }
                       if (a==1)
                          {
                             itemf[c][3] = 0; /* stop y move if on ground */
                             if (itemf[c][2] > 0) itemf[c][2] -= .03; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .03; /* slow down x */
                          }
                       if (a > 31) /* item riding mov  */
                          {
                             itemf[c][0] += lifts[a-32]->fxinc; /* move with xinc */
                             itemf[c][1]  = lifts[a-32]->fy - 20; /* align with Y1 */
                             if (itemf[c][2] > 0) itemf[c][2] -= .03; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .03; /* slow down x */
                          }
                     }
               }  /* end of if not carry */
}
proc_item_collison()
{
   for (x=0; x<500; x++) /* item collision with man */
      if (item[x][0])  /* is object active */
         if ((PX > itemf[x][0] - 16) && (PX < itemf[x][0] + 16))
            if ((PY > itemf[x][1] - 16) && (PY < itemf[x][1] + 16))
               {
                  if (item[x][3] == -1) /* try to pick up item */
                     if ((fire) && (!player_carry))  /* if not already carrying */
                        player_carry = x+1;
                  switch (item[x][0]) /* type */
                     {
                        case 1:  /* door */
                           event(5);


                           PX = item[x][6] * 20;
                           PY = item[x][7] * 20;
                           left_speed=0;
                           right_speed=0;
                           jump_count=0;
                           fall_count=0;
                     
                           if (WX < 0) WX = 0;
                           if (WX > 1680) WX = 1680;
                           if (WY>1800) WY = 1800;
                           if (WY < 0) WY = 0;
                           fade_out(10);
                           blit(level_2000, scrn_buffer, WX, WY, 0, 0, 320, 200);
                           fade_in(pallete,10);
                        break;
                        case 2:

                           if (item[x][7])
                              {
                                 if (LIFE < 100)
                                    {
                                       item[x][0] = 0;
                                       LIFE += item[x][7];
                                       if (LIFE > 100) LIFE = 100;
                                       event(6);
                                    }
                                 else event(26);
                              }
                           if (item [x][8])
                              {
                                 if (num_bullets < max_bullets) /* only if not full */
                                    {
                                       item[x][0] = 0;
                                       num_bullets += item[x][8];
                                       if (num_bullets > max_bullets) num_bullets = max_bullets;
                                       event(7);
                                    }
                                 else event(27);

                              }
                           if (item[x][9])
                              {
                                 item[x][0] = 0;
                                 level_time += item[x][9] * 50;

                                 event(8);

                              }
                        break;
                        case 3: /* exit */
                            if ( (item[x][8]) && (num_enemy) )
                               {
                                    event(3);
                               }
                            else
                               {
                                  level_done = 1;
                                  event(4);
                               }
                         break;
                         case 4: /* key */
                            item[x][0] = 0;
                            event(2);
                            for (c = item[x][6]; c <= item[x][8]; c++)
                               for (y = item[x][7]; y <= item[x][9]; y++)
                                  {
                                     l[c][y] = 0;
                                     blit(memory_bitmap[0], level_2000, 0, 0, c*20, y*20, 20, 20);
                                     putpixel(map100_bkg, c, y, map_empty_color);

                                  }
                            draw_lift_lines();

                         break;
                         case 6: /* free man */
                            item[x][0] = 0;
                            LIVES++;
                            event(9);
                            break;

                         case 7:
                           event(10);
                           LIFE -= (float) item[x][8]/10;
                         break;
                         case 8: /* un-lit bomb */
                           event(24);
                           item[x][0] = 99; /* lit bomb */
                           item[x][3] = -1; /* carry */
                           for (d=0; d<20; d++)
                              if (!bomb[d][0])  /* find empty */
                                 {
                                    bomb[d][0] = 32 + x; /* link to item */
                                    bomb[d][1] = item[x][9] * zz[4][25]; /* total fuse wait */
                                    bomb[d][2] = item[x][9]; /* seq fuse wait */
                                    bomb[d][3] = item[x][7]; /* damage */
                                    bomb[d][4] = 1; /* for blow up */
                                    d = 20; /* end bomb loop */
                                 }
                               else if (d == 19) item[x][0] = 0; /* erase if no space in the bomb array */
                         break;
                         case 10: /* POP UP MESSAGE */
                           pop_msg = x+1;
                           pop_msg_count = 120;

                         break;
                         case 11: /* rocket */

                           event(25);
                           item[x][0] = 98; /* new type - lit rocket */
                           item[x][1] = 1026; /* new ans */
                           item[x][2] = 0; /* no draw */
                           item[x][3] = -1; /* carryable */
                           itemf[x][3] = 0; /* stop if falling */
                         break;
             
                      } /* end of switch case */
               } /* end of if on screen */

}
void pm_main(void) /* game loop! */
{
   int loop_time = msec_timer;
   int old_msec_timer = msec_timer;
   text_mode(-1);  /* masked */
   if (!start_mode) stimp();
   while (!game_exit) /* game loop */
      {
         if (start_mode)
            {
               if (start_mode == 1)  /* load level */
                  {
                     if (load_level(play_level,0))
                        {
                           initialize_zz(0);
                           maps_and_background_fill();
                        }
                     else
                        {
                           game_exit = 1;
                           resume_allowed = 0;
                           goto badload;
                        }
                  }
               if (start_mode == 2) /* resume after death */
                  {
                     LIFE = 100;
                     num_bullets = 100;
                  }
               for (c=0; c<500; c++)  /* get start and time */
                  if (item[c][0] == 5)
                     {
                        PX = itemf[c][0];
                        PY = itemf[c][1];
                        level_time = item[c][8] * 50;
                        stimp();
                        break;
                     }
               for (c=0; c<8; c++)
                  sample_delay[c] = passcount;

               player_carry = 0;
               player_ride = 0;
               level_done = 0;
               bottom_msg=0;
               pop_msg_count=0;
               right_speed = left_speed = 0;
               jump_count = fall_count = 0;
               clear_keybuf();
               start_mode = 0;

            }
         /*  true game loop starts here !!!!  above is only setup */

         /* frame speed delay */
         while ((msec_timer-loop_time) < frame_speed);

         if (passcount % 20 == 0) /* calc frames per sec */
            {
               fps =  1000*( (float)20/(float)(msec_timer-old_msec_timer) );
               old_msec_timer = msec_timer;
            }
         loop_time = msec_timer;
         if (--bottom_msg > 0) textout_centre(scrn_buffer, font, b_msg, SCREEN_W/2, SCREEN_H-9, bottom_display_color);
         if (--pop_msg_count > 0) draw_pop_msg();
         else pop_msg = 0;
         if (top_display_on) draw_top_display();
         if (game_map_on) draw_map();
         blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W,SCREEN_H); /* screen buffer to screen */
         move_lifts();
         if (ap_mode == 1) proc_ap_control();
#ifdef MV
         else if (ap_mode == 2) rec_ap_control();
#endif
         else proc_controllers();
   
         player_move();
         get_new_background();
         update_animation();
   
         draw_items();
         draw_player();
         draw_lifts();
         proc_ebullets();
         proc_pbullets();
         enemy_move();
         enemy_draw_and_collision();
         proc_lit_rocket();
         proc_player_carry();
         proc_item_collison();
         proc_item_move();
         proc_lit_bomb();
         if (sound_on)
            {
               if ((!fuse_loop_playing) && (lit_item))
                  {
                     fuse_loop_playing = 1;
                     play_sample(snd[3], 200, 127, 1000, 1);
                  }
               if ((fuse_loop_playing) && (!lit_item))
                  {
                     fuse_loop_playing = 0;
                     stop_sample(snd[3]);
                  }
               lit_item = 0;
            }
         if (--level_time < 40) LIFE = -1;
         if (LIFE>100) LIFE = 100;
         if (LIFE < 0)
            {
               if (sound_on)
                  {
                     stop_sample( snd[3] ); /* fuse hiss */
                     fuse_loop_playing = 0;
                  }
               start_mode = 2;
               event(21);
               if (--LIVES < 0)
                  {
                     stretch_text("Game", "Over!", 14);
                     resume_allowed = 0;
                     top_menu_sel = 3; /* not resume */
                     game_exit = 1;
                  }
               else if (level_time < 40) /* out of time */
                  stretch_text("Time Up!", NULL, 10);
               else stretch_text("You", "Died!", 10);
            }
         if (level_done)
            {
               if (sound_on) stop_sample( snd[3] );
               stretch_text("Level", "Done!", 9);
               play_level++;
               start_mode = 1;
            }

     } /* end of while (!game_exit) */

   badload:
   if (resume_allowed) top_menu_sel = 4; /* resume */
   if (sound_on)
      {
         stop_sample( snd[3] ); /* fuse hiss */
         fuse_loop_playing = 0;
      }
   stamp();
   text_mode(0);  /* normal */
   clear_keybuf();
}

