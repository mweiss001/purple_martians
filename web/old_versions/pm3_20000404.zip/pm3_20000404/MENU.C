#include "pm.h"

char global_string[20][25][80]; /* menu.c */

char help_string[2400][90];


void fill_fnlst(char *cfname, int attrib, int param) /* for demo mode */
{
   extern char fnlst[50][80];
   extern int fn;
   strcpy(fnlst[fn++], cfname);

}
void demo_mode(void)
{
   extern int resume_allowed;
   extern int ap_mode;
   extern int api;
   extern int level_done;
   extern int num_bullets;
   extern int start_mode;
   extern int game_exit;
   extern int LIVES;
   extern float LIFE;

   extern int fn;
   extern char fnlst[50][80];
   extern int old_tf;
   char msg[80];
   int tf;

   /* make list of *.apl files */

   fn = 1;

   for_each_file("*.apl", NULL, fill_fnlst, NULL );


   if (fn == 2)  /* only one file */
      tf = 1;
   if (fn > 2)   /* 2 or more */
      {
         do
            {
               tf = (random()%(fn-1))+1;   /* get random */
            } while(tf == old_tf ); /* must be new */
         old_tf = tf;
      }

   if (fn>1)
      {
         extern int tmx, tmy; /* menu pos */
         extern int start_level;
         extern int top_menu_sel;
         load_apl( tf ) ;

         sprintf(msg, "Demo Mode (0)");
         textout_centre(screen, font, msg, tmx, tmy+(9*8), 10);

         set_volume(92, -1);
         ap_mode = 1;
         api = 0;
         level_done = 0;
         num_bullets = 200;
         LIVES = 5;
         LIFE = 100;
         start_mode = 1; /* load start */
         game_exit = 0;

         pm_main();
         ap_mode = 0;
         top_menu_sel = 3;
         resume_allowed = 0;
         clear(screen);
         frame_and_title();
         slow_load_and_draw_level(start_level);
         set_volume(255, -1);

      }
}
int load_help(void)
{
   FILE *filepntr;
   char buff[90], msg[80];
   int line=0;
   int loop;
   int ch=0;

   if ((exists("pmhelp.txt")) == 0)
      {
         textout(screen, font, "can't find pmhelp.txt", 16, 184, 10);
         rest(5000);
         return 0;
      }
   else
      {
         filepntr=fopen("pmhelp.txt","r");
         while(ch != EOF)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                     buff[loop] = ch;
                     loop++;
                     ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               strcpy (help_string[line], buff);
               line++;
            }
        fclose(filepntr);
      }
   return line;
}
void help(char *topic)
{
   BITMAP *screenbuf;
   extern BITMAP *memory_bitmap[512];
   extern int zz[20][64];
   int ans, c, b, k, x, xindent, just, color, rcolor=15, hcolor=14;
   int got_num =0;
   int redraw = 1;
   int num_of_lines;
   int last_pos;
   int sl = 13; /* position of section list */

   int xo;
   int yo = 0;
   int sc=10;  /* section divider */
   int stc=14; /* section divider text color */

   int fc=4;  /* frame color */
   int tc=9;  /* bottom line text color */


   int line = 0;
   int num_sections;
   int section_first_lines[60];
   char section_names[60][80];
   int lpp; /* lines per page */
   int y = 8;
   char msg[90], buff2[90];

   extern int sx;
   extern int sy;

   if (sy < 480)
      {
         set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0);
         sc_setup();
      }

   xo = (SCREEN_W-640)/2;
   lpp = (SCREEN_H-48)/8; /* lines per page */



   screenbuf = create_bitmap(640, SCREEN_H);

   num_of_lines = load_help();

   /* fill section_name, section_first_lines and set last_pos */
   num_sections = 0;
   line = 0;
   while (line < num_of_lines)
      {
         if (strncmp(help_string[line], "<section>", 9) != 0)
            line++;
         else
            {
               strcpy(msg, help_string[line]);
               for(x=9; x < strlen(msg)+1; x++)
                  buff2[x-9] = msg[x]; /* chop first 9 */
               strcpy(section_names[num_sections], buff2);
               section_first_lines[num_sections] = line;

               if (num_sections < 10)
                  sprintf(help_string[line], "<section>0%-1d - %s",  num_sections, section_names[num_sections]);
               else
                  sprintf(help_string[line], "<section>%-2d - %s",  num_sections, section_names[num_sections]);

               line++;
               num_sections++;
            }
         last_pos = section_first_lines[num_sections-1];
       }
   line=0;

   /* add section headings to page 1 */

   /* slide all down */
   for(x=num_of_lines+num_sections; x > (sl-1+num_sections); x--)
      strcpy(help_string[x], help_string[x-num_sections]);

   for (c=0; c<num_sections; c++)
      {
         /* slide section first line numbers */
         if (c > 0) section_first_lines[c]+=num_sections;

         if (c < 10)
            sprintf(msg, "<l07>         0%-1d   %s", c, section_names[c] );
         else
            sprintf(msg, "<l07>         %-2d   %s", c, section_names[c] );
         strcpy(help_string[sl+c], msg);
      }

   last_pos+= num_sections;
   num_of_lines+=num_sections;
   text_mode(-1);

   /* topic */
   if (strlen(topic)>1)
      for (c=0; c<num_sections; c++)
         if (strncmp(section_names[c], topic, strlen(topic)) == 0)
            line = section_first_lines[c];

   show_mouse(NULL);
   clear_keybuf();

   while (!((key[KEY_ESC]) || (mouse_b & 2)))
      {
         if (redraw)
            {
               clear(screenbuf);
               for (x=0;x<16;x++)
                  {
                     hline(screenbuf, x, SCREEN_H-1-x, 639-x, fc+(x*16) );
                     hline(screenbuf, x, x, 639-x, fc+(x*16) );
                     vline(screenbuf, x, x, SCREEN_H-1-x, fc+(x*16) );
                     vline(screenbuf, 639-x, x, SCREEN_H-1-x, fc+(x*16) );
                     textout(screenbuf, font, "<UP><DOWN>", 16, 2, tc);
                     textout(screenbuf, font, "<ESC>-quits", 640-(11*8)-16, 2, tc);
                     textout(screenbuf, font, "<PAGEUP><PAGEDOWN>", 16, SCREEN_H-9, tc);
                     textout(screenbuf, font, "<HOME><END>", 640-(11*8)-16, SCREEN_H-9, tc);
                     textout_centre(screenbuf, font, "Purple Martians Help", 320, 2, tc);
                  }
            }
         else rest(20);
         update_animation();
         for (c=0; c<lpp; c++) /* cycle lines */
            {
               xindent = 0;
               just = 0;
               color = rcolor; /* default regular color */
               sprintf(msg, help_string[line+c]);
               if (strncmp(msg, "<ac", 3) == 0)
                  {
                      buff2[0] = msg[3];
                      buff2[1] = msg[4];
                      buff2[2] = msg[5];
                      buff2[3] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,xo+(640/2)-10,yo+y+4+(c*8),20,20);
                      msg[0]= NULL;
                  }
               if (strncmp(msg, "<a", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,xo+20,yo+y+4+(c*8),20,20);
                      for(x=5; x < strlen(msg)+1; x++)
                         buff2[x-5] = msg[x]; /* chop first 5 */
                      strcpy(msg, buff2);
                      xindent = 24;
                  }
               if (redraw)
                  {
                     if (strncmp(msg, "<section>", 9) == 0)
                        {
                            for(x=9; x < strlen(msg)+1; x++)
                               buff2[x-9] = msg[x]; /* chop first 9 */
                            strcpy(msg, buff2);
                            just = 1;
                            color = stc;
                            for (x=0;x<16;x++)
                               {
                                  hline(screenbuf, 0+x, y+20+(c*8)+x, 640-1-x, sc+(x*16) );
                                  hline(screenbuf, 0+x, y+20+(c*8)-x, 640-1-x, sc+(x*16) );
                               }
                        }
                     if (strncmp(msg, "<s", 2) == 0)
                        {
                            buff2[0] = msg[2];
                            buff2[1] = msg[3];
                            buff2[2] = msg[4];
                            buff2[3] = NULL;
                            ans = atoi(buff2);
                            blit(memory_bitmap[ans], screenbuf, 0,0,20,y+4+(c*8),20,20);
                            for(x=6; x < strlen(msg)+1; x++)
                               buff2[x-6] = msg[x]; /* chop first 6 */
                            strcpy(msg, buff2);
                            xindent = 24;
                        }
                     if (strncmp(msg, "<ms", 2) == 0)
                        {
                            int z;
                            for(z=0; z < 20; z++)
                               {
      
                                  buff2[0] = msg[3+z*3];
                                  buff2[1] = msg[4+z*3];
                                  buff2[2] = msg[5+z*3];
                                  buff2[3] = NULL;
                                  ans = atoi(buff2);
                                  blit(memory_bitmap[ans], screenbuf, 0,0,20+(z*20),y+4+(c*8),20,20);
                               }
                            strcpy(msg, "");
                        }
                     if (strncmp(msg, "<l", 2) == 0)
                        {
                            buff2[0] = msg[2];
                            buff2[1] = msg[3];
                            buff2[2] = NULL;
                            color = atoi(buff2);
                            for(x=5; x < strlen(msg)+1; x++)
                               buff2[x-5] = msg[x]; /* chop first 5 */
                            strcpy(msg, buff2);
                        }
                     if (strncmp(msg, "<c", 2) == 0)
                        {
                            buff2[0] = msg[2];
                            buff2[1] = msg[3];
                            buff2[2] = NULL;
                            color = atoi(buff2);
                            for(x=5; x < strlen(msg)+1; x++)
                               buff2[x-5] = msg[x]; /* chop first five */
                            strcpy(msg, buff2);
                            just = 1;
                        }

                     if (just) textout_centre(screenbuf, font, msg, 640/2, y+16+(c*8), color);
                     else textout(screenbuf, font, msg, 20+xindent, y+16+(c*8), color);
                  }
            }
         if (redraw)
            {
               blit(screenbuf, screen, 0,0,xo,yo, 640, SCREEN_H);
               redraw = 0;
            }

         if ( (key[KEY_UP] & KB_EXTENDED) ||
             ((key[KEY_UP] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line--;
            }
         if ( (key[KEY_DOWN] & KB_EXTENDED) ||
             ((key[KEY_DOWN] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line++;
            }
         if ( (key[KEY_PGUP] & KB_EXTENDED) ||
             ((key[KEY_PGUP] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line--;
               while ((strncmp(help_string[line], "<section>", 9) != 0) && (line > 0))
                  line--;
               while (key[KEY_PGUP]);
            }
         if ( (key[KEY_PGDN] & KB_EXTENDED) ||
             ((key[KEY_PGDN] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line++;
               while ((strncmp(help_string[line], "<section>", 9) != 0) && (line < num_of_lines - lpp))
                  line++;
               while (key[KEY_PGDN]);
            }
         if ( (key[KEY_HOME] & KB_EXTENDED) ||
             ((key[KEY_HOME] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line = 0;
            }
         if ( (key[KEY_END] & KB_EXTENDED) ||
             ((key[KEY_END] & KB_NORMAL) && (!(key_shifts & KB_NUMLOCK_FLAG))) )
            {
               redraw = 1;
               line = last_pos;
            }
         /* limits */
         if (line < 0)  line = 0;
         if (line > last_pos)  line = last_pos;


         if (got_num)
            {
               sprintf(msg, "jump to section %c_", got_num);
               textout_centre(screen, font, msg, xo+320, SCREEN_H-9, tc);
            }
         if (keypressed()) /* don't wait for keypress */
            {
               k = readkey();
               k = (k & 0xFF);  /* strip upper bits */
               if ((k>47) && (k<58))   /* if alphanumeric and return */
                 {
                    clear_keybuf();
                    if (got_num) /* last keypress was num */
                       {
                          int sn = (got_num-48)*10 + (k-48);
                          if (sn < num_sections)
                             line = section_first_lines[sn];
                          redraw = 1;
                          got_num = 0;
                       }
                    else got_num = k;
                 }
               else got_num = 0; /* keypressed but not num */
            }

      }
   while ((key[KEY_ESC]) || (mouse_b & 2)); /* wait till released */

   if (SCREEN_H != sy)
      {
         set_gfx_mode(GFX_AUTODETECT, sx, sy, 0, 0);
         sc_setup();
      }



   text_mode(0);
   destroy_bitmap(screenbuf);
   clear(screen);
}
int zmenu(int menu_num, int menu_pos, int y)  /* this menu function does not pass through like the next one */
{                               /* it waits for a selection and then exits */
   extern int resume_allowed;
   extern int joy_key;
   extern int up_key;
   extern int down_key;
   extern int oac;
   extern int tmx;
   int highlight = menu_pos;
   int selection = 999;
   int last_list_item;
   int c, b;
   int old_my, new_my;
   char msg[80];
   int ac = 999;
   int mx = tmx;
   if (menu_num != 7) mx = SCREEN_W/2; /* ignore unless top menu */
   show_mouse(NULL);
   clear_keybuf();
   do   /* until selection is made */
      {
          /* no attract if not game menu or game paused  */
          if ((menu_num != 7) || (resume_allowed)) ac = 999;
          else ac--;
          c = 0;
          while (strcmp(global_string[menu_num][c],"end") != 0)
            {
               b = 137; /* dimmer aqua */
               if (c == 0) b = 8; /* purple banner */
               if (c == highlight) b=9; /* brighest aqua */

               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if ((c==4) || (c==6)) b = 239; /* dim grey */
               textout_centre(screen, font, global_string[menu_num][c], mx, y+(c*8), b);
               c++;
            }
          last_list_item = c-1;
          position_mouse(SCREEN_W/2, SCREEN_H/2);
          old_my=mouse_y;
          rest(20);
          new_my=mouse_y;

         if ((key[KEY_DOWN]) || (key[down_key]) || (new_my > old_my+1) || (joy_down))
            {
               if (++highlight > last_list_item) highlight = last_list_item;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if ((highlight==4) || (highlight==6)) highlight++;
               ac = 999;
               rest(100);
            }
         if ((key[KEY_UP]) || (key[up_key]) || (new_my < old_my-1) || (joy_up))
            {
               if (--highlight < 2) highlight = 2;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if ((highlight==4) || (highlight==6)) highlight--;
               ac = 999;
               rest(100);
            }
         if (key[KEY_ENTER]) selection = highlight;
         if (mouse_b & 1)
            {
               while (mouse_b & 1); /* wait for release */
               selection = highlight; /* get selection */
            }
         while (joy_down) poll_joystick();
         while (joy_up) poll_joystick();

         if (joy_key) /* joystick control */
            {
               poll_joystick();
               if  (joy_b1)
                  {
                     selection = highlight; /* wait for release */
                     do {
                          poll_joystick();
                        } while (joy_b1);
                  }
            }

         if ((key[KEY_ESC]) || (mouse_b & 2))
           {
              while ((key[KEY_ESC]) || (mouse_b & 2)); /* until released */

              selection = last_list_item;
              if (menu_num == 8) selection = 2; /* back is at top of options menu */
              if (menu_num == 7) selection = 1; /* for top menu only */
           }

         sprintf(global_string[7][9], "Demo Mode (%1d)", ac/100);

         if ( (ac/100) != oac) /* not old one */
            {
               oac = ac/100;
               sprintf(msg, "%1d" ,ac/100 );
               sprintf(msg, "Demo Mode (%1d)", ac/100);
               textout(screen, font, msg, -(8*(strlen(msg))) + mx + (strlen(global_string[7][9])*8) / 2, y+72, 10 +(((oac/2)*16)) );
               rest(100+ (10-oac)*50   );
               textout(screen, font, "               ", -(8*(strlen(msg))) + mx + (strlen(global_string[7][9])*8) / 2, y+72, 10 +(((oac/2)*16)) );
            }
         if (ac<100)  /* attract mode */
            {
               demo_mode();
               ac = 999;
            }
      } while (selection == 999);
   return selection;
}
void menu_setup(void)
{

   strcpy (global_string[5][0], "Keyboard Setup"); /* new main menu */
   strcpy (global_string[5][1], "--------------");
   strcpy (global_string[5][2], "Up    ");
   strcpy (global_string[5][3], "Down  ");
   strcpy (global_string[5][4], "Left  ");
   strcpy (global_string[5][5], "Right ");
   strcpy (global_string[5][6], "Jump  ");
   strcpy (global_string[5][7], "Fire  ");
   strcpy (global_string[5][8], "Map   ");
   strcpy (global_string[5][9], "Menu  ");
   strcpy (global_string[5][10], "------------");
   strcpy (global_string[5][11], "Back to Menu");
   strcpy (global_string[5][12], "end");


   strcpy (global_string[7][0],  ""); /* new main menu */
   strcpy (global_string[7][1],  "");
   strcpy (global_string[7][2],  "Start Level  (1)");
   strcpy (global_string[7][3],  "Start New Game");
   strcpy (global_string[7][4],  "Resume Current Game");
   strcpy (global_string[7][5],  "Load Game");
   strcpy (global_string[7][6],  "Save Game");
   strcpy (global_string[7][7],  "Options Menu");
   strcpy (global_string[7][8],  "Help Screens");
   strcpy (global_string[7][9],  "Demo Mode (9)");
   strcpy (global_string[7][10], "end");

   strcpy (global_string[8][0], "Options Menu"); /* OPTION MENU new main menu */
   strcpy (global_string[8][1], "----------");
   strcpy (global_string[8][2], "Back to Game Menu");
   strcpy (global_string[8][3], "Keyboard Setup");
   strcpy (global_string[8][4], "Joystick Setup");
   strcpy (global_string[8][5], "Difficulty: Normal");
   strcpy (global_string[8][6], "Speed:Fast");
   strcpy (global_string[8][7], "Sound:Off");
   strcpy (global_string[8][8], "Screen Mode: 640 x 480");
   strcpy (global_string[8][9], "Level Editor");
   strcpy (global_string[8][10], "end");
#ifdef MV
   strcpy (global_string[8][10],"Record autoplay");
   strcpy (global_string[8][11],"Run autoplay");
   strcpy (global_string[8][12],"end");
#endif


}

