#include <math.h>
#include <allegro.h>

void enemy_move()
{
   /* global variables  */
   extern int Ei[100][32];
   extern float Ef[100][16];
   extern int zz[20][64];
   extern int passcount;
   extern int PXint, PYint;
   int EXint, EYint, EN, b, c, d, x, y;
   for (EN=0; EN<100; EN++)
      if (Ei[EN][0]) /* if enemy active */
         {
            EXint = Ef[EN][0];
            EYint = Ef[EN][1];
            switch (Ei[EN][0])
               {
                  case 3: /* enemy type 3  ArchWagon
                             follows man with regard
                             to walls and gravity
                             Ei[EN][0] = type 3
                             Ei[EN][1] = bitmap
                             Ei[EN][2] = draw type
                             Ei[EN][3] = ans
                             Ei[EN][4] = ans type
                             Ei[EN][5] =
                             Ei[EN][6] = jump wait (0=none)
                             Ei[EN][7] = jump when player above
                             Ei[EN][8] = follow(0) or bounce(1)
                             Ei[EN][9] = collision box size
                             Ei[EN][10] =
                             Ei[EN][11] = jump before hole
                             Ei[EN][12] = jump before wall
                             Ei[EN][13] =
                             Ei[EN][14] =
                             Ei[EN][15] = bullet wait counter
                             Ei[EN][16] = bullet prox (0=none)
                             Ei[EN][17] = bullet wait amount
                             Ei[EN][18] =
                             Ei[EN][19] = follow delay counter
                             Ei[EN][20] = reserved for rot !!!!
                             Ei[EN][21] = follow delay ammount
                             Ei[EN][22] =
      
      
                             Ef[EN][0] = x
                             Ef[EN][1] = y
                             Ef[EN][2] = xinc
                             Ef[EN][3] = yinc
                             Ef[EN][4] = LIFE decrement
                             Ef[EN][5] = speed
                             Ef[EN][6] =
                             Ef[EN][7] = bullet speed
                             Ef[EN][8] = fall and fallcount
                             Ef[EN][9] = jump and jumpcount
                             Ef[EN][10] =
                                                                  */
      
                     /* arrows or bullets  */
                     if (Ei[EN][16])
                        {
                           if (Ei[EN][15] > 0) /* if  wait */
                              {
                                 Ei[EN][15]--;   /* dec  wait */
                                 Ei[EN][3] = 3; /* empty wagon ans */
                              }
                           else
                              {
                                 Ei[EN][3] = 2; /* arrow wagon ans */
                                 if ((Ef[EN][1] > PYint - 5) && (Ef[EN][1] < PYint + 5))
                                    {
                                       if (Ei[EN][2]) /* attempt shoot right */
                                          if ((EXint > PXint - Ei[EN][16]) && (EXint < PXint) )
                                             {
                                                fire_enemy_x_bullet(EN, EXint, EYint);
                                                Ei[EN][15] = Ei[EN][17]; /* set new prox wait */
                                             }
                                       if (!Ei[EN][2]) /* attempt shoot left */
                                          if ((EXint > PXint) && (EXint < PXint + Ei[EN][16]))
                                             {
                                                fire_enemy_x_bullet(EN, EXint, EYint);
                                                Ei[EN][15] = Ei[EN][17]; /* set new prox wait */
                                             }
                                    }
                              }
                        }
      
      
      
      
                     if (!Ei[EN][8]) /* follow mode */
                        {
                           if (Ei[EN][19]) Ei[EN][19]--; /* follow delay */
                           else
                              {
                                 Ei[EN][19] = Ei[EN][21]; /* reset follow delay */
                                 if ((EXint < PXint) && (Ef[EN][2] < 0))
                                    Ef[EN][2] = -Ef[EN][2];
                                 if ((EXint > PXint) && (Ef[EN][2] > 0))
                                    Ef[EN][2] = -Ef[EN][2];
                              }
                        }
      
      
      
                     if ((Ef[EN][2]) > 0)  /* move right */
                        {
                          Ei[EN][2] = 1; /* no h_flip */
                          Ef[EN][0] += Ef[EN][2];
                          EXint=Ef[EN][0];
                          if (Ei[EN][12]) /* jump before wall */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (is_right_solid(EXint+Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                          if (Ei[EN][11]) /* jump before hole */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (!is_right_solid(EXint+Ei[EN][11]-18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
                          if (is_right_solid(EXint, EYint))
                             {
                                Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                EXint=Ef[EN][0];
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
                           Ei[EN][2] = 0; /* h_flip to face left */
                           Ef[EN][0] += Ef[EN][2];
                           EXint=Ef[EN][0];
                           if (Ei[EN][12]) /* jump before wall */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (is_left_solid(EXint-Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                           if (Ei[EN][11]) /* jump before hole */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (!is_left_solid(EXint-Ei[EN][11]+18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
      
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                 if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
      
                                 EXint=Ef[EN][0];
                              }
                        }
      
                     if (Ef[EN][9])  /*jump*/
                        {
                           Ef[EN][9] -= .05;
                           if (Ef[EN][9] < .1)      /* top of jump */
                              {
                                 Ef[EN][9] = 0;    /* jump done */
                                 Ef[EN][8] = 1.6;   /* start fall */
      
                              }
                           else
                              {
                                 Ef[EN][1] -= (sin(Ef[EN][9]) * Ef[EN][3]);
                                 EYint=Ef[EN][1];
                                 if (is_up_solid(EXint, EYint, 1, 0))
                                    {
                                       Ef[EN][9] = 0;   /* abort jump */
                                       Ef[EN][8] = 1.6;   /* start fall */
                                    }
                              }
                        }
      
                     else  /* not jump */
                        {
                           if (Ef[EN][8])   /* if fall = 1 */
                              {
                                 Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                                 if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                                 Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                                 if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                                 EYint=Ef[EN][1];
                                 if (is_down_solid(EXint, EYint, 1))  /* look for end of fall */
                                    {
                                       Ef[EN][8] = 0; /*  fall=0;  */
                                       Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                       EYint=Ef[EN][1];
                                    }
                              }
                           if (!Ef[EN][8])  /* fall = 0 */
                              {
                                 /* start fall? look for no block below */
                                 if (!is_down_solid(EXint, EYint, 1)) Ef[EN][8] = 1.6;
      
                                 /* passcount jump */
                                 if ((Ei[EN][6] > 0) && ((passcount % Ei[EN][6]) == 1))
                                    Ef[EN][9] = 1.6; /* jump! */
      
                                 /* jump when player passes over width */
                                 if ((Ei[EN][7] > 0) && (EXint < (PXint + Ei[EN][7])) && (EXint > (PXint - Ei[EN][7])) && (EYint > PYint))
                                    Ef[EN][9] = 1.6;
                              } /* end of fall = 0  */
                        } /* end of else if not fall  */
      
                             /* set the bitmap and drawing mode */
                             b = Ei[EN][3];      /* ans */
                             c = zz[4][b];         /* num_of_shapes in seq */
      
                             if (Ei[EN][4] == 0) Ei[EN][1] = Ei[EN][3]; /* bmp, not ans */
                             if (Ei[EN][4] == 1) Ei[EN][1] = zz[0][b];    /* animate with time */
                             if (Ei[EN][4] == 2) /* animate with h move */
                                {
                                   if (Ei[EN][2] == 1) /* right */
                                      {
                                         x = (EXint/3) % c;
                                         Ei[EN][1] = zz[x+5][b];
                                      }
                                   if (Ei[EN][2] == 0) /* left */
                                      {
                                         x = (EXint/3) % c;
                                         Ei[EN][1] = zz[5+c-x][b];
                                      }
      
      
      
      
      
      
                                }
                             if (Ei[EN][4] == 3) /* animate with v move */
                                {
                                   x = (EYint/3) % c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
                             if (Ei[EN][4] == 4) /* animate with v and h move */
                                {
                                   x = ((EYint/3) % c) + ((EXint/3) % c);
                                   if (x > c) x-=c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
      
      
                  break;
                  case 4: /* enemy type 4  bouncer !
                             does not follow man, except when seeking!
                      bounces off walls , no gravity
                             Ei[EN][0] = type 4
                             Ei[EN][1] = bitmap
                             Ei[EN][2] = draw type
                             Ei[EN][3] = ans
                             Ei[EN][4] = ans type
                             Ei[EN][5] = main ans
                             Ei[EN][6] = seek ans
                             Ei[EN][7] = seek counter
                             Ei[EN][8] = seek count
                             Ei[EN][9] = collision box size
      
      
                             Ef[EN][0] = x
                             Ef[EN][1] = y
                             Ef[EN][2] = xinc
                             Ef[EN][3] = yinc
                             Ef[EN][8] = seek speed */




                    if ((Ei[EN][8]) && (Ei[EN][7] > Ei[EN][8])) /* time to do a seek! */
                       {
                          Ei[EN][7] = 0;
                          seek_set_xyinc(EN, EXint, EYint);
                          Ei[EN][20] = get_rot_from_xyinc(EN);
                          Ei[EN][3] = Ei[EN][6]; /* seek ans */
                       }
                    else Ei[EN][3] = Ei[EN][5]; /* main ans */


                    if ((Ef[EN][2]) > 0)  /* move right */
                        {
      
                          Ef[EN][0] += Ef[EN][2];
                          EXint = Ef[EN][0];
                          if (is_right_solid(EXint, EYint))
                             {
                                Ei[EN][7]++;
                                Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                Ef[EN][0] += Ef[EN][2];
                                EXint = Ef[EN][0];
                                Ei[EN][20] = get_rot_from_xyinc(EN);
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
      
                           Ef[EN][0] += Ef[EN][2];
                           EXint = Ef[EN][0];
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                 Ef[EN][0] += Ef[EN][2];
                                 EXint = Ef[EN][0];
                                 Ei[EN][20] = get_rot_from_xyinc(EN);
                              }
                        }
                     if (Ef[EN][3] > 0) /* move down */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           EYint = Ef[EN][1];
                           if (is_down_solid(EXint, EYint, 1))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
                                 Ei[EN][20] = get_rot_from_xyinc(EN);
                              }
                        }
                     if (Ef[EN][3] < 0)  /* move up */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           EYint = Ef[EN][1];
                           if (is_up_solid(EXint, EYint, 0, 0))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
                                 Ei[EN][20] = get_rot_from_xyinc(EN);
                              }
                        }
                     /* set the bitmap from animation sequence */
                     /* always with time */
                     Ei[EN][1] = zz[0][Ei[EN][3]];
      
                 break;
                 case 6: /* enemy type 6  cannon
                             Ei[EN][0] = type 6
                             Ei[EN][1] = bitmap
                             Ei[EN][2] = draw type alway 0;
                             Ei[EN][20] = rotation;
                             Ei[EN][3] =
                             Ei[EN][4] =
                             Ei[EN][5] =
                             Ei[EN][6] = bullet_wait
                             Ei[EN][7] = seek counter
                             Ei[EN][8] = seek count
                             Ei[EN][9] = collision box size
      
      
                             Ef[EN][0] = x
                             Ef[EN][1] = y
                             Ef[EN][2] = xinc
                             Ef[EN][3] = yinc
                             Ef[EN][7] = bullet speed
                             Ef[EN][8] = seek speed */
      
                    if ( (passcount % Ei[EN][6]) == (Ei[EN][6])-1)
                    fire_enemy_bulleta(EN, EXint, EYint, 55);
      
      
                    if ((Ei[EN][8]) && (Ei[EN][7] > Ei[EN][8])) /* time to do a seek! */
                       {
                          seek_set_xyinc(EN, EXint, EYint);
                          Ei[EN][7] = 0;
                       }
                    Ei[EN][20] = get_rot_from_PXY(EN, EXint, EYint);

                   /* set bitmap */
                   if ((passcount % Ei[EN][6]) > ((Ei[EN][6] * 5) / 6) ) /* show warning */
                      {
                         Ei[EN][1] = 506; /* red cannon */
                      }
                   else Ei[EN][1] = 507;  /* green cannon */
      
                     if ((Ef[EN][2]) > 0)  /* move right */
                        {
      
                          Ef[EN][0] += Ef[EN][2];
                          EXint = Ef[EN][0];
                          if (is_right_solid(EXint, EYint))
                             {
                                Ei[EN][7]++;
                                Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                Ef[EN][0] += Ef[EN][2];
      
      
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
      
                           Ef[EN][0] += Ef[EN][2];
                           EXint = Ef[EN][0];
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                 Ef[EN][0] += Ef[EN][2];
      
                              }
                        }
                     if (Ef[EN][3] > 0) /* move down */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           if (is_down_solid(EXint, EYint, 1))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
      
                              }
                        }
                     if (Ef[EN][3] < 0)  /* move up */
                        {
                           Ef[EN][1] += Ef[EN][3];
                           if (is_up_solid(EXint, EYint, 0, 0))
                              {
                                 Ei[EN][7]++;
                                 Ef[EN][3] =- Ef[EN][3]; /* bounce */
                                 Ef[EN][1] += Ef[EN][3];
                              }
      
                        }
                   break;
                   case 7:/* Podzilla
                             Ei[EN][0] = type 7
                             Ei[EN][1] = !rsvd bitmap
                             Ei[EN][2] = !rsvd draw type
                             Ei[EN][3] = wait count
                             Ei[EN][4] = wait limit
                             Ei[EN][5] = sequence counter
                             Ei[EN][6] = sequence limit
                             Ei[EN][7] = mode
                             Ei[EN][8] =
                             Ei[EN][9] = collision window
                             Ei[EN][11] = trigger box x1
                             Ei[EN][12] = trigger box x1
                             Ei[EN][13] = trigger box x2
                             Ei[EN][14] = trigger box y2
      
                             Ef[EN][0] = x
                             Ef[EN][1] = y
                             Ef[EN][2] = x inc
                             Ef[EN][3] = y inc
                             Ef[EN][4] = health dec
                             Ef[EN][5] =
                             Ef[EN][6] =
                             Ef[EN][7] = bullet speed
                             Ef[EN][8] = move speed creator only   */
      
      
                     if (!Ei[EN][7]) /* only trigger from mode 0 */
                        if ((PXint > Ei[EN][11]*20) && (PXint < Ei[EN][13]*20))
                           if ((PYint > Ei[EN][12]*20) && (PYint < Ei[EN][14]*20))
      
                              {
                                 Ei[EN][7] = 1; /* triggered! mode 1; */
                                 Ei[EN][5] = 0;  /* zero counter */
                              }
                     if (Ei[EN][7] == 1) /* mode 1; out */
                        {
                           Ef[EN][0] += Ef[EN][2];
                           Ef[EN][1] += Ef[EN][3];
                           if (++Ei[EN][5] > Ei[EN][6]) /* if (++count > limit) */
                              {
                                 Ei[EN][7] = 2; /* next mode */
                                 Ei[EN][3] = passcount;
                             }
                        }
                     if (Ei[EN][7] == 2)  /* mode 2; shoot */
                        {
                           if (Ei[EN][3] < (passcount-Ei[EN][4]) )
                              {
                                 fire_enemy_bulleta(EN, EXint, EYint, 54);
                                 Ei[EN][7] = 3; /* next mode */
                                 Ei[EN][3] = passcount;
                              }
                        }
                     if (Ei[EN][7] == 3)  /* mode 4; post shoot pause */
                        {
                           if (Ei[EN][3] < (passcount-Ei[EN][4]) )
                              {
                                 Ei[EN][7] = 4; /* next mode */
                                 Ei[EN][3] = passcount;
                              }
                        }
                     if (Ei[EN][7] == 4) /* mode 4; in */
                        {
                           Ef[EN][0] -= Ef[EN][2];
                           Ef[EN][1] -= Ef[EN][3];
                           if (--Ei[EN][5] < 1 ) /* if (--count < 1) */
                              Ei[EN][7] = 0; /* done; back to mode 0 */
                        }
                   Ei[EN][1] = zz[ 5 + (Ei[EN][5] * zz[4][15] / Ei[EN][6]) ][15];
                   /* bitmap =           counter * numshapes / limit  */
                  if ( (Ei[EN][7] == 2) || (Ei[EN][7] == 3) )
                     {
                        Ei[EN][20] = get_rot_from_PXY(EN, EXint, EYint);
                        Ei[EN][1] = 335; /* green cannon */
                     }
                  else Ei[EN][20] = get_rot_from_xyinc(EN);
      
                  break;
                  case 8: /* enemy type 8  */
                  {
                     /* WALL CLIMBER DUDE
                     Ei[EN][0] = type 8
                     Ei[EN][1] = bitmap
                     Ei[EN][2] = draw type
                     Ei[EN][3] = ans
                     Ei[EN][4] = bullet prox re-trigger delay
                     Ei[EN][5] =
                     Ei[EN][6] = mode
                     Ei[EN][7] = fall when player below
                     Ei[EN][8] =
                     Ei[EN][9] = collision box size
      
                     Ef[EN][0] = x
                     Ef[EN][1] = y
                     Ef[EN][2] = xinc
                     Ef[EN][3] = yinc
                     Ef[EN][4] = LIFE decrement
                     Ef[EN][5] = bullet waitcount
                     Ef[EN][6] = bullet prox (0=none)
                     Ef[EN][7] = bullet speed
                     Ef[EN][8] = fall and fallcount
                     Ef[EN][9] =                    */
      
                     int bullet_request = 0;
                     int mode = Ei[EN][6];
                     int prox = Ef[EN][6];
                     int te = 4;
      
                     /* bullet prox */
                     if ((prox) && (--Ef[EN][5] < 0))
                        {
                           bullet_request = 1;
                           Ei[EN][3] = 17;
                        }
                     else Ei[EN][3] = 18;
      
      
      
                           if (Ef[EN][8])   /* if fall = 1 */
                              {
      
                                 Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                                 if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                                 Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                                 if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                                 EYint=Ef[EN][1];
                                 if (is_down_solid(EXint, EYint, 1))  /* look for end of fall */
                                    {
                                       Ef[EN][8] = 0; /*  fall=0;  */
                                       Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                       EYint=Ef[EN][1];
                                    }
                              }
                           if (!Ef[EN][8])  /* if not fall */
                              {
                                if ( (Ei[EN][7]) && (EXint < (PXint + 15)) && (EXint > (PXint - 15))
                                  && (EYint < (PYint     )) ) /* if above */
      
                                   {
                                      if (mode == 2)
                                         {
                                            Ef[EN][8] = 1.6; /* fall */
                                            mode = 4;
                                            Ei[EN][2] = 0;
                                            Ei[EN][20] = 0;
                                         }
                                      if (mode == 6)
                                         {
                                            Ef[EN][8] = 1.6; /* fall */
                                            mode = 0;
                                            Ei[EN][2] = 1;
                                            Ei[EN][20] = 0;
                                         }
                                   
                                   }
                              } /* end of fall = 0  */
      
      
                 if (!Ef[EN][8])  /* not fall */
                    switch (mode)
                     {
                         case 0: /* floor right */
                          if (!is_down_solid(EXint, EYint, 0))
                            {
                               mode = 3;
                               Ef[EN][0] = 19 + (EXint/20)*20;
                               Ef[EN][1] += te;
      
                               Ei[EN][2] = 1;
                               Ei[EN][20] = 32;
      
                               break;
                            }
                         if (is_right_solid(EXint, EYint))
                            {
                               mode = 1;
                               Ef[EN][0] = (EXint/20)*20;
      
                               Ei[EN][2] = 1;
                               Ei[EN][20] = 224;
      
                               break;
                            }
      
                         if (bullet_request)
                            if (EYint >= PYint)
                               if ((EYint-prox) < PYint)
                                  if (EXint < PXint)
                                     if ((EXint+prox) > PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 1;
                         Ei[EN][20] = 0;
                         Ef[EN][0] += Ef[EN][2];
                         break;
      
      
                         case 1: /* rwall up */
                          if (!is_right_solid(EXint, EYint))
                            {
                               mode = 0;
                               Ef[EN][1] = (EYint/20)*20;
                               Ef[EN][0] += te;
                               Ei[EN][2] = 1;
                               Ei[EN][20] = 224;
      
                               break;
                            }
                         if (is_up_solid(EXint, EYint, 0, 1))
                            {
                               mode = 2;
                               Ef[EN][1] = (((EYint+te)/20)*20)-1;
                               Ei[EN][2] = 1; /* no flip */
                               Ei[EN][20] = 160; /* rotation */
                               break;
                            }
                         if (bullet_request)
                            if (EYint >= PYint)
                               if ((EYint-prox) < PYint)
                                  if (EXint > PXint)
                                     if ((EXint-prox) < PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 1;
                         Ei[EN][20] = 192;
                         Ef[EN][1] -= Ef[EN][3];
                         break;
      
      
                         case 2: /* ceil left */
                         if (!is_up_solid(EXint, EYint, 0, 1))
                            {
                               mode = 1;
                               Ef[EN][0] = (EXint/20)*20;
                               Ef[EN][1] -= te;
                               Ei[EN][2] = 160; /* rotation */
                               break;
                            }
                       if (is_left_solid(EXint, EYint))
                            {
                               mode = 3;
                               Ef[EN][0] = 19 + (EXint/20)*20;
                               Ei[EN][2] = 1; /* no flip */
                               Ei[EN][20] = 96; /* rotation */
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint > PXint)
                                     if ((EXint-prox) < PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 1;
                         Ei[EN][20] = 128;
                         Ef[EN][0] -= Ef[EN][2];
                         break;
                         case 3: /* lwall down */
                         if (!is_left_solid(EXint, EYint))
                            {
                               mode = 2;
                               Ef[EN][1] = 19 + (EYint/20)*20;
                               Ef[EN][0] -= te;
                               Ei[EN][2] = 1; /* rotation */
                               Ei[EN][20] = 96; /* rotation */
                               break;
                            }
                         if (is_down_solid(EXint, EYint, 0))
                            {
                               mode = 0;
                               Ef[EN][1] = (EYint/20)*20;
                               Ei[EN][2] = 1;
                               Ei[EN][20] = 32; /* rotation */
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint < PXint)
                                     if ((EXint+prox) > PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 1;
                         Ei[EN][20] = 64;
                         Ef[EN][1] += Ef[EN][3];
                         break;
      
                         case 4: /* floor left */
                          if (!is_down_solid(EXint, EYint, 0))
                            {
                               mode = 7;
                               Ef[EN][0] = (EXint/20)*20;
                               Ef[EN][1] += te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 224;
                               break;
                            }
                         if (is_left_solid(EXint, EYint))
                            {
                               mode = 5;
                               Ef[EN][0] = 19+((EXint)/20)*20;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 32;
                               break;
                            }
                         if (bullet_request)
                            if (EYint >= PYint)
                               if ((EYint-prox) < PYint)
                                  if (EXint > PXint)
                                     if ((EXint-prox) < PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 0;
                         Ef[EN][0] -= Ef[EN][2];
                         break;
      
      
                         case 5: /* lwall up */
                          if (!is_left_solid(EXint, EYint))
                            {
                               mode = 4;
                               Ef[EN][1] = (EYint/20)*20;
                               Ef[EN][0] -= te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 32;
                               break;
                            }
                         if (is_up_solid(EXint, EYint, 0, 1))
                            {
                               mode = 6;
                               Ef[EN][1] = (((EYint+te)/20)*20)-1;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 96;
                               break;
                            }
                         if (bullet_request)
                            if (EYint >= PYint)
                               if ((EYint-prox) < PYint)
                                  if (EXint < PXint)
                                     if ((EXint+prox) > PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 64;
                         Ef[EN][1] -= Ef[EN][3];
                         break;
      
      
                         case 6: /* ceil right */
                         if (!is_up_solid(EXint, EYint, 0, 1))
                            {
                               mode = 5;
                               Ef[EN][0] = 19+(EXint/20)*20;
                               Ef[EN][1] -= te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 96;
                               break;
                            }
                       if (is_right_solid(EXint, EYint))
                            {
                               mode = 7;
                               Ef[EN][0] = (EXint/20)*20;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 160;
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint < PXint)
                                     if ((EXint+prox) > PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 128;
                         Ef[EN][0] += Ef[EN][2];
                         break;
                         case 7: /* rwall down */
                         if (!is_right_solid(EXint, EYint))
                            {
                               mode = 6;
                               Ef[EN][1] = 19 + (EYint/20)*20;
                               Ef[EN][0] += te;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 160;
                               break;
                            }
                         if (is_down_solid(EXint, EYint, 0))
                            {
                               mode = 4;
                               Ef[EN][1] = (EYint/20)*20;
                               Ei[EN][2] = 0;
                               Ei[EN][20] = 224;
                               break;
                            }
                         if (bullet_request)
                            if (EYint < PYint)
                               if ((EYint+prox) > PYint)
                                  if (EXint > PXint)
                                     if ((EXint-prox) < PXint)
                                       {
                                          fire_enemy_bulleta(EN, EXint, EYint, 20);
                                          Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                       }
      
                         Ei[EN][2] = 0;
                         Ei[EN][20] = 192;
                         Ef[EN][1] += Ef[EN][3];
                         break;
                      } /* end of switch mode */
      
      
      
                             /* set the bitmap and drawing mode */
                             b = Ei[EN][3];    /* ans */
                             c = zz[4][b];     /* num_of_shapes in seq */
                             d = 2;            /* to link movement to seq */
                             if (mode % 2) /* ymove, if odd */
                                {
                                   if ((Ei[EN][6] == 1) || (Ei[EN][6] == 5))
                                      {
                                         x = (EYint/d) % c;
                                         Ei[EN][1] = zz[x+5][b];
                                      }
                                   if ((Ei[EN][6] == 3) || (Ei[EN][6] == 7))
                                      {
                                         x = (EYint/d) % c;
                                         Ei[EN][1] = zz[c+5-x][b];
                                      }
      
                                }
                             else  /* xmove, if even */
                                {
                                   if ((Ei[EN][6] == 2) || (Ei[EN][6] == 4))
                                      {
                                         x = (EXint/d) % c;
                                         if (x > c) x-=c;
                                         Ei[EN][1] = zz[x+5][b];
                                      }
                                   if ((Ei[EN][6] == 0) || (Ei[EN][6] == 6))
                                      {
                                         x = (EXint/d) % c;
                                         if (x > c) x-=c;
                                         Ei[EN][1] = zz[c+5-x][b];
                                      }
                                }
      
                  if (Ei[EN][6] == mode) Ei[EN][8] = 0;
                  if (Ei[EN][6] != mode)
                     {
                        Ei[EN][6] = mode;
                        if (++Ei[EN][8] > 4) /* twirling */
                           {
                              Ef[EN][8] = 1.6; /* fall */
                              Ei[EN][6] = 0;
                              Ei[EN][2] = 1;
                              Ei[EN][20] = 0;
                           }
                     }
                  }
                  break; /* end of case 8 */
                  case 9:
                     /* CLONER
                     Ei[EN][0] = type 9
                     Ei[EN][1] = bitmap
                     Ei[EN][2] = draw type
                     Ei[EN][3] = ans
                     Ei[EN][4] =
                     Ei[EN][5] =
                     Ei[EN][6] = create wait
                     Ei[EN][7] = create wait counter
                     Ei[EN][8] =
                     Ei[EN][9] = collision box size
      
                     Ef[EN][0] = x
                     Ef[EN][1] = y
                     Ef[EN][2] = copy box x size
                     Ef[EN][3] = copy box y size
                     Ef[EN][4] = LIFE decrement
                     Ef[EN][5] =
                     Ef[EN][6] = copy box x (2000)
                     Ef[EN][7] = copy box y (2000)
                     Ef[EN][8] = dest box x (2000)
                     Ef[EN][9] = dest box y (2000) */
      
      
                     {
                        float ratio = (float) Ei[EN][7] / (float) Ei[EN][6] * 10;
                        b = 9 - (int) ratio;
                        Ei[EN][2] = 1;
                        Ei[EN][1] = zz[5+b][53];
                     }
      
                     if (--Ei[EN][7] < 0)  /* time for create */
                        {
                           int x1 = Ef[EN][6]-2;    /* source x */
                           int y1 = Ef[EN][7]-2;    /* source y */
                           int x2 = x1 + Ef[EN][2];   /* sizes */
                           int y2 = y1 + Ef[EN][3];
      
                           int x3 = Ef[EN][8]-2;    /* dest x */
                           int y3 = Ef[EN][9]-2;    /* dest y */
                           int x4 = x3 + Ef[EN][2];   /* sizes */
                           int y4 = y3 + Ef[EN][3];
                           extern BITMAP *scrn_buffer;
                           extern int WX,WY;
                           extern int item[500][16];
                           extern float itemf [500][4];
      
                           event(14);
      
                           rectfill (scrn_buffer, x1-WX, y1-WY, x2-WX, y2-WY, 10);
                           rectfill (scrn_buffer, x3-WX, y3-WY, x4-WX, y4-WY, 11);
      
                           Ei[EN][7] = Ei[EN][6]; /* reset counter */
                           Ei[EN][1] = zz[15][53]; /* full red */
                
      
                           for (b=0; b<100; b++) /* check for enemies in box */
                              if (Ei[b][0])     /* if active */
                                 if (Ef[b][0] > x1)
                                    if (Ef[b][0] < x2)
                                       if (Ef[b][1] > y1)
                                          if (Ef[b][1] < y2)
                                             {
                                                /* copy to dest box */
                                                /* find empty */
                                                for (c=0; c<100; c++)
                                                   if (Ei[c][0] == 0)
                                                      {
                                                         for (y=0; y<32; y++)
                                                            Ei[c][y] = Ei[b][y];
                                                         for (y=0; y<16; y++)
                                                            Ef[c][y] = Ef[b][y];
      
                                                         Ef[c][0]= x3 + (Ef[b][0]-x1);
                                                         Ef[c][1]= y3 + (Ef[b][1]-y1);
                                                         c = 100; /* end loop */
                                                      }
                                             }
      
                           for (b=0; b<500; b++) /* check for items in box */
                              if (item[b][0])     /* if active */
                                 if (itemf[b][0] > x1)
                                    if (itemf[b][0] < x2)
                                       if (itemf[b][1] > y1)
                                          if (itemf[b][1] < y2)
                                             {
                                                /* copy to dest box */
                                                /* find empty */
                                                for (c=0; c<500; c++)
                                                   if (item[c][0] == 0)
                                                      {
                                                         for (y=0; y<16; y++)
                                                            item[c][y] = item[b][y];
      
                                                         itemf[c][0]= x3 + (itemf[b][0]-x1);
                                                         itemf[c][1]= y3 + (itemf[b][1]-y1);
                                                         itemf[c][2]= 0;
                                                         itemf[c][3]= 0;
      
      
                                                         c = 500; /* end loop */
                                                      }
                                             }
                        }
                  break;
                  case 11: /* Block Walker
                             follows man with regard
                             to walls and gravity
                             Ei[EN][0] = type 11
                             Ei[EN][1] = bitmap
                             Ei[EN][2] = draw type
                             Ei[EN][3] = ans
                             Ei[EN][4] = ans type
                             Ei[EN][5] =
                             Ei[EN][6] = jump wait (0=none)
                             Ei[EN][7] = jump when player above
                             Ei[EN][8] = follow(0) or bounce(1)
                             Ei[EN][9] = collision box size
                             Ei[EN][10] =
                             Ei[EN][11] = jump before hole
                             Ei[EN][12] = jump before wall
      
                             Ei[EN][19] = follow delay counter
                             Ei[EN][20] = reserved for rot !!!!
                             Ei[EN][21] = follow delay ammount
      
                             Ef[EN][0] = x
                             Ef[EN][1] = y
                             Ef[EN][2] = xinc
                             Ef[EN][3] = yinc
                             Ef[EN][4] = LIFE decrement
                             Ef[EN][5] =
                             Ef[EN][6] =
                             Ef[EN][7] =
                             Ef[EN][8] = fall and fallcount
                             Ef[EN][9] = jump and jumpcount
                                                                  */
      
      
                     if (!Ei[EN][8]) /* follow mode */
                        {
                           if (Ei[EN][19]) Ei[EN][19]--; /* follow delay */
                           else
                              {
                                 Ei[EN][19] = Ei[EN][21]; /* reset follow delay */
                                 if ((EXint < PXint) && (Ef[EN][2] < 0))
                                    Ef[EN][2] = -Ef[EN][2];
                                 if ((EXint > PXint) && (Ef[EN][2] > 0))
                                    Ef[EN][2] = -Ef[EN][2];
                              }
                        }
                     if ((Ef[EN][2]) > 0)  /* move right */
                        {
                          Ei[EN][2] = 1; /* h_flip to face right */
                          Ef[EN][0] += Ef[EN][2];
                          EXint=Ef[EN][0];
                          if (Ei[EN][12]) /* jump before wall */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (is_right_solid(EXint+Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                          if (Ei[EN][11]) /* jump before hole */
                             {
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                    if (!is_right_solid(EXint+Ei[EN][11]-18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
                          if (is_right_solid(EXint, EYint))
                             {
                                Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                EXint=Ef[EN][0];
                             }
                        }
                     if ((Ef[EN][2]) < 0)  /* move left */
                        {
                           Ei[EN][2] = 0; /* no h_flip */
                           Ef[EN][0] += Ef[EN][2];
                           EXint=Ef[EN][0];
                           if (Ei[EN][12]) /* jump before wall */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (is_left_solid(EXint-Ei[EN][12], EYint))
                                      Ef[EN][9] = 1.6;
                             }
                           if (Ei[EN][11]) /* jump before hole */
                             {
      
                                if (Ef[EN][9] == 0) /* not jump */
                                  if (Ef[EN][8] == 0) /* not fall */
                                   if (!is_left_solid(EXint-Ei[EN][11]+18, EYint+20))
                                      Ef[EN][9] = 1.6;
                             }
      
                           if (is_left_solid(EXint, EYint))
                              {
                                 Ef[EN][0] -= Ef[EN][2]; /* take back last move */
                                 if (Ei[EN][8]) Ef[EN][2] =- Ef[EN][2]; /* bounce */
      
                                 EXint=Ef[EN][0];
                              }
                        }
      
                     if (Ef[EN][9])  /*jump*/
                        {
                           Ef[EN][9] -= .05;
                           if (Ef[EN][9] < .1)      /* top of jump */
                              {
                                 Ef[EN][9] = 0;    /* jump done */
                                 Ef[EN][8] = 1.6;   /* start fall */
      
                              }
                           else
                              {
                                 Ef[EN][1] -= (sin(Ef[EN][9]) * Ef[EN][3]);
                                 EYint=Ef[EN][1];
                                 if (is_up_solid(EXint, EYint, 1, 0))
                                    {
                                       Ef[EN][9] = 0;   /* abort jump */
                                       Ef[EN][8] = 1.6;   /* start fall */
                                    }
                              }
                        }
      
                     else  /* not jump */
                        {
                           if (Ef[EN][8])   /* if fall = 1 */
                              {
                                 Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                                 if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                                 Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                                 if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                                 EYint=Ef[EN][1];
                                 if (is_down_solid(EXint, EYint, 1))  /* look for end of fall */
                                    {
                                       Ef[EN][8] = 0; /*  fall=0;  */
                                       Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                       EYint=Ef[EN][1];
                                    }
                              }
                           if (!Ef[EN][8])  /* fall = 0 */
                              {
                                 /* start fall? look for no block below */
                                 if (!is_down_solid(EXint, EYint, 1)) Ef[EN][8] = 1.6;
      
                                 /* passcount jump */
                                 if ((Ei[EN][6] > 0) && ((passcount % Ei[EN][6]) == 1))
                                    Ef[EN][9] = 1.6; /* jump! */
      
                                 /* jump when player passes over width */
                                 if ((Ei[EN][7] > 0) && (EXint < (PXint + Ei[EN][7])) && (EXint > (PXint - Ei[EN][7])) && (EYint > PYint))
                                    Ef[EN][9] = 1.6;
                              } /* end of fall = 0  */
                        } /* end of else if not fall  */
      
                             /* set the bitmap and drawing mode */
                             b = Ei[EN][3];      /* ans */
                             c = zz[4][b];         /* num_of_shapes in seq */
      
                             if (Ei[EN][4] == 0) Ei[EN][1] = Ei[EN][3]; /* bmp, not ans */
                             if (Ei[EN][4] == 1) Ei[EN][1] = zz[0][b];    /* animate with time */
                             if (Ei[EN][4] == 2) /* animate with h move */
                                {
                                   x = (EXint/3) % c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
                             if (Ei[EN][4] == 3) /* animate with v move */
                                {
                                   x = (EYint/3) % c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
                             if (Ei[EN][4] == 4) /* animate with v and h move */
                                {
                                   x = ((EYint/3) % c) + ((EXint/3) % c);
                                   if (x > c) x-=c;
                                   Ei[EN][1] = zz[x+5][b];
                                }
                  break;
               }  /* end of switch enemy type */
         } /* end of if enemy active */
}
