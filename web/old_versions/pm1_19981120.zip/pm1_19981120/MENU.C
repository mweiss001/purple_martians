 /* menu.c  main, initial setup, menu stuff, strings */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro.h>
 /*   list of functions

   zmenu()
   bottom_menu()
   menu_setup()

 */
char global_string[20][25][80]; /* menu.c */
char help_string[20][25][80];



void level_text_editor(void)
{
extern char level_text[100][40];
extern int level_header[20];
extern BITMAP *memory_bitmap[512];
extern int zz[20][64];
extern int edit_int_retval;

int tx = 0, ty = 0;
int line_length = 30;
int k;
int x,y,z;
int wy = 0;
int redraw = 1;
int menu_sel;
int last_line = level_header[6];
char msg[80], temp_string[80];

/* initialization */
/* clear the ones higher than the number defined in */
/* level_header[6] */

for (x=last_line+1; x<100; x++)
   for (y=0; y<40; y++)
      level_text[x][y] = NULL;

clear_keybuf();

do {

   if (redraw)
      {
         redraw = 0;
         show_mouse(NULL);
         clear(screen);

         textout(screen, font,"LEVEL TEXT EDITOR",0,0,13);
         sprintf(msg,"line %d last line %d", wy+ty+1, last_line+1);
         textout(screen, font, msg, 0,8, 13);
          
         for (x=0; x<20; x++)
            textout(screen, font, level_text[wy+x], 0, 20+(x*8), 240);
      }
   /* check for last line */
   last_line = -1; /* default if all nulls */
   for (x=99; x>=0; x--)  /* loop down from 99 */
      if (level_text[x][0] != NULL) /* look for non NULL line */
        {
           last_line = x;
           break;
        }

   msg[0] = level_text[wy+ty][tx];
   if (msg[0] != NULL)
      {
         msg[0] = level_text[wy+ty][tx];
         msg[1] = NULL;
         text_mode(-1);
         textout(screen, font, msg, (tx*8), 20+(ty*8), 10);
         text_mode(0);
      }
   if ((msg[0] == NULL) || (msg[0] == 32)) /* draw inverse blank for cursor */
      {
         msg[0] = 32;
         msg[1] = NULL;
         text_mode(1);
         textout(screen, font, msg, (tx*8), 20+(ty*8), 10);
         text_mode(0);
      }
   if (keypressed()) /* don't wait for keypress */
      {
         k = readkey();
         redraw = 1;
      }
   else k = 0;
   k = (k & 0xFF);  /* strip upper bits */
   if ((k>31) && (k<128))   /* if alphanumeric */
      {
         z = strlen(level_text[wy+ty]);
         if (z > line_length) z = line_length;
         for (x=z; x>tx; x--) /* slide over */
            level_text[wy+ty][x] = level_text[wy+ty][x-1];
         level_text[wy+ty][z+1] = NULL; /* terminate the line*/

         level_text[wy+ty][tx] = k;
         if (++tx > line_length) /* end of line? */
            {
               level_text[wy+ty][tx] = NULL; /* terminate the line */
               tx = 0; /* CR */
               if (++ty >= 19) /* LF */
                  {
                     ty = 19;
                     if (++wy>80) wy = 80;
                  }
            }
      }
   if (key[KEY_BACKSPACE])
      {
         if (--tx<0) tx = 0;
         z = strlen(level_text[wy+ty]);
         for (x=tx; x<z; x++)
            level_text[wy+ty][x] = level_text[wy+ty][x+1];
      }
   if (key[KEY_ENTER])
      {
         for (y=99; y>wy+ty; y--)  /* slide all down */
            strcpy(level_text[y],level_text[y-1]);

         if (strlen(level_text[wy+ty]) >= tx) /* cursor not past end of line */
            {
               for (x=0; x <= line_length-tx; x++)         /* split line at tx */
                   level_text[wy+ty+1][x] = level_text[wy+ty+1][tx+x];
               level_text[wy+ty][tx] = NULL;  /* terminate top line */
               tx = 0; /* CR */
               if (++ty >= 19) /* LF */
                  {
                     ty = 19;
                     if (++wy>80) wy = 80;
                  }
            }
      }
   if (key[KEY_DEL])
      {
         if (level_text[wy+ty][tx] == NULL) /* delete line */
            {
               for (x=0; x<=line_length-tx; x++) /* get portion from line below */
                   level_text[wy+ty][tx+x] = level_text[wy+ty+1][x];
               for (y=ty+1; y<99; y++)  /* slide all up */
                  strcpy(level_text[wy+y],level_text[wy+y+1]);
               level_text[99][0] = NULL; /* last line empty */
            }
         else  /* delete char */
            {
               z = strlen(level_text[wy+ty]);
               for (x=tx; x<z; x++)
                  level_text[wy+ty][x] = level_text[wy+ty][x+1];
            }
      }

      if (key[KEY_RIGHT])  if (++tx > line_length-1) tx = line_length-1;
      if (key[KEY_LEFT]) if (--tx < 0) tx = 0;
      if (key[KEY_UP])
         if (--ty < 0)
            {
               ty = 0;
               if (--wy<0) wy = 0;
            }

      if (key[KEY_PGUP])
         {
            ty -=10;
            if (ty < 0)
               {
                  ty = 0;
                  wy -=10;
                  if (wy<0)
                     wy = 0;
               }
         }
      if (key[KEY_PGDN])
         {
            ty +=10;
            if (ty >= 19)
               {
                  ty = 19;
                  wy +=10;
                  if (wy > 80)
                     wy = 80;
               }
         }
      if (key[KEY_DOWN]) if (++ty >= 19)
         {
            ty = 19;
            if (++wy>80) wy = 80;
         }
      if ((mouse_b & 1) && (mouse_x < 250) && (mouse_y > 20) && (mouse_y < 180))
         {
            redraw = 1;
            ty = (mouse_y-20)/8;
            tx = mouse_x/8;
         }
   
      if (tx > strlen(level_text[wy+ty])) tx = strlen(level_text[wy+ty]);
     clear_keybuf();
  } while ((k != 27) && (!(mouse_b & 2)) );
level_header[6]=last_line+1;
}
int load_help()
{
FILE *filepntr;
char buff[40], buff2[20];
char msg[20];
int num_of_pages, page, line;
int loop, ch, fexit, c, x, y;

         textout(screen, font, "loading help...", 16, 184, 1);
         if ((exists("pmhelp.txt")) == 0)
            {
               textout(screen, font, "can't find pmhelp.txt", 16, 184, 1);
               rest(1000);
               return 0;
            }
         else
            {

               filepntr=fopen("pmhelp.txt","r");

                    /* get num_of_pages, should be 1st line */
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     if (strncmp(buff, "<num_of_pages=", 14) == 0)
                        {
                           buff2[0] = buff[14];
                           buff2[1] = buff[15];
                           buff2[3] = NULL;
                           num_of_pages = atoi(buff2);
                        }


                    /* cycle the pages */
                    for (page = 0; page < num_of_pages; page++)
                       {
                          line = 0;
                          do
                             {

                                loop = 0;
                                ch = fgetc(filepntr);
                                while((ch != '\n') && (ch != EOF))
                                   {
                                      buff[loop] = ch;
                                      loop++;
                                      ch = fgetc(filepntr);
                                   }
                                buff[loop] = NULL;
                                strcpy (help_string[page][line], buff);
                                line++;

                           } while (strcmp(buff, "<end_of_page>") != 0);
                       }
               fclose(filepntr);
            }
}


void help(int page)
{
   extern BITMAP *memory_bitmap[512];
   extern int zz[20][64];
   extern int joy_key;
   int ans, c, b, x, xindent, just, color, rcolor=15, hcolor=14;
   char msg[80], buff2[80];
   load_help();
   clear(screen);
   clear_keybuf();
   do {
         c=0;
         while (strcmp(help_string[page][c],"<end_of_page>") != 0)
          {
             xindent = 0;
             just = 0;
             color = rcolor; /* default regular color */
             sprintf(msg, help_string[page][c]);
             if (strncmp(msg, "<ac", 3) == 0)
                  {
                      buff2[0] = msg[3];
                      buff2[1] = msg[4];
                      buff2[2] = msg[5];

                      buff2[3] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,150,4+(c*8),20,20);

                      msg[0]= NULL;

                  }
           
             if (strncmp(msg, "<s", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = msg[4];

                      buff2[3] = NULL;
                      ans = atoi(buff2);
                      blit(memory_bitmap[ans], screen, 0,0,20,4+(c*8),20,20);

                      for(x=6; x < strlen(msg)+1; x++)
                         buff2[x-6] = msg[x]; /* chop first six */
                      strcpy(msg, buff2);
                      xindent = 40;
                  }
         
             if (strncmp(msg, "<a", 2) == 0)
                  {
                      buff2[0] = msg[2];
                      buff2[1] = msg[3];
                      buff2[2] = NULL;
                      ans = zz[0][atoi(buff2)];
                      blit(memory_bitmap[ans], screen, 0,0,20,4+(c*8),20,20);

                      for(x=5; x < strlen(msg)+1; x++)
                         buff2[x-5] = msg[x]; /* chop first five */
                      strcpy(msg, buff2);
                      xindent = 40;
                  }
              if (strncmp(msg, "<c>", 3) == 0)
                  {

                      for(x=3; x < strlen(msg)+1; x++)
                         buff2[x-3] = msg[x]; /* chop first three */
                      strcpy(msg, buff2);
                      just = 1;
                  }
              if (strncmp(msg, "<h>", 3) == 0)
                  {

                      for(x=3; x < strlen(msg)+1; x++)
                         buff2[x-3] = msg[x]; /* chop first three */
                      strcpy(msg, buff2);
                      just = 1;
                      color = hcolor;
                     
                  }



             if (c == 0) textout_centre(screen, font, msg, SCREEN_W/2, 16+(c*8), 10);
             else /* not top line */
                {
                   if (just) textout_centre(screen, font, msg, SCREEN_W/2, 16+(c*8), color);
                   else textout(screen, font, msg, 20+xindent, 16+(c*8), color);
                  
                }
             c++;
            }
         for (x=0;x<16;x++) rect(screen, x,x, 319-x, 199-x, 8+(x*16) );
         textout_centre(screen, font, "<-PREV        ESC-BACK        NEXT->",SCREEN_W/2, 177, 245);
        if (joy_key) poll_joystick();

        if ((key[KEY_LEFT]) || (joy_left)) /* prev */
            {
               if (--page < 0)  page = 19;
               while (joy_left) poll_joystick();
               clear(screen);
               clear_keybuf();

            }
         if ((key[KEY_RIGHT]) || (joy_right))  /* next */
            {
               if (++page > 19)  page = 0;
               while (joy_right) poll_joystick();
               clear(screen);
               clear_keybuf();

            }

         update_animation();
         rest(20);
         } while ((!key[KEY_ESC]) && (!(mouse_b & 2)) && (!joy_b1) );
    while ((key[KEY_ESC]) || (mouse_b & 2)); /* wait till released */
    while (joy_b1) poll_joystick();
            
    clear(screen);
}

int pmenu(int menu_num, int y)  /* this menu function does not pass through like the next one */
{                               /* it waits for a selection and then exits */

   int highlight = 2;
   int selection = 999;
   int last_list_item;
   int c, b;
   char msg[80];

   position_mouse(80,20);
   clear_keybuf();

   do   /* until selection is made */
      {
          c = 0;
          rest(20);
          show_mouse(NULL);
          while (strcmp(global_string[menu_num][c],"end") != 0)
            {
               b = 198;
               if (c == 0) b = 245;
               if (c == highlight) b=246;
               textout(screen, font, global_string[menu_num][c], 0, y+(c*8), b);
               c++;
            }
          last_list_item = c-1;
          show_mouse(screen);
          highlight = 14;
          if ((mouse_x< 100) && (mouse_y > 16) && (mouse_y < 168))
             highlight = (mouse_y/8);


        if (!(mouse_b & 2)) /* mouse b2 released */
           {
              selection = highlight;
           }

      } while (selection == 999);
   return selection;
}





int zmenu(int menu_num, int menu_pos, int y)  /* this menu function does not pass through like the next one */
{                               /* it waits for a selection and then exits */
   extern int resume_allowed;
   extern int joy_key;
   extern int up_key;
   extern int down_key;

   int highlight = menu_pos;
   int selection = 999;
   int last_list_item;
   int c, b;
   int old_my, new_my;
   char msg[80];

   show_mouse(NULL);
   /* rectfill(screen, 60, y, 300, 140, 0);  */
   clear_keybuf();

   do   /* until selection is made */
      {
          c = 0;
          while (strcmp(global_string[menu_num][c],"end") != 0)
            {
               b = 137; /* dimmer aqua */
               if (c == 0) b = 8; /* purple banner */
               if (c == highlight) b=9; /* brighest aqua */

               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if ((c==3) || (c==5)) b = 239; /* dim grey */

               textout_centre(screen, font, global_string[menu_num][c], SCREEN_W/2, y+(c*8), b);
               c++;
            }
          last_list_item = c-1;

          position_mouse(160,100);
          old_my=mouse_y;
          rest(20);
          new_my=mouse_y;


         if ((key[KEY_DOWN]) || (key[down_key]) || (new_my > old_my+1) || (joy_down))
            {
               if (++highlight > last_list_item) highlight = last_list_item;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
                  if ((highlight==3) || (highlight==5)) highlight++;

               rest(100);
            }
         if ((key[KEY_UP]) || (key[up_key]) || (new_my < old_my-1) || (joy_up))
            {
               if (--highlight < 2) highlight = 2;
               if ((!resume_allowed) && (menu_num == 7)) /* can't resume or save */
               if ((highlight==3) || (highlight==5)) highlight--;

               rest(100);
            }
         if (key[KEY_ENTER]) selection = highlight;
         if (mouse_b & 1)
            {
               while (mouse_b & 1); /* wait for release */
               selection = highlight; /* get selection */
            }
         while (joy_down) poll_joystick();
         while (joy_up) poll_joystick();


         if (joy_key) /* joystick control */
            {
               poll_joystick();
               if  (joy_b1)
                  {
                     selection = highlight; /* wait for release */
                     do {
                          poll_joystick();
                        } while (joy_b1);
                  }
            }




         if ((key[KEY_ESC]) || (mouse_b & 2))
           {
              while ((key[KEY_ESC]) || (mouse_b & 2)); /* until released */

              selection = last_list_item;
              if (menu_num == 8) selection = 2; /* back is at top of options menu */

           }

      } while (selection == 999);
   return selection;
}



int bottom_menu(int menu_num)
   /* this is a pass through once funtion and should be called in a loop */
{
   extern char global_string[20][25][80];
   char msg[80];
   int selection, c, d;
   show_mouse(screen);
   rest(5);
   show_mouse(NULL);
   if (mouse_y > 186) selection = (mouse_x / 40);   /* highlight only */
   for (c=0; c <= 7; c++)
      {
         if (c == selection) d = 246; else d = 214;
         sprintf(msg," F%-1d  ",c+1);
         textout(screen, font, msg,                   c*40, 184, d);
         textout(screen, font, global_string[menu_num][c], c*40, 192, d);
      }
   selection = 999; /* normal return --  nothing happened */
   if ((mouse_b & 1) && (mouse_y > 186))
      {
         selection = (mouse_x / 40);
         while (mouse_b & 1);   /* wait for release */
      }


   if (selection == 7) selection = -1;
   if (key[KEY_F1]) selection = 0;
   if (key[KEY_F2]) selection = 1;
   if (key[KEY_F3]) selection = 2;
   if (key[KEY_F4]) selection = 3;
   if (key[KEY_F5]) selection = 4;
   if (key[KEY_F6]) selection = 5;
   if (key[KEY_F7]) selection = 6;
   if (key[KEY_F8]) selection = -1;
   if (key[KEY_ESC]) selection = -1;
   if ((mouse_b & 2) && (mouse_y > 160))
      {
         selection = -1;
         while (mouse_b & 2); /* wait for release */
      }
   return selection;
}

void menu_setup(void)
{

   strcpy (global_string[0][0],"ZOOM");   /* edit main  menu */
   strcpy (global_string[0][1],"BTMP");
   strcpy (global_string[0][2],"SPEC");
   strcpy (global_string[0][3],"ENEM");
   strcpy (global_string[0][4],"PDEO");
   strcpy (global_string[0][5],"LOAD");
   strcpy (global_string[0][6],"SAVE");
   strcpy (global_string[0][7],"QUIT");

   strcpy (global_string[1][0],"VIEW");  /* item sub menu */
   strcpy (global_string[1][1],"NEW ");
   strcpy (global_string[1][2]," -- ");
   strcpy (global_string[1][3]," -- ");
   strcpy (global_string[1][4]," -- ");
   strcpy (global_string[1][5]," -- ");
   strcpy (global_string[1][6],"HELP");
   strcpy (global_string[1][7],"BACK");

   strcpy (global_string[2][0]," -- "); /* enemy sub menu */
   strcpy (global_string[2][1],"MOVE");
   strcpy (global_string[2][2],"COPY");
   strcpy (global_string[2][3]," -- ");
   strcpy (global_string[2][4]," -- ");
   strcpy (global_string[2][5],"PDFE");
   strcpy (global_string[2][6],"HELP");
   strcpy (global_string[2][7],"BACK");

   strcpy (global_string[3][0],"ANIM");  /* bitmap sub menu */
   strcpy (global_string[3][1],"BTMP");
   strcpy (global_string[3][2],"DRAW");
   strcpy (global_string[3][3],"COLR");
   strcpy (global_string[3][4],"FX1 ");
   strcpy (global_string[3][5],"LOAD");
   strcpy (global_string[3][6],"SAVE");
   strcpy (global_string[3][7],"BACK");

   strcpy (global_string[4][0],"FLPX"); /* fx1 sub sub menu */
   strcpy (global_string[4][1],"FLPY");
   strcpy (global_string[4][2],"SCRU");
   strcpy (global_string[4][3],"SCRD");
   strcpy (global_string[4][4],"SCRL");
   strcpy (global_string[4][5],"SCRR");
   strcpy (global_string[4][6]," -- ");
   strcpy (global_string[4][7],"BACK");

   strcpy (global_string[5][0],"GET"); /* PD sub menu */
   strcpy (global_string[5][1],"PUT");
   strcpy (global_string[5][2],"NEXT");
   strcpy (global_string[5][3],"PREV");
   strcpy (global_string[5][4],"COPY");
   strcpy (global_string[5][5],"SAVE");
   strcpy (global_string[5][6],"HELP");
   strcpy (global_string[5][7],"BACK");

   strcpy (global_string[6][0],"ZERO"); /*  block sub-menu */
   strcpy (global_string[6][1],"SETF");
   strcpy (global_string[6][2],"SETB");
   strcpy (global_string[6][3],"COPY");
   strcpy (global_string[6][4],"PAST");
   strcpy (global_string[6][5],"NEW-");
   strcpy (global_string[6][6],"BLOK");
   strcpy (global_string[6][7],"BACK");

   strcpy (global_string[7][0], "GAME MENU"); /* new main menu */
   strcpy (global_string[7][1], "--------");
   strcpy (global_string[7][2], "NEW GAME");
   strcpy (global_string[7][3], "RESUME GAME");
   strcpy (global_string[7][4], "LOAD GAME");
   strcpy (global_string[7][5], "SAVE GAME");
   strcpy (global_string[7][6], "OPTIONS MENU");
   strcpy (global_string[7][7], "HELP");
   strcpy (global_string[7][8], "EXIT");
   strcpy (global_string[7][9], "end");


   strcpy (global_string[8][0],"OPTIONS MENU"); /* OPTION MENU new main menu */
   strcpy (global_string[8][1],"-------");
   strcpy (global_string[8][2],"BACK TO GAME MENU");
   strcpy (global_string[8][3],"KEYBOARD SETUP");
   strcpy (global_string[8][4],"JOYSTICK SETUP");
   strcpy (global_string[8][5],"DIFFICULTY: NORMAL");
   strcpy (global_string[8][6],"SPEED:FAST");
   strcpy (global_string[8][7],"SOUND:ON");
   strcpy (global_string[8][8],"START LEVEL (1)");
   strcpy (global_string[8][9],"LEVEL EDITOR");
   strcpy (global_string[8][10],"SYSTEM VALUES");
   strcpy (global_string[8][11],"end");

   strcpy (global_string[9][0], "EDITOR POP-UP MENU");
   strcpy (global_string[9][1], "------------------");
   strcpy (global_string[9][2], "COPY ---");
   strcpy (global_string[9][3], "VIEW ---");
   strcpy (global_string[9][4], "MOVE ---");
   strcpy (global_string[9][5], "ZERO ---");
   strcpy (global_string[9][6], "------------------");
   strcpy (global_string[9][7], "ZOOM OUT (100X100)");
   strcpy (global_string[9][8], "PREDEFINED OBJECTS");
   strcpy (global_string[9][9], "BITMAP MENU");
   strcpy (global_string[9][10],"ITEM MENU");
   strcpy (global_string[9][11],"ENEMY MENU");
   strcpy (global_string[9][12],"LOAD LEVEL");
   strcpy (global_string[9][13],"SAVE LEVEL");
   strcpy (global_string[9][14],"EXIT POP UP MENU");
   strcpy (global_string[9][15]," ");
   strcpy (global_string[9][16],"MOVEABLE OBJECT MENU");
   strcpy (global_string[9][17],"HIDE|SHOW BOTTOM DISPLAY");
   strcpy (global_string[9][18],"LEVEL TEXT EDITOR");
   strcpy (global_string[9][19],"SAVE AND EXIT LEVEL EDITOR");
   strcpy (global_string[9][20],"EXIT LEVEL EDITOR");
   strcpy (global_string[9][21],"end");

   strcpy (global_string[10][0],"OBJ+"); /*  mov_ob */
   strcpy (global_string[10][1],"OBJ-");
   strcpy (global_string[10][2],"STP+");
   strcpy (global_string[10][3],"STP-");
   strcpy (global_string[10][4],"COLR");
   strcpy (global_string[10][5],"NEW ");
   strcpy (global_string[10][6],"DEL ");
   strcpy (global_string[10][7],"BACK");


}


