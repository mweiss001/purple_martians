/* ITEM.C - this has all the item stuff */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>

int item_sort(void)
{
extern int item_num_of_type[20];   /* sort stuff used by others */
extern int item_first_num[20];
extern int item_coloc_num;
extern int item_coloc_x;
extern int item_coloc_y;
extern char item_desc[20][5][40];
extern int item[500][16];
char msg[80];
int b, c, d, quit, temp;
/* item variable description */

   strcpy (item_desc[0][0],"item_empty");

   strcpy (item_desc[1][0],"Door");
   strcpy (item_desc[1][1],"x_destination");
   strcpy (item_desc[1][2],"y_destination");
   strcpy (item_desc[1][3],"n/a");
   strcpy (item_desc[1][4],"n/a");

   strcpy (item_desc[2][0],"Bonus");
   strcpy (item_desc[2][1],"points");
   strcpy (item_desc[2][2],"health");
   strcpy (item_desc[2][3],"bullet");
   strcpy (item_desc[2][4],"timer");

   strcpy (item_desc[3][0],"Exit");
   strcpy (item_desc[3][1],"n/a");
   strcpy (item_desc[3][2],"n/a");
   strcpy (item_desc[3][3],"enemies all dead?");
   strcpy (item_desc[3][4],"n/a");

   strcpy (item_desc[4][0],"Key");
   strcpy (item_desc[4][1],"x1-target");
   strcpy (item_desc[4][2],"y1-target");
   strcpy (item_desc[4][3],"x2-target");
   strcpy (item_desc[4][4],"y2-target");

   strcpy (item_desc[5][0],"Start");
   strcpy (item_desc[5][1],"n/a");
   strcpy (item_desc[5][2],"n/a");
   strcpy (item_desc[5][3],"level_time");
   strcpy (item_desc[5][4],"");

   strcpy (item_desc[6][0],"Free Man");
   strcpy (item_desc[6][1],"n/a");
   strcpy (item_desc[6][2],"n/a");
   strcpy (item_desc[6][3],"n/a");
   strcpy (item_desc[6][4],"n/a");

   strcpy (item_desc[7][0],"Mine");
   strcpy (item_desc[7][1],"n/a");
   strcpy (item_desc[7][2],"health dec");
   strcpy (item_desc[7][3],"n/a");
   strcpy (item_desc[7][4],"n/a");

   strcpy (item_desc[8][0],"Bomb");
   strcpy (item_desc[8][1],"n/a");
   strcpy (item_desc[8][2],"damage");
   strcpy (item_desc[8][3],"n/a");
   strcpy (item_desc[8][4],"fuse");

   strcpy (item_desc[9][0], "undefined");
   strcpy (item_desc[9][1],"n/a");
   strcpy (item_desc[9][2],"n/a");
   strcpy (item_desc[9][3],"n/a");
   strcpy (item_desc[9][4],"n/a");

   strcpy (item_desc[10][0],"Message");
   strcpy (item_desc[10][1],"first line");
   strcpy (item_desc[10][2],"last line");
   strcpy (item_desc[10][3],"text color");
   strcpy (item_desc[10][4],"box color");

quit=0;
while (!quit) /* sort item list */
{
   quit=1;    /* quit if no swap */
   for (c=0; c < 499; c++)
      if (item[c][0] < item[c+1][0]) /* sort by first value 'type' */
         {  /* swap */
            quit=0;      /* as long as a swap has been made */
            for (d=0; d<16; d++)
               {
                  temp = item[c][d];
                  item[c][d] = item[c+1][d];
                  item[c+1][d] = temp;
               }
         }
}


/* get data about first 10 item types
   make sub lists of item types using these variables */

for (c=0; c<20; c++)   /* zero the counters */
   {
      item_num_of_type[c] = 0;
      item_first_num[c] = 0;
   }

for (c=0; c<500; c++)    /* get the type counts */
   {
      if (item[c][0] < 20)
      item_num_of_type[item[c][0]]++;   /* inc number of this type        */
      else item_num_of_type[9]++;       /* if type > 8 group together   */
                                        /* in type 9  as unknown      */
   }
for (c=0; c<20; c++)  /* get first nums */
   if (item_num_of_type[c] > 0)  /* are there any of this type?  */
      for (d=0; d<500; d++)
         if (item[d][0] == c)
            {
               item_first_num[c] = d;
               d=500;   /* exit loop */
            }

item_first_num[0] = 0; /* to show all  */


   d = 0;
   for (c=0; c < 500; c++)
      if (item[c][0] != 0) d++;


return d;
}

void new_view_item_list(int type)
{
extern BITMAP *memory_bitmap[512];
extern int item[500][16];
extern int zz[64][20];
extern int item_num_of_type[20];   /* sort results */
extern int item_first_num[20];
extern int edit_int_retval;
extern char item_desc[20][5][40];
int b, c, d, e, f, x, y, y1, nsl_redraw = 1;
int new_item_list_quit = 0;
char msg[80];
int first_screen_column = 6, first_screen_row = 0;
int screen_column = 0, screen_row = 0;
int column_count = 0, row_count = 0;
int list_menu_selection= 99;
int col_size = 60;
int hf = 245;
int rv = 240; /* reg value white */
int hv = 241; /* higlighted value red */
int vd = 128; /* value desc grey */
int ypos = 22, list_size = 15;
clear(screen);
item_sort();
set_mouse_range(0,0,319,199);

     do
       {   show_mouse(screen);
           rest(10);
           show_mouse(NULL);
           if (nsl_redraw)
              {
                 nsl_redraw = 0;
                 rectfill(screen, 0, ypos-20, 319, ypos+(list_size*10), 0); /* erase old */
                 screen_column = 0;
                 screen_row = 0;
                 row_count = 0;
                 for (y = item_first_num[type]; y < item_first_num[type]+item_num_of_type[type]; y++)
                    {
                          row_count++;
                          if (row_count > first_screen_row)  /* past the start */
                             if (++screen_row < list_size)    /* before the end */
                               {
                                   screen_column = 0;
                                   sprintf(msg,"%2d",y); /* item number */
                                   textout(screen, font, msg,2,ypos+1+(screen_row*10), hv);

                                   for (x=first_screen_column; x<10; x++)  /* cycle the values, they are columns */
                                      {
                                         if (x==0) sprintf(msg,"type");
                                         if (x==1) sprintf(msg,"bmp/ans");
                                         if (x==2) sprintf(msg,"draw mode");
                                         if (x==3) sprintf(msg,"move mode");
                                         if (x==4) sprintf(msg,"x origin");
                                         if (x==5) sprintf(msg,"y origin");

                                         if (x>5) sprintf(msg,"%s", item_desc[type][x-5] );  /* column title */
                                         textout(screen, font, msg, 32+(screen_column*col_size),ypos+1,vd); /* column title */

                                         sprintf(msg,"%d", item[y][x]);  /* actual value! */
                                         textout(screen, font, msg, 32+(screen_column*col_size),ypos+1+(screen_row*10), rv);
                                         screen_column++;
                                      }
                               }
                    }
                 if (first_screen_column > 8)  first_screen_column = 0;
                 if (first_screen_row > row_count)  first_screen_row = 0;

                  for (x=0; x<8; x++) /* column dividers */
                    vline (screen, 30+(x * col_size), -1+ypos+(list_size*10), ypos-1, hv);
        
                 for (x=0; x<list_size; x++)  /* row dividers */
                    hline (screen, 1, -1 + ypos+(x*10), 318, hv);
        
                 sprintf(msg,"IT#" );
                 textout(screen, font, msg, 2, ypos+1, hv);
        
                 d = hf;
                 sprintf(msg,"List of %-2d %ss", item_num_of_type[type],item_desc[type][0] );
                 textout_centre(screen, font, msg, SCREEN_W/2, ypos-20, d);

                 sprintf(msg,"row+|row-|col+|col-|csz+|csz-|help|back");
                 textout(screen, font, msg, 2, ypos-10, d);

                 /* title dividers */
                  hline (screen, 1, ypos -12, 318, d);
                  hline (screen, 1, ypos -2, 318, d);
                 /* frame */
                 rect(screen, 0, ypos-22, 319, ypos+(list_size*10),d); /* outer drawn last */

              } /* end of if (nsl)redraw) */

                 list_menu_selection = 99;
                 if ((mouse_y > (ypos-10) ) && (mouse_y < (ypos-2))) /* is mouse on menu bar */
                    if (mouse_b & 1) list_menu_selection = ((mouse_x-2)/40);

                   if ((key[KEY_DOWN]) || (list_menu_selection == 0))
                     {
                        if (++first_screen_row > row_count-list_size+2)
                           first_screen_row = row_count-list_size+2;
                        rest(100);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_UP]) || (list_menu_selection == 1))
                     {
                        if (--first_screen_row < 0)
                           first_screen_row = 0;
                        rest(100);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }
                  if ( (key[KEY_CONTROL]) && (key[KEY_PGUP]) )
                     {
                        first_screen_row -=10;
                        if (first_screen_row < 0)
                           first_screen_row = 0;
                        rest(100);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }
                  if ( (key[KEY_CONTROL]) && (key[KEY_PGDN])  )
                     {
                        first_screen_row += 10;

                        if ((type > 0) && (first_screen_row > row_count-list_size+2))
                           first_screen_row = row_count-list_size+2;

                        if ((type == 0) && (first_screen_row > 80))
                           first_screen_row = 80;

                        rest(100);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }

                  if ((key[KEY_RIGHT]) || (list_menu_selection == 2))
                     {
                        if (++first_screen_column > 7)
                           first_screen_column = 7;
                        rest(100);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_LEFT]) || (list_menu_selection == 3))
                     {
                        if (--first_screen_column < 0)
                           first_screen_column = 0;
                        rest(100);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_PGUP]) || (list_menu_selection == 4))
                     {
                        col_size += 4;
                        rest(20);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_PGDN]) || (list_menu_selection == 5))
                     {
                        col_size -= 4;
                        if (col_size < 30) col_size=30;
                        rest(20);
                        nsl_redraw = 1;
                        clear_keybuf();
                     }
                  if ((list_menu_selection == 6))
                     {
                        clear(screen);
                        help(15);
                        nsl_redraw = 1;
                        clear_keybuf();
                        clear(screen);
                     }
                 if ((mouse_b & 1) && (mouse_y > ypos)) /* edit an int */
                    {
                       x = (-32 + mouse_x) / col_size;
                       if (x<0) x = 0;
                       if (x>9) x = 9;
                       y = ((-2 + mouse_y - ypos) / 10)-1;
                       y1 = 11+(y*10) + ypos;
                       y = y + (item_first_num[type] + first_screen_row);
                       if (y < item_first_num[type])
                          y = item_first_num[type];
                       if (y > item_first_num[type] + item_num_of_type[type])
                          y = item_first_num[type]+item_num_of_type[type];
                       if ((x+first_screen_column) > 12) x = 0;
                       if (edit_int(32+(x*col_size), y1, item[y][x+first_screen_column], 1, -1, 500)) item[y][x+first_screen_column] = edit_int_retval;
                       item_sort();
                       nsl_redraw = 1;
                       clear(screen);
                    }
                 if (mouse_b & 2) list_menu_selection = 7;
                 if (list_menu_selection == 7)
                    {
                        new_item_list_quit = 1;
                        while (mouse_b & 1); /* wait till released */
                    }
   } while (!new_item_list_quit);
}
void create_item(int type)
{
   extern int item[500][16];
   extern int l[100][100];
   extern int get100_x, get100_y;
   int c=0, d;
   char msg[80];

   do /* find empty item  */
      {
         c++;
      }  while ((c < 500) && (item[c][0] != 0));

   if (c > 499)
      {
         textout(screen, font, " item list full ", 20, 20, 1);
         type = 0;
         rest(2000);
      }
                  switch (type)
                     {
                        default:
                           textout(screen, font, "no creator exists for that item type  ", 0, 160, 1);
                           rest(700);
                        break;
                        case 1: /* door creator  */
                           clear(screen);
                           textout(screen, font, "DOOR CREATOR" ,205,122,240);
                           textout(screen, font, "------------" ,205,130,240);
                           textout(screen, font, "mouse b1"     ,205,138,11);
                           textout(screen, font, "PUT DOOR"     ,205,146,11);
                           textout(screen, font, "mouse b2/esc" ,205,156,10);
                           textout(screen, font, "ABORT"        ,205,164,10);
                           if (getxy100(999))
                              {
                                 item[c][0] = 1; /* type 1 */
                                 item[c][1] = 1005; /* ans */
                                 item[c][2] = 1; /* draw mode normal */
                                 item[c][3] = 0; /* stationary */
                                 item[c][4] = get100_x*20;
                                 item[c][5] = get100_y*20;

                                 l[item[c][4]/20][item[c][5]/20] = 0;   /* zero block */

                                 rest(300);
                                 textout(screen, font, "DESTINATION ", 205,146,11);
                                 if (getxy100(999))
                                    {
                                       item[c][6] = get100_x;
                                       item[c][7] = get100_y;
                                    }
                              }
                           item_sort();
                           show_mouse(NULL);
                           rest(300);
                           clear(screen);
                        break;
                        case 3: /* exit creator */
                           clear(screen);
                           textout(screen, font, "EXIT CREATOR", 205,122,240);
                           textout(screen, font, "------------", 205,130,240);
                           textout(screen, font, "mouse b1",    205,138,11);
                           textout(screen, font, "PUT EXIT    ", 205,146,11);
                           textout(screen, font, "mouse b2/esc",205,156,10);
                           textout(screen, font, "ABORT",       205,164,10);
                           if (d = getxy100(999));  /* xorg, yorg */
                              {
                                 item[c][0] = 3 ;   /* type 3 exit */
                                 item[c][1] = 1022;   /* default animation seq */
                                 item[c][2] = 1;    /* draw mode */
                                 item[c][3] = 0;    /* stationary */
                                 item[c][4] = get100_x*20;  /* mouse click x */
                                 item[c][5] = get100_y*20;  /* mouse click y */
                                 item[c][6] = 0;    /* NOT ALL DEAD */
                                 l[item[c][4]/20][item[c][5]/20] = 0; /* zero on l */
                              }
                           item_sort();
                           show_mouse(NULL);
                           rest(300);
                           clear(screen);
                        break;
                        case 9:     /* all dead exit creator */
                           clear(screen);
                           textout(screen, font, "EXIT CREATOR", 205,122,240);
                           textout(screen, font, "------------", 205,130,240);
                           textout(screen, font, "mouse b1",    205,138,11);
                           textout(screen, font, "PUT EXIT    ", 205,146,11);
                           textout(screen, font, "mouse b2/esc",205,156,10);
                           textout(screen, font, "ABORT",       205,164,10);
                           if (d = getxy100(999));  /* xorg, yorg */
                              {
                                 item[c][0] = 3 ;   /* type 3 exit */
                                 item[c][1] = 1022;   /* default animation seq */
                                 item[c][2] = 1;    /* draw mode */
                                 item[c][3] = 0;    /* stationary */
                                 item[c][4] = get100_x*20;  /* mouse click x */
                                 item[c][5] = get100_y*20;  /* mouse click y */
                                 item[c][6] = 1;    /* ALL DEAD */
                                 l[item[c][4]/20][item[c][5]/20] = 0; /* zero l */
                              }
                           item_sort();
                           show_mouse(NULL);
                           rest(300);
                           clear(screen);
                        break;
                        case 4: /* key creator */
                           {
                              extern BITMAP *memory_bitmap[512];
                              int key_color, x, exit=0;
                              while (mouse_b & 1); /* wait for release */

                              clear(screen);
                              textout_centre(screen, font, "Key and Locked Block Creator", SCREEN_W/2, 10, 240);
                              textout_centre(screen, font, "----------------------------", SCREEN_W/2, 18, 208);
                              textout_centre(screen, font, "b1 to choose a color", SCREEN_W/2, 180, 240);
                              textout_centre(screen, font, "b2 or <esc> to quit", SCREEN_W/2, 188, 208);

                              for (x=0; x<4; x++)
                                 draw_sprite(screen, memory_bitmap[220+x],(160),(x*20)+60);
                              while (!exit)
                                 {
                                    show_mouse(screen);
                                    if ((mouse_b & 2) || (key[KEY_ESC]))  exit = 1;
                                    if ((mouse_b & 1) && (mouse_x > 160 ) && (mouse_x <  180))
                                       {
                                          key_color = (mouse_y - 60)/20;
                                          exit = 1;
                                          if ((key_color < 0) || (key_color > 3))
                                             key_color = 0;
                                       }
                                  }
                              while (mouse_b & 1); /* wait for release */
                              clear(screen);

                                 textout(screen, font, "KEY CREATOR", 205,122,240);
                                 textout(screen, font, "-----------", 205,130,240);
                                 textout(screen, font, "mouse b1",    205,138,11);
                                 textout(screen, font, "PUT KEY", 205,146,11);
                                 textout(screen, font, "mouse b2/esc",205,156,10);
                                 textout(screen, font, "ABORT",       205,164,10);

                                 if (getxy100(999))
                                    {
                                       item[c][0] = 4; /* type 4 - block killer ! */
                                       item[c][1] = 1039 + key_color; /* animation seq */
                                       item[c][2] = 1; /* draw mode */
                                       item[c][3] = 1; /* fall */
                                       item[c][4] = get100_x*20;
                                       item[c][5] = get100_y*20;
                                    
                                       l[item[c][4]/20][item[c][5]/20] =0;

                                       rest(300);
                                       show_mouse(NULL);
                                       clear(screen);
                                       textout(screen, font, "KEY CREATOR", 205,122,240);
                                       textout(screen, font, "-----------", 205,130,240);
                                       textout(screen, font, "mouse b1",    205,138,11);
                                       textout(screen, font, "PUT TOP-RIGHT", 205,146,11);
                                       textout(screen, font, "mouse b2/esc",205,156,10);
                                       textout(screen, font, "ABORT",       205,164,10);
                                       if (getxy100(999))
                                          {
                                             item[c][6] = get100_x;
                                             item[c][7] = get100_y;
                                          }
                                       rest(300);
                                       show_mouse(NULL);
                                       clear(screen);
                                       textout(screen, font, "KEY CREATOR", 205,122,240);
                                       textout(screen, font, "-----------", 205,130,240);
                                       textout(screen, font, "mouse b1",    205,138,11);
                                       textout(screen, font, "BOTTOM-LEFT", 205,146,11);
                                       textout(screen, font, "mouse b2/esc",205,156,10);
                                       textout(screen, font, "ABORT",       205,164,10);
                                       if (getxy100(999))
                                          {
                                             int x,y;
                                             item[c][8] = get100_x;
                                             item[c][9] = get100_y;
                                             /* set the block */
                                             for (x = item[c][6];x <= item[c][8];x++)
                                                for (y = item[c][7];y <= item[c][9];y++)
                                                   l[x][y] = 220+key_color; /* keyed block */
                                          }
                                    }
                              }
                           item_sort();
                           show_mouse(NULL);
                           rest(300);
                           clear(screen);
                        break;
                        case 5:     /* initial PX, PY */
                        {
                           int x,y;
                           for (x=0; x<500; x++)  /* erase all other starts*/
                               if (item[x][0] == 5)
                                  for (y=0; y<16; y++)
                                     item[x][y] = 0;
                           clear(screen);
                           textout(screen, font, "START CREATOR", 205,122,240);
                           textout(screen, font, "-------------", 205,130,240);
                           textout(screen, font, "mouse b1",    205,138,11);
                           textout(screen, font, "PUT START    ", 205,146,11);
                           textout(screen, font, "mouse b2/esc",205,156,10);
                           textout(screen, font, "ABORT",       205,164,10);
                
                           if (d = getxy100(999));  /* xorg, yorg */
                              {
                                 item[c][0] = 5 ;   /* type 5 start */
                                 item[c][1] = 1021;   /* default animation seq */
                                 item[c][2] = 1;  /* draw mode */
                                 item[c][3] = 0;  /* stationary */
                                 item[c][4] = get100_x*20;  /* mouse click x */
                                 item[c][5] = get100_y*20;  /* mouse click y */
                                 item[c][8] = 300;  /* default level_time */
                                 l[item[c][4]/20][item[c][5]/20] = 0; /* zero l */
                              }
                           item_sort();
                           show_mouse(NULL);
                           rest(300);
                           clear(screen);
                           }
                           break;
                           case 10: /* pop up message creator */
                              {
                                 extern int edit_int_retval;
                                 int redraw = 1;
                                 int quit = 0;
                                 int l1=10; /* default 1st line */
                                 int l2=l1+2; /* default 2nd line  */
                                 int tc=14; /* default text color (yellow) */
                                 int fc=10; /* default frame color (red) */
      
                                 while (!quit)
                                    {
                                       if (redraw)
                                          {
                                             redraw = 0;
                                             clear(screen);
                                             textout_centre(screen, font, "Pop Up Message Creator",SCREEN_W/2,0,9);
                                             textout_centre(screen, font, "----------------------",SCREEN_W/2,8,9);
                                             /* draw the message */
                                                {
                                                   extern char level_text[100][40];

                                                   int ln1 = l1;
                                                   int ln2 = l2;
                                                   int y;
                                                   int text_color = tc;
                                                   int frame_color = fc;
                                                   int px, py, px2, py2;
                                                   int width = 1; /* default */
                                                   int border = 8;
                                                   int height;
                 
                                                   height = 1 + abs(ln2-ln1); /* if zero height is one line */
                                                   /* border = 2 * height;  */
                 
                                                   for (y=ln1; y<= ln2; y++) /* find width */
                                                      if (strlen(level_text[y]) > width)
                                                         width = strlen(level_text[y]);
                                                   px = (320 - border - (width*8)) / 2;
                                                   py = 30;
                                                   px2 = px+(width*8)+(border*2);
                                                   py2 = py+(height*8)+(border*2);
                 
                                                   rectfill(screen, px,py,px2,py2,0); /* clear */
                                                   for (y=0; y<border; y++)
                                                       {
                                                          int color_offset = y*16;
                                                          rect(screen, px+y,py+y,px2-y,py2-y,fc+color_offset); /* frame */
                 
                                                       }
                                                   for (y=ln1; y<=ln2; y++)
                                                       textout(screen, font, level_text[y]
                                                        ,1+border+px,1+border+py + ((y-ln1)*8), tc); /* text line */
                                                }
                               
                                             textout(screen, font, " FIRST LINE:", 20,144,12);
                                             sprintf(msg,"%d", l1+1);
                                             textout(screen,font,msg,116,144,13);
                                          
                                             textout(screen, font, "  LAST LINE:", 20,152,12);
                                             sprintf(msg,"%d", l2+1);
                                             textout(screen,font,msg,116,152,13);
                                          
                                             textout(screen, font, " TEXT COLOR:", 20,160,tc);
                                             sprintf(msg,"%d", tc);
                                             textout(screen,font,msg,116,160,13);
                                          
                                             textout(screen, font, "FRAME COLOR:", 20,168,fc);
                                             sprintf(msg,"%d",fc);
                                             textout(screen,font,msg,116,168,13);
                                             textout(screen, font, "   CONTINUE:", 20,184,11);
                                             textout(screen, font, "      ABORT:", 20,192,10);
                                          } /* end of if redraw */
                                       if (key[KEY_PGUP])
                                          {
                                              if (--l2<1) l2 = 1;
                                              rest(50);
                                              redraw = 1;
                                          }
                                       if (key[KEY_PGDN])
                                          {
                                              if (++l2>98) l2 = 98;
                                              rest(50);
                                              redraw = 1;
                                          }
                                      if (key[KEY_DOWN])
                                         if (l2 < 99)
                                            {
                                               l1++;
                                               l2++;
                                               rest(20);
                                               redraw = 1;
                                            }
                                      if (key[KEY_UP])
                                         if (l1 > 2)
                                            {
                                               --l1;
                                               --l2;
                                               rest(20);
                                               redraw = 1;
                                            }
                                       if ((l2-l1) > 10) l2=l1+10; /* max height = 10 */
                                       if (l2<l1) l2 = l1;
                                       show_mouse(screen); rest(10); show_mouse(NULL);
                                       if ((mouse_b & 1) && (mouse_x > 2) && (mouse_x < 150) && (mouse_y > 144) && (mouse_y < 200))
                                          {
                                             redraw = 1;
                                             switch ((mouse_y-144)/8)
                                                {
                                                   case 0: /* edit x size */
                                                   if (edit_int(116, 144, l1+1, 1, 1, 99)) l1 =edit_int_retval-1; break;
                                                   case 1: /* edit y size */
                                                   if (edit_int(116, 152, l2+1, 1, 1, 99)) l2 =edit_int_retval-1; break;
                                                   case 2: /* edit color */
                                                   if (edit_int(116, 160, tc, 1, 7, 15)) tc =edit_int_retval; break;
                                                   case 3: /* edit other */
                                                   if (edit_int(116, 168, fc, 1, 7, 15)) fc =edit_int_retval; break;
                                                   case 5: /* CONTINUE */ quit = 1; break;
                                                   case 6: /* ABORT */  quit = -1; break;
                                                }
                                          }
                                    } /* end of while (!quit) */
                                 while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
                                 if (quit == 1) quit = 0; /* reset quit if good previous exit */
                                 while (!quit)
                                    {
                                       clear(screen);
                                       textout(screen, font, "-PUT MSG-", 200, 104, 240);
                                       textout(screen, font, "click b1 on xy ", 200, 112, 208);
                                       textout(screen, font, " default mine", 200, 120, 208);
                                       textout(screen, font, "b2/esc - aborts", 200, 128, 176);
                                       d = getxy100(999);  /* xorg, yorg */
                                       if ((d == 0) || (d == 2)) quit = -1;
                                       if (d == 1)
                                          {
                                             quit = 1;
                                             item[c][0] = 10 ;  /* type 10 msg */
                                             item[c][1] = 1036;  /*  animation seq */
                                             item[c][2] = 1; /* draw mode */
                                             item[c][3] = 0; /* stationary */

                                             item[c][4] = get100_x*20;  /* mouse click x */
                                             item[c][5] = get100_y*20;  /* mouse click y */

                                             item[c][6] = l1+1;
                                             item[c][7] = l2+1;
                                             item[c][8] = tc;
                                             item[c][9] = fc;
                                             l[item[c][4]/20][item[c][5]/20] = 0; /* zero l */
                                          }
                                    }  /* end of while (!quit) */
                                item_sort();
                                clear(screen);
                             }
                          break;


                     }  /* end of switch case */
}  /* end of create item function */


void item_menu()
{
      extern int item[500][16];
      extern char item_desc[20][5][40];
      extern int item_num_of_type[20];   /* sort stuff used by others */
      extern int item_coloc_num;
      extern int item_coloc_x;
      extern int item_coloc_y;
      char msg[80];
      int c, d;
      int spgry=999;
      int menu=1; /* item type menu */
      item_sort();  /* intial setup */
      clear_keybuf();
      show_mouse(NULL);
      clear(screen);

      do /* item menu loop */
         {
            if (spgry == 1) create_item(menu);

            if (spgry == 0)
               {
                  new_view_item_list(menu);
                  clear(screen);
               }
            show_mouse(NULL);
            textout(screen, font, "Special Block List and Create ", 0, 160, 246);
            textout(screen, font, "b1 - select type   b2 - exit  ", 0, 168, 198);
            sprintf(msg, "%d co-located items x%d y%d", item_coloc_num, item_coloc_x, item_coloc_y);
            if (item_coloc_num) textout(screen, font, msg, 20, 150, 3);

            textout(screen, font, "| num |type       ", 0, 16, 246);
            textout(screen, font, "|  of |description", 0, 24, 246);
            textout(screen, font, " -----|-----------", 0, 32, 246);

            for (c=0; c<10; c++)    /* print menu choices  */
               {
                  d=198;  /* <----------------default color */
                  if (menu == c) d=246; /* <-----other color if selected */
                  sprintf(msg,"%d",item_num_of_type[c]);
                  textout(screen, font, msg, 10, 40+(c*10),d);
                  sprintf(msg,"%s",item_desc[c][0] );
                  textout(screen, font, msg, 40, 40+(c*10),d);
               }  /* new line */
            if ((mouse_x > 10) && (mouse_x < 120) & (mouse_y > 39) && (mouse_y < 140) )
               {    /* test for mouse click on the type menu (upper) */
                  if (mouse_b & 1) menu = (mouse_y-40) / 10; /* set the menu pointer only */
                  if (mouse_b & 2)
                     {
                        spgry = -1; /* exit on b2 */

                     }
               }
            if (key[KEY_DOWN])
                      {
                         menu++;
                         rest(150);
                      }
            if (key[KEY_UP])
                      {
                         menu--;
                         rest(150);
                      }
            if (menu > 9) menu = 9;
            if (menu < 0 ) menu = 0;
            show_mouse(screen);
            rest(5);
            show_mouse(NULL);
            spgry = (bottom_menu(1));   /* call the menu handler */
         } while (spgry != -1);
      rest(200);
      clear(screen);
   }  /* end of if (gry == 1) F2 NEW  */


