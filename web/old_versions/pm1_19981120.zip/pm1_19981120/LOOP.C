#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <allegro.h>

/* global variables  */
BITMAP *memory_bitmap[512];
BITMAP *level_2000, *scrn_buffer;
BITMAP *map100_bmp, *map100_bkg;
BITMAP *pm_title;
PALLETE pallete;
SAMPLE *snd[10];

char level_text[100][40];
int level_header[20];
int l[100][100];    /* level */
int item[500][16];  /* items */
int Ei[100][10];    /* enemies */
float Ef[100][10];  /* enemies */
int zz[20][64];
int passcount;

/* timer variables  */
volatile int msec_timer = 0;

/* new x move stuff */
float right_speed=0, left_speed=0;
float initial_x_speed =1.15, max_x_speed=3;
float p_xmove=0;
float accel=.06, de_accel=.3;
float jump_sinc=.05, fall_sinc = 0.1;
float pmovey = 5;

int joy_key = 1;
int joy_buttons = 1;
int joy_jump;
int joy_fire;
int joy_map;
int joy_menu;

int right_key = 38;
int left_key = 36;
int up_key = 23;
int down_key = 37;
int jump_key = 57;
int fire_key = 46;
int map_key = 15;
int menu_key = 41;

int jump;
int fire;
int speed;

int play_level;
int start_mode;
int next_level=0;
int next_entrance=0;
int resume_allowed=0;
int top_menu_sel = 2;
int dif = 2;
int p1_points = 0;
int level_time;
float LIFE;
int LIVES;

int start_level=1;
int WX, WY; /* the 16x10 window */
int sound_on=1;
int frame_speed = 20;
int fade_count = 16;

float PX, PY;
int PXint, PYint;

int num_bullets = 100; /* number of bullets player is carrying */
int bullet_active[50], bullet_x[50], bullet_y[50], bullet_xinc[50], bullet_yinc[50];
int bullet_wait_counter=0, request_bullet = 0;
int num_of_bullets = 30; /* number allowed on screen at one time */
int bullet_wait = 1, bullet_speed = 12;
int pm_bullet_collision_box = 8;

int e_bullet_active[50], e_bullet_shape[50];
int enemy_bullet_colision_window = 2;
float e_bullet_x[50], e_bullet_y[50], e_bullet_xinc[50], e_bullet_yinc[50];

int bomb[20][5];

float itemf[500][4];

int player_ride;
float mov_obf[20][4];
int mov_ob[20][20];
int mov_obi[20][20][4];

int player_carry=0;
int fire_held = 0;

int left_right=0;
float jump_count=0, fall_count=0;

int map_on=0;

int level_done = 0;
int game_exit = 0;
int num_enemy = 0;

int wx, wy;

/* counters and temp string  */
int a, b, c, d, e, f, x, y, EN, BN;
char msg[80];
char b_msg[80];
int bottom_msg=0;
int health_msg=0;

int map100_x = 220, map100_y = 20;
int map100_on=0, top_display_on = 1;
int top_display_x=60, top_display_y=0, top_display_color=240;
int bottom_display_y=186, bottom_display_color=240;

int map_solid_color = 240, map_semi_color = 176;
int map_break_color = 128, map_empty_color = 0;
int map_enemy_color=5 , map_bullet_color= 4;
int map_item_color=6, map_player_color = 1;


int level_num=1, sprit_num=1; /* used in ect and main */
/* char descriptions */

/* PDE STUFF  */
int PDEi[100][10];
float PDEf[100][10];
char PDEt[100][20][40];

char eftype_desc[10][10][40];   /* enemy.c */
char eitype_desc[10][10][40];   /* enemy.c */
char item_desc[20][5][40];
char buff[20];

int bmp_index = 255, zzindx = 3;  /* used by edit menu */
int b1_color = 3, bs_win = 0;

int item_num_of_type[20];   /* sort stuff used by others */
int item_first_num[20];
int item_coloc_num;
int item_coloc_x;
int item_coloc_y;

int get100_x, get100_y; /* used by edit functions */
int edit_int_retval;
float edit_float_retval;
float finitial, fxinc, fyinc, flv, fuv;



loop

