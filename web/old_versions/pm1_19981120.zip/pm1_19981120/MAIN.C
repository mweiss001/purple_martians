#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <allegro.h>

/* global variables  */
BITMAP *memory_bitmap[512];
BITMAP *level_2000, *scrn_buffer;
BITMAP *map100_bmp, *map100_bkg;
BITMAP *pm_title;
PALLETE pallete;
SAMPLE *snd[10];

char level_text[100][40];
int level_header[20];
int l[100][100];    /* level */
int item[500][16];  /* items */
int Ei[100][10];    /* enemies */
float Ef[100][10];  /* enemies */
int zz[20][64];
int passcount;

/* timer variables  */
volatile int msec_timer = 0;

/* new x move stuff */
float right_speed=0, left_speed=0;
float initial_x_speed =1.15, max_x_speed=3;
float p_xmove=0;
float accel=.06, de_accel=.3;
float jump_sinc=.05, fall_sinc = 0.1;
float pmovey = 5;

int joy_key = 1;
int joy_buttons = 1;
int joy_jump;
int joy_fire;
int joy_map;
int joy_menu;

int right_key = 38;
int left_key = 36;
int up_key = 23;
int down_key = 37;
int jump_key = 57;
int fire_key = 46;
int map_key = 15;
int menu_key = 41;

int jump;
int fire;
int speed;

int play_level;
int start_mode;
int next_level=0;
int next_entrance=0;
int resume_allowed=0;
int top_menu_sel = 2;
int dif = 2;
int level_time;
float LIFE;
int LIVES;

int start_level=1;
int WX, WY; /* the 16x10 window */
int sound_on=1;
int frame_speed = 20;
int fade_count = 16;

float PX, PY;
int PXint, PYint;
int num_bullets = 100;
int pbullet[50][6];
int bullet_wait_counter=0, request_bullet = 0;
int bullet_wait = 1, bullet_speed = 12;
int pm_bullet_collision_box = 8;

int e_bullet_active[50], e_bullet_shape[50];
int enemy_bullet_colision_window = 2;
float e_bullet_x[50], e_bullet_y[50], e_bullet_xinc[50], e_bullet_yinc[50];

int bomb[20][5];

float itemf[500][4];

int player_ride;
float mov_obf[20][4];
int mov_ob[20][20];
int mov_obi[20][20][4];

int player_carry=0;
int fire_held = 0;

int left_right=0;
float jump_count=0, fall_count=0;

int map_on=0;

int level_done = 0;
int game_exit = 0;
int num_enemy;

/* counters and temp string  */
int a, b, c, d, e, f, x, y;
char msg[80];
char b_msg[80];
int bottom_msg=0;

int map100_x = 220, map100_y = 20;
int map100_on=0, top_display_on = 1;
int top_display_x=60, top_display_y=0, top_display_color=240;
int bottom_display_y=186, bottom_display_color=240;

int map_solid_color = 240, map_semi_color = 176;
int map_break_color = 128, map_empty_color = 0;
int map_enemy_color=5 , map_bullet_color= 4;
int map_item_color=6, map_player_color = 1;


int level_num=1, sprit_num=1; /* used in ect and main */
/* char descriptions */

/* PDE STUFF  */
int PDEi[100][10];
float PDEf[100][10];
char PDEt[100][20][40];

char eftype_desc[10][10][40];   /* enemy.c */
char eitype_desc[10][10][40];   /* enemy.c */
char item_desc[20][5][40];
char buff[20];

int bmp_index = 255, zzindx = 3;  /* used by edit menu */
int b1_color = 3, bs_win = 0;

int item_num_of_type[20];   /* sort stuff used by others */
int item_first_num[20];
int item_coloc_num;
int item_coloc_x;
int item_coloc_y;

int get100_x, get100_y; /* used by edit functions */
int edit_int_retval;
float edit_float_retval;
float finitial, fxinc, fyinc, flv, fuv;

void inc_msec_timer()
{
   msec_timer++;
}
END_OF_FUNCTION(inc_msec_timer);


void get_new_background()
{
    WX = PX - 150; /* set window from PX,PY */
    WY = PY - 90;
    if (WX < 0) WX = 0;
    if (WX > 1679) WX = 1679;
    if (WY > 1799) WY = 1799;
    if (WY < 0) WY = 0;
    blit(level_2000, scrn_buffer, WX, WY, 0, 0, 320, 200);
}
void proc_controllers()
{
    jump=0;
    fire=0;
    if (key[fire_key]) fire = 1;
    else fire_held = 0;
    if (key[jump_key]) jump = 1;
    if (key[map_key]) map100_on = 200;
    if ((key[KEY_ESC]) || (key[menu_key]))
         {
            resume_allowed = 1;
            game_exit = 1;
         }
    if (joy_key) /* joystick control */
       {
          poll_joystick();
          if ((joy_b1) && (joy_fire == 1)) fire = 1;
          if ((joy_b2) && (joy_fire == 2)) fire = 1;
          if ((joy_b3) && (joy_fire == 3)) fire = 1;
          if ((joy_b4) && (joy_fire == 4)) fire = 1;

          if ((joy_b1) && (joy_jump == 1)) jump = 1;
          if ((joy_b2) && (joy_jump == 2)) jump = 1;
          if ((joy_b3) && (joy_jump == 3)) jump = 1;
          if ((joy_b4) && (joy_jump == 4)) jump = 1;

          if ((joy_b1) && (joy_map == 1)) map100_on = 200;
          if ((joy_b2) && (joy_map == 2)) map100_on = 200;
          if ((joy_b3) && (joy_map == 3)) map100_on = 200;
          if ((joy_b4) && (joy_map == 4)) map100_on = 200;

          if ((joy_b1) && (joy_menu == 1))
             {
                resume_allowed = 1;
                game_exit = 1;
             }
          if ((joy_b2) && (joy_menu == 2))
             {
                resume_allowed = 1;
                game_exit = 1;
             }
          if ((joy_b3) && (joy_menu == 3))
             {
                resume_allowed = 1;
                game_exit = 1;
             }
          if ((joy_b4) && (joy_menu == 4))
             {
                resume_allowed = 1;
                game_exit = 1;
             }
      }
}
player_move()
{
   /* X-MOVE  */
   if ((key[left_key]) || (joy_left))
      {
         left_right = 0;
         if (left_speed < initial_x_speed) left_speed = initial_x_speed;
         else
            {
               left_speed += accel;
               if (left_speed > max_x_speed) left_speed = max_x_speed;
            }
      }
   else
      {
         left_speed -= de_accel;
         if (left_speed < 0) left_speed = 0;
      }
   if ((key[right_key]) || (joy_right))
      {
         left_right = 1;
         if (right_speed < initial_x_speed) right_speed = initial_x_speed;
         else
            {
               right_speed += accel;
               if (right_speed > max_x_speed) right_speed = max_x_speed;
            }
      }
   else
      {
         right_speed -= de_accel;
         if (right_speed < 0) right_speed = 0;
      }
   p_xmove = right_speed - left_speed;
   PXint = PX + p_xmove;
   PYint = PY;

   /* check for player being pushed by lift */
   a = (is_left_solid(PXint,PYint));
   if ( a > 31 )
      {
         p_xmove += mov_obf[a-32][2] + left_speed;
         left_speed=0;
      }
   a = is_right_solid(PXint,PYint);
   if ( a > 31 )
      {
         p_xmove += mov_obf[a-32][2] - right_speed;
         right_speed = 0;
      }
   /* check if trying to move through wall */
   if ((p_xmove > 0) && (!is_right_solid(PXint+ (int) p_xmove,PYint)) )
            {
               PX += p_xmove;
               if (PX>1980) PX=1980;
               PXint = PX;
            }
   if ((p_xmove < 0) && (!is_left_solid(PXint+ (int) p_xmove,PYint)) )
            {
               PX += p_xmove;
               if (PX<0) PX=0;
               PXint = PX;
            }
   /* Y MOVEMENT   */
   /* check if in the middle of a jump */
   if (jump_count)
      {
         jump_count -= jump_sinc;
         if (jump_count < .1)
            {
               jump_count = 0;
               fall_count = 1.57;
            }
         else
            {
               if (!jump) jump_count -= (jump_sinc*4); /* jump released */
               if (is_up_solid(PXint,PYint))
                  {
                     jump_count = 0;
                     fall_count = 1.57;
                  }
               else PY -= (sin(jump_count) * pmovey);
            }
      }
   else   /* not jump  */
      {
         if (fall_count)
            {
               fall_count -= fall_sinc;
               if (fall_count < .1) fall_count = .1;
               PY += (sin(1.57 - fall_count) * pmovey);
               PYint = PY;
               a = is_down_solid(PXint,PYint);
               if (a == 1)
                  {
                     fall_count = 0;
                     PY -= fmod (PY, 20); /* align with floor */
                  }
               if (a > 31) /* on lift */
                  {
                     fall_count = 0;
                     player_ride = a; /* lift num */
                  }
            }
         else /* not jump or fall */
            {
               a = is_down_solid(PXint,PYint); /* on lift? */
               if (a > 31)  /* player is riding lift */
                  {
                     player_ride = a ; /* number of shape he's riding */
                     if (mov_obf[a-32][3] < 0) /* yinc (up) */
                        {
                           PYint = PY + mov_obf[a-32][3];
                           if (is_up_solid(PXint, PYint))  /* hit ceiling? */
                              {
                                 player_ride = 0;    /* fall off lift */
                                 fall_count = 1.57;
                                 PY += 5; /* set y so he falls*/
                              }
                        }
                     if (mov_obf[player_ride - 32][3] > 0) /* yinc (down)*/
                        {
                           PYint = PY + mov_obf[player_ride - 32][3];
                           if (is_down_solid_block_only(PXint, PYint))  /* floor below? */
                              {
                                 player_ride = 0;   /* off lift */
                                 fall_count = 1.57;
                                 PY -= 5; /* set y */
                              }
                        }
                  }
               if (a == 0)  /* start fall? */
                  {
                     player_ride = 0;
                     fall_count = 1.57;
                  }
               if ((a) && (jump)) /* check if jump pressed  */
                  {
                     player_ride = 0;
                     jump_count=1.57;
                  }
            }
      } /* end of else not jump and end of Y_MOVE */
}
draw_player()
{
   PXint = PX;
   PYint = PY;
   x = (PXint/4) % zz[4][9];
   if ((jump_count) || (fall_count)) x = 0;
   if ((player_ride) && (right_speed<.5) && (left_speed<.5)) x = 0;
   y = zz[x+5][9];

   if ((key[up_key]) || (joy_up))   y=418;
   if ((key[down_key]) || (joy_down)) y=419;
   if (left_right) draw_sprite(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
   else draw_sprite_h_flip(scrn_buffer, memory_bitmap[y], PXint-WX, PYint-WY);
   if (map100_on) putpixel(map100_bmp,(PXint+10)/20, PYint/20,map_player_color);
}
move_lifts()
{
   for (d=0; d<20; d++)
      if (mov_ob[d][0]) /* if active */
         {
            int next_mode = 0;
            mov_obf[d][0] += mov_obf[d][2]; /* xinc */
            mov_obf[d][1] += mov_obf[d][3]; /* yinc */
            if (d == player_ride-32)
               {
                  PXint = PX;
                  PYint = PY;
                  if ((mov_obf[d][2] > 0) && (!is_right_solid(PXint,PYint)) )
                     {
                        PX += mov_obf[d][2];
                        if (PX>1980) PX=1980;
                     }
                  if ((mov_obf[d][2] < 0) && (!is_left_solid(PXint,PYint)) )
                     {
                        PX += mov_obf[d][2];
                        if (PX<0) PX=0;
                     }
                  PY = mov_obf[d][1]-20; /* align with Y1 */
               }
            mov_ob[d][2] = mov_obf[d][0]; /* put as int in x1 */
            mov_ob[d][3] = mov_obf[d][1]; /* put as int in y1 */
            mov_ob[d][4] = mov_ob[d][2] + (mov_ob[d][10]*20)-1; /* width  */
            mov_ob[d][5] = mov_ob[d][3] + (mov_ob[d][11]*20)-1; /* height */
   
            /* limits */
            switch (mov_ob[d][9]) /* limit type */
               {
                  case 5: /* timer wait */
                          if (--mov_ob[d][8] < 0)
                          next_mode = 1;
                  break;
                  case 6: /* prox wait */
                     {
                        int bx1 = ((mov_ob[d][2]+ mov_ob[d][4])/2)- mov_ob[d][8];
                        int by1 = ((mov_ob[d][3]+ mov_ob[d][5])/2)- mov_ob[d][8];
                        int bx2 = ((mov_ob[d][2]+ mov_ob[d][4])/2)+ mov_ob[d][8];
                        int by2 = ((mov_ob[d][3]+ mov_ob[d][5])/2)+ mov_ob[d][8];
                        if ( (PX > bx1) && (PX < bx2) && (PY > by1) && (PY < by2) )
                           next_mode = 1;
                     }
                  break;
                  case 7: /* step count */
                          if (--mov_ob[d][8] < 0)
                          next_mode = 1;
                  break;
               }
            if (next_mode)
               {
                  int step = ++mov_ob[d][6];
                  next_mode = 0;
                  switch (mov_obi[d][step][3])
                     {
                        case 1: /* move */
                           {
                              float speed, angle, xlen, ylen, xinc, yinc;
                              speed = mov_obi[d][step][2];
                              speed /=10;
                              xlen = abs( mov_ob[d][2] - mov_obi[d][step][0] );
                              if (xlen == 0) xlen = .000001;
                              ylen = abs( mov_ob[d][3] - mov_obi[d][step][1] );
                              if (ylen == 0) ylen = .000001;
                              angle = atan(ylen/xlen);
                              xinc = cos(angle) * speed;
                              yinc = sin(angle) * speed;
                              if (xlen > ylen)
                                 mov_ob[d][8] = abs( xlen / xinc); /* distance/speed=time! */
                              if (xlen <= ylen)
                                 mov_ob[d][8] = abs( ylen / yinc); /* distance/speed=time! */
                              mov_ob[d][9] = 7; /* step countdown limit type 7 */
   
                              if (mov_ob[d][2] < mov_obi[d][step][0]) mov_obf[d][2] = +xinc;
                              if (mov_ob[d][2] == mov_obi[d][step][0]) mov_obf[d][2] = 0;
                              if (mov_ob[d][2] > mov_obi[d][step][0]) mov_obf[d][2] = -xinc;
   
                              if (mov_ob[d][3] < mov_obi[d][step][1]) mov_obf[d][3] = +yinc;
                              if (mov_ob[d][3] == mov_obi[d][step][1]) mov_obf[d][3] = 0;
                              if (mov_ob[d][3] > mov_obi[d][step][1]) mov_obf[d][3] = -yinc;
                           }
                        break;
                        case 2: /* wait time */
                           mov_ob[d][9] = 5; /* time is limit type 5 */
                           mov_ob[d][8] = mov_obi[d][step][2]; /* limit */
                           mov_obf[d][2] = 0; /* no xinc */
                           mov_obf[d][3] = 0; /* no yinc */
                        break;
   
   
                        case 3: /* wait prox */
                           mov_ob[d][9] = 6; /* wait prox is limit type 6 */
                           mov_ob[d][8] = mov_obi[d][step][2]; /* limit */
                           mov_obf[d][2] = 0; /* no xinc */
                           mov_obf[d][3] = 0; /* no yinc */
                 
   
                        break;
                        case 4: /* move to step 0 */
                           {
                              float speed, angle, xlen, ylen, xinc, yinc;
                              step = mov_ob[d][6] = 0; /* set step 0 */
                              speed = (float) mov_obi[d][step][2]/10;
   
                              xlen = abs( mov_ob[d][2] - mov_obi[d][step][0] );
                              if (xlen == 0) xlen = .000001;
                              ylen = abs( mov_ob[d][3] - mov_obi[d][step][1] );
                              if (ylen == 0) ylen = .000001;
                              angle = atan(ylen/xlen);
                              xinc = cos(angle) * speed;
                              yinc = sin(angle) * speed;
                              if (xlen > ylen)
                                 mov_ob[d][8] = abs( xlen / xinc); /* distance/speed=time! */
                              if (xlen <= ylen)
                                 mov_ob[d][8] = abs( ylen / yinc); /* distance/speed=time! */
                              mov_ob[d][9] = 7; /* step countdown limit type 7 */
   
                              if (mov_ob[d][2] < mov_obi[d][step][0]) mov_obf[d][2] = +xinc;
                              if (mov_ob[d][2] == mov_obi[d][step][0]) mov_obf[d][2] = 0;
                              if (mov_ob[d][2] > mov_obi[d][step][0]) mov_obf[d][2] = -xinc;
   
                              if (mov_ob[d][3] < mov_obi[d][step][1]) mov_obf[d][3] = +yinc;
                              if (mov_ob[d][3] == mov_obi[d][step][1]) mov_obf[d][3] = 0;
                              if (mov_ob[d][3] > mov_obi[d][step][1]) mov_obf[d][3] = -yinc;
                           }
                        break;
                     } /* end of switch case */
               }  /* end of if (next_mode)  */
         } /* end of if (active) */
}
draw_lifts()
{
   for (d=0; d<20; d++)
      if (mov_ob[d][0])
         {
            extern char level_text[100][40];
            int x1 = mov_ob[d][2];
            int x2 = mov_ob[d][4];
            int y1 = mov_ob[d][3];
            int y2 = mov_ob[d][5];
            int mode = mov_ob[d][6];
            int color = mov_ob[d][12];
            int text_line = mov_ob[d][13]-1;
            if (map100_on)
               {
                  if (y2-y1 > 20) rect(map100_bmp, x1/20, y1/20, x2/20, -1 + y2/20, mov_ob[d][12]);
                  else hline(map100_bmp, x1/20, y1/20, x2/20, mov_ob[d][12]); /* single line */
               }
            for (a=0; a<10; a++)
               rect(scrn_buffer, x1-WX+a, y1-WY+a, x2-WX-a, y2-WY-a, color + ((9 - a)*16) );
            rectfill(scrn_buffer, x1-WX+a, y1-WY+a, x2-WX-a, y2-WY-a, color );
            if (text_line) textout_centre(scrn_buffer, font, level_text[text_line], ((x1+x2)/2)-WX, ((y1+y2)/2)-WY-2, color+160);
            else
               {
                  sprintf(msg, "lift #%d", d);
                  textout_centre(scrn_buffer, font, msg, ((x1+x2)/2)-WX, ((y1+y2)/2)-WY-2, color+160);
               }
         }  /* end of draw lift */
}
enemy_draw_and_collision(void)
{
   int nec = 0;
   for (e = 0; e < 100; e++)
      if (Ei[e][0])  /* if enemy active */
         {
            int EXint = Ef[e][0];
            int EYint = Ef[e][1];
            nec++;
            for (c=0; c<50; c++)  /* check all bullets */
               if (pbullet[c][0]) /* if active */
                {
                  a = abs(pbullet[c][4]/2) + pm_bullet_collision_box; /* bullet stretch collision box size */
                  b = abs(pbullet[c][5]/2) + pm_bullet_collision_box;
                     if (abs(pbullet[c][2] - EXint) < a)
                        if (abs(pbullet[c][3] - EYint) < b)
                                {
                                    /* enemy dies from bullet wound */
                                    bottom_msg = 120;
                                    if (sound_on) play_sample( snd[4], 200, 127, 1000, 0);
                                    sprintf(b_msg, "enemy killed!...%d left", num_enemy-1);
                                    Ei[e][0] = 0; /* set to inactive */
                                    pbullet[c][0] = 0; /* bullet dies too */

                                 }
               }
            b = Ei[e][9]; /* collision box size */

            if (PXint > (EXint -b)) /* check for collision with player */
               if (PXint < (EXint +b))
                  if (PYint > (EYint -b))
                     if (PYint < (EYint +b))
                        {
                           /* player loses some LIFE */
                           bottom_msg = 10;
                           if (sound_on) play_sample( snd[2], 200, 127, 1000, 0);
                           sprintf(b_msg, "You got hit!");
                           LIFE -= Ef[e][4]*( (float) dif/4 );
                        }
              /* check for on screen */
              if (EXint > WX - 20)
                 if (EXint < WX + 320)
                    if (EYint > WY - 20)
                       if (EYint < WY + 200)
                          {
                             c = Ei[e][1]; /* bitmap set by enemy_move */
                             if (Ei[e][2] == 0) draw_sprite_h_flip(scrn_buffer, memory_bitmap[c], EXint-WX, EYint-WY);
                             if (Ei[e][2] == 1) draw_sprite(scrn_buffer, memory_bitmap[c], EXint-WX, EYint-WY);
                             if (Ei[e][2] == 2) draw_sprite_v_flip(scrn_buffer, memory_bitmap[c], EXint-WX, EYint-WY);
                             if (Ei[e][2] == 3) draw_sprite_vh_flip(scrn_buffer, memory_bitmap[c], EXint-WX, EYint-WY);

                             if ((Ei[e][2] > 10) && (Ei[e][2] < 500))
                                {
                                   fixed fixed_angle;
                                   fixed_angle = itofix(Ei[e][2] -10);
                                   rotate_sprite(scrn_buffer, memory_bitmap[c], EXint-WX, EYint-WY, fixed_angle);
                                }
                             if (Ei[e][2] > 999)
                                {
                                   fixed fixed_angle;
                                   fixed_angle = itofix(Ei[e][2] - 1000);
                                   clear(memory_bitmap[254]);
                                   draw_sprite_h_flip(memory_bitmap[254], memory_bitmap[c],0,0);
                                   rotate_sprite(scrn_buffer, memory_bitmap[254], EXint-WX, EYint-WY, fixed_angle);
                                }
                           }
              if (map100_on) putpixel(map100_bmp, (EXint/20), (EYint/20), map_enemy_color);
         } /* end of if active */
   num_enemy=nec; /* this function uses num_enemy so...*/
}
proc_pbullets()
{
   request_bullet=0;
   if ( (fire) && (!fire_held) && (!bullet_wait_counter)) /* fire button pressed */
      {
         if (num_bullets > 0)
            {
               request_bullet = 1;
               bullet_wait_counter = bullet_wait;
               fire_held=1;
            }
         else
            {
               bottom_msg = 120;
               sprintf(b_msg, "No bullets!");
            }
      }
   else if (--bullet_wait_counter < 0) bullet_wait_counter = 0;
   for (b = 0; b < 50; b++)
      {
         if (pbullet[b][0])  /* if bullet not active skip to next one */
            {
               pbullet[b][2] += pbullet[b][4];  /* xinc */
               pbullet[b][3] += pbullet[b][5];  /* yinc */
               if ((pbullet[b][2] < 0) || (pbullet[b][2] > 2000) || (pbullet[b][3]<0) || (pbullet[b][3] > 2000) )
                  pbullet[b][0];
               x = ( (pbullet[b][2] + 10) / 20);
               y = ( (pbullet[b][3] + 10) / 20);
               d = l[x][y];
               if ((d > 15) && (d < 256)) /* if hit solid or breakable */
                  {
                     pbullet[b][0] = 0;  /* bullet dies  */
                     if ((d > 23) && (d < 32)) /* breakable wall */
                        {
                           l[x][y] = 0; /* wall dies too */
                           blit(memory_bitmap[0], level_2000, 0, 0, (x*20), (y*20), 20, 20);
                           putpixel(map100_bkg, x, y, 0);
                        }
                  }
            draw_sprite(scrn_buffer, memory_bitmap[zz[0][4]], pbullet[b][2]-WX, pbullet[b][3]-WY);
            if (map100_on) putpixel(map100_bmp, pbullet[b][2]/20, pbullet[b][3]/20, map_bullet_color);
            }
         else if (request_bullet)
            {
                      /* setting initial...*/
                      if (sound_on) play_sample( snd[0], 200, 127, 1000, 0);
                      pbullet[b][0] = 1;
                      pbullet[b][2] = PXint;
                      pbullet[b][3] = PYint + 1;
                      pbullet[b][4] = 0; /* xinc */
                      pbullet[b][5] = 0; /* yinc */
                      num_bullets--;
                      if ((key[up_key]) || (joy_up))
                         {
                            pbullet[b][5] = -bullet_speed;
                            pbullet[b][2] = -5 + PXint + (left_right*10);
                         }
                      else if ((key[down_key]) || (joy_down))
                         {
                            pbullet[b][5] = bullet_speed;
                            pbullet[b][2] = -5 + PXint + (left_right*10);
                         }
                      else pbullet[b][4] = (left_right * (bullet_speed*2) ) - bullet_speed;
                      request_bullet = 0;
            }
      }
}
proc_ebullets()
{
   for (b = 0; b < 50; b++)
      if (e_bullet_active[b])  /* if bullet not active skip to next one */
         {
            int ex, ey;
            e_bullet_x[b] += e_bullet_xinc[b]; /* inc x */
            e_bullet_y[b] += e_bullet_yinc[b]; /* inc y */
            ex = e_bullet_x[b];
            ey = e_bullet_y[b];
            if ((ex<0) || (ex>2000) || (ey<0) || (ey>2000))
               e_bullet_active[b] = 0;
            x = (ex+10)/20;
            y = (ey+10)/20;
            d = l[x][y];
            if ((d > 15) && (d<256)) /* bullet hit solid or breakable wall */
               {
                  e_bullet_active[b] = 0;  /* bullet dies */
                  if ((d > 23) && (d < 32)) /* remove breakable wall */
                     {
                        l[x][y] = 0;
                        blit(memory_bitmap[0], level_2000, 0, 0, (x*20), (y*20), 20, 20);
                        putpixel(map100_bkg, x, y, 0);
                     }
               }
            if (e_bullet_shape[b] > 1000)
               {
                   d =  e_bullet_shape[b]-1000;
                   d = zz[0][d];
                   draw_sprite(scrn_buffer, memory_bitmap[d], ex-WX, ey-WY);

               }
            else draw_sprite(scrn_buffer, memory_bitmap[e_bullet_shape[b]], ex-WX, ey-WY);
            if (map100_on) putpixel(map100_bmp, (ex-5)/20, y, map_bullet_color);
            /* check for collision with player */
            if (ex > (PXint - enemy_bullet_colision_window ))
               if (ex < (PXint + enemy_bullet_colision_window ))
                  if (ey > (PYint - enemy_bullet_colision_window ))
                     if (ey < (PYint + enemy_bullet_colision_window ))
                              {
                                 /* player got hit ! */

                                 switch (e_bullet_shape[b])
                                    {
                                       /* arrow */
                                       case 488:  LIFE -= 5  * dif; break;
                                       case 489:  LIFE -= 5  * dif; break;
                                       /* ball */
                                       case 490:  LIFE -= 7 * dif; break;
                                       /* yellow things */
                                       case 1020:  LIFE -= 10 * dif; break;
                                    }
                                 if (sound_on) play_sample( snd[1], 200, 127, 1000, 0);
                                 sprintf(b_msg, "You got shot!");
                                 bottom_msg = 120;
                                 e_bullet_active[b] = 0;
                              }
         } /* end of if active */
}
proc_lit_rocket()
{
   for (c=0; c<500; c++)
      if (item[c][0] == 98) /* lit rocket! */
         {
            if (itemf[c][3] > -4) itemf[c][3] -=.06; /* accel */
            itemf[c][1] += itemf[c][3];
            x = itemf[c][0];
            y = itemf[c][1];
            if (c == (player_carry-1)) /* player is riding this rocket! */
               {
                  fall_count=0;
                  PY = itemf[c][1] + itemf[c][3];
                  if (PX >= itemf[c][0]) PX = itemf[c][0] + 14;
                  if (PX < itemf[c][0])  PX = itemf[c][0] - 14;
                  if (map100_on) putpixel(map100_bmp, x/20, y/20, 7);
                     {
                       int shape = 255;
                       a = item[c][1]; /* get shape */
                       if (a < 512) shape = a; /* bitmap */
                       if (a > 999) shape = zz[0][a-1000]; /* ans */
                       if (item[c][2] == 1) /* draw mode normal */
                           draw_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY);
                     }
               }
            if (is_up_solid_nosemi(x,y))  /* rocket done */
               {
                  for (d=0; d<20; d++)  /* make boom! */
                     if (!bomb[d][0])  /* find empty */
                        {
                           itemf[c][3] = -1; /* slow down lift */
                           bomb[d][0] = 32 + c; /* link to item */
                           bomb[d][1] = 5; /* total fuse wait */
                           bomb[d][2] = 1; /* seq fuse wait */
                           bomb[d][3] = item[c][7]; /* damage */
                           bomb[d][4] = 1; /* for blow up */
                           d = 20; /* end bomb loop */
                        }
                      else if (d == 19) item[c][0] = 0; /* erase if no space in the bomb array */
               }
         }
}
proc_player_carry()
{
   if (player_carry)  /* move with player */
      {
         int pc = player_carry-1;
         if (item[pc][0] != 98) /* not lit rocket */
            {
               itemf[pc][1] = PY - 2;
               if (!left_right) itemf[pc][0] = PX - 15;
               if (left_right) itemf[pc][0] = PX + 15;
               x = (int) itemf[pc][0];
               y = (int) itemf[pc][1];
               if (map100_on) putpixel(map100_bmp, x/20, y/20, 7);
               if (item[pc][0] != 99) /* not lit bomb */
                     {
                       int shape;
                       a = item[pc][1]; /* get shape */
                       if (a < 512) shape = a; /* bitmap */
                       if (a > 999) shape = zz[0][a-1000]; /* ans */
                       if (item[pc][2] == 1) /* draw mode normal */
                           draw_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY);
                     }
               }
         if (!fire) /* drop */
            {
               player_carry = 0;
               if (item[pc][0] != 98) /* not lit rocket */
                  {
                     x = itemf[pc][0];
                     y = itemf[pc][1];
                     itemf[pc][2] = 0;  /* xinc = 0 */
                     if (fall_count) itemf[pc][3] = (sin(1.57-fall_count) * pmovey);
                     if (jump_count) itemf[pc][3] = (sin(jump_count) * pmovey);
  
                     if ((key[up_key]) || (joy_up))
                        itemf[pc][3] = -6; /* throw up */
  
                     if (p_xmove > 0)
                        if (!is_right_solid(x,y))
                           itemf[pc][2] = p_xmove;
  
                     if (p_xmove < 0)
                        if (!is_left_solid(x,y))
                           itemf[pc][2] = p_xmove;
                  }
               else /* lit rocket */
                  {

                  }

            } /* end of if (!fire) */
      } /* end of if player carry */
}
proc_lit_bomb()
{
   for (d=0; d<20; d++)   /* lit bomb handler! */
      if (bomb[d][0])   /* bomb lit! */
         {
            if (--bomb[d][1] > 0)  /* dec the fuse count */
               {
                  e = bomb[d][1] / bomb[d][2]; /* shape # */
                  c = zz[16-e][25];
                  x = itemf[bomb[d][0]-32][0];
                  y = itemf[bomb[d][0]-32][1];
   
                  if (bomb[d][1] < (bomb[d][2] * 5)) /* start blow-up */
                     {
                        a = ((bomb[d][2] * 6) - bomb[d][1]); /* 50 - ticks */
                        a = 2 * a * bomb[d][3]; /* 2 times damage */
                        a = a / (bomb[d][2] * 5);  /* / 50 */
   
                        if (map100_on)
                           {
                              rect(map100_bmp, (x/20)-(a/40), (y/20)-(a/40),(x/20)+(a/40), (y/20)+(a/40),10);
                              stretch_sprite(map100_bmp, memory_bitmap[c], (x/20) - (a/40), (y/20) - (a/40), 1 + (a/20), 1 + (a/20) );
                           }
                        stretch_sprite(scrn_buffer, memory_bitmap[c], (x-WX) - (a/2), (y-WY) - (a/2), 20 + a, 20 +a );
                     }
                  else draw_sprite(scrn_buffer, memory_bitmap[c], x-WX, y-WY);
               }
            if (bomb[d][1] < (bomb[d][2] * 6)) /* fuse done !*/
               if (bomb[d][4])  /* first time only */
                  {
                     bomb[d][1] = 23;  /* speed up ans */
                     bomb[d][2] = 4;
                     bomb[d][4] = 0;
                  }
            if (bomb[d][1] < (bomb[d][2] * 3)) /* do the damage! */
               {
                  c = bomb[d][3];  /* damage window */
                  x = itemf[ bomb[d][0]-32 ][0];
                  y = itemf[ bomb[d][0]-32 ][1];
                  bottom_msg = 120;
                  sprintf(b_msg, "KA-BOOM!");
   
                  for (e=0;e<100;e++) /* enemies in damage window? */
                     if (Ei[e][0])
                        if (Ef[e][0] > ((x-c)) )
                           if (Ef[e][0] < ((x+c)) )
                              if (Ef[e][1] > ((y-c)) )
                                 if (Ef[e][1] < ((y+c)) )
                                    {
                                       Ei[e][0] = 0; /* dead! */
                                       bottom_msg = 100;
                                       sprintf(b_msg, "Enemy killed by bomb!");
                                    }
   
                  if (PX > (x-c)) /* is player in window?*/
                     if (PX < (x+c))
                        if (PY > (y-c))
                           if (PY < (y+c))
                              {
                                 LIFE -= 3;
                              }
                  c /= 20;  /* convert to (0-100)  */
                  x /= 20;
                  y /= 20;
   
                  for (e = (x-c); e < (x+c)+1; e++)    /* erase on the maps */
                     for (f = (y-c); f < (y+c)+1; f++)
                       if ((e>0) && (e<99) && (f>0) && (f<99)) /* if on screen */
                           if (l[e][f] != 23) /* if not bullet_proof */
                                 {
                                    l[e][f] = 0;
                                    putpixel(map100_bkg, e, f, 0);
                                    blit(memory_bitmap[0], level_2000, 0, 0, e*20, f*20, 20, 20);
                                 }
               } /* end of damage */
            if (bomb[d][1] < 1)  /* bomb done */
               {
                  item[ bomb[d][0]-32 ] [0] = 0;
                  bomb[d][0] = 0;  /* set to inactive */
               }
         } /* end of if lit bomb */
}
draw_items()
{
   for (c=0; c<500; c++) /* rem update items on scrn_buffer */
      if (item[c][0])   /* if not type 0  */
         {
            int shape = 255; /* default */
            x = (int) itemf[c][0];
            y = (int) itemf[c][1];
            if (map100_on) putpixel(map100_bmp, x/20, y/20, 7);
            if ((item[c][0] != 99) && ((player_carry-1) != c) )
               if ((x > WX-20) && (x < (WX + 320)) && (y > WY-20) && (y < (WY + 200)))
                  {
                    /* get shape */
                    a = item[c][1];
                    if (a < 512) shape = a; /* bitmap */
                    if (a > 999) shape = zz[0][a-1000]; /* ans */
                    /* do draw mode */
                    if (item[c][2] == 1) /* draw mode normal */
                        draw_sprite(scrn_buffer, memory_bitmap[shape], x-WX, y-WY);
                  }
          }
}
proc_item_move()
{
   for (c=0; c<500; c++)  /* item move */
      if ((item[c][0]) && (item[c][3])) /* active and not stationary */
         if (item[c][0] != 98) /* not lit rocket */
            if (c != (player_carry-1)) /* not carrying */
               {
                  itemf[c][0] += itemf[c][2];  /* xinc */
                  itemf[c][1] += itemf[c][3];  /* yinc */
                  x = (int) itemf[c][0];
                  y = (int) itemf[c][1];
                  if (itemf[c][2] > 0) itemf[c][2] -= .01; /* slow down x move */
                  if (itemf[c][2] < 0) itemf[c][2] += .01; /* slow down x move */
   
                  if (itemf[c][2] > 0) /* right */
                     if (is_right_solid(x,y)) /* check for block right */
                        itemf[c][2] = 0;  /* stop */
   
                  if (itemf[c][2] < 0) /* left */
                     if (is_left_solid(x,y)) /* check for block left */
                        itemf[c][2] = 0;  /* stop */
   
                  if (itemf[c][3] < 0) /* rising */
                    {
                       if (!is_up_solid(x,y)) itemf[c][3] += .1; /* de-accel */
                       else itemf[c][3] = 0; /* stop y move if hit ceiling */
                    }
                 if (itemf[c][3] > 0) /* falling */
                    {
                       if (!is_down_solid(x,y)) /* check for block below */
                          {
                             itemf[c][3] += .1;  /* accel */
                             if (itemf[c][3] > 3) itemf[c][3] = 3;  /* max accel */
                          }
                       else
                          {
                             if (itemf[c][2] > 0) itemf[c][2] -= .15; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .15; /* slow down x move if on ground */
   
                             itemf[c][1] = ((y/20)*20); /* align with ground */
   
                             itemf[c][3] = 0; /* stop y move if on ground */
                          }
                     }
                if (itemf[c][3] == 0) /* yinc steady */
                    {
                       a = is_down_solid(x,y); /* check for block below */
                       if (a==0)
                          {
                             itemf[c][3] += .1;  /* accel */
                             if (itemf[c][3] > 4) itemf[c][3] = 4;  /* max accel */
                          }
                       if (a==1)
                          {
                             itemf[c][3] = 0; /* stop y move if on ground */
                             if (itemf[c][2] > 0) itemf[c][2] -= .03; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .03; /* slow down x */
                          }
                       if (a > 31) /* item riding mov  */
                          {
                             itemf[c][0] += mov_obf[a-32][2] ; /* move with xinc */
                             itemf[c][1] = mov_obf[a-32][1] - 20; /* align with Y1 */
                             if (itemf[c][2] > 0) itemf[c][2] -= .03; /* slow down x move if on ground */
                             if (itemf[c][2] < 0) itemf[c][2] += .03; /* slow down x */
                          }
                     }
               }  /* end of if not carry */
}
proc_item_collison()
{
   for (x=0; x<500; x++) /* item collision with man */
      if (item[x][0])  /* is object active */
         if ((PX > itemf[x][0] - 16) && (PX < itemf[x][0] + 16))
            if ((PY > itemf[x][1] - 16) && (PY < itemf[x][1] + 16))
               {
                  if (item[x][3] == -1) /* try to pick up item */
                     if ((fire) && (!player_carry))  /* if not already carrying */
                        player_carry = x+1;
                  switch (item[x][0]) /* type */
                     {
                        case 1:  /* door */
                           PX = item[x][6] * 20;
                           PY = item[x][7] * 20;
                           left_speed=0;
                           right_speed=0;
                           jump_count=0;
                           fall_count=0;
                           bottom_msg = 120;
                           sprintf(b_msg, "Teleport Door!");

                           if (WX < 0) WX = 0;
                           if (WX > 1680) WX = 1680;
                           if (WY>1800) WY = 1800;
                           if (WY < 0) WY = 0;
                           fade_out(10);
                           blit(level_2000, scrn_buffer, WX, WY, 0, 0, 320, 200);
                           fade_in(pallete,10);
                        break;
                        case 2:
                           item[x][0] = 0;
                           if (sound_on) play_sample( snd[6], 200, 127, 1000, 0);
                                
                           if (item[x][7])
                              {
                                 LIFE += item[x][7];
                                 bottom_msg = 120;
                                 sprintf(b_msg, "BONUS! health + %d", item[x][7]);
                              }
                           if (item[x][8])
                              {
                                 num_bullets += item[x][8];
                                 bottom_msg = 120;
                                 sprintf(b_msg, "BONUS! bullets + %d", item[x][8]);
                              }
                           if (item[x][9])
                              {
                                 level_time += item[x][9] * 50;
                                 bottom_msg = 120;
                                 sprintf(b_msg, "BONUS! time + %d", item[x][9]);
                              }
                        break;
                        case 3: /* exit */
                            if ( (item[x][8]) && (num_enemy) )
                               {
                                    bottom_msg = 120;
                                    sprintf(b_msg, "%d enemies left!", num_enemy);
                               }
                            else level_done = 1;
                         break;
                         case 4:
                            item[x][0] = 0;
                            bottom_msg = 120;
                            sprintf(b_msg, "Locked block(s) removed!");

                            for (c = item[x][6]; c <= item[x][8]; c++)
                               for (y = item[x][7]; y <= item[x][9]; y++)
                                  {
                                     l[c][y] = 0;
                                     blit(memory_bitmap[0], level_2000, 0, 0, c*20, y*20, 20, 20);
                                     putpixel(map100_bkg, c, y, 0);
                                  }
                         break;
                         case 6: /* free man */
                            item[x][0] = 0;
                            LIVES++;
                            bottom_msg = 120;
                            sprintf(b_msg, "EXTRA LIFE!");
                            if (sound_on) play_sample( snd[5], 200, 127, 1000, 0);
                                
                            break;
                      

                         case 7:
                           bottom_msg = 120;
                           sprintf(b_msg, "You hit a mine! %d", x);
                           LIFE -= (float) item[x][8]/10;
                         break;
                         case 8: /* un-lit bomb */
                           item[x][0] = 99; /* lit bomb */
                           item[x][3] = -1; /* carry */
                           bottom_msg = 120;
                           sprintf(b_msg, "#%d BOMB with %d second fuse",item[x][7]/20, item[x][9]/10 );
                           for (d=0; d<20; d++)
                              if (!bomb[d][0])  /* find empty */
                                 {
                                    bomb[d][0] = 32 + x; /* link to item */
                                    bomb[d][1] = item[x][9] * zz[4][25]; /* total fuse wait */
                                    bomb[d][2] = item[x][9]; /* seq fuse wait */
                                    bomb[d][3] = item[x][7]; /* damage */
                                    bomb[d][4] = 1; /* for blow up */
                                    d = 20; /* end bomb loop */
                                 }
                               else if (d == 19) item[x][0] = 0; /* erase if no space in the bomb array */
                         break;
                         case 10: /* POP UP MESSAGE */
                           {
                              int ln1 = item[x][6]-1;
                              int ln2 = item[x][7]-1;
                              int text_color = item[x][8];
                              int frame_color = item[x][9];
                              int px, py, px2, py2;
                              int width = 1; /* default */
                              int border = 8;
                              int height;

                              height = 1 + abs(ln2-ln1); /* if zero height is one line */

                              for (y=ln1; y<= ln2; y++) /* find width */
                                 if (strlen(level_text[y]) > width)
                                    width = strlen(level_text[y]);
                              px = (320 - border - (width*8)) / 2;
                              py = 30;
                              px2 = px+(width*8)+(border*2);
                              py2 = py+(height*8)+(border*2);

                              rectfill(scrn_buffer, px,py,px2,py2,0); /* clear */
                              for (y=0; y<border; y++)
                                  {
                                     int color_offset = y*16;
                                     rect(scrn_buffer, px+y,py+y,px2-y,py2-y,frame_color+color_offset); /* frame */

                                  }
                              for (y=ln1; y<=ln2; y++)
                                  textout(scrn_buffer, font, level_text[y]
                                   ,1+border+px,1+border+py + ((y-ln1)*8), text_color); /* text line */
                           }
                           bottom_msg = 120;
                           sprintf(b_msg, "You hit a pop-up message");
                         break;
                         case 11: /* rocket */
                           bottom_msg = 120;
                           sprintf(b_msg, "Rocket!");

                           item[x][1] = 1026; /* new ans */
                           item[x][0] = 98; /* new type - lit rocket */

                         break;
             
                      } /* end of switch case */
               } /* end of if on screen */

}

void sound_setup()
{
     /* 0 - Player Shoots
               1 - Player gets shot
               2 - Player gets hit
               3 - Player dead
               4 - Enemy dead
               5 - Free Man
               6 - Bonus
               7
               8
               9                */
         
   if (install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL) == 0)
      {
         sound_on = 1;
         for (x=0; x<7; x++)
            {
               char fn[20] = "test0.wav";
               char *filename;
               fn[4] = 48+x;
               filename = fn;
               snd[x] = load_sample(filename);
            }
      }
   else
     {
        sound_on = 0;
        clear(screen);
        textout_centre(screen, font, "...Sound Card Not Found...", SCREEN_W/2, 174, 10);
        rest(2000);

     }

}
void set_dif(void)
{
                   extern char global_string[20][25][80]; /* menu.c */
               
                   switch (dif)
                     {
                      case 1:
                           sprintf(global_string[8][5], "DIFFICULTY: EASY");
                           pm_bullet_collision_box = 10;
                           enemy_bullet_colision_window = 4;
                      break;
                      case 2:
                           sprintf(global_string[8][5], "DIFFICULTY: NORMAL");
                           pm_bullet_collision_box = 7;
                           enemy_bullet_colision_window = 6;
                      break;
                      case 3:
                           sprintf(global_string[8][5], "DIFFICULTY: HARD");
                           pm_bullet_collision_box = 4;
                           enemy_bullet_colision_window = 8;
                      break;
                   
                     }
}
void set_speed(void)
{
                  extern char global_string[20][25][80]; /* menu.c */
                  switch (speed)
                  {
                     case 1:
                          sprintf(global_string[8][6],"SPEED:SLOW   ");
                          frame_speed = 30;
                     break;
                     case 2:
                          sprintf(global_string[8][6],"SPEED:NORMAL ");
                          frame_speed = 25;
                     break;
                     case 3:
                          sprintf(global_string[8][6],"SPEED:FAST   ");
                          frame_speed = 20;
                     break;
                     case 4:
                          sprintf(global_string[8][6],"SPEED:FASTER ");
                          frame_speed = 12;
                     break;
                     case 5:
                          sprintf(global_string[8][6],"SPEED:FASTEST");
                          frame_speed = 0;
                     break;
                  }
}


int get_joy_button(void)
{
   do {
         poll_joystick();
      } while ((joy_b1) || (joy_b2) || (joy_b3) || (joy_b4));
      rest(10);
 
   do {
         poll_joystick();
      } while ((!joy_b1) && (!joy_b2) && (!joy_b3) && (!joy_b4));
if (joy_b1) return 1;
if (joy_b2) return 2;
if (joy_b3) return 3;
if (joy_b4) return 4;
}



void press_any()
{
 textout_centre(screen, font, "...press any key to continue...", SCREEN_W/2, 174, 5);
 rest(200);
 clear_keybuf();
     if (joy_key) /* joystick control */
        {

           do {
                poll_joystick();
              } while ((joy_b1) || (joy_b2));  /* wait for release */
           do {
                poll_joystick();

              } while ((!joy_b1) && (!keypressed()) && (!joy_b2));  /* wait for press */
        }
     else readkey();
}


void draw_game_screen(int current_level)
{
   int c;
   int x = 80;
   int y = 70;
   int dc=11; /* done color */
   int nc=10; /* not done color */
   int cc=7; /* current color */

   fade_out(fade_count);

   show_mouse(NULL);
   clear(screen);
   for (c=0;c<16;c++)
      rect(screen, c,c, 319-c, 199-c, 10+(c*16) );
   efm();
   blit(memory_bitmap[8], screen, 0, 0, 30, 70, 20, 20);
   blit(memory_bitmap[8], screen, 0, 0, 270, 70, 20, 20);

   draw_sprite(screen, memory_bitmap[401], 28, 50);
   draw_sprite_h_flip(screen, memory_bitmap[401], 272, 50);

   switch (current_level)
   {

   case 1:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | <--- ", x, y+16, cc);
   textout(screen, font, "2|Armory     |      ", x, y+24, nc);
   textout(screen, font, "3|Hospital   |      ", x, y+32, nc);
   textout(screen, font, "4|Dungeon    |      ", x, y+40, nc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 2:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | <--- ", x, y+24, cc);
   textout(screen, font, "3|Hospital   |      ", x, y+32, nc);
   textout(screen, font, "4|Dungeon    |      ", x, y+40, nc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 3:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | done ", x, y+24, dc);
   textout(screen, font, "3|Hospital   | <--- ", x, y+32, cc);
   textout(screen, font, "4|Dungeon    |      ", x, y+40, nc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 4:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | done ", x, y+24, dc);
   textout(screen, font, "3|Hospital   | done ", x, y+32, dc);
   textout(screen, font, "4|Dungeon    | <--- ", x, y+40, cc);
   textout(screen, font, "5|Space Ship |      ", x, y+48, nc);
   break;
   case 5:
   textout(screen, font, "#|Level      |Status", x, y   , nc);
   textout(screen, font, "-+-----------+------", x, y+8 , nc);
   textout(screen, font, "1|Warehouse  | done ", x, y+16, dc);
   textout(screen, font, "2|Armory     | done ", x, y+24, dc);
   textout(screen, font, "3|Hospital   | done ", x, y+32, dc);
   textout(screen, font, "4|Dungeon    | done ", x, y+40, dc);
   textout(screen, font, "5|Space Ship | <--- ", x, y+48, cc);
   break;

 }
fade_in(pallete, fade_count);
press_any();

}
void frame_and_title(void)
{
   clear(screen);
   for (x=0;x<16;x++)
      rect(screen, x,x, 319-x, 199-x, 8+(x*16) );
   blit(pm_title, screen,0,0,20,20,280,20);
   blit(memory_bitmap[8], screen, 0, 0, 30, 70, 20, 20);
   blit(memory_bitmap[8], screen, 0, 0, 270, 70, 20, 20);

   draw_sprite(screen, memory_bitmap[401], 28, 50);
   draw_sprite_h_flip(screen, memory_bitmap[401], 272, 50);
}

void maps_and_background_fill()
{
   clear(map100_bmp);
   clear(map100_bkg);
   clear(scrn_buffer);

   for (c=0; c < 500; c++) /* set all of itemf[500][4] to 0 */
      for(y=0; y<4; y++)
         itemf[c][y] = 0;

   for (x=0; x<500; x++)
      if (item[x][0]) /* only if active set float x y */
      {
         itemf[x][0] = item[x][4];
         itemf[x][1] = item[x][5];

      }

   for (x = 0; x < 20; x++)
      for (y = 0; y < 5; y++)
         bomb[x][y] = 0;


   for (d=0; d<20; d++)
      if (mov_ob[d][0]) /* test to see if needed at all !! active */
         {
            mov_ob[d][2] = mov_obi[d][0][0];      /* set x1 from mode 0 */
            mov_ob[d][3] = mov_obi[d][0][1];      /* set y1 from mode 0 */
            mov_ob[d][4] = mov_ob[d][2] + mov_ob[d][10]; /* width */
            mov_ob[d][5] = mov_ob[d][3] - mov_ob[d][11]; /* height */

            mov_obf[d][0] = mov_obi[d][0][0]; /* set float x */
            mov_obf[d][1] = mov_obi[d][0][1]; /* set float y */
            mov_obf[d][2] = 0; /* set float xinc */
            mov_obf[d][3] = 0; /* set float yinc */

            mov_ob[d][6] = 0;  /* mode 0  */
            mov_ob[d][9] = 5;  /* type wait for time   */
            mov_ob[d][8] = 0;  /* 0 = no wait! immediate next mode  */
         }


   for (x=0; x<100; x++) /* fill maps and background */
      for (y=0; y<100; y++)
         {
            d=0;
            c = l[x][y];
            if (c<256) d = c;
            blit(memory_bitmap[d], level_2000, 0, 0, x*20, y*20, 20, 20);

            if ((c > 0  ) && (c < 8   )) d = map_empty_color;  /* empty */
            if ((c > 7  ) && (c < 16  )) d = map_semi_color;   /* semi-solid */
            if ((c > 15 ) && (c < 256 )) d = map_solid_color;  /* solid */
            if ((c > 23 ) && (c < 32  )) d = map_break_color;  /* breakable */
            putpixel(map100_bkg, x, y, d );
         }

   jump_count=0; fall_count=0;

   for (c = 0; c < 50; c++)
      {
         e_bullet_xinc[c] = 0;
         e_bullet_yinc[c] = 0;
         e_bullet_y[c] = 0;
         e_bullet_x[c] = 0;
         e_bullet_active[c] = 0;
         e_bullet_shape[c] = 0;
         pbullet[c][0] = 0;
         pbullet[c][1] = 0;
         pbullet[c][2] = 0;
         pbullet[c][3] = 0;
         pbullet[c][4] = 0;
         pbullet[c][5] = 0;
      }
}
void save_game()
{
FILE *filepntr;
float junkfloat = 23.3;
int junkint = 448;

   for (x=0; x<500; x++)
      if (item[x][0]) /* only if active set float x y */
      {
         item[x][4] = itemf[x][0];
         item[x][5] = itemf[x][1];

      }


   save_level(900);

   filepntr = fopen("save_g1","w");
   fprintf(filepntr,"%f\n",PX);
   fprintf(filepntr,"%f\n",PY);
   fprintf(filepntr,"%f\n",LIFE);
   fprintf(filepntr,"%f\n",junkfloat);    /* padded for the future */
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   fprintf(filepntr,"%f\n",junkfloat);
   
   fprintf(filepntr,"%d\n",LIVES);
   fprintf(filepntr,"%d\n",play_level);
   fprintf(filepntr,"%d\n",num_bullets);
   fprintf(filepntr,"%d\n",level_time);
   fprintf(filepntr,"%d\n",passcount);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   fprintf(filepntr,"%d\n",junkint);
   
   fclose(filepntr);
}
void load_game()
{
FILE *filepntr;
char buff[20];
int loop, ch, fexit, c, x, y;

   load_level(900,0);

   textout_centre(screen, font, "loading saved game...", SCREEN_W/2 , 176, 245);
   filepntr=fopen("save_g1","r");
      for (x=0; x<20; x++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
               {
                  buff[loop] = ch;
                  loop++;
                  ch = fgetc(filepntr);
               }
            buff[loop] = NULL;

            switch (x)
               {
                  case 0: PX = atof(buff); break;
                  case 1: PY = atof(buff); break;
                  case 2: LIFE = atof(buff); break;
              /*     case 3:  = atof(buff); break;
                     case 4:  = atof(buff); break;
                     case 5:  = atof(buff); break;
                     case 6:  = atof(buff); break;
                     case 7:  = atof(buff); break;
                     case 8:  = atof(buff); break;
                     case 9:  = atof(buff); break;  */

                  case 10: LIVES = atoi(buff); break;
                  case 11: play_level = atoi(buff); break;
                  case 12: num_bullets = atoi(buff); break;
                  case 13: level_time = atoi(buff); break;
                  case 14: passcount = atoi(buff); break;
              /*     case 15:  = atoi(buff); break;
                     case 16:  = atoi(buff); break;
                     case 17:  = atoi(buff); break;
                     case 18:  = atoi(buff); break;
                     case 19:  = atoi(buff); break;        */
               }
         }

   fclose(filepntr);

   for (x = 0; x < 20; x++)
      for (y = 0; y < 5; y++)
         bomb[x][y] = 0;

   for (c = 0; c < 50; c++)
      {
         e_bullet_xinc[c] = 0;
         e_bullet_yinc[c] = 0;
         e_bullet_y[c] = 0;
         e_bullet_x[c] = 0;
         e_bullet_active[c] = 0;
         e_bullet_shape[c] = 0;
         pbullet[c][0] = 0;
         pbullet[c][1] = 0;
         pbullet[c][2] = 0;
         pbullet[c][3] = 0;
         pbullet[c][4] = 0;
         pbullet[c][5] = 0;
      }
   level_done=0;
   bottom_msg=0;
   right_speed=0;
   left_speed=0;

}
void save_keys()
{
   FILE *filepntr;
   filepntr = fopen("keycfg.pm","w");

   fprintf(filepntr,"%d\n",up_key);
   fprintf(filepntr,"%d\n",down_key);
   fprintf(filepntr,"%d\n",left_key);
   fprintf(filepntr,"%d\n",right_key);
   fprintf(filepntr,"%d\n",jump_key);
   fprintf(filepntr,"%d\n",fire_key);
   fprintf(filepntr,"%d\n",map_key);
   fprintf(filepntr,"%d\n",menu_key);
   fprintf(filepntr,"%d\n",joy_key);
   fprintf(filepntr,"%d\n",joy_jump);
   fprintf(filepntr,"%d\n",joy_fire);
   fprintf(filepntr,"%d\n",joy_map);
   fprintf(filepntr,"%d\n",joy_menu);
   fprintf(filepntr,"%d\n",dif);
   fprintf(filepntr,"%d\n",speed);
   fprintf(filepntr,"%d\n",sound_on);

   fclose(filepntr);
}
void load_keys()
{
FILE *filepntr;
char buff[20];
int loop, ch, fexit, c, x, y;
   textout(screen, font, "loading keys...", 16, 184, 1);
   if ((exists("keycfg.pm")) == 0)
      {
         textout(screen, font, "can't find keycfg.pm", 16, 184, 1);
         rest(1000);
      }
   else
      {
         filepntr=fopen("keycfg.pm","r");
         for (x=0; x<16; x++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
                  {
                     buff[loop] = ch;
                     loop++;
                     ch = fgetc(filepntr);
                  }
               buff[loop] = NULL;
               switch (x)
                  {
                     case 0: up_key = atoi(buff); break;
                     case 1: down_key = atoi(buff); break;
                     case 2: left_key = atoi(buff); break;
                     case 3: right_key = atoi(buff); break;
                     case 4: jump_key = atoi(buff); break;
                     case 5: fire_key = atoi(buff); break;
                     case 6: map_key = atoi(buff); break;
                     case 7: menu_key = atoi(buff); break;
                     case 8: joy_key = atoi(buff); break;
                     case 9: joy_jump = atoi(buff); break;
                     case 10: joy_fire = atoi(buff); break;
                     case 11: joy_map = atoi(buff); break;
                     case 12: joy_menu = atoi(buff); break;
                     case 13: dif = atoi(buff); break;
                     case 14: speed = atoi(buff); break;
                     case 15: sound_on = atoi(buff); break;

                  }
            }
         fclose(filepntr);
         set_dif();
         set_speed();
      }
}
void system_values()
{
char msg[80];
int y;

clear(screen);
do
   {
      textout_centre(screen, font, "System Values", SCREEN_W/2, 0, 240);
      sprintf(msg, "%f initial x speed", initial_x_speed);
      textout(screen, font, msg, 5, 10, 240);
      sprintf(msg, "%f max x speed", max_x_speed);
      textout(screen, font, msg, 5, 18, 240);
      sprintf(msg, "%f accel", accel);
      textout(screen, font, msg, 5, 26, 240);
      sprintf(msg, "%f de_accel", de_accel);
      textout(screen, font, msg, 5, 34, 240);
      sprintf(msg, "%f jump_sinc", jump_sinc);
      textout(screen, font, msg, 5, 42, 240);
      sprintf(msg, "%f fall_sinc", fall_sinc);
      textout(screen, font, msg, 5, 50, 240);
      sprintf(msg, "%f pmovey", pmovey);
      textout(screen, font, msg, 5, 58, 240);

      sprintf(msg, "%d bullet_speed", bullet_speed);
      textout(screen, font, msg, 5, 106, 240);
      sprintf(msg, "%d frame_speed", frame_speed);
      textout(screen, font, msg, 5, 114, 240);
      sprintf(msg, "%d num_bullets", num_bullets);
      textout(screen, font, msg, 5, 122, 240);


      sprintf(msg, "%d bullet_wait", bullet_wait );
      textout(screen, font, msg, 5, 138, 240);
      sprintf(msg, "%d fade count", fade_count);
      textout(screen, font, msg, 5, 146, 240);
   
      show_mouse(screen);
      rest(5);
      show_mouse(NULL);

      if ((mouse_x < 30) && (mouse_b & 1))
         {
            y = (mouse_y-10) / 8;
            if ((y > -1) && (y < 18))
               {
                  if (y<10)
                     {
                        fxinc=.05; fyinc=.2; flv=0; fuv = 10;
                        if (y == 0)
                           {
                              finitial = initial_x_speed;
                              if (edit_float(5, (y * 8) + 10) ) initial_x_speed = edit_float_retval;
                           }
                        if (y == 1)
                           {
                              finitial = max_x_speed;
                              if (edit_float(5, (y * 8) + 10) ) max_x_speed = edit_float_retval;
                           }
                        if (y == 2)
                           {
                              fxinc=.005; fyinc=.02; flv=0; fuv = 1;
                              finitial = accel;
                              if (edit_float(5, (y * 8) + 10) ) accel = edit_float_retval;
                           }
                        if (y == 3)
                           {
                              fxinc=.005; fyinc=.02; flv=0; fuv = 1;
                              finitial = de_accel;
                              if (edit_float(5, (y * 8) + 10) ) de_accel = edit_float_retval;
                           }
                        if (y == 4)
                           {
                              fxinc=.005; fyinc=.02; flv=0; fuv = 1;
                              finitial = jump_sinc;
                              if (edit_float(5, (y * 8) + 10) ) jump_sinc = edit_float_retval;
                           }
                        if (y == 5)
                           {
                              fxinc=.01; fyinc=.1; flv=0; fuv = 100;
                              finitial = fall_sinc;
                              if (edit_float(5, (y * 8) + 10) ) fall_sinc = edit_float_retval;
                           }
                        if (y == 6)
                           {
                              fxinc=.01; fyinc=.1; flv=0; fuv = 100;
                              finitial = pmovey;
                              if (edit_float(5, (y * 8) + 10) ) pmovey = edit_float_retval;
                           }

                     }
                  if ((y > 11) && (y < 18))
                     switch (y)
                        {
                           case 12: if (edit_int(5, ((y * 8) + 10), bullet_speed, 1, 0, 20)) bullet_speed = edit_int_retval; break;
                           case 13: if (edit_int(5, ((y * 8) + 10), frame_speed, 1, 5, 130)) frame_speed = edit_int_retval; break;
                           case 14: if (edit_int(5, ((y * 8) + 10), num_bullets, 1, 20, 180)) num_bullets = edit_int_retval; break;
                           case 16: if (edit_int(5, ((y * 8) + 10), bullet_wait, 1, 1, 30)) bullet_wait = edit_int_retval; break;
                           case 17: if (edit_int(5, ((y * 8) + 10), fade_count, 1, 1, 99)) fade_count = edit_int_retval; break;
                        }
                }
         }

   } while ((!(mouse_b & 2)) && (!key[KEY_ESC]) );
}
efm()
{
      BITMAP *temp_title;
      temp_title = create_bitmap(140,8);
      clear(temp_title);
      textout_centre(temp_title, font, "Escape from Mars", 70,0,202);
      for (x=0; x<5; x++)
         for (y=0; y<5; y++)
            stretch_sprite(screen, temp_title, x+20, y+20,280,16);
      textout_centre(temp_title, font, "Escape from Mars",70,0,154);
      stretch_sprite(screen, temp_title, 21,21,280,16);
      stretch_sprite(screen, temp_title, 21,23,280,16);
      stretch_sprite(screen, temp_title, 23,21,280,16);
      stretch_sprite(screen, temp_title, 23,23,280,16);
      textout_centre(temp_title, font, "Escape from Mars",70,0,10);
      stretch_sprite(screen, temp_title, 22,22,280,16);
      destroy_bitmap(temp_title);
}
game_over()
{
      BITMAP *btemp;
      btemp = create_bitmap(72,8);
      clear(btemp);
      textout(btemp, font, "GAME OVER", 0, 0, 14);
      stretch_sprite(screen, btemp, 16,40,288,64);
      resume_allowed = 0;
      top_menu_sel = 2;
      game_exit = 1;
}
time_up()
{
      BITMAP *btemp;
      btemp = create_bitmap(64,8);
      clear(btemp);
      textout(btemp, font, "TIME UP!", 0, 0, 186);
      stretch_sprite(screen, btemp, 64,120,216,48);
      textout(btemp, font, "TIME UP!", 0, 0, 106);
      stretch_sprite(screen, btemp, 62,122,216,48);
      textout(btemp, font, "TIME UP!", 0, 0, 10);
      stretch_sprite(screen, btemp, 60,124,216,48);
      press_any();
}
you_died()
{
      BITMAP *btemp;
      btemp = create_bitmap(72,8);
      clear(btemp);
      textout(btemp, font, "YOU DIED!", 0, 0, 186);
      stretch_sprite(screen, btemp, 61,120,216,48);
      textout(btemp, font, "YOU DIED!", 0, 0, 106);
      stretch_sprite(screen, btemp, 59,122,216,48);
      textout(btemp, font, "YOU DIED!", 0, 0, 10);
      stretch_sprite(screen, btemp, 57,124,216,48);
      if (sound_on) play_sample( snd[3], 200, 127, 1000, 0);
                                           
      press_any();
}
lev_done()
{
      BITMAP *btemp;
      btemp = create_bitmap(40,8);

      clear(btemp);
      textout(btemp, font, "LEVEL", 0, 0, 187);
      stretch_sprite(screen, btemp, 74,28,180,64);
      textout(btemp, font, "LEVEL", 0, 0, 107);
      stretch_sprite(screen, btemp, 72,30,180,64);
      textout(btemp, font, "LEVEL", 0, 0, 11);
      stretch_sprite(screen, btemp, 70,32,180,64);

      clear(btemp);
      textout(btemp, font, "DONE!", 0, 0, 187);
      stretch_sprite(screen, btemp, 74,108,180,64);
      textout(btemp, font, "DONE!", 0, 0, 107);
      stretch_sprite(screen, btemp, 72,110,180,64);
      textout(btemp, font, "DONE!", 0, 0, 11);
      stretch_sprite(screen, btemp, 70,112,180,64);
       press_any();
}
int controller_setup(void)
{

   switch (alert3("Select Joystick Type", NULL, NULL,
		  "None", "Standard", "4-Button", 0, 0, 0))
      {
         case 1:
            return 0;
         break;
         case 2:
   	 joy_type = JOY_TYPE_STANDARD;
   	 if (initialise_joystick()) /* standard found! */
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, 100, 13);
                  rest(1500);
               }
            else return 1;
         break;
         case 3:
   	 joy_type = JOY_TYPE_4BUTTON;
            if (initialise_joystick()) /* found! */
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, 100, 13);
                  rest(1500);
               }
            else return 4;
         break;
      }

}
void final_wrapup(void)
{
int c;
   bad_load_exit: /* jumps here if bad load */
   for (c=0; c<256; c++)
      destroy_bitmap(memory_bitmap[c]);
   destroy_bitmap(map100_bmp);
   destroy_bitmap(map100_bkg);
   destroy_bitmap(level_2000);
   destroy_bitmap(scrn_buffer);
   for (c=0; c<10; c++)
      destroy_sample(snd[c]);

   allegro_exit();
}
int initial_setup(void)
{
int c, x, y;

   allegro_init();
   install_keyboard();
   install_timer();
   install_mouse();
   set_gfx_mode(GFX_VGA,320,200,0,0);
   clear(screen);
   rest(2000); /* because my screen takes a while to come up */
   menu_setup(); /* load a bunch of text */
   load_keys();
   set_dif();
   set_speed();

   if (joy_key == 1) joy_type = JOY_TYPE_STANDARD;
   if (joy_key == 4) joy_type = JOY_TYPE_4BUTTON;
   if (joy_key)
      if (initialise_joystick())
               {
                  textout_centre(screen, font, "Joystick Not Found",SCREEN_W/2, 100, 13);
                  joy_key=0;
                  rest(1500);
               }
   if (sound_on) sound_setup();
   /* timer stuff */
   LOCK_VARIABLE(msec_timer);
   LOCK_FUNCTION(inc_msec_timer);
   install_int(inc_msec_timer,1);


   for (x=0; x<20; x++)
      for (c=0; c<64; c++)   /* animation initial zeroing */
         zz[x][c] = 0;

   for (c=0; c < 100; c++) /* zero enemies */
      for (y=0; y < 10; y++)
         {
            Ef[c][y] = 0;
            Ei[c][y] = 0;
         }
   for (c=0; c<100; c++) /* set all of l[100][100] to 0 */
      for (y=0; y<100; y++)
         l[c][y]=0;

   for (c=0; c < 500; c++) /* set all of itemf[500][4] to 0 */
      for(y=0; y<4; y++)
         itemf[c][y] = 0;
   for (c=0; c < 500; c++) /* set all of item[500][16] to 0 */
      for (y=0; y < 16; y++)
         item[c][y]=0;

   for (c = 0; c < 20; c++)
      for (d = 0; d < 20; d++)
         mov_ob[c][d] = 0;

   for (c = 0; c < 20; c++)
      for (d = 0; d < 20; d++)
         for (y = 0; y < 4; y++)
            mov_obi[c][d][y] = 0;

   for (c=0; c<512; c++)
      {
         memory_bitmap[c] = create_bitmap(20,20);
         clear(memory_bitmap[c]);
      }
   level_2000 = create_bitmap(2000,2000);
   scrn_buffer = create_bitmap(320,200);
   map100_bkg = create_bitmap(100,100);
   map100_bmp = create_bitmap(100,100);

   pm_title = create_bitmap(280,20);
   clear(pm_title);
   {
      BITMAP *temp_title;
      temp_title = create_bitmap(140,8);
      clear(temp_title);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,200);
      for (x=0; x<5; x++)
         for (y=0; y<5; y++)
            stretch_sprite(pm_title, temp_title, x,y,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,136);
      stretch_sprite(pm_title, temp_title, 1,1,280,16);
      stretch_sprite(pm_title, temp_title, 1,3,280,16);
      stretch_sprite(pm_title, temp_title, 3,1,280,16);
      stretch_sprite(pm_title, temp_title, 3,3,280,16);
      textout_centre(temp_title, font, "Purple Martians!", 70,0,8);
      stretch_sprite(pm_title, temp_title, 2,2,280,16);
      destroy_bitmap(temp_title);
   }
  

   if (!load_sprit(1,1)) /* load sprit001 , with display */
      {
         textout_centre(screen, font, "Error loading sprit file...Exiting",SCREEN_W/2, 150, 2);
         rest(1000);
         return 0;
      }
   initialize_zz(); /* zero the pass counters in the animation seqs */
   return 1;
}

void pm_main() /* start of game! */
{
int fade_in_count = 2; /* for fade in */
int loop_time = 0;
text_mode(-1);  /* masked */
do /* start of game loop */
   {
      if (start_mode)
         {
            if (start_mode == 1)  /* load level */
               {
                  if (!load_level(play_level,1))
                     {
                        sprintf(msg, "Error loading level %d ", play_level);
                        textout_centre(screen, font, msg, SCREEN_W/2, 176, 1);
                        final_wrapup();
                        exit(1);
                     }

                  bottom_msg=0;
                  initialize_zz();
                  maps_and_background_fill();
               }
            if (start_mode == 2) /* resume after death */
               {
                  LIFE = 100;
                  right_speed = left_speed = 0;
                  jump_count = fall_count = 0;
               }
            draw_game_screen(play_level);
            for (c=0; c<500; c++)  /* get start and time */
               if (item[c][0] == 5)
                  {
                     PX = item[c][4];
                     PY = item[c][5];
                     level_time = item[c][8] * 50;
                     break;
                  }
            player_carry = 0;
            player_ride = 0;
                  
            level_done = 0;
            fade_out(fade_count);
            fade_in_count = 4;
            start_mode = 0;
         }
      /*  true game loop starts here !!!!  above is only one decision */

      /* frame speed delay */
      while ((msec_timer-loop_time) < frame_speed);
      loop_time = msec_timer;

      /* level_time dec and check */
      level_time -= 1;

      if (--bottom_msg > 0) textout_centre(scrn_buffer, font, b_msg, SCREEN_W/2, bottom_display_y, bottom_display_color);

      if (top_display_on)
         {
            sprintf(msg,"Level:%-3d",play_level) ;
            textout(scrn_buffer, font, msg, top_display_x + 2, top_display_y + 2, top_display_color);
            sprintf(msg,"Lives:%-1d",LIVES) ;
            textout(scrn_buffer, font, msg, top_display_x + 2, top_display_y + 11, top_display_color);
            sprintf(msg,"Health") ;
            textout(scrn_buffer, font, msg, top_display_x + 67, top_display_y + 2, top_display_color);
            rectfill (scrn_buffer, top_display_x+65, top_display_y + 10, top_display_x + 115, top_display_y +17, 1); /*  red   */
            rectfill (scrn_buffer, top_display_x+65, top_display_y + 10, top_display_x + 65+(LIFE/2), top_display_y +17, 2); /*  green */

            sprintf(msg,"Time:%-3d",level_time/50);
            textout(scrn_buffer, font, msg, top_display_x + 124, top_display_y + 2, top_display_color);
            sprintf(msg,"Shot:%-3d",num_bullets);
            textout(scrn_buffer, font, msg, top_display_x + 124, top_display_y + 11, top_display_color);
         }

      if (map100_on)
         {
            if ( (PX-WX) < 100 ) map100_x = 220;
            if ( (PX-WX) > 220 ) map100_x = 0;
            if (--map100_on < 0) map100_on = 0;

            draw_sprite(scrn_buffer, map100_bmp, map100_x, map100_y);
            blit(map100_bkg, map100_bmp, 0,0,0,0,100,100);
         }

      blit(scrn_buffer, screen, 0,0,0,0, 320,200); /* screen buffer to screen */
      if (fade_in_count) if (--fade_in_count == 0) fade_in(pallete,fade_count);

      move_lifts();
      proc_controllers();
      player_move();
      get_new_background();
      update_animation();

      draw_items();
      draw_player();
      draw_lifts();

      proc_ebullets();
      proc_pbullets();

      enemy_move();
      enemy_draw_and_collision();

      proc_lit_rocket();

      proc_player_carry();

      proc_item_collison();

      proc_item_move();

      proc_lit_bomb();

      if (LIFE>100) LIFE = 100;

      if (level_time < 40)
         {
           if (--LIVES < 0) game_over();
           time_up();
           start_mode = 2;
         }
      if (LIFE < 0)
         {
            if (--LIVES < 0) game_over();
            you_died();
            start_mode = 2;
         }

      if (level_done)
         {
            lev_done();
            bottom_msg=0;
            play_level++;
            start_mode = 1;
         }

    } while (!game_exit); /*  */
text_mode(0);  /* normal */
clear_keybuf();
}

main()  /* look how small it is! */
{
if (initial_setup())
   {

      do
         {
            frame_and_title();
            if (resume_allowed) top_menu_sel = 3;
            top_menu_sel = zmenu(7, top_menu_sel, 50);
            if (top_menu_sel == 2)
               {
                  textout_centre(screen, font, "GET READY!",SCREEN_W/2, 160, 241);
                  level_done = 0;
                  play_level = start_level;
                  num_bullets = 200;
                  LIVES = 5;
                  LIFE = 100;
                  start_mode = 1; /* load start */
                  game_exit = 0;
                  pm_main();
               }
            if ((top_menu_sel == 3) && (resume_allowed))
               {
                  start_mode = 0;  /* resume */
                  game_exit = 0;
                  pm_main();
               }
            if (top_menu_sel == 4) /* load game */
               {
                  load_game();
                  maps_and_background_fill();
                  start_mode = 0;
                  game_exit = 0;
                  pm_main();
               }
            if ((top_menu_sel == 5) && (resume_allowed)) save_game();
            if (top_menu_sel == 7) help(0); /* help */
            if (top_menu_sel == 6) /* OPTIONS MENU */
               {
                  int options_menu_sel = 2;
                  do
                     {
                        frame_and_title();
                        options_menu_sel = zmenu(8,options_menu_sel,50);
                        if (options_menu_sel == 3)
                           {
                              clear(screen);
                              clear_keybuf();
                              rest(100);
                              textout_centre(screen, font, "Keyboard Configuration", SCREEN_W/2, 40, 245);

                              textout(screen, font, "Press the new key for 'up'", 10, 60, 245);
                              up_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'down'", 10, 70, 245);
                              down_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'left'", 10, 80, 245);
                              left_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'right'", 10, 90, 245);
                              right_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'jump'", 10, 100, 245);
                              jump_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'fire'", 10, 110, 245);
                              fire_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'map'", 10, 120, 245);
                              map_key = readkey() >> 8;
                              textout(screen, font, "Press the new key for 'menu'", 10, 130, 245);
                              menu_key = readkey() >> 8;
                            joy_key = 0;
                              save_keys();
                              clear(screen);

                           }
                          if (options_menu_sel == 4)
                           {
                              clear(screen);
                              clear_keybuf();
                              rest(500);

                          text_mode(0);

                          joy_key = controller_setup();
                          rest(500);

                          text_mode(0);

                       if (joy_key == 1) /* standard */
                          {
                              joy_key = 1; /* enable joystick control for the game */

                              textout_centre(screen, font, "Joystick Calibration", SCREEN_W/2, 40, 245);
                              textout_centre(screen, font, "Centre the joystick", SCREEN_W/2, SCREEN_H/2-8, 15);
                              textout_centre(screen, font, "and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);

                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((!joy_b1) && (!joy_b2));


                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((joy_b1) || (joy_b2));
                           
                              clear(screen);
                              textout_centre(screen, font, "Move the joystick to the top", SCREEN_W/2, SCREEN_H/2-8, 15);
                              textout_centre(screen, font, "left corner and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);
                           
                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((!joy_b1) && (!joy_b2));

                              calibrate_joystick_tl();
                           
                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((joy_b1) || (joy_b2));
                           
                              clear(screen);
                              textout_centre(screen, font, "Move the joystick to the bottom", SCREEN_W/2, SCREEN_H/2-8, 15);
                              textout_centre(screen, font, "right corner and press a button", SCREEN_W/2, SCREEN_H/2+8, 15);
                           
                              rest(10);
                              do {
                                 poll_joystick();
                              } while ((!joy_b1) && (!joy_b2));
                           
                              calibrate_joystick_br();

                              joy_menu = 0;
                              joy_map = 0;

                         }  /* end of standard only */


                      if (joy_key) /* standard and 4 button */
                         {
                              clear(screen);
                              textout(screen, font, "Press the button to jump", 10, 60, 245);
                              joy_jump = get_joy_button();
                              rest (500);
                              clear(screen);
                              textout(screen, font, "Press the button to shoot", 10, 60, 245);
                              joy_fire = get_joy_button();
                              rest (500);
                          }
                       if (joy_key == 4) /* 4 button only */
                          {
                              clear(screen);
                              textout(screen, font, "Press the map button", 10, 60, 245);
                              joy_map = get_joy_button();

                              rest (500);
                              clear(screen);
                              textout(screen, font, "Press the menu button", 10, 60, 245);
                              joy_menu = get_joy_button();

                              rest(500);
                          }
                     save_keys();
                     clear(screen);

                }
             if (options_menu_sel == 5) /* Difficulty  */
               {
                   if (++dif > 3) dif=1;
                   set_dif();
               }
            if (options_menu_sel == 6) /* Speed */
               {
                  if (++speed > 5) speed = 1;
                  set_speed();
               }
            if (options_menu_sel == 7) /* Sound */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  sound_on = (!sound_on);
                  if (sound_on) sound_setup();

                  if (sound_on) sprintf(global_string[8][7],"SOUND:ON ");
                  else sprintf(global_string[8][7],"SOUND:OFF");
               }


            if (options_menu_sel == 8) /* START LEVEL */
               {
                  extern char global_string[20][25][80]; /* menu.c */
                  int old_mouse;
                  int quit = 0;
                  while (key[KEY_ENTER]);
                  while (mouse_b&1);
                  while (joy_b1) poll_joystick(); /* wait for release */
                  while (!quit)
                     {

                        if (joy_key) poll_joystick();
                        /* make it red */
                        sprintf(msg, "(%d) ",start_level );
                        textout(screen, font, msg, 196,114, 241);
                        if ((key[KEY_UP]) || (key[up_key]) || (joy_up))
                           {
                              if (++start_level > 99) start_level=99;
                              while ((key[KEY_UP]) || (key[up_key]));
                              while (joy_up) poll_joystick(); /* wait for release */
                           }
                        if ((key[KEY_DOWN]) || (key[down_key]) || (joy_down))
                           {
                              if (--start_level < 1) start_level=1;
                              while ((key[KEY_DOWN]) || (key[down_key]));
                              while (joy_down) poll_joystick(); /* wait for release */
                           }
                        position_mouse(160,100);
                        old_mouse = mouse_y;
                        rest(10);
                        if (mouse_y > old_mouse) if (--start_level < 1) start_level=1;
                        if (mouse_y < old_mouse) if (++start_level > 99) start_level = 99;
                        if (mouse_y != old_mouse) rest(50);

                        if (key[KEY_ESC]) quit = 1;
                        if (key[KEY_ENTER]) quit = 1;
                        if ((mouse_b&1) || (mouse_b&2)) quit = 1;
                        if (joy_b1) quit = 1;
                      } /* end of while ! quit */

                      while ((key[KEY_ESC]) || (key[KEY_ENTER]));
                      while ((mouse_b&1) || (mouse_b&2));
                      while (joy_b1) poll_joystick(); /* wait for release */

                  sprintf(global_string[8][8], "START LEVEL (%d)",start_level);

               }


                        if (options_menu_sel == 9) /* Level Editor */
                           {
                              edit_menu();
                              rest(100);
                              clear(screen);
                           }
                        if (options_menu_sel == 10) /* System Values */
                           {
                              system_values();
                              rest(100);
                              clear(screen);
                           }

                     }  while (options_menu_sel != 2); /* end of options menu */
                  save_keys();
                  rest(100);
                  clear(screen);
               }
         }  while (top_menu_sel != 8); /* end of game menu */
   }
show_mouse(NULL);
textout_centre(screen, font, "Thanks for playing Purple Martians!", SCREEN_W/2,174,245);
rest(1000);
final_wrapup();
exit(0);
}

