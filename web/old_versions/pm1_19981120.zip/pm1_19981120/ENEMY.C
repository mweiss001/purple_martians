/* ENEMY STUFF  */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>

/* functions
   enemy_move()
   enemy-textdesc_setup()
   enemy_test()
   enemy_menu()
*/

void create_cloner(int EN)
{
extern int PDEi[100][10];
extern float PDEf[100][10];
extern float Ef[100][10];
extern int Ei[100][10];
extern int get100_x, get100_y;
extern int edit_int_retval;
char msg[80];
int d, x;
int redraw = 1;
int quit = 0;
int speed = 8;
int delay = 20;
int first_empty;

for (d=99; d>-1; d--) /* find empty enemy */
   if (Ei[d][0] == 0) first_empty = d;

while (!quit)  /* get speed and delay */
{
   if (redraw)
      {
         redraw = 0;
         clear(screen);
         textout_centre(screen, font, "CLONER CREATOR",SCREEN_W/2,20,240);
         textout_centre(screen, font, "--------------",SCREEN_W/2,28,240);
         
         textout(screen, font, "SPEED:", 20,40,240);
         sprintf(msg,"%d", speed);
         textout(screen,font,msg,76,40,11);
      
         textout(screen, font, "DELAY:", 20,50,240);
         sprintf(msg,"%d", delay);
         textout(screen,font,msg,76,50,11);
      
         textout(screen, font, "CONTINUE", 20,130,11);
         textout(screen, font, "ABORT", 20,150,11);
      }
   show_mouse(screen); rest(20); show_mouse(NULL);

   if ((mouse_b & 1) && (mouse_x > 20) && (mouse_x < 100) && (mouse_y > 20) && (mouse_y < 170))
      {
        redraw = 1;
        switch ((mouse_y-40)/10)
        {
              case 0: /* edit speed */
              if (edit_int(76, 40, speed,1,1,20)) speed=edit_int_retval; break;
              case 1: /* edit delay */
              if (edit_int(76, 50, delay,1,1,100)) delay=edit_int_retval; break;

              case 9: /* CONTINUE */ quit = 1; break;
              case 11: /* ABORT */  quit = -1; break;
        }
      }
} /* end of while (!quit) */

while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
if (quit == 1) quit = 0;
if (quit != -1)
   {
      clear(screen);
      textout(screen, font, "CLONER     ", 205,122,240);
      textout(screen, font, "-----------", 205,130,240);
      textout(screen, font, "mouse b1",    205,138,11);
      textout(screen, font, "SET INITIAL", 205,146,11);
      textout(screen, font, "mouse b2/esc",205,156,10);
      textout(screen, font, "ABORT",       205,164,10);
      while (!quit)
      {
          d = getxy100(999);
          if ((d == 2) || (d == 0)) quit = -1;
          if (d == 1)
             {
                Ef[first_empty][0] = get100_x * 20;  /* ans x,y */
                Ef[first_empty][1] = get100_y * 20;
                quit = 1;
             }

      }  /* end of while (!quit) */
   } /* end of if (quit != -1) */

while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
if (quit == 1) quit = 0;
if (quit != -1)
   {
      clear(screen);
      textout(screen, font, "CLONER     ", 205,122,240);
      textout(screen, font, "-----------", 205,130,240);
      textout(screen, font, "mouse b1",    205,138,11);
      textout(screen, font, "COPY BOX TL", 205,146,11);
      textout(screen, font, "mouse b2/esc",205,156,10);
      textout(screen, font, "ABORT",       205,164,10);
      while (!quit)
      {
          d = getxy100(999);
          if ((d == 2) || (d == 0)) quit = -1;
          if (d == 1)
             {
                Ef[first_empty][6] = get100_x * 20;  /* copy box x,y */
                Ef[first_empty][7] = get100_y * 20;
                quit = 1;
             }

      }  /* end of while (!quit) */
   } /* end of if (quit != -1) */


                          while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
if (quit == 1) quit = 0;
if (quit != -1)
   {
      clear(screen);
      textout(screen, font, "CLONER     ", 205,122,240);
      textout(screen, font, "-----------", 205,130,240);
      textout(screen, font, "mouse b1",    205,138,11);
      textout(screen, font, "COPY BOX BR", 205,146,11);
      textout(screen, font, "mouse b2/esc",205,156,10);
      textout(screen, font, "ABORT",       205,164,10);
      while (!quit)
      {
          d = getxy100(999);
          if ((d == 2) || (d == 0)) quit = -1;
          if (d == 1)
             {
                quit = 1;
                Ef[first_empty][2] = 20 + get100_x * 20 - Ef[first_empty][6];  /* set new x,y */
                Ef[first_empty][3] = 20 + get100_y * 20 - Ef[first_empty][7];
             }

      }  /* end of while (!quit) */
   } /* end of if (quit != -1) */



while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
if (quit == 1) quit = 0;
if (quit != -1)
   {
      clear(screen);
      textout(screen, font, "CLONER     " ,205,122,240);
      textout(screen, font, "-----------" ,205,130,240);
      textout(screen, font, "mouse b1"    ,205,138,11);
      textout(screen, font, "DEST BOX TL",205,146,11);
      textout(screen, font, "mouse b2/esc",205,156,10);
      textout(screen, font, "ABORT"       ,205,164,10);
      while (!quit)
         {
            d = getxy100(first_empty);
            if ((d == 2) || (d == 0)) quit = -1;
            if (d == 1)
               {
                  Ef[first_empty][8] = get100_x * 20;  /* dest x,y */
                  Ef[first_empty][9] = get100_y * 20;

                  Ei[first_empty][0] = 9;
                  Ei[first_empty][1] = 151;
                  Ei[first_empty][2] = 1;
                  Ei[first_empty][6] = delay*50;
                  Ei[first_empty][7] = delay*50;
                
                  quit = 1;
               }  /* end of if (d == 1) */
          }  /* end of while (!quit) */
   }  /* end of if (quit != -1) */
}
void create_pod(int EN)
{
extern int PDEi[100][10];
extern float PDEf[100][10];
extern float Ef[100][10];
extern int Ei[100][10];
extern int get100_x, get100_y;
extern int edit_int_retval;
char msg[80];
int d, x;
int redraw = 1;
int quit = 0;
int speed = 8;
int delay = 20;
int first_empty;

for (d=99; d>-1; d--) /* find empty enemy */
   if (Ei[d][0] == 0) first_empty = d;

while (!quit)  /* get speed and delay */
{
   if (redraw)
      {
         redraw = 0;
         clear(screen);
         textout_centre(screen, font, "POD CREATOR",SCREEN_W/2,20,240);
         textout_centre(screen, font, "-----------",SCREEN_W/2,28,240);
         
         textout(screen, font, "SPEED:", 20,40,240);
         sprintf(msg,"%d", speed);
         textout(screen,font,msg,76,40,11);
      
         textout(screen, font, "DELAY:", 20,50,240);
         sprintf(msg,"%d", delay);
         textout(screen,font,msg,76,50,11);
      
         textout(screen, font, "CONTINUE", 20,130,11);
         textout(screen, font, "ABORT", 20,150,11);
      }
   show_mouse(screen); rest(20); show_mouse(NULL);

   if ((mouse_b & 1) && (mouse_x > 20) && (mouse_x < 100) && (mouse_y > 20) && (mouse_y < 170))
      {
        redraw = 1;
        switch ((mouse_y-40)/10)
        {
              case 0: /* edit speed */
              if (edit_int(76, 40, speed,1,1,20)) speed=edit_int_retval; break;
              case 1: /* edit delay */
              if (edit_int(76, 50, delay,1,0,100)) delay=edit_int_retval; break;

              case 9: /* CONTINUE */ quit = 1; break;
              case 11: /* ABORT */  quit = -1; break;
        }
      }
} /* end of while (!quit) */
while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
if (quit == 1) quit = 0;
if (quit != -1)
   {
      clear(screen);
      textout(screen, font, "POD CREATOR", 205,122,240);
      textout(screen, font, "-----------", 205,130,240);
      textout(screen, font, "mouse b1",    205,138,11);
      textout(screen, font, "SET INITIAL", 205,146,11);
      textout(screen, font, "mouse b2/esc",205,156,10);
      textout(screen, font, "ABORT",       205,164,10);
      while (!quit)
      {
          d = getxy100(999);
          if ((d == 2) || (d == 0)) quit = -1;
          if (d == 1)
             {
                quit = 1;
                for (x=0; x<10; x++) /* put enemy  */
                   {
                      Ei[first_empty][x] = PDEi[EN][x];
                      Ef[first_empty][x] = PDEf[EN][x];
                   }
                Ei[first_empty][0] = 7;  /* type 7 */
                Ei[first_empty][4] = delay;
                Ef[first_empty][0] = get100_x * 20;  /* set new x,y */
                Ef[first_empty][1] = get100_y * 20;
             }

      }  /* end of while (!quit) */
   } /* end of if (quit != -1) */
while ((mouse_b & 1) || (mouse_b & 2)); /* wait for release */
if (quit == 1) quit = 0;
if (quit != -1)
   {
      clear(screen);
      textout(screen, font, "POD CREATOR" ,205,122,240);
      textout(screen, font, "-----------" ,205,130,240);
      textout(screen, font, "mouse b1"    ,205,138,11);
      textout(screen, font, "SET EXTENDED",205,146,11);
      textout(screen, font, "mouse b2/esc",205,156,10);
      textout(screen, font, "ABORT"       ,205,164,10);
      while (!quit)
         {
            d = getxy100(first_empty);
            if ((d == 2) || (d == 0)) quit = -1;
            if (d == 1)
               {
                  float angle, xlen, ylen, xinc, yinc;
                  int x1 = Ef[first_empty][0];
                  int y1 = Ef[first_empty][1];
                  int x2 = get100_x * 20;
                  int y2 = get100_y * 20;
                  quit = 1;

                  xlen = abs(x1-x2);
                  if (xlen == 0) xlen = .00001;
                  ylen = abs(y1-y2);
                  if (ylen == 0) ylen = .00001;
                  angle = atan(ylen/xlen);

                  xinc = cos(angle) * speed;
                  yinc = sin(angle) * speed;

                  /* set number of steps */
                  if (xlen > ylen)
                     {
                        Ei[first_empty][6] = xlen/xinc;
                     }
                  if (ylen >= xlen)
                     {
                        Ei[first_empty][6] = ylen/yinc;
                     }

                  /* set xinc, yinc */
                  if (x1 > x2) Ef[first_empty][2] = -xinc;
                  if (x1 == x2) Ef[first_empty][2] = 0;
                  if (x1 < x2) Ef[first_empty][2] = +xinc;
                  if (y1 > y2) Ef[first_empty][3] = -yinc;
                  if (y1 == y2) Ef[first_empty][3] = 0;
                  if (y1 < y2) Ef[first_empty][3] = +yinc;

               }  /* end of if (d == 1) */
          }  /* end of while (!quit) */
   }  /* end of if (quit != -1) */
}
void save_PDE()
{
   FILE *filepntr;
   extern char PDEt[100][20][40];
   extern int PDEi[100][10];
   extern float PDEf[100][10];
   char msg[80];
   int c, x;
   filepntr = fopen("PDE.XXX","w");
   for (c=0; c < 100; c++)  /* enemy float */
      for (x=0; x<10; x++)
         fprintf(filepntr,"%f\n",PDEf[c][x]);

   for (c=0; c < 100; c++) /* enemy int */
      for (x=0; x<10; x++)
         fprintf(filepntr,"%d\n",PDEi[c][x]);

   for (c=0; c < 100; c++) /* enemy text */
      for (x=0; x<20; x++)
         fprintf(filepntr,"%s\n",PDEt[c][x]);




      fclose(filepntr);
}

int load_PDE()
{
   FILE *filepntr;
   extern int PDEi[100][10];
   extern float PDEf[100][10];
   extern char PDEt[100][20][40];
   int PDE_load_error;
   int loop, ch, c, x, y;
   char buff[80], msg[80];

   textout_centre(screen, font, "loading PDE...", SCREEN_W/2, 176, 245);
   PDE_load_error = 0;
   if (!exists("PDE.XXX"))
      {
         textout(screen, font, "Can't find PDE.XXX", 0, 160, 1);
         PDE_load_error = 1;
      }
   if (!PDE_load_error) /* file exists */
      if ((filepntr=fopen("PDE.XXX","r")) == NULL)
         {
            textout(screen, font, "Error opening PDE.XXX", 0, 160, 1);
            PDE_load_error = 1;
         }
   if (!PDE_load_error) /* file exists and is open! */
      {
         for (c=0; c<100; c++) /* read PDE enemy floats */
            for (x=0; x<10; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        buff[loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  PDEf[c][x] = atof(buff);
                  if (ch == EOF)
                     {
                        textout(screen, font, "Error reading floats in PDE", 0, 176, 1);
                        rest(3000);
                        PDE_load_error = 1;
                     }
               }
         for (c=0; c < 100; c++)  /* enemy ints */
            for (x=0; x<10; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        buff[loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  buff[loop] = NULL;
                  PDEi[c][x] = atoi(buff);
                  if (ch == EOF)
                     {
                        textout(screen, font, "Error reading ints in PDE", 0, 176, 1);
                        rest(3000);
                        PDE_load_error = 1;
                     }
               }

         for (c=0; c < 100; c++)  /* enemy text */
            for (x=0; x<20; x++)
               {
                  loop = 0;
                  ch = fgetc(filepntr);
                  while((ch != '\n') && (ch != EOF))
                     {
                        PDEt[c][x][loop] = ch;
                        loop++;
                        ch = fgetc(filepntr);
                     }
                  PDEt[c][x][loop] = NULL;
                  if (ch == EOF)
                     {
                        sprintf(msg,"Error reading text at %d %d %d in PDE", loop, c, x);
                        textout(screen, font, msg, 0, 176, 10);
                        rest(3000);
                        PDE_load_error = 1;
                     }
               }
  



         fclose(filepntr);

         for (c=0; c < 100; c++) /* enemy text */
            for (x=0; x<20; x++)
               if (strlen(PDEt[c][x]) < 1)   strcpy(PDEt[c][x]," ");




      }
   if  (PDE_load_error)
      {
         rest(2000);
         return 0;
      }
   else return 1;
}
void predefined_enemies(void)
{
   extern int PDEi[100][10];
   extern float PDEf[100][10];
   extern char PDEt[100][20][40];
   extern BITMAP *memory_bitmap[512];
   extern int zz[20][64];
   extern float finitial, fxinc, fyinc, flv, fuv, edit_float_retval;
   extern int edit_int_retval;

   if (!exists("PDE.XXX"))  /* blank the data and save !*/
      {
         int c, x;
         for (c=0; c < 100; c++)  /* enemy float */
            for (x=0; x<10; x++)
               PDEf[c][x] = 0;
         for (c=0; c < 100; c++) /* enemy int */
            for (x=0; x<10; x++)
               PDEi[c][x] = 0;
      
         for (c=0; c < 100; c++) /* enemy text */
            for (x=0; x<20; x++)
               strcpy(PDEt[c][x],"---");
         save_PDE();
      }

if (load_PDE())
   {
      int x,y,z, EN = 0, redraw = 1, menu_sel;
      char msg[80], temp_string[80];
      clear_keybuf();

      do
         {
            show_mouse(screen);
            rest(10);
            show_mouse(NULL);
            menu_sel = (bottom_menu(5));   /* call the menu handler */

            if (redraw)
               {
                  int a,b=0;
                  int rt = PDEi[EN][0];
                  redraw = 0;
                  clear(screen);

                  a = PDEi[EN][1]; /* bmp or ans */
                  if (a < 512) b = a; /* bmp */
                  if (a > 999) b = zz[5][a-1000]; /* ans */

                  blit(memory_bitmap[b], screen, 0,0,0,0,20,20);

                  if (rt < 99)
                     {
                        sprintf(msg, "Predefined Enemy %d", EN);
                        textout(screen, font, msg, 40, 0, 240);
                        for (x=0; x<10; x++)
                           {
                              textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);
                              textout(screen, font, PDEt[EN][x+10], 0, 100+(x*8), 240);
                              sprintf(msg, "Ei%-1d %d", x, PDEi[EN][x]);
                              textout(screen, font, msg, 256, 20+(x*8), 240);
                              sprintf(msg, "Ef%-1d %f", x, PDEf[EN][x]);
                              textout(screen, font, msg, 256, 100+(x*8), 240);
                           }
                     }
                  if ((rt > 99) && (rt < 200))
                     {
                        sprintf(msg, "Predefined Object %d", EN);
                        textout(screen, font, msg, 40, 0, 240);
                        for (x=0; x<10; x++)
                           {
                              textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);
                              textout(screen, font, PDEt[EN][x+10], 0, 100+(x*8), 240);
                           }
                        for (x=0; x<10; x++)
                           {
                              sprintf(msg, "I%-2d %d", x, PDEi[EN][x]);
                              textout(screen, font, msg, 256, 20+(x*8), 240);
                           }
                     }
                  if (rt > 199)
                     {
                        sprintf(msg, "Creator %d", EN);
                        textout(screen, font, msg, 40, 0, 240);
                         for (x=0; x<10; x++)
                           {
                              textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);
                              textout(screen, font, PDEt[EN][x+10], 0, 100+(x*8), 240);
                           }
                     }
               }
            if ((mouse_b & 1) && (mouse_x < 240) && (mouse_y > 20) && (mouse_y < 180))
               {    /* edit text */
                  int k, tx = 0, ty = 0;
                  int line_length = 30;
                  ty = (mouse_y-20)/8;
                  tx = mouse_x/8;
                  redraw = 1;
                  do
                     {

                        show_mouse(screen);
                        rest(10);
                        show_mouse(NULL);
                         if (redraw)
                           for (x=0; x<20; x++)
                              {
                                 redraw = 0;
                                 textout(screen, font, "                               ", 0, 20+(x*8), 240); /* 31 spaces */
                                 textout(screen, font, PDEt[EN][x], 0, 20+(x*8), 240);
                              }
                        msg[0] = PDEt[EN][ty][tx];
                        if (msg[0] == NULL) msg[0] = 32;
                        msg[1] = NULL;
                        text_mode(1);
                        textout(screen, font, msg, (tx*8), 20+(ty*8), 240);
                        text_mode(0);

                        if (keypressed()) /* don't wait for keypress */
                           {
                              k = readkey();
                              redraw = 1;

                           }
                        else k = 0;
                 
                        k = (k & 0xFF);  /* strip upper bits */
                        if ((k>31) && (k<128))   /* if alphanumeric */
                           {
                              z = strlen(PDEt[EN][ty]);
                              if (z > line_length) z = line_length;
                              for (x=z; x>tx; x--)
                                 PDEt[EN][ty][x] = PDEt[EN][ty][x-1];

                              PDEt[EN][ty][tx] = k;
                              if (++tx > line_length) /* end of line? */
                                 {
                                    PDEt[EN][ty][tx] = NULL; /* terminate the line */
                                    ty++;  /* LF */
                                    tx = 0; /* CR */
                                 }
                           }
                        if (key[KEY_BACKSPACE])
                           {
                              if (--tx<0) tx = 0;
                              z = strlen(PDEt[EN][ty]);
                              for (x=tx; x<z; x++)
                                 PDEt[EN][ty][x] = PDEt[EN][ty][x+1];
                           }
                        if (key[KEY_ENTER])
                           {


                              for (y=19; y>ty; y--)  /* slide all down */
                                 {
                                    strcpy(PDEt[EN][y],PDEt[EN][y-1]);
                                 }
                              if (strlen(PDEt[EN][ty]) == 999) /* cursor past end of line */
                                 {
                                    PDEt[EN][ty+1][0] = NULL; /* next line empty */
                                 }
                              if (strlen(PDEt[EN][ty]) >= tx) /* cursor not past end of line */
                                 {
                                    for (x=0; x <= 30-tx; x++)         /* split line at tx */
                                        PDEt[EN][ty+1][x] = PDEt[EN][ty+1][tx+x];

                                    PDEt[EN][ty][tx] = NULL;  /* terminate top line */
                                    tx = 0;
                                    ty++;
                                 }


                           }
                        if (key[KEY_DEL])
                           {
                              if (PDEt[EN][ty][tx] == NULL)
                                 {

                                    for (x=0; x<=30-tx; x++) /* get portion from line below */
                                        PDEt[EN][ty][tx+x] = PDEt[EN][ty+1][x];

                                    for (y=ty+1; y<19; y++)  /* slide all up */
                                       strcpy(PDEt[EN][y],PDEt[EN][y+1]);

                                    PDEt[EN][19][0] = NULL; /* last line empty */

                                 }
                              else
                                 {
                                    z = strlen(PDEt[EN][ty]);
                                    for (x=tx; x<z; x++)
                                       PDEt[EN][ty][x] = PDEt[EN][ty][x+1];
                                 }
                           }
       
                        if (key[KEY_RIGHT])  if (++tx > line_length-1) tx = line_length-1;
                        if (key[KEY_LEFT]) if (--tx < 0) tx = 0;
                        if (key[KEY_UP]) if (--ty < 0) ty = 0;
                        if (key[KEY_DOWN]) if (++ty > 19) ty = 19;
                        if ((mouse_b & 1) && (mouse_x < 250) && (mouse_y > 20) && (mouse_y < 180))
                           {
                              redraw = 1;
                              ty = (mouse_y-20)/8;
                              tx = mouse_x/8;
                           }
                     
                        if (tx > strlen(PDEt[EN][ty])) tx = strlen(PDEt[EN][ty]);


                        clear_keybuf();
                     } while ((k != 27) && (!(mouse_b & 2)) );
                  clear_keybuf();
                  redraw = 1;

               }
            if (key[KEY_PGDN])
               {
                  EN -=10;
                  if (EN < 0) EN = 0;
                  clear_keybuf();

                  redraw =1;
               }

            if ((key[KEY_CONTROL]) && (key[KEY_DEL]))
               { /* DELETE PD */
                  for (x=0; x<10; x++)
                     {
                        PDEi[EN][x] = 0;
                        PDEf[EN][x] = 0;
                        strcpy(PDEt[EN][x]," ");
                        strcpy(PDEt[EN][x+10]," ");
                     }
                     redraw =1;
               }
            if ((key[KEY_CONTROL]) && (key[KEY_S]))
               { /* sort */
                  int swap_flag = 1;
                  int do_swap = 0;
                  int st1, st2;
                  redraw = 1;

                  while (swap_flag)
                     {
                        do_swap = 0;
                        swap_flag = 0;
                        for (x=0;x<99;x++)
                           {
                              while (key[KEY_P]);
                              if (key[KEY_Q])
                                 {
                                    swap_flag = 0;
                                    break;

                                 }
                              sprintf(msg, "x=%d sf=%d st1=%d st2=%d", x, swap_flag, st1, st2);
                              textout(screen, font, msg , 100, 120, 10);

                              if ( PDEi[x][0] > 199)   /* creator */
                                 if (strncmp(PDEt[x][1], PDEt[x+1][1], strlen(PDEt[x][1])) > 0)
                                       do_swap = 1; /* sort by text line 1 */

                              if ( PDEi[x][0] < 200) /* item and enemy  */
                                 {
                                    if ( PDEi[x][0] < PDEi[x+1][0] ) do_swap = 1;  /* sort by type */
                                    if ( PDEi[x][0] == PDEi[x+1][0] ) /* secondary sort by text line 1 */
                                       if (strncmp(PDEt[x][1], PDEt[x+1][1], strlen(PDEt[x][1]) ) > 0)
                                          do_swap = 1;
                                 }
                             if (do_swap) /* do the swap */
                                {
                                    swap_flag++; /* if any swaps */
                                    st1 = PDEi[x][0];
                                    st2 = PDEi[x+1][0];


                                    do_swap = 0;
                                    for (y=0; y<10; y++)
                                       {
                                          int temp;
                                          float ftemp;
                                          char stemp[80];

                                          temp = PDEi[x][y];
                                          PDEi[x][y] = PDEi[x+1][y];
                                          PDEi[x+1][y] = temp;

                                          ftemp = PDEf[x][y];
                                          PDEf[x][y] = PDEf[x+1][y];
                                          PDEf[x+1][y] = ftemp;

                                          strcpy(stemp,PDEt[x][y] );
                                          strcpy(PDEt[x][y],PDEt[x+1][y] );
                                          strcpy(PDEt[x+1][y], stemp);

                                          strcpy(stemp,PDEt[x][y+10] );
                                          strcpy(PDEt[x][y+10],PDEt[x+1][y+10] );
                                          strcpy(PDEt[x+1][y+10], stemp);

                                       }
                                 } /* end of swap */
                            } /* end of for x */
                     } /* end of while swap flag */
               }


           if (key[KEY_PGUP])
               {
                  EN +=10;
                  if (EN > 99) EN = 99;
                  clear_keybuf();

                  redraw =1;
               }
            if ((key[KEY_RIGHT]) || (menu_sel == 2))
               {
                  if (++EN > 99) EN = 99;
                  clear_keybuf();
                  while (mouse_b & 1); /* wait for release */
                  redraw =1;
               }
            if ((key[KEY_LEFT]) || (menu_sel == 3))
               {
                  if (--EN < 0) EN = 0;
                  clear_keybuf();
                  while (mouse_b & 1); /* wait for release */
                  redraw =1;
               }
            if (menu_sel == 4)  /* copy to new location */
               {
                  int new_EN = EN + 1;
                  int menu_exit = 0;
                  clear(screen);
                  while (!menu_exit)
                     {
                        show_mouse(screen);
                        rest(5);
                        show_mouse(NULL);

                        textout(screen, font, "COPY THIS PD TO A NEW PD ",100, 80, 242);
                        textout(screen, font, "WARNING! ERASES DESTINATION",100, 90, 242);
                        sprintf(msg, "SOURCE:PD#%d  ", EN);
                        textout(screen, font, msg    , 100, 110, 240);
                        sprintf(msg, "TARGET:PD#%d  ",new_EN);
                        textout(screen, font, msg    , 100, 120, 241);

                        textout(screen, font, "YES |  NO",100, 130, 242);

                        if ((mouse_b & 2) || (key[KEY_ESC]))
                           menu_exit=1;

                        if (mouse_b & 1)
                           {
                              if ((mouse_y > 129) && (mouse_y < 138) && (mouse_x < 134))
                                 {  /* yes pressed */
                                    for (x=0; x<10; x++)
                                       {
                                          PDEi[new_EN][x] = PDEi[EN][x];
                                          PDEf[new_EN][x] = PDEf[EN][x];
                                          strcpy(PDEt[new_EN][x],PDEt[EN][x] );
                                          strcpy(PDEt[new_EN][x+10],PDEt[EN][x+10] );
                                       }
                                    menu_exit=1;
                                    redraw =1;
                                 }
                              if ((mouse_y > 119) && (mouse_y < 128) && (mouse_x > 134))
                                 if (edit_int(180, 120, new_EN, 1, 0, 99)) new_EN = edit_int_retval;                                    redraw=1;
                           }
                     }
               }
            if (menu_sel == 6)
               {
                  help(17);
                  redraw =1;
               }
            if (menu_sel == 5)
               {
                  save_PDE();
                  clear_keybuf();
                  redraw =1;
               }
            if ((mouse_b & 1) && (mouse_x > 256) && (mouse_y > 20) && (mouse_y < 100))
               {  /* edit int */
                  y = (mouse_y-20)/8;
                  if (edit_int(288, 20+(y*8), PDEi[EN][y], 1, -1, 1063)) PDEi[EN][y] = edit_int_retval;
                  redraw=1;
               }
            if ((mouse_b & 1) && (mouse_x > 256) && (mouse_y > 100) && (mouse_y < 180))
               {  /* edit float */
                  redraw = 1;
                  fxinc=.01;   /* y inc */
                  fyinc=.1;   /* x inc */
                  flv=-2000;     /* lv    */
                  fuv=2000;   /* uv    */
                  y = (mouse_y-100)/8;
                  finitial = PDEf[EN][y];
                 if (edit_float(288, 100+(y*8))) PDEf[EN][y] = edit_float_retval;
               }
         if ((menu_sel == 1) && (PDEi[EN][0] > 99) && (PDEi[EN][0] < 200)) /* PUT ITEM */
            {
               extern int get100_x, get100_y;
               extern int item[500][16];
               int num_empty;
               int first_empty;
               int c=0, d, x;

               do
                  {
                     num_empty = 0;
                     item_sort();
                     for (d=499; d >= 0; d--)  /* find empty item */
                        if (item[d][0] == 0)
                              {
                                 first_empty = d;
                                 num_empty++;
                              }
                     if (num_empty < 1)
                        {
                           textout(screen, font, " item list full ", 20, 20, 1);
                           rest(2000);
                        }
                     clear(screen);
                     textout(screen, font, "PUT PD ITEM" ,205,122,240);
                     textout(screen, font, "-----------" ,205,130,240);
                     textout(screen, font, "mouse b1"    ,205,138,11);
                     textout(screen, font, "PUT ITEM"    ,205,146,11);
                     textout(screen, font, "mouse b2/esc",205,156,10);
                     textout(screen, font, "ABORT"       ,205,164,10);
                     sprintf(msg,"%d ITEM EMPTY", num_empty);
                     textout(screen, font, msg, 205,174, 12);
                     d = getxy100(first_empty);
                     if (d == 1)
                        {
                           for (x=0; x<10; x++) /* item */
                              item[first_empty][x] = PDEi[EN][x];
                           item[first_empty][0] -= 100;
                           item[first_empty][4] = get100_x * 20;
                           item[first_empty][5] = get100_y * 20;
                           item_sort();
                        }
                  } while ((d != 2) && (d != 0));
               redraw = 1;
               clear(screen);
            }
         if ((menu_sel == 1) && (PDEi[EN][0] > 199)) /* Creator */
            {
               switch (PDEi[EN][0]-199)
                  {
                     case 1: /* type 200 */
                     create_item(1); /* door creator */
                     break;
                     case 2: /* type 201 */
                     create_item(5); /* start */
                     break;
                     case 3: /* type 202 */
                     create_item(3); /* normal exit */
                     break;
                     case 4: /* type 203 */
                     create_item(4); /* key */
                     break;
                     case 5: /* type 204 */
                     create_pod(EN); /* pod creator */
                     break;
                     case 6: /* type 205 */
                     create_item(9); /* exit all dead */
                     break;
                     case 7: /* type 206 */
                     create_item(10); /* pop up message */
                     break;
                     case 8: /* type 207 */
                     create_cloner(EN); /* cloner */
                     break;

                  }
               redraw = 1;
               clear(screen);
            }
         if ((menu_sel == 1) && (PDEi[EN][0] < 99)) /* PUT ENEMY */
            {
               extern float Ef[100][10];
               extern int Ei[100][10];
               extern int get100_x, get100_y;
               int d, x;
               do
                  {
                     int num_empty = 0;
                     int first_empty;
                     for (d=0; d<100; d++) /* find empty and num of empty */
                        if (Ei[d][0] == 0)
                                 {
                                    num_empty++;
                                    if (num_empty == 1) first_empty = d;
                                 }
                   
                     clear(screen);

                     textout(screen, font, "PUT PD ENEMY" ,205,122,240);
                     textout(screen, font, "------------" ,205,130,240);
                     textout(screen, font, "mouse b1"    ,205,138,11);
                     textout(screen, font, "PUT ENEMY"    ,205,146,11);
                     textout(screen, font, "mouse b2/esc",205,156,10);
                     textout(screen, font, "ABORT"       ,205,164,10);
                     sprintf(msg,"%d ENEMY LEFT", num_empty);
                     textout(screen, font, msg, 210,174, 12);


                     d = getxy100(first_empty);
                     if (d == 1)
                        {
                           for (x=0; x<10; x++) /* put enemy  */
                              {
                                 Ei[first_empty][x] = PDEi[EN][x];
                                 Ef[first_empty][x] = PDEf[EN][x];
                              }
                           Ef[first_empty][0] = get100_x * 20;  /* set new x,y */
                           Ef[first_empty][1] = get100_y * 20;
                        }

                  } while ((d != 2) && (d != 0));
               redraw = 1;
               clear(screen);
            }
           if (menu_sel == 0) /* GET */
            {
               extern float Ef[100][10];
               extern int Ei[100][10];
               extern int get100_x, get100_y;
               int num_empty = 0, first_empty_PDE;
               int c, d, x;
                    for (x=0; x<100; x++) /* find empty and num of empty */
                       if (PDEi[x][0] == 0)
                          {
                             num_empty++;
                             if (num_empty == 1) first_empty_PDE = x;
                          }
                   
                     clear(screen);
                     textout(screen, font, "get PDFE...", 205,122, 240);
                     sprintf(msg,"%d left", num_empty);
                     textout(screen, font, msg, 210,110, 240);
                     textout(screen, font, "b1 - get", 210,118, 230);
                     textout(screen, font, "esc - abort", 210,126, 230);
                     d = getxy100(0);  /* what to pass here ? */
                     if (d == 1)
                        for (c=0;c<100; c++)  /* find which enemy is being pointed at */
                           if (Ef[c][0] > (get100_x * 20) - 10)
                              if (Ef[c][0] < (get100_x * 20) + 10)
                                 if (Ef[c][1] > (get100_y * 20) - 10)
                                    if (Ef[c][1] < (get100_y * 20) + 10)
                                       for (x=0; x<10; x++) /* copy enemy  */
                                          {
                                             PDEi[first_empty_PDE][x] = Ei[c][x];
                                             PDEf[first_empty_PDE][x] = Ef[c][x];
                                             PDEf[first_empty_PDE][0] = 0;
                                             PDEf[first_empty_PDE][1] = 0;
                                  
                                          }


               EN = first_empty_PDE;
               redraw = 1;
               while (mouse_b & 1); /* wait till released */
               clear(screen);
            }
    

         } while (!(key[KEY_ESC]) && (menu_sel != -1));

   } /* end of if load succesfull */

}



int get_rot_from_xyinc(int EN)
{
extern float Ef[100][10];
float angle, xlen, ylen;
int rot=0;


xlen = abs(Ef[EN][2]);
if (xlen == 0) xlen = .001; /* to prevent divide by zero */
ylen = abs(Ef[EN][3]);

angle = atan(ylen/xlen);
angle *= (64/1.57); /* convert from radians (0 to pi/2) to fixed (0 to 64) */


if (Ef[EN][2] <= 0)    /* xinc <= 0 */
    {
       if (Ef[EN][3] <= 0) rot += 64+angle;   /* yinc <= 0 */
       if (Ef[EN][3] >  0) rot += 64-angle;   /* yinc > 0 */
    }
if (Ef[EN][2] > 0)    /* xinc > 0 */
    {
       rot += 128;
       if (Ef[EN][3] >  0) rot += 64+angle;   /* yinc > 0 */
       if (Ef[EN][3] <= 0) rot += 64-angle;   /* yinc <= 0 */
    }
return rot;

}
void seek_set_xyinc(int EN, int EXint, int EYint)
{
extern float Ef[100][10];
extern int PXint, PYint;
float angle, xlen, ylen, xinc, yinc;

xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .001;
ylen = abs(PYint - EYint);

angle = atan(ylen/xlen);
xinc = cos(angle) * Ef[EN][8];  /* hypotenuse is the speed! */
yinc = sin(angle) * Ef[EN][8];

if (EXint < PXint) Ef[EN][2] = +xinc;
if (EXint > PXint) Ef[EN][2] = -xinc;
if (EYint < PYint) Ef[EN][3] = +yinc;
if (EYint > PYint) Ef[EN][3] = -yinc;
}

int get_rot_from_PXY(int EN, int EXint, int EYint)
{
extern float Ef[100][10];
extern int PXint, PYint;
float angle, xlen, ylen;
int rot=0;


xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .001; /* to prevent divide by zero */
ylen = abs(PYint - EYint);

angle = atan(ylen/xlen);
angle *= (64/1.57); /* convert from radians (0 to pi/2) to fixed (0 to 64) */

if (EXint >= PXint)
    {
       if (EYint >= PYint) rot += 64+angle;
       if (EYint <  PYint) rot += 64-angle;
    }
if (EXint < PXint)
    {
       rot += 128;
       if (EYint <= PYint) rot += 64+angle;
       if (EYint >  PYint) rot += 64-angle;
    }
return rot;
}
void fire_enemy_bulleta(int EN, int EXint, int EYint, int ans) /* animation */
{
extern int e_bullet_active[50];
extern int e_bullet_shape[50];
extern int zz[20][64];
extern float e_bullet_x[50];
extern float e_bullet_y[50];
extern float e_bullet_xinc[50];
extern float e_bullet_yinc[50];
extern float Ef[100][10];
extern int PXint, PYint;
float angle, xlen, ylen, xinc, yinc;
int z;


xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .00001;
ylen = abs(PYint - EYint);
if (ylen == 0) ylen = .00001;
angle = atan(ylen/xlen);
xinc = cos(angle) * Ef[EN][7];
yinc = sin(angle) * Ef[EN][7];

for (z=0; z<50; z++)  /* find empty e_bullet */
   if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_shape[z] = 1000+ans;
         e_bullet_x[z] = EXint;
         e_bullet_y[z] = EYint;
         if (EXint <  PXint) e_bullet_xinc[z] = +xinc;
         if (EXint >  PXint) e_bullet_xinc[z] = -xinc;
         if (EXint == PXint) e_bullet_xinc[z] = 0;
         if (EYint <  PYint) e_bullet_yinc[z] = +yinc;
         if (EYint >  PYint) e_bullet_yinc[z] = -yinc;
         if (EYint == PYint) e_bullet_yinc[z] = 0;
         z=50;
      }
}
void fire_enemy_bullet(int EN, int EXint, int EYint) /* cannon ball  */
{
extern int e_bullet_active[50];
extern int e_bullet_shape[50];
extern float e_bullet_x[50];
extern float e_bullet_y[50];
extern float e_bullet_xinc[50];
extern float e_bullet_yinc[50];
extern float Ef[100][10];
extern int PXint, PYint;
float angle, xlen, ylen, xinc, yinc;
int z;


xlen = abs(PXint - EXint);
if (xlen == 0) xlen = .001;
ylen = abs(PYint - EYint);
if (ylen == 0) ylen = .001;
angle = atan(ylen/xlen);
xinc = cos(angle) * Ef[EN][7];
yinc = sin(angle) * Ef[EN][7];

for (z=0; z<50; z++)  /* find empty e_bullet */
   if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_shape[z] = 490;
         e_bullet_x[z] = EXint;
         e_bullet_y[z] = EYint;
         if (EXint <  PXint) e_bullet_xinc[z] = +xinc;
         if (EXint >  PXint) e_bullet_xinc[z] = -xinc;
         if (EXint == PXint) e_bullet_xinc[z] = 0;
         if (EYint <  PYint) e_bullet_yinc[z] = +yinc;
         if (EYint >  PYint) e_bullet_yinc[z] = -yinc;
         if (EYint == PYint) e_bullet_yinc[z] = 0;
         z=50;
      }
}
void fire_enemy_x_bullet(int EN, int EXint, int EYint)
{
extern int e_bullet_active[50];
extern int e_bullet_shape[50];
extern float e_bullet_x[50];
extern float e_bullet_y[50];
extern float e_bullet_xinc[50];
extern float e_bullet_yinc[50];
extern float Ef[100][10];
extern int PXint, PYint;

int z;
int x_bullet_speed = abs(Ef[EN][2] * 3);  /* bullet speed fromx move */
if (x_bullet_speed < 5) x_bullet_speed =5; /* default if low x_move */
for (z=0; z<50; z++)  /* find empty e_bullet */
   if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_x[z] = EXint;
         e_bullet_y[z] = EYint;
         if (EXint < PXint)
            {
               e_bullet_xinc[z] = x_bullet_speed;
               e_bullet_shape[z] = 488;
            }
         if (EXint > PXint)
            {
               e_bullet_xinc[z] = -x_bullet_speed;
               e_bullet_shape[z] = 489;
            }
  

         e_bullet_yinc[z] = 0;
         z=50;
      }
}

void enemy_move()
{
/* extern int l[100][100];  */
extern int zz[20][64];
extern int Ei[100][10];
extern float Ef[100][10];
extern int passcount;


extern int PXint, PYint;
int EN, b, c, x, y;


   for (EN=0; EN<100; EN++)
      if (Ei[EN][0])  /* if enemy active */
         {
            int EXint = Ef[EN][0];
            int EYint = Ef[EN][1];
            switch (Ei[EN][0])
            {
               case 1:  /* enemy type 1
                           follows man with no regard
                           to walls or gravity
                           and no checks for out-of-bounds  */
                  if ((Ef[EN][0]) < PXint) (Ef[EN][0]) = (Ef[EN][0]) + Ef[EN][2];
                  if ((Ef[EN][0]) > PXint) (Ef[EN][0]) = (Ef[EN][0]) - Ef[EN][2];
                  if ((Ef[EN][1]) < PYint) (Ef[EN][1]) = (Ef[EN][1]) + Ef[EN][3];
                  if ((Ef[EN][1]) > PYint) (Ef[EN][1]) = (Ef[EN][1]) - Ef[EN][3];
               break;
               case 2: /* enemy type 2
                          follows man with regard
                          to walls , but no gravity
                          Ei[EN][0] = type 2
                          Ei[EN][1] = bitmap
                          Ei[EN][2] = draw type
                          Ei[EN][3] = ans
                          Ei[EN][4] = ans type
                          Ei[EN][5] =
                          Ei[EN][6] =
                          Ei[EN][7] =
                          Ei[EN][8] =
                          Ei[EN][9] = collision box size


                          Ef[EN][1] = x
                          Ef[EN][2] = y
                          Ef[EN][3] = xinc
                          Ef[EN][4] = yinc */

                  if (((Ef[EN][0]) < PXint) && (!is_right_solid(EXint, EYint)))
                     Ef[EN][0] += Ef[EN][2]; /* move right */
                  if (((Ef[EN][0]) > PXint) && (!is_left_solid(EXint, EYint)))
                     Ef[EN][0] -= Ef[EN][2]; /* move left */
                  if (((Ef[EN][1]) < PYint) && (!is_down_solid(EXint, EYint)))
                     Ef[EN][1] += Ef[EN][3]; /* move down */
                  if (((Ef[EN][1]) > PYint) && (!is_up_solid(EXint, EYint)))
                     Ef[EN][1] -= Ef[EN][3]; /* move up */

                     /* set the bitmap and drawing mode */

                          Ei[EN][2] == 0;  /* no flips */
                          b = Ei[EN][3];      /* ans */
                          c = zz[4][b];         /* num_of_shapes in seq */

                          if (Ei[EN][4] == 0) Ei[EN][1] = Ei[EN][3]; /* bmp, not ans */
                          if (Ei[EN][4] == 1) Ei[EN][1] = zz[0][b];    /* animate with time */
                          if (Ei[EN][4] == 2) /* animate with h move */
                             {
                                x = fmod(Ef[EN][0]/3, c);
                                Ei[EN][1] = zz[x+5][b];
                             }
                          if (Ei[EN][4] == 3) /* animate with v move */
                             {
                                x = fmod(Ef[EN][1]/3, c);
                                Ei[EN][1] = zz[x+5][b];
                             }
                          if (Ei[EN][4] == 4) /* animate with v and h move */
                             {
                                x = fmod(Ef[EN][1]/3, c) + fmod(Ef[EN][1]/3, c);
                                while (x > c) x-=c;
                                Ei[EN][1] = zz[x+5][b];
                             }

               break;
               case 3: /* enemy type 3
                          follows man with regard
                          to walls and gravity
                          Ei[EN][0] = type 3
                          Ei[EN][1] = bitmap
                          Ei[EN][2] = draw type
                          Ei[EN][3] = ans
                          Ei[EN][4] = ans type
                          Ei[EN][5] = bullet wait (0=none)
                          Ei[EN][6] = jump wait (0=none)
                          Ei[EN][7] = jump when player above
                          Ei[EN][8] = x mode follow(0) or bounce(1)
                          Ei[EN][9] = collision box size


                          Ef[EN][0] = x
                          Ef[EN][1] = y
                          Ef[EN][2] = xinc
                          Ef[EN][3] = yinc
                          Ef[EN][4] = LIFE decrement
                          Ef[EN][5] = bullet waitcount
                          Ef[EN][6] = bullet prox (0=none)
                          Ef[EN][7] = bullet prox delay
                          Ef[EN][8] = fall and fallcount
                          Ef[EN][9] = jump and jumpcount     */

                  /* bullet wait */
                  if ((Ei[EN][5] > 0) && ((passcount % Ei[EN][5]) == 1)) fire_enemy_x_bullet(EN, EXint, EYint);
                  /* bullet prox */
                  if (Ef[EN][6])
                     {
                        if (Ef[EN][5] > 0) /* if prox wait */
                           {
                              Ef[EN][5]--;   /* dec prox wait */
                              Ei[EN][3] = 3; /* empty wagon ans */
                           }
                        else
                           {
                              Ei[EN][3] = 2; /* arrow wagon ans */
                              if ((Ef[EN][1] > PYint - 5) && (Ef[EN][1] < PYint + 5))
                                 {

                                    if (Ei[EN][2]) /* move right */
                                       if ((EXint > PXint - Ef[EN][6]) && (EXint < PXint) )
                                          {
                                             fire_enemy_x_bullet(EN, EXint, EYint);
                                             Ef[EN][5] = Ef[EN][7]; /* set new prox wait */
                                          }
                                    if (!Ei[EN][2]) /* move left */
                                       if ((EXint > PXint) && (EXint < PXint + Ef[EN][6]))
                                          {
                                             fire_enemy_x_bullet(EN, EXint, EYint);
                                             Ef[EN][5] = Ef[EN][7]; /* set new prox wait */
                                          }
                                 }
                           }
                     }

                  if (!Ei[EN][8]) /* follow mode */
                     {
                        if (EXint < PXint)  /* try to move right */
                           {
                              Ei[EN][2] = 1; /* h_flip */
                              if (!is_right_solid(EXint, EYint))
                                 {
                                    Ef[EN][0] += Ef[EN][2];
                                    EXint = Ef[EN][0];
                                 }
                           }
      
                        if (EXint > PXint)  /* try to move left */
                           {
                              Ei[EN][2] = 0; /* no h_flip */
                              if (!is_left_solid(EXint, EYint))
                                 {
                                    Ef[EN][0] -= Ef[EN][2];
                                    EXint = Ef[EN][0];
                                 }
                           }
                     }
                  if (Ei[EN][8]) /* x bounce mode */
                     {
                        if ((Ef[EN][2]) > 0)  /* move right */
                           {
                             Ei[EN][2] = 1; /* h_flip to face right */
                             Ef[EN][0] += Ef[EN][2];
                             EXint=Ef[EN][0];
                             if (is_right_solid(EXint, EYint))
                                {

                                   Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                   Ef[EN][0] += Ef[EN][2]; /* take back last move */
                                   EXint=Ef[EN][0];
                                }
                           }
                        if ((Ef[EN][2]) < 0)  /* move left */
                           {
                              Ei[EN][2] = 0; /* no h_flip */
                              Ef[EN][0] += Ef[EN][2];
                              EXint=Ef[EN][0];
                              if (is_left_solid(EXint, EYint))
                                 {

                                    Ef[EN][2] =- Ef[EN][2]; /* bounce */
                                    Ef[EN][0] += Ef[EN][2]; /* take back last move */
                                    EXint=Ef[EN][0];
                                 }
                           }
                     }
                  if (Ef[EN][9])  /*jump*/
                     {
                        Ef[EN][9] -= .05;
                        if (Ef[EN][9] < .1)      /* top of jump */
                           {
                              Ef[EN][9] = 0;    /* jump done */
                              Ef[EN][8] = 1.6;   /* start fall */

                           }
                        else
                           {
                              Ef[EN][1] -= (sin(Ef[EN][9]) * Ef[EN][3]);
                              EYint=Ef[EN][1];
                              if (is_up_solid(EXint, EYint))
                                 {
                                    Ef[EN][9] = 0;   /* abort jump */
                                    Ef[EN][8] = 1.6;   /* start fall */
                                 }
                           }
                     }

                  else  /* not jump */
                     {
                        if (Ef[EN][8])   /* if fall = 1 */
                           {
                              Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                              if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                              Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                              if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                              EYint=Ef[EN][1];
                              if (is_down_solid(EXint, EYint))  /* look for end of fall */
                                 {
                                    Ef[EN][8] = 0; /*  fall=0;  */
                                    Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                    EYint=Ef[EN][1];
                                 }
                           }
                        if (!Ef[EN][8])  /* fall = 0 */
                           {
                              /* start fall? look for no block below */
                              if (!is_down_solid(EXint, EYint)) Ef[EN][8] = 1.6;

                              /* passcount jump */
                              if ((Ei[EN][7] > 0) && ((passcount % Ei[EN][7]) == 1)) Ef[EN][9] = 1.6; /* jump! */
                              /* jump when player passes over */
                              if ((Ei[EN][6] > 0) && (EXint < (PXint + 15)) && (EXint > (PXint - 15)) && (EXint > PYint)) Ef[EN][9] = 1.6;
                           } /* end of fall = 0  */
                     } /* end of else if not fall  */

                          /* set the bitmap and drawing mode */
                          b = Ei[EN][3];      /* ans */
                          c = zz[4][b];         /* num_of_shapes in seq */

                          if (Ei[EN][4] == 0) Ei[EN][1] = Ei[EN][3]; /* bmp, not ans */
                          if (Ei[EN][4] == 1) Ei[EN][1] = zz[0][b];    /* animate with time */
                          if (Ei[EN][4] == 2) /* animate with h move */
                             {
                                x = (EXint/3) % c;
                                Ei[EN][1] = zz[x+5][b];
                             }
                          if (Ei[EN][4] == 3) /* animate with v move */
                             {
                                x = (EYint/3) % c;
                                Ei[EN][1] = zz[x+5][b];
                             }
                          if (Ei[EN][4] == 4) /* animate with v and h move */
                             {
                                x = ((EYint/3) % c) + ((EXint/3) % c);
                                if (x > c) x-=c;
                                Ei[EN][1] = zz[x+5][b];
                             }





               break;

               case 4: /* enemy type 4  bouncer !
                          does not follow man!
                   bounces off walls , no gravity
                          Ei[EN][0] = type 4
                          Ei[EN][1] = bitmap
                          Ei[EN][2] = draw type
                          Ei[EN][3] = ans
                          Ei[EN][4] = ans type
                          Ei[EN][5] = main ans
                          Ei[EN][6] = seek ans
                          Ei[EN][7] = bounce count
                          Ei[EN][8] = seek bounce count wait
                          Ei[EN][9] = collision box size


                          Ef[EN][0] = x
                          Ef[EN][1] = y
                          Ef[EN][2] = xinc
                          Ef[EN][3] = yinc

                          Ef[EN][8] = seek speed
                          Ef[EN][9] = sekk */




                 Ei[EN][3] = Ei[EN][5]; /* main ans by default */
                 if (Ei[EN][8])  /* is seek on? */
                   if (Ei[EN][7] % Ei[EN][8] == 0) /* time to do a seek! */
                     {
                        Ei[EN][3] = Ei[EN][6]; /* seek ans */
                        if (Ef[EN][9] != 1) /* seek 1st time only */
                           {
                              Ef[EN][9] = 1;
                              seek_set_xyinc(EN, EXint, EYint);
                              Ei[EN][2] = 11 + get_rot_from_xyinc(EN);
                           }
                     }
                  else Ef[EN][9]=0;


                  if ((Ef[EN][2]) > 0)  /* move right */
                     {

                       Ef[EN][0] += Ef[EN][2];
                       EXint = Ef[EN][0];
                       if (is_right_solid(EXint, EYint))
                          {
                             Ei[EN][7]++;
                             Ef[EN][2] =- Ef[EN][2]; /* bounce */
                             Ef[EN][0] += Ef[EN][2];
                             EXint = Ef[EN][0];
                             Ei[EN][2] = 11 + get_rot_from_xyinc(EN);
                          }
                     }
                  if ((Ef[EN][2]) < 0)  /* move left */
                     {

                        Ef[EN][0] += Ef[EN][2];
                        EXint = Ef[EN][0];
                        if (is_left_solid(EXint, EYint))
                           {
                              Ei[EN][7]++;
                              Ef[EN][2] =- Ef[EN][2]; /* bounce */
                              Ef[EN][0] += Ef[EN][2];
                              EXint = Ef[EN][0];
                              Ei[EN][2] = 11 + get_rot_from_xyinc(EN);
                           }
                     }
                  if (Ef[EN][3] > 0) /* move down */
                     {
                        Ef[EN][1] += Ef[EN][3];
                        EYint = Ef[EN][1];
                        if (is_down_solid(EXint, EYint))
                           {
                              Ei[EN][7]++;
                              Ef[EN][3] =- Ef[EN][3]; /* bounce */
                              Ef[EN][1] += Ef[EN][3];
                              Ei[EN][2] = 11 + get_rot_from_xyinc(EN);
                           }
                     }
                  if (Ef[EN][3] < 0)  /* move up */
                     {
                        Ef[EN][1] += Ef[EN][3];
                        EYint = Ef[EN][1];
                        if (is_up_solid_nosemi(EXint, EYint))
                           {
                              Ei[EN][7]++;
                              Ef[EN][3] =- Ef[EN][3]; /* bounce */
                              Ef[EN][1] += Ef[EN][3];
                              Ei[EN][2] = 11 + get_rot_from_xyinc(EN);
                           }

                     }
                         /* set the bitmap and drawing mode */

                         /* always with time */
                         Ei[EN][1] = zz[0][Ei[EN][3]];

              break;
              case 5: /* enemy type 5  stationery bullet firer !  */

                    /*    Ei[EN][0] = type 5
                          Ei[EN][1] = !rsvd bitmap
                          Ei[EN][2] = !rsvd draw type
                          Ei[EN][3] =
                          Ei[EN][4] =
                          Ei[EN][5] =
                          Ei[EN][6] = bullet wait
                          Ei[EN][7] =
                          Ei[EN][8] =
                          Ei[EN][9] = collision window

                          Ef[EN][0] = x
                          Ef[EN][1] = y
                          Ef[EN][2] =
                          Ef[EN][3] =
                          Ef[EN][3] = health dec
                          Ef[EN][7] = bullet speed    */

                if ( (passcount % Ei[EN][6]) == (Ei[EN][6])-1)
                   fire_enemy_bullet(EN, EXint, EYint);


                Ei[EN][2] = 11 + get_rot_from_PXY(EN, EXint, EYint);


                /* set bitmap */
                if ((passcount % Ei[EN][6]) > ((Ei[EN][6] * 7) / 8) ) /* show warning */
                   Ei[EN][1] = 506; /* red cannon */
                else Ei[EN][1] = 507;  /* green cannon */

               break;

               case 6: /* enemy type 6  bouncing cannon !
                          Ei[EN][0] = type 6
                          Ei[EN][1] = bitmap
                          Ei[EN][2] = draw type
                          Ei[EN][3] =
                          Ei[EN][4] =
                          Ei[EN][5] =
                          Ei[EN][6] = bullet_wait
                          Ei[EN][7] = bounce count
                          Ei[EN][8] = seek bounce count wait
                          Ei[EN][9] = collision box size


                          Ef[EN][0] = x
                          Ef[EN][1] = y
                          Ef[EN][2] = xinc
                          Ef[EN][3] = yinc
                          Ef[EN][7] = bullet speed
                          Ef[EN][8] = seek speed
                          Ef[EN][9] = sekk */

                 if ( (passcount % Ei[EN][6]) == (Ei[EN][6])-1)
                 fire_enemy_bullet(EN, EXint, EYint);


                 if (Ei[EN][8])  /* is seek on? */
                   if (Ei[EN][7] % Ei[EN][8] == 0) /* time to do a seek! */
                     {

                        if (Ef[EN][9] != 1) /* seek 1st time only */
                           {
                              Ef[EN][9] = 1;
                              seek_set_xyinc(EN, EXint, EYint);

                           }
                     }
                  else Ef[EN][9]=0;
                  Ei[EN][2] = 11 + get_rot_from_PXY(EN, EXint, EYint);
                /* set bitmap */
                if ((passcount % Ei[EN][6]) > ((Ei[EN][6] * 5) / 6) ) /* show warning */
                   {
                      Ei[EN][1] = 506; /* red cannon */
                   }
                else Ei[EN][1] = 507;  /* green cannon */

                  if ((Ef[EN][2]) > 0)  /* move right */
                     {

                       Ef[EN][0] += Ef[EN][2];
                       EXint = Ef[EN][0];
                       if (is_right_solid(EXint, EYint))
                          {
                             Ei[EN][7]++;
                             Ef[EN][2] =- Ef[EN][2]; /* bounce */
                             Ef[EN][0] += Ef[EN][2];


                          }
                     }
                  if ((Ef[EN][2]) < 0)  /* move left */
                     {

                        Ef[EN][0] += Ef[EN][2];
                        EXint = Ef[EN][0];
                        if (is_left_solid(EXint, EYint))
                           {
                              Ei[EN][7]++;
                              Ef[EN][2] =- Ef[EN][2]; /* bounce */
                              Ef[EN][0] += Ef[EN][2];

                           }
                     }
                  if (Ef[EN][3] > 0) /* move down */
                     {
                        Ef[EN][1] += Ef[EN][3];
                        if (is_down_solid(EXint, EYint))
                           {
                              Ei[EN][7]++;
                              Ef[EN][3] =- Ef[EN][3]; /* bounce */
                              Ef[EN][1] += Ef[EN][3];

                           }
                     }
                  if (Ef[EN][3] < 0)  /* move up */
                     {
                        Ef[EN][1] += Ef[EN][3];
                        if (is_up_solid(EXint, EYint))
                           {
                              Ei[EN][7]++;
                              Ef[EN][3] =- Ef[EN][3]; /* bounce */
                              Ef[EN][1] += Ef[EN][3];
                           }

                     }
                break;
                case 7: /* pod cannon stationery bullet firer  */
                          /*    Ei[EN][0] = type 7
                          Ei[EN][1] = !rsvd bitmap
                          Ei[EN][2] = !rsvd draw type
                          Ei[EN][3] = wait count
                          Ei[EN][4] = wait limit
                          Ei[EN][5] = sequence counter
                          Ei[EN][6] = sequence limit
                          Ei[EN][7] = mode
                          Ei[EN][8] = trigger limit
                          Ei[EN][9] = collision window

                          Ef[EN][0] = x
                          Ef[EN][1] = y
                          Ef[EN][2] = x inc
                          Ef[EN][3] = y inc
                          Ef[EN][4] = health dec
                          Ef[EN][5] =
                          Ef[EN][6] =
                          Ef[EN][7] = bullet speed
                          Ef[EN][8] = move speed creator only   */


                  if (!Ei[EN][7]) /* only trigger from mode 0 */
                     if (abs(PXint - EXint) < Ei[EN][8])
                        if (abs(PYint - EYint) < Ei[EN][8])

                           {
                              Ei[EN][7] = 1; /* triggered! mode 1; */
                              Ei[EN][5] = 0;  /* zero counter */
                           }
                  if (Ei[EN][7] == 1) /* mode 1; out */
                     {
                        Ef[EN][0] += Ef[EN][2];
                        Ef[EN][1] += Ef[EN][3];
                        if (++Ei[EN][5] > Ei[EN][6]) /* if (++count > limit) */
                           {
                              Ei[EN][7] = 2; /* next mode */
                              Ei[EN][3] = passcount;
                          }
                     }
                  if (Ei[EN][7] == 2)  /* mode 2; shoot */
                     {
                        if (Ei[EN][3] < (passcount-Ei[EN][4]) )
                           {
                              fire_enemy_bullet(EN, EXint, EYint);
                              Ei[EN][7] = 3; /* next mode */
                              Ei[EN][3] = passcount;
                           }
                     }
                  if (Ei[EN][7] == 3)  /* mode 4; post shoot pause */
                     {
                        if (Ei[EN][3] < (passcount-Ei[EN][4]) )
                           {
                              Ei[EN][7] = 4; /* next mode */
                              Ei[EN][3] = passcount;
                           }
                     }
                  if (Ei[EN][7] == 4) /* mode 4; in */
                     {
                        Ef[EN][0] -= Ef[EN][2];
                        Ef[EN][1] -= Ef[EN][3];
                        if (--Ei[EN][5] < 1 ) /* if (--count < 1) */
                           {
                              Ei[EN][7] = 0; /* done; back to mode 0 */

                           }
            
                     }


                Ei[EN][1] = zz[ 5 + (Ei[EN][5] * zz[4][15] / Ei[EN][6]) ][15];
                /* bitmap =           counter * numshapes / limit  */
               if ( (Ei[EN][7] == 2) || (Ei[EN][7] == 3) )
                  {
                     Ei[EN][2] = 11 + get_rot_from_PXY(EN, EXint, EYint);
                     Ei[EN][1] = 335; /* green cannon */
                  }
               else   Ei[EN][2] = 11 + get_rot_from_xyinc(EN);


               break;
               case 8: /* enemy type 3  */
               {
                  /* CLIMBER DUDE
                  Ei[EN][0] = type 8
                  Ei[EN][1] = bitmap
                  Ei[EN][2] = draw type
                  Ei[EN][3] = ans
                  Ei[EN][4] = bullet prox re-trigger delay
                  Ei[EN][5] =
                  Ei[EN][6] = mode
                  Ei[EN][7] = fall when player below
                  Ei[EN][8] =
                  Ei[EN][9] = collision box size
   
                  Ef[EN][0] = x
                  Ef[EN][1] = y
                  Ef[EN][2] = xinc
                  Ef[EN][3] = yinc
                  Ef[EN][4] = LIFE decrement
                  Ef[EN][5] = bullet waitcount
                  Ef[EN][6] = bullet prox (0=none)
                  Ef[EN][7] = bullet speed
                  Ef[EN][8] = fall and fallcount
                  Ef[EN][9] =                    */

                  int bullet_request = 0;
                  int mode = Ei[EN][6];
                  int prox = Ef[EN][6];
                  int te = 4;

                  /* bullet prox */
                  if ((prox) && (--Ef[EN][5] < 0)) bullet_request = 1;


                        if (Ef[EN][8])   /* if fall = 1 */
                           {

                              Ef[EN][8] -= .1; /* fall_count = fall_count - .1; */
                              if (Ef[EN][8] < .1)  Ef[EN][8] = .1; /* keep falling at this rate */
                              Ef[EN][1] += (sin(1.6 - Ef[EN][8]) * Ef[EN][3]);
                              if (Ef[EN][1] > 2000) Ef[EN][1]=2000;
                              EYint=Ef[EN][1];
                              if (is_down_solid(EXint, EYint))  /* look for end of fall */
                                 {
                                    Ef[EN][8] = 0; /*  fall=0;  */
                                    Ef[EN][1] -= fmod(Ef[EN][1], 20); /* align with floor */
                                    EYint=Ef[EN][1];
                                 }
                           }
                        if (!Ef[EN][8])  /* if not fall */
                           {
                             if ( (EXint < (PXint + 15)) && (EXint > (PXint - 15))
                               && (EYint < (PYint     )) ) /* if above */

                                {
                                   if (mode == 2)
                                      {
                                         Ef[EN][8] = 1.6; /* fall */
                                         mode = 4;
                                         Ei[EN][2] = 0;
                                      }
                                   if (mode == 6)
                                      {
                                         Ef[EN][8] = 1.6; /* fall */
                                         mode = 0;
                                         Ei[EN][2] = 1;
                                      }
                                
                                }
                           } /* end of fall = 0  */




              if (!Ef[EN][8])  /* not fall */
                 switch (mode)
                  {
                      case 0: /* floor right */
                       if (!is_down_solid(EXint, EYint))
                         {
                            mode = 3;
                            Ef[EN][0] = 19 + (EXint/20)*20;
                            Ef[EN][1] += te;
                            Ei[EN][2] = 42; /* rotation */
                            break;
                         }
                      if (is_right_solid(EXint, EYint))
                         {
                            mode = 1;
                            Ef[EN][0] = (EXint/20)*20;
                            Ei[EN][2] = 234; /* rotation */
                            break;
                         }

                      if (bullet_request)
                         if (EYint >= PYint)
                            if ((EYint-prox) < PYint)
                               if (EXint < PXint)
                                  if ((EXint+prox) > PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 1;
                      Ef[EN][0] += Ef[EN][2];
                      break;


                      case 1: /* rwall up */
                       if (!is_right_solid(EXint, EYint))
                         {
                            mode = 0;
                            Ef[EN][1] = (EYint/20)*20;
                            Ef[EN][0] += te;
                            Ei[EN][2] = 234; /* rotation */
                            break;
                         }
                      if (is_up_solid_nosemi(EXint, EYint))
                         {
                            mode = 2;
                            Ef[EN][1] = (((EYint+te)/20)*20)-1;
                            Ei[EN][2] = 170; /* rotation */
                            break;
                         }
                      if (bullet_request)
                         if (EYint >= PYint)
                            if ((EYint-prox) < PYint)
                               if (EXint > PXint)
                                  if ((EXint-prox) < PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 202;
                      Ef[EN][1] -= Ef[EN][3];
                      break;


                      case 2: /* ceil left */
                      if (!is_up_solid_nosemi(EXint, EYint))
                         {
                            mode = 1;
                            Ef[EN][0] = (EXint/20)*20;
                            Ef[EN][1] -= te;
                            Ei[EN][2] = 170; /* rotation */
                            break;
                         }
                    if (is_left_solid(EXint, EYint))
                         {
                            mode = 3;
                            Ef[EN][0] = 19 + (EXint/20)*20;
                            Ei[EN][2] = 106; /* rotation */
                            break;
                         }
                      if (bullet_request)
                         if (EYint < PYint)
                            if ((EYint+prox) > PYint)
                               if (EXint > PXint)
                                  if ((EXint-prox) < PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 138;
                      Ef[EN][0] -= Ef[EN][2];
                      break;
                      case 3: /* lwall down */
                      if (!is_left_solid(EXint, EYint))
                         {
                            mode = 2;
                            Ef[EN][1] = 19 + (EYint/20)*20;
                            Ef[EN][0] -= te;
                            Ei[EN][2] = 106; /* rotation */
                            break;
                         }
                      if (is_down_solid(EXint, EYint))
                         {
                            mode = 0;
                            Ef[EN][1] = (EYint/20)*20;
                            Ei[EN][2] = 170; /* rotation */
                            break;
                         }
                      if (bullet_request)
                         if (EYint < PYint)
                            if ((EYint+prox) > PYint)
                               if (EXint < PXint)
                                  if ((EXint+prox) > PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 74;
                      Ef[EN][1] += Ef[EN][3];
                      break;

                      case 4: /* floor left */
                       if (!is_down_solid(EXint, EYint))
                         {
                            mode = 7;
                            Ef[EN][0] = (EXint/20)*20;
                            Ef[EN][1] += te;
                            Ei[EN][2] = 1224;
                            break;
                         }
                      if (is_left_solid(EXint, EYint))
                         {
                            mode = 5;
                            Ef[EN][0] = 19+((EXint)/20)*20;
                            Ei[EN][2] = 1032;
                            break;
                         }
                      if (bullet_request)
                         if (EYint >= PYint)
                            if ((EYint-prox) < PYint)
                               if (EXint > PXint)
                                  if ((EXint-prox) < PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 0;
                      Ef[EN][0] -= Ef[EN][2];
                      break;


                      case 5: /* lwall up */
                       if (!is_left_solid(EXint, EYint))
                         {
                            mode = 4;
                            Ef[EN][1] = (EYint/20)*20;
                            Ef[EN][0] -= te;
                            Ei[EN][2] = 1032;
                            break;
                         }
                      if (is_up_solid_nosemi(EXint, EYint))
                         {
                            mode = 6;
                            Ef[EN][1] = (((EYint+te)/20)*20)-1;
                            Ei[EN][2] = 1096;
                            break;
                         }
                      if (bullet_request)
                         if (EYint >= PYint)
                            if ((EYint-prox) < PYint)
                               if (EXint < PXint)
                                  if ((EXint+prox) > PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 1064;
                      Ef[EN][1] -= Ef[EN][3];
                      break;


                      case 6: /* ceil right */
                      if (!is_up_solid_nosemi(EXint, EYint))
                         {
                            mode = 5;
                            Ef[EN][0] = 19+(EXint/20)*20;
                            Ef[EN][1] -= te;
                            Ei[EN][2] = 1096;
                            break;
                         }
                    if (is_right_solid(EXint, EYint))
                         {
                            mode = 7;
                            Ef[EN][0] = (EXint/20)*20;
                            Ei[EN][2] = 1160;
                            break;
                         }
                      if (bullet_request)
                         if (EYint < PYint)
                            if ((EYint+prox) > PYint)
                               if (EXint < PXint)
                                  if ((EXint+prox) > PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 1128;
                      Ef[EN][0] += Ef[EN][2];
                      break;
                      case 7: /* rwall down */
                      if (!is_right_solid(EXint, EYint))
                         {
                            mode = 6;
                            Ef[EN][1] = 19 + (EYint/20)*20;
                            Ef[EN][0] += te;
                            Ei[EN][2] = 1160;
                            break;
                         }
                      if (is_down_solid(EXint, EYint))
                         {
                            mode = 4;
                            Ef[EN][1] = (EYint/20)*20;
                            Ei[EN][2] = 1224;
                            break;
                         }
                      if (bullet_request)
                         if (EYint < PYint)
                            if ((EYint+prox) > PYint)
                               if (EXint > PXint)
                                  if ((EXint-prox) < PXint)
                                    {
                                       fire_enemy_bulleta(EN, EXint, EYint, 20);
                                       Ef[EN][5] = Ei[EN][4]; /* set new prox wait */
                                    }

                      Ei[EN][2] = 1192;
                      Ef[EN][1] += Ef[EN][3];
                      break;
                   } /* end of switch mode */



                          /* set the bitmap and drawing mode */
                          b = Ei[EN][3];      /* ans */
                          c = zz[4][b];         /* num_of_shapes in seq */

                          if (mode % 2) /* ymove, if odd */
                             {
                                x = (EYint/3) % c;
                                Ei[EN][1] = zz[x+5][b];
                             }
                          else  /* xmove, if even */
                             {
                                x = (EXint/3) % c;
                                if (x > c) x-=c;
                                Ei[EN][1] = zz[x+5][b];
                             }
               if (Ei[EN][6] == mode) Ei[EN][8] = 0;
               if (Ei[EN][6] != mode)
                  {
                     Ei[EN][6] = mode;
                     if (++Ei[EN][8] > 4) /* twirling */
                        {
                           Ef[EN][8] = 1.6; /* fall */
                           Ei[EN][6] = 0;
                           Ei[EN][2] = 1;
                        }
                  }
               }
               break; /* end of case 8 */
               case 9:
                  /* CLONER
                  Ei[EN][0] = type 9
                  Ei[EN][1] = bitmap
                  Ei[EN][2] = draw type
                  Ei[EN][3] = ans
                  Ei[EN][4] =
                  Ei[EN][5] =
                  Ei[EN][6] = create wait
                  Ei[EN][7] = create wait counter
                  Ei[EN][8] =
                  Ei[EN][9] = collision box size
   
                  Ef[EN][0] = x
                  Ef[EN][1] = y
                  Ef[EN][2] = copy box x size
                  Ef[EN][3] = copy box y size
                  Ef[EN][4] = LIFE decrement
                  Ef[EN][5] =
                  Ef[EN][6] = copy box x (2000)
                  Ef[EN][7] = copy box y (2000)
                  Ef[EN][8] = dest box x (2000)
                  Ef[EN][9] = dest box y (2000) */


                  {
                     float ratio = (float) Ei[EN][7] / (float) Ei[EN][6] * 10;
                     b = 9 - (int) ratio;
                     Ei[EN][2] = 1;
                     Ei[EN][1] = zz[5+b][53];
                  }

                  if (--Ei[EN][7] < 0)  /* time for create */
                     {
                        int x1 = Ef[EN][6]-2;    /* source x */
                        int y1 = Ef[EN][7]-2;    /* source y */
                        int x2 = x1 + Ef[EN][2];   /* sizes */
                        int y2 = y1 + Ef[EN][3];

                        int x3 = Ef[EN][8]-2;    /* dest x */
                        int y3 = Ef[EN][9]-2;    /* dest y */
                        int x4 = x3 + Ef[EN][2];   /* sizes */
                        int y4 = y3 + Ef[EN][3];
                        extern BITMAP *scrn_buffer;
                        extern int WX,WY;
                        extern int item[500][16];
                        extern float itemf [500][4];

                        rectfill (scrn_buffer, x1-WX, y1-WY, x2-WX, y2-WY, 10);
                        rectfill (scrn_buffer, x3-WX, y3-WY, x4-WX, y4-WY, 11);

                        Ei[EN][7] = Ei[EN][6]; /* reset counter */
                        Ei[EN][1] = zz[15][53]; /* full red */
             

                        for (b=0; b<100; b++) /* check for enemies in box */
                           if (Ei[b][0])     /* if active */
                              if (Ef[b][0] > x1)
                                 if (Ef[b][0] < x2)
                                    if (Ef[b][1] > y1)
                                       if (Ef[b][1] < y2)
                                          {
                                             /* copy to dest box */
                                             /* find empty */
                                             for (c=0; c<100; c++)
                                                if (Ei[c][0] == 0)
                                                   {
                                                      for (y=0; y<10; y++)
                                                         {
                                                            Ei[c][y] = Ei[b][y];
                                                            Ef[c][y] = Ef[b][y];
                                                         }
                                                      Ef[c][0]= x3 + (Ef[b][0]-x1);
                                                      Ef[c][1]= y3 + (Ef[b][1]-y1);
                                                      c = 100; /* end loop */
                                                   }
                                          }

                        for (b=0; b<500; b++) /* check for items in box */
                           if (item[b][0])     /* if active */
                              if (itemf[b][0] > x1)
                                 if (itemf[b][0] < x2)
                                    if (itemf[b][1] > y1)
                                       if (itemf[b][1] < y2)
                                          {
                                             /* copy to dest box */
                                             /* find empty */
                                             for (c=0; c<500; c++)
                                                if (item[c][0] == 0)
                                                   {
                                                      for (y=0; y<16; y++)
                                                         item[c][y] = item[b][y];
                                                      itemf[c][0]= x3 + (itemf[b][0]-x1);
                                                      itemf[c][1]= y3 + (itemf[b][1]-y1);
                                                      c = 500; /* end loop */
                                                   }
                                          }
                     }
               break;
            }  /* end of switch case */
         } /* end of if enemy active */
} /*  end of void enemy_move(void) */

void enemy_textdesc_setup(void)
{
   extern char eftype_desc[10][10][40];
   extern char eitype_desc[10][10][40];

  /* --- enemy type 0 variable descriptions --- */
   strcpy (eitype_desc[0][0],"<empty>");
   strcpy (eitype_desc[0][1],"!rsvd bitmap");
   strcpy (eitype_desc[0][2],"!rsvd draw_mode");
   strcpy (eitype_desc[0][3],"ans");
   strcpy (eitype_desc[0][4],"ans type");
   strcpy (eitype_desc[0][5],"-");
   strcpy (eitype_desc[0][6],"-");
   strcpy (eitype_desc[0][7],"-");
   strcpy (eitype_desc[0][8],"-");
   strcpy (eitype_desc[0][9],"collision window");

   strcpy (eftype_desc[0][0],"x pos");
   strcpy (eftype_desc[0][1],"y pos");
   strcpy (eftype_desc[0][2],"x inc");
   strcpy (eftype_desc[0][3],"y inc");
   strcpy (eftype_desc[0][4],"health dec");
   strcpy (eftype_desc[0][5],"-");
   strcpy (eftype_desc[0][6],"-");
   strcpy (eftype_desc[0][7],"-");
   strcpy (eftype_desc[0][8],"-");
   strcpy (eftype_desc[0][9],"-");
   /* --- enemy type 1 variable descriptions --- */
   strcpy (eitype_desc[1][0],"FOLLOWER no walls, grav");
   strcpy (eitype_desc[1][1],"!rsvd bitmap");
   strcpy (eitype_desc[1][2],"!rsvd draw_mode");
   strcpy (eitype_desc[1][3],"ans");
   strcpy (eitype_desc[1][4],"ans type");
   strcpy (eitype_desc[1][5],"-");
   strcpy (eitype_desc[1][6],"-");
   strcpy (eitype_desc[1][7],"-");
   strcpy (eitype_desc[1][8],"-");
   strcpy (eitype_desc[1][9],"collision window");
   strcpy (eftype_desc[1][0],"x pos");
   strcpy (eftype_desc[1][1],"y pos");
   strcpy (eftype_desc[1][2],"x inc");
   strcpy (eftype_desc[1][3],"y inc");
   strcpy (eftype_desc[1][4],"health dec");
   strcpy (eftype_desc[1][5],"-");
   strcpy (eftype_desc[1][6],"-");
   strcpy (eftype_desc[1][7],"-");
   strcpy (eftype_desc[1][8],"-");
   strcpy (eftype_desc[1][9],"-");

   strcpy (eitype_desc[2][0],"FOLLOWER with walls, grav");
   strcpy (eitype_desc[2][1],"!rsvd bitmap");
   strcpy (eitype_desc[2][2],"!rsvd draw_mode");
   strcpy (eitype_desc[2][3],"ans");
   strcpy (eitype_desc[2][4],"ans type");
   strcpy (eitype_desc[2][5]," - ");
   strcpy (eitype_desc[2][6]," - ");
   strcpy (eitype_desc[2][7]," - ");
   strcpy (eitype_desc[2][8]," - ");
   strcpy (eitype_desc[2][9],"collision window");
   strcpy (eftype_desc[2][0],"x pos");
   strcpy (eftype_desc[2][1],"y pos");
   strcpy (eftype_desc[2][2],"x inc");
   strcpy (eftype_desc[2][3],"y inc");
   strcpy (eftype_desc[2][4],"health dec");
   strcpy (eftype_desc[2][5]," - ");
   strcpy (eftype_desc[2][6]," - ");
   strcpy (eftype_desc[2][7]," - ");
   strcpy (eftype_desc[2][8]," - ");
   strcpy (eftype_desc[2][9]," - ");

   strcpy (eitype_desc[3][0],"WAGON ARCHER");
   strcpy (eitype_desc[3][1],"!rsvd bitmap");
   strcpy (eitype_desc[3][2],"!rsvd draw_mode");
   strcpy (eitype_desc[3][3],"ans");
   strcpy (eitype_desc[3][4],"ans type");
   strcpy (eitype_desc[3][5],"bullet wait (0)none");
   strcpy (eitype_desc[3][6],"jump when under player");
   strcpy (eitype_desc[3][7],"jump wait count");
   strcpy (eitype_desc[3][8],"x move (0)follow (1)bounce");
   strcpy (eitype_desc[3][9],"collision window");
   strcpy (eftype_desc[3][0],"x pos");
   strcpy (eftype_desc[3][1],"y pos");
   strcpy (eftype_desc[3][2],"x inc");
   strcpy (eftype_desc[3][3],"y inc");
   strcpy (eftype_desc[3][4],"health dec");
   strcpy (eftype_desc[3][5],"bullet prox wait count");
   strcpy (eftype_desc[3][6],"bullet prox");
   strcpy (eftype_desc[3][7],"bullet prox wait");
   strcpy (eftype_desc[3][8],"!rsvd fall count");
   strcpy (eftype_desc[3][9],"!rsvd jumpcount");

   strcpy (eitype_desc[4][0],"BOUNCER");
   strcpy (eitype_desc[4][1],"!rsvd bitmap");
   strcpy (eitype_desc[4][2],"!rsvd draw_mode");
   strcpy (eitype_desc[4][3],"ans");
   strcpy (eitype_desc[4][4],"ans type");
   strcpy (eitype_desc[4][5],"main ans");
   strcpy (eitype_desc[4][6],"seek ans");
   strcpy (eitype_desc[4][7],"bounce count");
   strcpy (eitype_desc[4][8],"seek bounce count wait");
   strcpy (eitype_desc[4][9],"collision window");
   strcpy (eftype_desc[4][0],"x pos");
   strcpy (eftype_desc[4][1],"y pos");
   strcpy (eftype_desc[4][2],"x inc");
   strcpy (eftype_desc[4][3],"y inc");
   strcpy (eftype_desc[4][4],"health dec");
   strcpy (eftype_desc[4][5],"");
   strcpy (eftype_desc[4][6],"");
   strcpy (eftype_desc[4][7],"");
   strcpy (eftype_desc[4][8],"seek speed");
   strcpy (eftype_desc[4][9],"!rsvd sekk");

   strcpy (eitype_desc[5][0],"FIXED CANNON");
   strcpy (eitype_desc[5][1],"!rsvd bitmap");
   strcpy (eitype_desc[5][2],"!rsvd draw_mode");
   strcpy (eitype_desc[5][3],"ans");
   strcpy (eitype_desc[5][4],"ans type");
   strcpy (eitype_desc[5][5],"");
   strcpy (eitype_desc[5][6],"bullet wait");
   strcpy (eitype_desc[5][7],"");
   strcpy (eitype_desc[5][8],"");
   strcpy (eitype_desc[5][9],"collision window");
   strcpy (eftype_desc[5][0],"x pos");
   strcpy (eftype_desc[5][1],"y pos");
   strcpy (eftype_desc[5][2],"");
   strcpy (eftype_desc[5][3],"");
   strcpy (eftype_desc[5][4],"health dec");
   strcpy (eftype_desc[5][5],"");
   strcpy (eftype_desc[5][6],"");
   strcpy (eftype_desc[5][7],"bullet speed");
   strcpy (eftype_desc[5][8],"");
   strcpy (eftype_desc[5][9],"");
   strcpy (eitype_desc[6][0],"BOUNCING CANNON");
   strcpy (eitype_desc[6][1],"!rsvd bitmap");
   strcpy (eitype_desc[6][2],"!rsvd draw_mode");
   strcpy (eitype_desc[6][3],"");
   strcpy (eitype_desc[6][4],"");
   strcpy (eitype_desc[6][5],"");
   strcpy (eitype_desc[6][6],"bullet wait");
   strcpy (eitype_desc[6][7],"bounce count");
   strcpy (eitype_desc[6][8],"seek bounce count wait");
   strcpy (eitype_desc[6][9],"collision window");
   strcpy (eftype_desc[6][0],"x pos");
   strcpy (eftype_desc[6][1],"y pos");
   strcpy (eftype_desc[6][2],"x inc");
   strcpy (eftype_desc[6][3],"y inc");
   strcpy (eftype_desc[6][4],"health dec");
   strcpy (eftype_desc[6][5],"");
   strcpy (eftype_desc[6][6],"");
   strcpy (eftype_desc[6][7],"bullet speed");
   strcpy (eftype_desc[6][8],"seek speed");
   strcpy (eftype_desc[6][9],"resvd sekk");
   strcpy (eitype_desc[7][0],"Podzilla ");
   strcpy (eitype_desc[7][1],"!rsvd bitmap");
   strcpy (eitype_desc[7][2],"!rsvd draw_mode");
   strcpy (eitype_desc[7][3],"!rsvd wait count");
   strcpy (eitype_desc[7][4],"wait limit");
   strcpy (eitype_desc[7][5],"seq count");
   strcpy (eitype_desc[7][6],"seq limit");
   strcpy (eitype_desc[7][7],"mode");
   strcpy (eitype_desc[7][8],"trigger distance");
   strcpy (eitype_desc[7][9],"collision window");
   strcpy (eftype_desc[7][0],"x pos");
   strcpy (eftype_desc[7][1],"y pos");
   strcpy (eftype_desc[7][2],"x inc");
   strcpy (eftype_desc[7][3],"y inc");
   strcpy (eftype_desc[7][4],"health dec");
   strcpy (eftype_desc[7][5],"");
   strcpy (eftype_desc[7][6],"");
   strcpy (eftype_desc[7][7],"bullet speed");
   strcpy (eftype_desc[7][8],"");
   strcpy (eftype_desc[7][9],"");

}



void enemy_menu(int EN)
{
   extern BITMAP *memory_bitmap[512];
   extern int zz[20][64];
   extern int Ei[100][10];
   extern float Ef[100][10];
   extern char eftype_desc[10][10][40];
   extern char eitype_desc[10][10][40];
   extern int edit_int_retval;
   extern float edit_float_retval;
   extern int get100_x, get100_y;
   extern float finitial, fxinc, fyinc, flv, fuv;
   extern int level_num; /* for the file */

   int temp_enemy_file_num;

   int a, b, c, d, e, f, x, y, x1, y1, x2, y2;
   int engry, en_quit;
   char msg[80];
   extern int l[100][100];
   short int ge_int_selection[10], ge_float_selection[10];
   extern int edit_int_retval;
   short int group_edit_selection[100];
   int e_type_sel_x = 135, e_type_sel_y = 0;
   int e_var_sel_x = 80, e_var_sel_y = 0;

   int redraw[10];
   int rv = 240; /* reg value white */
   int hv = 241; /* higlighted value red */
   int vd = 128; /* value desc grey */
   int rf = 149; /* regular frame */
   int hf = 245; /* higlight frame color */

   double rnd_div;
   int ge_current_type, ge_current_enemy;

   int screen_column, screen_row;
   int first_screen_column=1, first_screen_row=0;
   int list_size = 4;
   int col_size = 80;
   int list_menu_selection = 99;
   int full_screen_mode = 0;
   int dl_x = 0, dl_y = 0;  /* edit function window */

   int mouse_focus=0;

   int column_count = 0;
   int row_count = 0;
   int ypos = 142, xpos = 0;
   int do_edit_func = 0;
   int edit_function_select = 1;

   float ege_fx1=0, ege_fz1=0, ege_fr1=0;
   float ege_fx=0, ege_fz=0, ege_fr=0;


   enemy_textdesc_setup();
   show_mouse(NULL);
   clear_keybuf();
   clear(screen);
   set_mouse_range(0,0,319,199);
   rest(300);

   if (EN < 0 ) EN = 0;
   if (EN > 99) EN = 99;

   ge_current_enemy = EN;
   ge_current_type = Ei[ge_current_enemy][0];

   for (x=0; x<10; x++)
      {
         ge_float_selection[x] = 0;
         ge_int_selection[x] = 0;
      }

   for (x=0; x<100; x++)
      group_edit_selection[x]= 0;

   group_edit_selection[ge_current_enemy] = 1;
   ge_int_selection[0] = 1;

   for(x=0;x<5; x++) redraw[x]=1;

   do
      {

            y=ge_current_enemy;
            for (x=99; x>-1; x--) /* get first selected enemy */
               if (group_edit_selection[x]) ge_current_enemy = x;

            if (ge_current_enemy != y)
                for(x=0;x<5; x++) redraw[x]=1;


            show_mouse(screen);
            rest(10);
            show_mouse(NULL);



         /* ENEMY TYPE SEL (mouse_focus == 0) */

         if (redraw[0])
            {
               redraw[0] = 0;
               /* draw the selection grid */
               for (y=0; y<10; y++)
                  for (x=0; x<10; x++)
                     {
                        c = x + (y*10); /* get the enemy number */
                        if (Ei[c][0]) sprintf(msg, "%-1d", Ei[c][0]);
                        else sprintf(msg, "0");
                        if (group_edit_selection[(y*10)+x]) d = 1;
                        else if (Ei[(y*10)+x][0]) d = 2;
                        else d = 80; /* grey */
       

                        textout(screen, font, msg, 2 + e_type_sel_x + (x*8), 2 + e_type_sel_y + (y*8), d);
                    }
               /* draw a rectangle around type sel */

               if (mouse_focus == 0) d = hf;
               else d= rf; /* frame color */

               rect(screen, e_type_sel_x, e_type_sel_y, e_type_sel_x+82, e_type_sel_y+82, d);
            }
         if ((mouse_y > e_type_sel_y) && (mouse_y < (e_type_sel_y + 82)) && (mouse_x > e_type_sel_x) && (mouse_x < (e_type_sel_x+82)))
            {  /* mouse on enemy select menu */
               if ((mouse_b & 1) || (mouse_focus != 0))
                  for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */

               mouse_focus = 0;
               y = (mouse_y - (e_type_sel_y)-2)/8;
               if ((y<0) || (y>9)) y = -1;
               x = (mouse_x - (e_type_sel_x)-2)/8;
               if ((x<0) || (x>9)) x = -1;
               if ( (x!=-1) && (y!=-1) && (mouse_b & 1))
                  {
                     group_edit_selection[(y*10)+x] = (!group_edit_selection[(y*10)+x]);
                     while (mouse_b & 1);
                  }
               c = x + (y*10); /* get the enemy number */
               if (Ei[c][0]) sprintf(msg, "%-1d", Ei[c][0]);
               else sprintf(msg, "0");
 
               if (group_edit_selection[(y*10)+x]) d = 1;
               else if (Ei[(y*10)+x][0]) d = 2;
               else d = 80; /* grey */
               textout(screen, font, msg, 2 + e_type_sel_x + (x*8), 2 + e_type_sel_y + (y*8), d);

            }  /* end of enemy select */





         /* ENEMY VAR SEL (1)*/
         if (redraw[1])
            {
               for (y=0; y<10; y++)
                  {
                     redraw[1] = 0;
                     if (ge_int_selection[y]) d = 1;
                     else d = 2;
                     sprintf(msg,"Ei%1d",y);
                     textout(screen, font, msg ,2 + e_var_sel_x, 2 + e_var_sel_y+(y*8), d);
                     if (ge_float_selection[y]) d = 1;
                     else d = 2;
                     sprintf(msg,"Ef%1d",y);
                     textout(screen, font, msg, 28 + e_var_sel_x, 2 + e_var_sel_y + (y*8), d);
                  }
               /* put a frame around vars */
              if (mouse_focus == 1) d=hf; else d=rf;
              rect(screen, e_var_sel_x, e_var_sel_y, e_var_sel_x+54, e_var_sel_y+82, d);
            }
         if ((mouse_y > e_var_sel_y) && (mouse_y < (e_var_sel_y + 82)) && (mouse_x > e_var_sel_x+2) && (mouse_x < (e_var_sel_x+26))) /* mouse on int select menu */
            {  /* mouse on int select menu */
               if ((mouse_b & 1) || (mouse_focus != 1))
                  for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */

               mouse_focus=1;
               y = (-2 + mouse_y - e_var_sel_y) / 8;
               if (mouse_b & 1)
                  {
                     ge_int_selection[y] = (!ge_int_selection[y]);
                     while (mouse_b & 1);
                  }
               /* draw the ten ints */
               for (y=0; y<10; y++)
                  {
                     if (ge_int_selection[y]) d = 1;
                     else d = 2;
                     sprintf(msg,"Ei%d",y);
                     textout(screen, font, msg, 2 + e_var_sel_x, 2 + e_var_sel_y + (y*8), d);
                  }
            }
         if ((mouse_y > e_var_sel_y) && (mouse_y < e_var_sel_y + 82) && (mouse_x > e_var_sel_x+28) && (mouse_x < e_var_sel_x+54))
            /* mouse on float select menu */
            {
               if ((mouse_b & 1) || (mouse_focus != 1))
                  for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */

               mouse_focus = 1;
               y = (-2 + mouse_y - e_var_sel_y) / 8;
               if (mouse_b & 1)
                  {
                     ge_float_selection[y] = (!ge_float_selection[y]);
                     while (mouse_b & 1);
                  }
               /* draw the ten floats */
               for (y=0; y<10; y++)
                  {
                     if (ge_float_selection[y]) d = 1;
                     else d = 2;
                     sprintf(msg,"Ef%d",y);
                     textout(screen, font, msg, 28 + e_var_sel_x, 2 + e_var_sel_y + (y*8), d);

                  }
            }
        
         /* GROUP EDIT (3)*/
         if (redraw[3])
            {
               redraw[3] = 0;

               textout(screen, font, "ENEMY ", dl_x+2, dl_y + 2, 3);
               textout(screen, font, "EDIT", dl_x+48, dl_y + 2, 3);
               textout(screen, font, "current  ", dl_x+2, dl_y + 10, rv);
               textout(screen, font, "  ", dl_x+62, dl_y + 10, 0);
               sprintf(msg,"%d", ge_current_enemy);
               textout(screen, font, msg , dl_x+62, dl_y + 10, rv);
               blit (memory_bitmap[Ei[ge_current_enemy][1]],screen,0,0, 57, 20, 20, 20);
            
               textout(screen, font, "initial", dl_x+2, dl_y + 50, rv);
               if (ege_fx != 9999) sprintf(msg, "%-4.2f   ", ege_fx);
               else sprintf(msg, "orig   ");
               textout(screen, font, msg, dl_x+2, dl_y + 58, 244);

               textout(screen, font, "inc/dec", dl_x+2, dl_y + 66, rv);
               if (ege_fz != 9999) sprintf(msg, "%-3.4f  ", ege_fz);
               else sprintf(msg, "off   ");
               textout(screen, font, msg, dl_x+2, dl_y + 74, 244);

               textout(screen, font, "random", dl_x+2, dl_y + 82, rv);
               if (ege_fr != 9999) sprintf(msg, "%-2.3f  ", ege_fr);
               else sprintf(msg, "off  ");
               textout(screen, font, msg, dl_x+2, dl_y + 90, 244);

               textout(screen, font, "DO!", 10+dl_x, dl_y + 40, 244);
        /*     textout(screen, font, "", dl_x, dl_y + 88, 244);
      */
               if (mouse_focus == 3) d=hf; else d=rf;
               rect (screen, dl_x, dl_y, dl_x+79, dl_y+100, d);



            } /* end of redraw group edit */

         if ((mouse_y > 0) && (mouse_y < 102) && (mouse_x > 0) && (mouse_x < 82))
            {
               if (mouse_focus != 3)
                  for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */

               mouse_focus=3;  /* group edit */
               do_edit_func = 0;

               if (mouse_b & 1)
                  {
                     if ((mouse_y > dl_y+40) && (mouse_y < dl_y+48) && (mouse_x > 10) && (mouse_x < 30))
                        {
                           /* do the group edit function */
                           for(x=0; x<5; x++) redraw[x] = 1;
                           x=0;
                           for (y=0; y<100; y++)
                              if (group_edit_selection[y])
                                 {
                                    x++;
                                    for (a=0; a<10; a++)
                                       {
                                          rnd_div = random()/65535;
                                          rnd_div = rnd_div /32767;
      
                                          if (ege_fx == 9999) /* use original values */
                                             {
                                                if (ege_fz != 9999)
                                                   {
                                                      if (ge_int_selection[a]) Ei[y][a] += (x * ege_fz);
                                                      if (ge_float_selection[a]) Ef[y][a] += (x * ege_fz);
                                                   }
                                                if (ege_fr != 9999)
                                                   {
                                                      if (ge_int_selection[a]) Ei[y][a] += (rnd_div * ege_fr);
                                                      if (ge_float_selection[a]) Ef[y][a] += (rnd_div * ege_fr);
                                                   }
                                             }
                                          else
                                             {
                                                if (ege_fz != 9999)
                                                   {
                                                      if (ge_int_selection[a]) Ei[y][a] = ege_fx + (x * ege_fz);
                                                      if (ge_float_selection[a]) Ef[y][a] = ege_fx + (x * ege_fz);
                                                   }
                                                if (ege_fr != 9999)
                                                   {
                                                      if (ge_int_selection[a]) Ei[y][a] = ege_fx + (rnd_div * ege_fr);
                                                      if (ge_float_selection[a]) Ef[y][a] = ege_fx + (rnd_div * ege_fr);
                                                   }
                                             }

                                       }
                                 } /* end of if group edit sel */
                        }
                     if ((mouse_y > dl_y+50) && (mouse_y < dl_y+58) && (mouse_x > 0) && (mouse_x < 82))
                        {
                           /* toggle initial/ original */
                           if (ege_fx == 9999)
                              {
                                 ege_fx = ege_fx1;
                              }
                           else
                              {
                                 ege_fx1 = ege_fx;
                                 ege_fx = 9999;

                              }
                           while (mouse_b & 1);
                           for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                        
                        }
                     if  ((mouse_y > dl_y+58) && (mouse_y < dl_y+66) && (mouse_x > 0) && (mouse_x < 82))
                        {
                           /* edit initial */
                           for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                           fxinc=.01;   /* y inc */
                           fyinc=.1;   /* x inc */
                           flv=-2000;     /* lv    */
                           fuv=2000;   /* uv    */
                           finitial = ege_fx;
                          if (edit_float(2, dl_y + 58)) ege_fx = edit_float_retval;

                       }

                   if ((mouse_y > dl_y+66) && (mouse_y < dl_y+74) && (mouse_x > 0) && (mouse_x < 82))
                        {
                           /* toggle inc/dec  off */
                           if (ege_fz == 9999)
                              {
                                 ege_fz = ege_fz1;
                              }
                           else
                              {
                                 ege_fz1 = ege_fz;
                                 ege_fz = 9999;

                              }
                           while (mouse_b & 1);
                           for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                        
                        }
                     if  ((mouse_y > dl_y+74) && (mouse_y < dl_y+82) && (mouse_x > 0) && (mouse_x < 82))
                        {
                           /* edit inc/dec */
                           for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                           fxinc=.01;   /* y inc */
                           fyinc=.1;   /* x inc */
                           flv= -2000;     /* lv    */
                           fuv= 2000;   /* uv    */
                           finitial = ege_fz;
                          if (edit_float(2, dl_y + 74)) ege_fz = edit_float_retval;

                       }
       

                  if ((mouse_y > dl_y+82) && (mouse_y < dl_y+90) && (mouse_x > 0) && (mouse_x < 82))
                        {
                           /* toggle rnd/ off */
                           if (ege_fr == 9999)
                              {
                                 ege_fr = ege_fr1;
                              }
                           else
                              {
                                 ege_fr1 = ege_fr;
                                 ege_fr = 9999;

                              }
                           while (mouse_b & 1);
                           for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                        
                        }
                     if  ((mouse_y > dl_y+90) && (mouse_y < dl_y+98) && (mouse_x > 0) && (mouse_x < 82))
                        {
                           /* edit random */
                           for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                           fxinc=.01;   /* y inc */
                           fyinc=.1;   /* x inc */
                           flv= -2000;     /* lv    */
                           fuv= 2000;   /* uv    */
                             finitial = ege_fr;
                          if (edit_float(2, dl_y + 90)) ege_fr = edit_float_retval;

                       }

                  }

            }

         /* MAP */
         if (redraw[2])
            {
               redraw[2] = 0;
               for (x=0; x<100; x++)
                  for (y=0; y<100; y++)
                     {
                        d = l[x][y];
                        if (d > 255) d = 192;
                        if (d > 7) d = 166;
                        putpixel(screen, x+219, y+1, d);
                     }
               for (x=0; x<100; x++)
                  {
                     d = 80; /* default grey */
                     if (Ei[x][0])
                        {
                           if (group_edit_selection[x]) d = 1;

                           else d = 2;
                        }

                     putpixel(screen, 219 + Ef[x][0]/20, 1 + Ef[x][1]/20, d);
                  }

               if (mouse_focus == 2) d=hf; else d=rf;
               rect(screen, 218, 0, 319, 101, d );
            }
         textout(screen, font, "click and drag to select" , 10, 110, 0);
              
         if ((mouse_y > 0) && (mouse_y < 100) && (mouse_x < 319) && (mouse_x > 220))
             {
                if (mouse_focus != 2)
                   for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */

                   mouse_focus=2; /* map */

               if (mouse_b & 1)
                  {
                     for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                     textout(screen, font, "click and drag to select" , 10, 110, 244);
                     x1 = mouse_x;
                     y1 = mouse_y;
                     xor_mode(1);
                     while (mouse_b & 1)
                        {
                           x2 = mouse_x;
                           y2 = mouse_y;

                           rect(screen, x1, y1, x2, y2, 2);
                           rest(20);
                           rect(screen, x1, y1, x2, y2, 2);
                        }
                     xor_mode(0);

                     if (x1 > x2)
                        {
                           x  = x2;
                           x2 = x1;
                           x1 = x;
                        }
                       if (y1 > y2)
                        {
                           y  = y2;
                           y2 = y1;
                           y1 = y;
                        }



                     for(x=0; x<100; x++)
                        {
                           if (!key[KEY_CONTROL]) group_edit_selection[x]=0;

                           if (Ei[x][0])
                              if (Ef[x][0] > ((x1-219) * 20))

                                 if (Ef[x][0] < ((x2-219) * 20))
                                     if (Ef[x][1] > ((y1-2) * 20))
                                        if (Ef[x][1] < ((y2-2) * 20))
                                            group_edit_selection[x] = 1;

                        }
                  } /* end of if mouse _b & 1*/
             }

      /* start of LIST (4) */


       do
       {
           if (redraw[4])
              {
                 redraw[4] = 0;
                 rectfill(screen, 0, ypos-20, 319, ypos+(list_size*10), 0); /* erase old */

                 screen_column = 0;
                 screen_row = 0;
                 column_count = 0;
                 row_count = 0;
                 for (y=0; y<100; y++) /* cycle the enemies to see if they want to be on the list */
                    if (group_edit_selection[y])
                       {
                          row_count++;
                          if (row_count > first_screen_row)  /* past the start */
                             if (++screen_row < list_size)    /* before the end */
                               {
                                   screen_column = 0;
                                   column_count = 0;
                                   sprintf(msg,"%2d",y); /* enemy number */
                                   textout(screen, font, msg,2,ypos+1+(screen_row*10), hv);
   
                                   for (x=0; x<10; x++)  /* cycle the values selected.they are columns*/
                                      {
                                         if (ge_int_selection[x])
                                            if ((++column_count > first_screen_column-1) && ((screen_column*col_size) < 300))
                                               {
                                                  sprintf(msg,"Ei%d",x );
                                                  textout(screen, font, msg, xpos+32+(screen_column*col_size),ypos+1,hv); /* column title */
                                                  sprintf(msg,"                                            ");
                                                  textout(screen, font, msg,xpos+30+(screen_column*col_size),ypos+1+(screen_row*10),rv);

                                                  sprintf(msg,"%d", Ei[y][x]);
                                                  textout(screen, font, msg,xpos+32+(screen_column*col_size),ypos+1+(screen_row*10), rv);
                                                  a = 32+(strlen(msg)+1) * 8;
                                                  sprintf(msg,"%s", eitype_desc[Ei[y][0]][x]);
                                                  textout(screen, font, msg,xpos+a+(screen_column*col_size),ypos+1+(screen_row*10), vd);
   
                                                  screen_column++;
                                               }

                                      if (ge_float_selection[x])
                                         if ((++column_count > first_screen_column-1) && ((screen_column*col_size) < 300))
                                            {


                                               sprintf(msg,"Ef%d",x );
                                               textout(screen, font, msg,xpos+32+(screen_column*col_size),ypos+1,hv); /* column title */
                                               sprintf(msg,"                                            ");
                                               textout(screen, font, msg,xpos+32+(screen_column*col_size),ypos+1+(screen_row*10),rv);
                                               sprintf(msg,"%2.2f ", Ef[y][x]);
                                               textout(screen, font, msg,xpos+32+(screen_column*col_size),ypos+1+(screen_row*10),rv);
                                                  a = 32+(strlen(msg) * 8);
                                               sprintf(msg,"%s ", eftype_desc[Ei[y][0]][x]);
                                               textout(screen, font, msg,xpos+a+(screen_column*col_size),ypos+1+(screen_row*10),vd);

                                               screen_column++;
                                            }
                                   }
                          }
                    }
                  if (first_screen_column > column_count)  first_screen_column = 0;
                  if (first_screen_row > row_count)  first_screen_row = 0;


                  for (x=0; x<column_count; x++) /* column dividers */
                    vline (screen, 30+(x * col_size), -1+ypos+(list_size*10), ypos-1, hv);
        
                 for (x=0; x<list_size; x++)  /* row dividers */
                    hline (screen, 1, -1 + ypos+(x*10), 318, hv);
        
                 sprintf(msg,"EN#" );
                 textout(screen, font, msg, 2, ypos+1, hv);
        
                 if (mouse_focus == 4) d = hf; else d = rf; /* only if has focus */

                 sprintf(msg,"list of %d enemy(s) and %d variable(s)", row_count, column_count);
                 textout_centre(screen, font, msg, SCREEN_W/2, ypos-20, d);

        
                 sprintf(msg,"row+|row-|col+|col-|csz+|csz-|help|full");
                 if (full_screen_mode == 1) sprintf(msg,"row+|row-|col+|col-|csz+|csz-|help|back");

                 textout(screen, font, msg, 2, ypos-10, d);

                 /* title dividers */
                  hline (screen, 1, ypos -12, 318, d);
                  hline (screen, 1, ypos -2, 318, d);
                 /* frame */
                 rect(screen, 0, ypos-22, 319, ypos+(list_size*10),d); /* outer drawn last */

                 /* erase past bottom*/
                 if (full_screen_mode == 0) rectfill(screen, 0, 1 + ypos+(list_size*10), 319, 183,0); /* outer drawn last */
                   /* erase past bottom*/
                 if (full_screen_mode == 1) rectfill(screen, 0, 1 + ypos+(list_size*10), 319, 199,0); /* outer drawn last */




              } /* end of if redraw (list) */

           if ((mouse_y > (ypos-20) ) && (mouse_y < 184)) /* is mouse on list ? */
              {
                 if (mouse_focus != 4)
                 for (x=0; x<5; x++) redraw[x] = 1;
                 mouse_focus = 4;
              }
           if (mouse_focus == 4) /* list */
              {

                 list_menu_selection = 99;
                 if ((mouse_y > (ypos-10) ) && (mouse_y < (ypos-2))) /* is mouse on menu bar */
                    if (mouse_b & 1) list_menu_selection = ((mouse_x-2)/40);

      
      
                   if ((key[KEY_DOWN]) || (list_menu_selection == 0))
                     {
                        if (++first_screen_row > row_count-list_size+2)
                           first_screen_row = row_count-list_size+2;
                        rest(100);
                        redraw[4] = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_UP]) || (list_menu_selection == 1))
                     {
                        if (--first_screen_row < 0)
                           first_screen_row = 0;
      
                        rest(100);
                        redraw[4] = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_RIGHT]) || (list_menu_selection == 2))
                     {
                        if (++first_screen_column > column_count)
                           first_screen_column = column_count;
                        rest(100);
                        redraw[4] = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_LEFT]) || (list_menu_selection == 3))
                     {
                        if (--first_screen_column < 1)
                           first_screen_column = 1;
      
                        rest(100);
                        redraw[4] = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_PGUP]) || (list_menu_selection == 4))
                     {
                        col_size += 4;
                        rest(20);
                        redraw[4] = 1;
                        clear_keybuf();
                     }
                  if ((key[KEY_PGDN]) || (list_menu_selection == 5))
                     {
                        col_size -= 4;
                        if (col_size < 4) col_size=4;
                        rest(20);
                        redraw[4] = 1;
                        clear_keybuf();
                     }
                      if ((list_menu_selection == 6))
                     {
                        clear(screen);
                        help(15);
                        for(x=0; x<5; x++) redraw[x] = 1;
                        clear_keybuf();
                        clear(screen);
                     }
      
                  if ((list_menu_selection == 7))
                     {
                        full_screen_mode = (!full_screen_mode);
                        rest(20);
                        clear(screen);
                        if (full_screen_mode)
                           {
                              list_size = 17;
                              ypos=22;
                           }
                        else
                           {
                              list_size = 4;
                              ypos=142;
      
                           }
                        for(x=0; x<5; x++) redraw[x] = 1; /* redraw all */
                        clear_keybuf();
                     }

             } /* end of if (mouse_focus == 4) list */
           if (full_screen_mode == 1)
              {
                 show_mouse(screen);
                 rest(10);
                 show_mouse(NULL);
              }
         } while (full_screen_mode == 1);



         engry = (bottom_menu(2));   /* call the menu handler */

         if (engry == 1)  /* F2 MOVE */
            {
               clear(screen);
               do
                  {



                        sprintf(msg,"MOVE ENEMY %d ",ge_current_enemy);
                        textout(screen, font, msg, 205,122, 240);
                        textout(screen, font, "-------------", 205,130, 240);
                        textout(screen, font, "mouse b1"    ,205,138,11);
                        textout(screen, font, "MOVE",205,146,11);
                        textout(screen, font, "mouse b2/esc",205,156,10);
                        textout(screen, font, "ABORT"       ,205,164,10);



                        sprintf(msg,"x=%-2.0f ",Ef[ge_current_enemy][0] / 20);
                        textout(screen, font, msg, 272, 184, 11);
                        sprintf(msg,"y=%-2.0f ",Ef[ge_current_enemy][1] / 20);
                        textout(screen, font, msg, 272, 192, 11);

                        if (Ei[ge_current_enemy][0] == 0)
                           {
                              sprintf(msg,"inactive");
                              textout(screen, font, msg, 255,168, 3);
                           }
                        else
                           {
                              sprintf(msg,"        ");
                              textout(screen, font, msg, 255,168, 2);
                           }
                        d = getxy100(ge_current_enemy);
                        en_quit=0;
                        if (d == 0) en_quit=1;   /* pass the quit from getxy100*/
                        if (d == 1)  /* good xy */
                           {
                              Ef[ge_current_enemy][0] = get100_x * 20;
                              Ef[ge_current_enemy][1] = get100_y * 20;
                           }
                        if (d == 7) /* prev */
                           if (--ge_current_enemy < 0) ge_current_enemy = 0;

                        if (d == 8) /* next */
                           if (++ge_current_enemy > 99) ge_current_enemy = 99;

                  } while (!en_quit);
               for(x=0; x<5; x++) redraw[x] = 1;
               clear(screen);
            }
         if (engry == 2) /* F3 COPY */
            {

               en_quit=0;
               do
                  {
                     int num_empty = 0;
                     int first_empty;
                     for (c=0; c<100; c++) /* find empty and num of empty */
                        if (Ei[c][0] == 0)
                                 {
                                    num_empty++;
                                    if (num_empty == 1) first_empty = c;
                                 }
                   
                     clear(screen);
                        sprintf(msg,"COPY ENEMY %d ",ge_current_enemy);
                        textout(screen, font, msg            ,205,122,240);
                        textout(screen, font, "-------------",205,130,240);
                        textout(screen, font, "mouse b1"     ,205,138,11);
                        textout(screen, font, "COPY"         ,205,146,11);
                        textout(screen, font, "mouse b2/esc" ,205,156,10);
                        textout(screen, font, "ABORT"        ,205,164,10);

                     sprintf(msg,"%d ENEMY LEFT", num_empty);
                     textout(screen, font, msg, 205,174,12);

                     d = getxy100(ge_current_enemy);
                     if (d == 1)
                        {
                           for (x=0; x<10; x++) /* copy enemy  */
                              {
                                 Ei[first_empty][x] = Ei[ge_current_enemy][x];
                                 Ef[first_empty][x] = Ef[ge_current_enemy][x];
                              }
                           Ef[first_empty][0] = get100_x * 20;  /* set new x,y */
                           Ef[first_empty][1] = get100_y * 20;
                        }
                     if (d == 0) en_quit = 1;
                  } while (!en_quit);
               for(x=0; x<5; x++) redraw[x] = 1;
               clear(screen);
            }
         if (engry == 5)  /* F6 - PDFE */
            {
               clear(screen);
               predefined_enemies();
               for(x=0; x<5; x++) redraw[x] = 1;
               clear(screen);
            }






      } while (engry != -1);

   rest(200);
   clear(screen);
} /* end of enemy_menu();------------------------- */

