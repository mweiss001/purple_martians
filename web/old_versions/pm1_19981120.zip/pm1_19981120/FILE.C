/* FILE.C   this does all the file handling */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>

extern int num_of_shapes;

/* functions
   make_filename(int x, int y)
   load(int d, int e, int f, int g, int h)
   save(int d, int e, int f, int g, int h)
*/


void make_filename(int y, int x)
{
char sprit_filename[20];
char level_filename[20];

extern int level_num, sprit_num;
extern char buff[20]; /* cuz I'm to dum to pass a string  */
char msg[80];
  switch (y)
   {
      case 0:
         strcpy( buff, "LEVEL");
      break;
      case 1:
         strcpy( buff, "SPRIT");
      break;

   };

if ((x > 9) && (x < 100)) sprintf(msg,"0%-2d", x);
if (x < 10) sprintf(msg,"00%-1d", x);
if (x > 99) sprintf(msg,"%-3d", x);
strcat( buff, msg);
strcat( buff, ".XXX");
switch (y)
   {
      case 0:
         strcpy(level_filename, buff);
      break;
      case 1:
         strcpy(sprit_filename, buff);
      break;
   };
}
int save_sprit(int sprit_to_save)
{
FILE *filepntr;
char sprit_filename[20];
extern BITMAP *memory_bitmap[512];
extern PALLETE pallete;
extern int zz[20][64];
int sprit_load_error = 0;
int c, x, y;
extern char buff[20]; /* for make filename, cuz I'm to dum to pass a string!  */
char msg[80];

make_filename(1, sprit_to_save);   /* update filename */
strcpy(sprit_filename, buff);

     for (c=0; c<64; c++)    /* set all to initial */
        if (zz[4][c] != 0)
           {
              zz[0][c]=zz[5][c];
              zz[1][c]=0;
              zz[2][c]=0;
           }

     filepntr = fopen( sprit_filename,"wb");
     for (c=0; c<512; c++)
        for (y=0; y<20; y++)
             for (x=0; x<20; x++)
                fputc(getpixel(memory_bitmap[c],x,y), filepntr);
     for (c=0; c<256; c++)
        {
           fputc(pallete[c].r, filepntr);
           fputc(pallete[c].g, filepntr);
           fputc(pallete[c].b, filepntr);
        }
     for (c=0; c<64; c++)
        for (y=0; y<20; y++)
           {
              if (zz[y][c] > 255)
                 {
                    fputc(1, filepntr);
                    fputc(zz[y][c]-256, filepntr);
                 }
              else
                 {
                    fputc(0, filepntr);
                    fputc(zz[y][c], filepntr);
                 }
           }




     fclose(filepntr);
}


int save_level(level_to_save)
{
FILE *filepntr;
char level_filename[20];
extern char buff[20]; /* for make filename  */

extern char level_text[100][40];
extern int level_header[20];
extern int l[100][100];
extern int item[500][16];
extern int Ei[100][10];
extern float Ef[100][10];

extern int mov_ob[20][20];
extern int mov_obi[20][20][4];

int c, x, y;

make_filename(0, level_to_save);   /* update filename */
strcpy(level_filename, buff);

                      filepntr = fopen(level_filename,"w");


                           for (x=0; x<20; x++)
                              fprintf(filepntr,"%d\n",level_header[x]);

                           for (c=0; c<100; c++)  /* level */
                              for (x=0; x<100; x++)
                                   fprintf(filepntr,"%d\n",l[c][x]);

                           for (c=0; c < level_header[3]; c++) /* item */
                              for (x=0; x<16; x++)
                                   fprintf(filepntr,"%d\n",item[c][x]);

                           for (c=0; c < level_header[4]; c++)  /* enemy float */
                               for (x=0; x<10; x++)
                                    fprintf(filepntr,"%f\n",Ef[c][x]);
                           for (c=0; c < level_header[4]; c++) /* enemy int */
                               for (x=0; x<10; x++)
                                    fprintf(filepntr,"%d\n",Ei[c][x]);


                           /* moveable objects */

                           for (c=0; c < level_header[5]; c++) /* mov_ob */
                              for (x=0; x<20; x++)
                                    fprintf(filepntr,"%d\n",mov_ob[c][x]);

                           for (c=0; c < level_header[5]; c++) /* mov_obi */
                              for (x=0; x<20; x++)
                                  for (y=0; y<4; y++)
                                     fprintf(filepntr,"%d\n",mov_obi[c][x][y]);


                           for (c=0; c < level_header[6]; c++) /* enemy text */
                              fprintf(filepntr,"%s\n",level_text[c]);

                           fclose(filepntr);
}
int load_sprit(int sprit_to_load, int display)
{
FILE *filepntr;
char sprit_filename[20];
extern BITMAP *memory_bitmap[512];
extern PALLETE pallete;
extern int zz[20][64];

int sprit_load_error = 0;
int c, x, y;
extern char buff[20]; /* for make filename, cuz I'm to dum to pass a string!  */
char msg[80];

make_filename(1, sprit_to_load);   /* update filename */
strcpy(sprit_filename, buff);

                        if (display) textout(screen, font, "Loading shapes...", 16, 184, 1);
                        sprit_load_error = 0;
                        if ((exists(sprit_filename)) == 0) /* does file exist? */
                           {
                              sprintf(msg, "Can't find sprit %s ", sprit_filename);
                              textout(screen, font, msg, 0, 184, 1);
                              sprit_load_error = 1;
                           }
                        if (!sprit_load_error)  /* open file */
                           if ((filepntr=fopen(sprit_filename,"rb")) == NULL)
                              {
                                 sprintf(msg, "Error opening %s ", sprit_filename);
                                 textout(screen, font, msg, 0, 184, 1);
                                 sprit_load_error = 1;
                              }
                        if (!sprit_load_error)  /* file open ! */
                           {
                              for (c=0; c<512; c++)   /* 512 bitmaps */
                                 {
                                    sprintf(msg,".%d ", 512-c);
                                    if (display) textout(screen, font, msg, 152, 184, 1);

                                    for (y=0; y<20; y++)
                                       for (x=0; x<20; x++)
                                          putpixel(memory_bitmap[c],x,y, fgetc(filepntr));

                                  }
                              for (c=0; c<256; c++)      /* 256 colors */
                                    {
                                       pallete[c].r = fgetc(filepntr);
                                       pallete[c].g = fgetc(filepntr);
                                       pallete[c].b = fgetc(filepntr);
                                    }
                              for (c=0; c<64; c++)
                                 for (y=0; y<20; y++)
                                    {
                                       x = fgetc(filepntr);
                                       if (x) zz[y][c] = 256 + fgetc(filepntr);
                                       else   zz[y][c] = fgetc(filepntr);
                                    }
                           } /* end of if not sprit load error */
                        fclose(filepntr);
                        set_pallete(pallete);
        if  (sprit_load_error)
               {
                  rest(2000);
                  return 0;
               }
        else return 1;
}

int load_level(int level_to_load, int display)
{
FILE *filepntr;
char level_filename[20];
extern char level_text[100][40];
extern int level_header[20];
extern int l[100][100];
extern int item[500][16];
extern int Ei[100][10];
extern float Ef[100][10];
extern int mov_ob[20][20];
extern int mov_obi[20][20][4];
int level_load_error = 0;
int loop, ch, c, x, y;
extern char buff[20]; /* for make filename, cuz I'm to dum to pass a string!  */
char msg[80];

   /* erase all old data */
   for (x=0; x<20; x++)
      level_header[x] = 0;
   
   for (c=0; c<100; c++)  /* level */
      for (x=0; x<100; x++)
           l[c][x] = 0;
   
   for (c=0; c < 500; c++) /* item */
      for (x=0; x<16; x++)
         item[c][x] = 0;
   
   for (c=0; c < 100; c++)  /* enemy float */
       for (x=0; x<10; x++)
            Ef[c][x] = 0;
   for (c=0; c < 100; c++) /* enemy int */
       for (x=0; x<10; x++)
            Ei[c][x] = 0;
   
   for (c = 0; c < 20; c++)
      for (x = 0; x < 20; x++)
         mov_ob[c][x] = 0;
   
   for (c = 0; c < 20; c++)
      for (x = 0; x < 20; x++)
         for (y = 0; y < 4; y++)
            mov_obi[c][x][y] = 0;

   make_filename(0, level_to_load);   /* update filename */
   strcpy(level_filename, buff);
   if (display)
      {
         rectfill(screen, 30, 176, 290, 184, 0);
         sprintf(msg, "...loading level %d...", level_to_load);
         textout_centre(screen, font, msg, SCREEN_W/2, 176, 245);
         rest(200);
      }
   level_load_error = 0;
   if ((exists(level_filename)) == 0)
      {
         sprintf(msg, "Can't Find Level %s ", level_filename);
         textout_centre(screen, font, msg, SCREEN_W/2, 160, 1);
         level_load_error = 1;
      }
   if (!level_load_error) /* file exists */
      {
         if ((filepntr=fopen(level_filename,"r")) == NULL)
            {
               sprintf(msg, "Error opening %s ", level_filename);
               textout(screen, font, msg, 0, 160, 1);
               level_load_error = 1;
            }
         if (!level_load_error)  /* file open ! */
            {
               for (c=0; c<20; c++) /* level header */
                  {
                     loop = 0;
                     ch = fgetc(filepntr);
                     while((ch != '\n') && (ch != EOF))
                        {
                           buff[loop] = ch;
                           loop++;
                           ch = fgetc(filepntr);
                        }
                     buff[loop] = NULL;
                     level_header[c] = atoi(buff);
                     if (ch == EOF)
                        {
                           sprintf(msg, "Error reading %s ", level_filename);
                           textout(screen, font, msg, 0, 160, 1);
                           rest(3000);
                           level_load_error = 1;
                        }
                  }
               for (c=0; c<100; c++)  /* l[100][100] */
                  for (y=0; y<100; y++)
                     {
                        loop = 0;
                        ch = fgetc(filepntr);
                        while((ch != '\n') && (ch != EOF))
                           {
                               buff[loop] = ch;
                               loop++;
                               ch = fgetc(filepntr);
                           }
                        buff[loop] = NULL;
                        l[c][y] = atoi(buff);
                        if (ch == EOF)
                           {
                              sprintf(msg, "Error reading %s ", level_filename);
                              textout(screen, font, msg, 0, 160, 1);
                              rest(3000);
                              level_load_error = 1;
                           }
                     }
               if (!level_load_error)
                  {
                     for (c = 0; c < level_header[3]; c++)  /* read item */
                        for (x = 0; x < 16; x++)
                           {
                              loop = 0;
                              ch = fgetc(filepntr);
                              while((ch != '\n') && (ch != EOF))
                                 {
                                     buff[loop] = ch;
                                     loop++;
                                     ch = fgetc(filepntr);
                                 }
                              buff[loop] = NULL;
                              item[c][x] = atoi(buff);
                              if (ch == EOF)
                                 {
                                    sprintf(msg, "Error reading items in %s ", level_filename);
                                    textout(screen, font, msg, 0, 168, 1);
                                    rest(3000);
                                    level_load_error = 1;
                                 }
                           }
                  }
               if (!level_load_error)
                  {
                     for (c=0; c<level_header[4]; c++) /* read enemy floats */
                        for (x=0; x<10; x++)
                           {
                              loop = 0;
                              ch = fgetc(filepntr);
                              while((ch != '\n') && (ch != EOF))
                                 {
                                    buff[loop] = ch;
                                    loop++;
                                    ch = fgetc(filepntr);
                                 }
                              buff[loop] = NULL;
                              Ef[c][x] = atof(buff);
                              if (ch == EOF)
                                 {
                                    sprintf(msg, "Error reading Ef in %s ", level_filename);
                                    textout(screen, font, msg, 0, 176, 1);
                                    rest(3000);
                                    level_load_error = 1;
                                 }
                           }

                     for (c=0; c < level_header[4]; c++)  /* enemy ints */
                        for (x=0; x<10; x++)
                           {
                              loop = 0;
                              ch = fgetc(filepntr);
                              while((ch != '\n') && (ch != EOF))
                                 {
                                     buff[loop] = ch;
                                     loop++;
                                     ch = fgetc(filepntr);
                                 }
                              buff[loop] = NULL;
                              Ei[c][x] = atoi(buff);
                              if (ch == EOF)
                                 {
                                    sprintf(msg, "Error reading Ei in %s ", level_filename);
                                    textout(screen, font, msg, 0, 176, 1);
                                    rest(3000);
                                    level_load_error = 1;
                                 }

                           }
                  }
               if (!level_load_error)
                  {
                     for (c=0; c<level_header[5]; c++) /* read mov_ob */
                        for (x=0; x<20; x++)
                            {
                               loop = 0;
                               ch = fgetc(filepntr);
                               while((ch != '\n') && (ch != EOF))
                                  {
                                      buff[loop] = ch;
                                      loop++;
                                      ch = fgetc(filepntr);
                                  }
                               buff[loop] = NULL;
                               mov_ob[c][x] = atoi(buff);
                               if (ch == EOF)
                                  {
                                     sprintf(msg, "Error reading mov_ob[%d][%d] in %s ", level_filename, c, x);
                                     textout(screen, font, msg, 0, 176, 1);
                                     rest(3000);
                                     level_load_error = 1;
                                  }
                             }
                  }
               if (!level_load_error)
                  {
                     for (c=0; c<level_header[5]; c++) /* read mov_obi[20][10][4] */
                        for (x=0; x<20; x++)
                         for (y=0; y<4; y++)
                           {
                              loop = 0;
                              ch = fgetc(filepntr);
                              while((ch != '\n') && (ch != EOF))
                                 {
                                     buff[loop] = ch;
                                     loop++;
                                     ch = fgetc(filepntr);
                                 }
                              buff[loop] = NULL;
                              mov_obi[c][x][y] = atoi(buff);
                              if (ch == EOF)
                                 {
                                    sprintf(msg, "Error reading mov_obi[%d][%d][%d] in %s ", level_filename, c, x);
                                    textout(screen, font, msg, 0, 176, 1);
                                    rest(3000);
                                    level_load_error = 1;
                                 }
                            }
                  }
               if (!level_load_error)
                  {
                     for (c=0; c < level_header[6]; c++)  /* level text */
                        {
                           loop = 0;
                           ch = fgetc(filepntr);
                           while((ch != '\n') && (ch != EOF))
                              {
                                 level_text[c][loop] = ch;
                                 loop++;
                                 ch = fgetc(filepntr);
                              }
                           level_text[c][loop] = NULL;
                           if (ch == EOF)
                              {
                                 sprintf(msg,"Err read lvltxt %d %d %d", loop, c, x);
                                 textout(screen, font, msg, 0, 176, 1);
                                 rest(3000);
                              }
                        }
                  }
               fclose(filepntr);
            } /* end of file open */
      } /* end of if exists */

   if (level_load_error)
      {
         rest(3000);
         return 0;
      }
   else return 1;

}



int load(int d, int e, int f, int g, int h)
{

char sprit_filename[20];
char level_filename[20];

extern int level_num, sprit_num;
extern int edit_int_retval;
extern char buff[20]; /* cuz I'm to dum to pass a string  */
int level_load_error = 0, sprit_load_error = 0;

FILE *filepntr;


int load_lev;
int do_load=0;
int complex_load = 0;
int b=2;
int loop, ch, fexit, c, x, y;
char msg[80];

         do_load = d;

         if (do_load)
            {
               level_num = e;
               sprit_num = h;
            }
         show_mouse(NULL);
         fexit = do_load;

         if (do_load) complex_load = 1; /* just for the display */
         if (!complex_load)
            {
               load_lev = level_num;
               sprit_num=0;
            }
         if (load_lev < 1) load_lev = 1;
         do
            {

                if (!complex_load)
                   {

                      sprintf(msg, "LOAD LEVEL %d", load_lev);
                      if (b == 0) c = 2; else c=34; /* green*/
                      textout(screen, font, msg, 60, 84, c);
                      if (b == 1) c = 2; else c=34; /* green*/
                      textout(screen, font, "DO IT !", 100, 92, c);
                      if (b == 2) c = 2; else c=34; /* green*/
                      textout(screen, font, "EXIT LOAD", 100, 100, c);

                      if (key[KEY_ENTER])
                         {
                            clear_keybuf();
                            if (b == 1)
                               {
                                  level_num=load_lev;

                                  make_filename(0, load_lev);   /* update filename */
                                  strcpy(level_filename, buff);

                                  do_load = 1;
                                  fexit = 1;
                               }
                            if (b == 2) fexit = 1;
                         }
                      if ((key[KEY_CONTROL]) && (key[KEY_INSERT]))
                         {
                            clear_keybuf();
                            clear(screen);
                            complex_load = 1;
                            b = 3;
                         }
                      if (key[KEY_UP])
                         {
                            clear_keybuf();
                            if (--b < 0) b = 0;
                         }
                      if (key[KEY_DOWN])
                         {
                            clear_keybuf();
                            if (++b > 2) b = 2;
                         }
                      if (key[KEY_RIGHT])
                         {
                            clear_keybuf();
                            if (++load_lev > 99) load_lev = 99;
                         }
                      if (key[KEY_LEFT])
                         {
                            clear_keybuf();
                            if (--load_lev < 1) load_lev = 1;
                         }
                
                       c = 0;  /*  mouse handling crap    */
                      show_mouse(screen);
                      rest(10);
                      show_mouse(NULL);
      
                      if ((mouse_x > 100) && (mouse_x<180) && (mouse_y>84) && (mouse_y<108) && (mouse_b & 1) )  /* on menu and b1  */
                         {
                            b = ((mouse_y - 84) / 8);  /* pointer update */
                            if (b == 2) fexit = 1;
                            if (b == 1)
                               {
                                  level_num=load_lev;
                                  make_filename(0, load_lev);   /* update filename */
                                  strcpy(level_filename, buff);
                                  textout(screen, font, "LOADING...   ", 100, 92, 1);
                                  rest(200);
                                  do_load = 1;
                                  fexit = 1;
                               }
                            if (b == 0)
                               if (edit_int(148, 84, load_lev, 1, 1, 99))
                                  load_lev = edit_int_retval;
      

                         } /* end of if (mouse pressed on menu) */
                   }
                if (complex_load)
                   {
                      make_filename(0, level_num);   /* update filename */
                      strcpy(level_filename, buff);
                      make_filename(1, sprit_num);
                      strcpy(sprit_filename, buff);
                     if (!do_load)
                         {
                   
                      if (level_num < 1) sprintf(msg,"[ ] %s ",level_filename);
                      else sprintf(msg,"[X] %s ",level_filename);
                      if (b == 0) c = 2; else c=34; /* green */
                      textout(screen, font, msg, 100, 60, c);

                      if (sprit_num < 1) sprintf(msg,"[ ] %s ",sprit_filename);
                      else sprintf(msg,"[X] %s ",sprit_filename);
                      if (b == 1) c = 2; else c=34; /* green*/
                      textout(screen, font, msg, 100, 68, c);

                             if (b == 2) c = 2; else c=34; /* green*/
                            textout(screen, font, "LOAD config?", 100, 76, c);
                            if (b == 3) c = 2; else c=34; /* green*/
                            textout(screen, font, "EXIT LOAD", 100, 84, c);
                          }

                   
                c = 0;  /*  mouse handling crap    */
                show_mouse(screen);
                rest(10);
                show_mouse(NULL);
                if ((mouse_x > 100) && (mouse_x<180) && (mouse_y>60) && (mouse_y<92)) c = 1; /* mouse on menu */
                if ( (c == 1) && (mouse_b & 1) )  /* on menu and b1  */
                   {
                      b = ((mouse_y - 60) / 8);  /* pointer update */
                      if (b == 2)
                           {
                               textout(screen, font, "LOADING...   ", 100, 92, 1);
                               rest(200);
                               do_load = 1;
                               fexit = 1;
                           }
                      if (b == 3) fexit = 1;

                      if (b < 2)
                         {
                            do
                               {

                                  c = mouse_x;
                                  show_mouse(screen);
                                  rest(10);
                                  show_mouse(NULL);
                                  c = mouse_x - c;
                                  if (b == 0)
                                     {
                                        level_num = level_num + c;
                                        if (level_num > 999) level_num = 999;
                                        if (level_num < 0) level_num = 0;
                                        make_filename(b, level_num);
                                        strcpy(level_filename, buff);
                                        if (level_num < 1) sprintf(msg,"[ ] %s ",level_filename);
                                        else sprintf(msg,"[X] %s ",level_filename);
                                        textout(screen, font, msg, 100, 60, 2);
                                     }
                                  if (b == 1)
                                     {
                                        sprit_num = sprit_num + c;
                                        if (sprit_num > 999) sprit_num = 999;
                                        if (sprit_num < 0) sprit_num = 0;
                                        make_filename(b, sprit_num);
                                        strcpy(sprit_filename, buff);
                                        if (sprit_num < 1) sprintf(msg,"[ ] %s ",sprit_filename);
                                        else sprintf(msg,"[X] %s ",sprit_filename);
                                        textout(screen, font, msg, 100, 84, 2);
                                     }
                         


                                }  while (mouse_b & 1);
                         }

                   }
                if (key[KEY_ENTER])
                   {
                      clear_keybuf();
                      if (b == 2)
                         {
                             do_load = 1;
                             fexit = 1;
                         }
                      if (b == 3) fexit = 1;

                   }
                if ((key[KEY_CONTROL]) && (key[KEY_INSERT]))
                   {
                      clear_keybuf();
                      clear(screen);
                      complex_load = 0;
                      b=2;

                   }
                if (key[KEY_UP])
                   {
                      clear_keybuf();
                      if (--b < 0) b = 0;
                   }
                if (key[KEY_DOWN])
                   {
                      clear_keybuf();
                      if (++b > 3) b = 3;
                   }
                if (key[KEY_RIGHT])
                   {
                      clear_keybuf();
                      switch (b) {
                                    case 0: if (++level_num>999) level_num=999;
                                    make_filename(b,level_num);
                                    strcpy(level_filename, buff);
                                    break;

                                    case 1: if (++sprit_num>999) sprit_num=999;
                                    make_filename(b, sprit_num);
                                    strcpy(sprit_filename, buff);
                                    break;

                                 }

                   }
                if (key[KEY_LEFT])
                   {
                      clear_keybuf();
                      switch (b) {
                                    case 0: if (--level_num<0) level_num=0;
                                    make_filename(b, level_num);
                                    strcpy(level_filename, buff);
                                    break;

                                    case 1: if (--sprit_num<0) sprit_num=0;
                                    make_filename(b, sprit_num);
                                    strcpy(sprit_filename, buff);
                                    break;
                                 } /* end of switch case */
                  }   /* end of left */
              } /*   end of  if (complex_load)      */
           } while ((!fexit) && (!key[KEY_ESC]));




            if (do_load)
               {

                  if (level_num) load_level(level_num,1);
                  if (sprit_num) load_sprit(sprit_num,1);
               }

            if ( (level_load_error) || (sprit_load_error) )
               {
                  rest(2000);
                  return 0;
               }
            else return 1;

            show_mouse(NULL);

} /* end of LOAD  */


void save(int d, int e, int f, int g, int h)
{
char level_filename[20], sprit_filename[20];
extern int level_num, sprit_num;
extern int level_header[20];
extern int l[100][100];
extern int item[500][16];
extern int Ei[100][10];
extern float Ef[100][10];
extern BITMAP *memory_bitmap[512];
extern PALLETE pallete;
extern int zz[20][64];
extern char buff[20];

FILE *filepntr;
int do_save = 0;
int fexit, b, c, x, y;
char msg[80];

do_save = d;

      level_num = e;
      sprit_num = h;
      level_header[3] = item_sort(); /* num_of_items   */
      level_header[4] = sort_enemy(); /* num_of_enemies   */
      level_header[5] = sort_mov(); /* num_of_mov_ob   */

         b = 3;
         fexit = do_save;
         show_mouse(NULL);
         do
            {
                make_filename(0, level_num);   /* update filename */
                strcpy(level_filename, buff);
                make_filename(1, sprit_num);
                strcpy(sprit_filename, buff);
                if (level_num < 1) sprintf(msg,"[ ] %s ",level_filename);
                else sprintf(msg,"[X] %s ",level_filename);
                if (b == 0) c = 1; else c=17; /* red  */
                textout(screen, font, msg, 100, 60, c);

                if (sprit_num < 1) sprintf(msg,"[ ] %s ",sprit_filename);
                else sprintf(msg,"[X] %s ",sprit_filename);
                if (b == 3) c=1; else c=17;
                textout(screen, font, msg, 100, 68, c);

                if (b == 2) c=1; else c=17;
                textout(screen, font, "SAVE config?", 100, 76, c);
                if (b == 3) c=1; else c=17;
                textout(screen, font, "EXIT SAVE", 100, 84, c);

                sprintf(msg,"%d ITEM    ",level_header[3]);
                textout(screen, font, msg, 100, 120, c);
                sprintf(msg,"%d ENEMIES ",level_header[4]);
                textout(screen, font, msg, 100, 128, c);
                sprintf(msg,"%d MOV_OBJECT ",level_header[5]);
                textout(screen, font, msg, 100, 136, c);
                sprintf(msg,"%d LEVEL_TEXT ",level_header[6]);
                textout(screen, font, msg, 100, 144, c);

                c = 0;  /*  mouse handling crap    */
                show_mouse(screen);
                rest(10);
                show_mouse(NULL);
                if ((mouse_x > 100) && (mouse_x<180) && (mouse_y>60) && (mouse_y<92)) c = 1; /* mouse on menu */
                if ( (c == 1) && (mouse_b & 1) )  /* on menu and b1  */
                   {
                      b = ((mouse_y - 60) / 8);  /* pointer update */
                      if (b == 2)
                           {
                               textout(screen, font, "SAVE config?", 100, 92, 240);
                               rest(200);
                               do_save = 1;
                               fexit = 1;
                           }
                      if (b == 3) fexit = 1;
                      if (b < 2)
                         {
                            do
                               {
                                  c = mouse_x;
                                  show_mouse(screen);
                                  rest(10);
                                  show_mouse(NULL);
                                  c = mouse_x - c;
                                  if (b == 0)
                                     {
                                        level_num = level_num + c;
                                        if (level_num > 999) level_num = 999;
                                        if (level_num < 0) level_num = 0;
                                        make_filename(b, level_num);
                                        strcpy(level_filename, buff);
                                        if (level_num < 1) sprintf(msg,"[ ] %s ",level_filename);
                                        else sprintf(msg,"[X] %s ",level_filename);
                                        textout(screen, font, msg, 100, 60, 2);
                                     }
                                  if (b == 1)
                                     {
                                        sprit_num = sprit_num + c;
                                        if (sprit_num > 999) sprit_num = 999;
                                        if (sprit_num < 0) sprit_num = 0;
                                        make_filename(b, sprit_num);
                                        strcpy(sprit_filename, buff);
                                        if (sprit_num < 1) sprintf(msg,"[ ] %s ",sprit_filename);
                                        else sprintf(msg,"[X] %s ",sprit_filename);
                                        textout(screen, font, msg, 100, 84, 2);
                                     }

                                }  while (mouse_b & 1);
                         }
                   }
                if (key[KEY_ENTER])
                   {
                      clear_keybuf();
                      if (b == 2)
                         {
                             do_save = 1;
                             fexit = 1;
                         }
                      if (b == 3) fexit = 1;
                   }
                if (key[KEY_UP])
                   {
                      clear_keybuf();
                      if (--b < 0) b = 0;
                   }
                if (key[KEY_DOWN])
                   {
                      clear_keybuf();
                      if (++b > 3) b = 3;
                   }
                if (key[KEY_RIGHT])
                   {
                      clear_keybuf();
                      switch (b) {
                                    case 0: if (++level_num>999) level_num=999;
                                    make_filename(b,level_num);
                                    strcpy(level_filename, buff);
                                    break;

                                    case 1: if (++sprit_num>999) sprit_num=999;
                                    make_filename(b, sprit_num);
                                    strcpy(sprit_filename, buff);
                                    break;
        
                                 }

                   }
                if (key[KEY_LEFT])
                   {
                      clear_keybuf();
                      switch (b) {
                                    case 0: if (--level_num<0) level_num=0;
                                    make_filename(b, level_num);
                                    strcpy(level_filename, buff);
                                    break;

                                    case 1: if (--sprit_num<0) sprit_num=0;
                                    make_filename(b, sprit_num);
                                    strcpy(sprit_filename, buff);
                                    break;
                                 } /* end of switch case */
                   }   /* end of left */
                } while ((!fexit) && (!key[KEY_ESC]));
             if (do_save)
               {
                  if (level_num) save_level(level_num);
                  if (sprit_num) save_sprit(sprit_num);
                  do_save=0;
               }

}
