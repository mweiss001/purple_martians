
/* this file will have the bitmap shit from ect for now
   and maybe the bm stuff later */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>



void initialize_zz(void)
{
   extern int passcount;
   extern int zz[20][64];
   int c;
   for (c=0; c<64; c++)
      zz[2][c]=0;  /* reset the passcount */
   passcount = 0;
}

void update_animation(void)
{
   extern int passcount;
   extern int zz[20][64];
   int y;
   passcount++;   /* animation update */
   for (y=0; y<64; y++)
      if (zz[4][y] != 0)
         if ((passcount - zz[2][y]) > zz[3][y])
            {
               zz[1][y]++;     /* next bitmap */
               zz[2][y] = passcount;      /* set counter */
               if (zz[1][y] > zz[4][y]) zz[1][y] = 0;    /* is bitmap past end? */
               zz[0][y] = zz[ 5 + zz[1][y] ] [y];      /* put shape in 0 */
            }
}



void draw_color_selection_pallete()
     {
     int x,y;
     show_mouse(NULL);
       for (y=0; y<16; y++)
           for (x=0; x<16; x++)
               rectfill(screen,(x*4),((y*4)+90),((x*4)+3),((y*4)+93),((y*16)+x));
     }
void draw_current_image(BITMAP *memory_bitmap_current,int current_bmp_index)
{
   extern BITMAP *memory_bitmap[512];
   int x, y;
   show_mouse(NULL);
   for (y=0; y<20; y++)  /* draw the 8x image */
     for (x=0; x<20; x++)
        rectfill(screen,((x*8)+160),(y*8),((x*8)+167),((y*8)+7),getpixel(memory_bitmap_current,x,y));
}
void bm_flip_x_axis(int bmp_index)
{
        extern BITMAP *memory_bitmap[512];
        int x,y;
        BITMAP *temp_bitmap;
        temp_bitmap = create_bitmap(20,20);
        rest(100);
        for (x=0; x<20; x++)
            for (y=0; y<20; y++)
               putpixel(temp_bitmap, x, y, (getpixel(memory_bitmap[bmp_index], 19-x, y)) );
        for (x=0; x<20; x++)
            for (y=0; y<20; y++)
               putpixel(memory_bitmap[bmp_index], x, y, (getpixel(temp_bitmap,x,y)) );
       destroy_bitmap(temp_bitmap);
       draw_current_image(memory_bitmap[bmp_index],bmp_index);
}
void bm_flip_y_axis(int bmp_index)
{
        extern BITMAP *memory_bitmap[512];
        BITMAP *temp_bitmap;
        int x, y;
        temp_bitmap = create_bitmap(20,20);
        rest(100);
        for (x=0; x<20; x++)
            for (y=0; y<20; y++)
               putpixel(temp_bitmap, x, y, (getpixel(memory_bitmap[bmp_index], x, 19-y)) );
        for (x=0; x<20; x++)
            for (y=0; y<20; y++)
               putpixel(memory_bitmap[bmp_index], x, y, (getpixel(temp_bitmap,x,y)) );
       destroy_bitmap(temp_bitmap);
       draw_current_image(memory_bitmap[bmp_index],bmp_index);
   }


void bm_scroll_up(int bmp_index)
{
extern BITMAP *memory_bitmap[512];
int temp, x, y;
for (x=0; x<20; x++)
            {
            temp=getpixel(memory_bitmap[bmp_index],x,0);
            for (y=0; y<19; y++)
                putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x,y+1)) );
            putpixel(memory_bitmap[bmp_index],x,19,temp);
            draw_current_image(memory_bitmap[bmp_index],bmp_index);
            }
}
void bm_scroll_down(int bmp_index)
{
extern BITMAP *memory_bitmap[512];
int temp, x, y;
        for (x = 0; x < 20; x++)
            {
            temp=getpixel(memory_bitmap[bmp_index],x,19);
            for (y=19; y>0; y--)
                putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x,y-1)) );
            putpixel(memory_bitmap[bmp_index],x,0,temp);
            draw_current_image(memory_bitmap[bmp_index],bmp_index);
            }
}
void bm_scroll_left(int bmp_index)
{
extern BITMAP *memory_bitmap[512];
int temp, x, y;
        for (y = 0; y < 20; y++)
            {
            temp=getpixel(memory_bitmap[bmp_index],0,y);
            for (x=0; x<19; x++)
                putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x+1,y)) );
            putpixel(memory_bitmap[bmp_index],19,y,temp);
            draw_current_image(memory_bitmap[bmp_index],bmp_index);
            }
}
void bm_scroll_right(int bmp_index)
{
extern BITMAP *memory_bitmap[512];
int temp, x, y;
        for (y = 0; y < 20; y++)
            {
            temp=getpixel(memory_bitmap[bmp_index],19,y);
            for (x=19; x>0; x--)
                putpixel(memory_bitmap[bmp_index],x,y, (getpixel(memory_bitmap[bmp_index],x-1,y)) );
            putpixel(memory_bitmap[bmp_index],0,y,temp);
            draw_current_image(memory_bitmap[bmp_index],bmp_index);
            }
   }

void edit_pallete(int b_color)
{
   extern PALLETE pallete;
   int put_color = b_color;

   char msg[80];
   clear (screen);
   sprintf(msg,"EDIT PALLETE") ;
   textout(screen, font, msg, 100, 16, 255);
   pallete[252].r = pallete[b_color].r; /* set temp color to red value */
   pallete[252].g = 0;
   pallete[252].b = 0;
   pallete[253].r = 0;
   pallete[253].g = pallete[b_color].g; /* set temp color to green value */
   pallete[253].b = 0;
   pallete[254].r = 0;
   pallete[254].g = 0;
   pallete[254].b = pallete[b_color].b; /* set temp color to blue value */
   set_pallete(pallete);
   draw_color_selection_pallete();
   do
      {
         rectfill(screen,80, 80, 320, 160, b_color);

         if ((mouse_x < 64) && (mouse_y >89)  && (mouse_y < 154))
            {
               sprintf(msg,"color=%-4d",(((mouse_x) / 4) + (((mouse_y - 90) / 4) * 16))) ;
               textout(screen, font, msg, 0, 155, (((mouse_x) / 4) + (((mouse_y - 90) / 4) * 16) ) );
            }
         rectfill(screen,100, 28, 290, 38, 252); /* red rect */
         if ((mouse_y > 26) && (mouse_y < 38) && (mouse_x > 100))
            {
               sprintf(msg,"red=%-4d", (mouse_x - 100) / 3 );
               textout(screen, font, msg, 0, 28, 1 );
            }
         else
            {
              sprintf(msg,"red=%-4d", pallete[b_color].r);
              textout(screen, font, msg, 0, 28, 1 );
              rectfill(screen,(((pallete[b_color].r) * 3) + 100), 28,(((pallete[b_color].r) * 3) + 101), 38, 255);
            }
            rectfill(screen,100, 40, 290, 50, 253);
         if ((mouse_y > 38) && (mouse_y < 50) && (mouse_x > 100))
            {
              sprintf(msg,"green=%-4d", (mouse_x - 100) / 3 );
              textout(screen, font, msg, 0, 40, 2 );

            }
         else
            {
               sprintf(msg,"green=%-4d", pallete[b_color].g);
               textout(screen, font, msg, 0, 40, 2 );
               rectfill(screen,(((pallete[b_color].g) * 3) + 100), 38,(((pallete[b_color].g) * 3) + 101), 48, 255);
            }
         rectfill(screen,100, 52, 290, 62, 254);

            if ((mouse_y > 50) && (mouse_y < 62) && (mouse_x > 100))
            {
               sprintf(msg,"blue=%-4d", (mouse_x - 100) / 3 );
               textout(screen, font, msg, 0, 52, 3 );
            }
         else
            {
               sprintf(msg,"blue=%-4d", pallete[b_color].b);
               textout(screen, font, msg, 0, 52, 3 );
               rectfill(screen,(((pallete[b_color].b) * 3) + 100), 50, (((pallete[b_color].b) * 3) + 101), 60, 255);
            }
         show_mouse(screen);
         rest(10);
         show_mouse(NULL);
         if ((mouse_b & 1) && (key[KEY_CONTROL]))
            {
               if ( (mouse_x < 64) && (mouse_y >89)  && (mouse_y < 154))
                  {
                     put_color=(((mouse_x) / 4) + (((mouse_y - 90) / 4) * 16) );
                     pallete[252].r = pallete[b_color].r; /* set temp color to red value */
                     pallete[252].g = 0;
                     pallete[252].b = 0;
                     pallete[253].r = 0;
                     pallete[253].g = pallete[b_color].g; /* set temp color to green value */
                     pallete[253].b = 0;
                     pallete[254].r = 0;
                     pallete[254].g = 0;
                     pallete[254].b = pallete[b_color].b; /* set temp color to blue value */
                     pallete[put_color].r = pallete[b_color].r ;
                     pallete[put_color].g = pallete[b_color].g ;
                     pallete[put_color].b = pallete[b_color].b ;
                        set_pallete(pallete);
                     draw_color_selection_pallete();
                  }
            }
         if (mouse_b & 1)
            {

               if ((mouse_x < 64) && (mouse_y >89)  && (mouse_y < 154)) /* get the color from the 8x8 color square */
                  {
                     b_color=(((mouse_x) / 4) + (((mouse_y - 90) / 4) * 16) ) ;
                  }
               if (mouse_x > 100) /* mouse is in the bars */
                  {
                     if ((mouse_y > 25) && (mouse_y < 38) ) pallete[b_color].r = ((mouse_x - 100) / 3 );/* red bar */
                     if ((mouse_y > 37) && (mouse_y < 50) ) pallete[b_color].g = ((mouse_x - 100) / 3 );/* green bar */
                     if ((mouse_y > 49) && (mouse_y < 63) ) pallete[b_color].b = ((mouse_x - 100) / 3 );/* blue bar */
                     set_pallete(pallete);
                  }
               pallete[252].r = pallete[b_color].r; /* set temp color to red value */
               pallete[252].g = 0;
               pallete[252].b = 0;
               pallete[253].r = 0;
               pallete[253].g = pallete[b_color].g; /* set temp color to green value */
               pallete[253].b = 0;
               pallete[254].r = 0;
               pallete[254].g = 0;
               pallete[254].b = pallete[b_color].b; /* set temp color to blue value */
               set_pallete(pallete);

            }
        if (key[KEY_F12])
           {

              int x, cn;
              float ns;
              remove_keyboard();
              textout(screen, font, "color_number", 10,10, 255);
              scanf("%d", &cn);
              textout(screen, font, "steps", 10,10, 255);
              scanf("%f", &ns);

              for (x=0; x<ns; x++)
                 {
                    pallete[cn+(x*16)].r = pallete[cn].r * (1 - (x/ns)) ;
                    pallete[cn+(x*16)].g = pallete[cn].g * (1 - (x/ns)) ;
                    pallete[cn+(x*16)].b = pallete[cn].b * (1 - (x/ns)) ;
                 }
              install_keyboard();
              set_pallete(pallete);
           }






   } while ( (!key[KEY_ESC]) && (!(mouse_b & 2)) );
/* redraw the whole screen after edit pallete  */

}

int select_bitmap(int b1_exit_flag)  /* (1) b1 exits */
{
extern BITMAP *memory_bitmap[512];
extern int bmp_index;
extern int bs_win;   /* to keep the window position */
int bms_retval, bms_quit = 0;
int x, y;
char msg[80];
          show_mouse(NULL);

          textout(screen, font, "Select a Bitmap with b1 ", 0, 160,  246);
          textout(screen, font, "ctrl-b1 copy  b2-exit  esc-abort" , 0, 170, 214);
      do
         {
            /* this is to draw 16x8 bitmaps  */
            for (y = 0; y < 8; y++)
               for (x = 0; x < 16; x++)
                  blit(memory_bitmap[(((y+bs_win)*16)+x)], screen, 0, 0, (x*20), (y*20), 20, 20);
            sprintf(msg,"pointer %-2d  ",(mouse_x/20) + (((mouse_y/20)+bs_win) * 16) );
            textout(screen, font, msg, 220, 160, 198);

            show_mouse(screen);
            rest(10);
            show_mouse(NULL);
            if ( (key[KEY_DOWN]) || ((mouse_y > 155) && (mouse_y< 170)) )
               {
                  bs_win = bs_win + 1;
                  rest(60);
                  if (bs_win > 24) bs_win = 24;
               }
            if ((key[KEY_UP]) || (mouse_y < 5))
               {
                  bs_win = bs_win - 1;
                  if (bs_win < 0) bs_win = 0;
                  rest(60);
               }
            if (mouse_y < 160)
               {
                  if ((key[KEY_CONTROL]) && (mouse_b & 1))
                     {
                        x = ((mouse_x/20)+(((mouse_y/20)+bs_win)*16));
                        blit(memory_bitmap[bmp_index], memory_bitmap[x], 0, 0, 0, 0, 20, 20);/* put */
                     }
                  else if (mouse_b & 1)
                     {
                        bmp_index = ((mouse_x/20)+(((mouse_y/20)+bs_win)*16));
                        bms_retval = 1;
                        if (b1_exit_flag) bms_quit = 1;

                     }
               }
             if (mouse_b & 2)
                {
                   bms_retval = 0;
                   bms_quit = 1;
                }
             if (key[KEY_ESC])
                {
                   bms_retval = -1;
                   bms_quit = 1;
                }
     

           } while (!bms_quit);

      return bms_retval;
      clear_keybuf();
      rest(500); /* to kill key presses */
   }





int animation(int zzindx)
{
extern BITMAP *memory_bitmap[512];
extern int zz[20][64];
extern int passcount;
extern int bmp_index;
extern int edit_int_retval;

int as_quit = 0;
int c, x, y;
float fx, fy;
char msg[80];
          show_mouse(NULL);
          clear(screen);
   do
      {
         show_mouse(screen);
         rest(20);
         show_mouse(NULL);
         
         sprintf(msg,"passcount delay %d  ",zz[3][zzindx]);
         textout(screen, font, msg, 0, 118, 240);
         sprintf(msg,"get new shapes");
         textout(screen, font, msg, 0, 126, 240);
         
         sprintf(msg,"pointer %d  ",(mouse_x / 20)+((mouse_y/20)*16) );
         textout(screen, font, msg, 0, 176, 192);
         sprintf(msg,"current sequence %d  ",zzindx);
         textout(screen, font, msg, 0, 184, 192);
         sprintf(msg,"passcount %d ",passcount);
         textout(screen, font, msg, 0, 192, 246);
     if (key[KEY_DEL])
        {
           for (c=0;c<20;c++)
              zz[c][zzindx] = 0;
           clear(screen);
        }
     if (mouse_b & 1)
        {
           if (mouse_y < 80)
              {
                 zzindx = ( (mouse_x / 20) + ( (mouse_y / 20) * 16) );
                 clear(screen);
              }
           /* edit delay */
           if ( (mouse_y > 117) && (mouse_y < 126) && (mouse_x < 150) )
              if (edit_int(160, 118, zz[3][zzindx], 1, 0, 100))
                 zz[3][zzindx] = edit_int_retval;

           if ( (mouse_y > 125) && (mouse_y < 134) && (mouse_x < 120) )
              {   /* get new shapes  */
                 int temp_zzindx = zz[4][zzindx];
                 zz[4][zzindx] = 0;
                 as_quit = 0;
                 rest(200);
                 do
                    {
                       clear(screen);
                       sprintf(msg, "Get Shape #%d ", zz[4][zzindx] );
                       textout(screen, font, msg, 0, 192, 1);
                       x = select_bitmap(1);

                       if (x == 1) /* good return b1 */
                          {
                             zz[5 + zz[4][zzindx]][zzindx] = bmp_index;
                             rest(300); /* to prevent repeat */
                             zz[4][zzindx]++; /* set last shape to point at next */
                          }
                       if (x == 0)  /* done  b2 */
                          {
                             zz[4][zzindx]--;
                             as_quit=1;
                          }
                       if (x == -1)  /* abort esc */
                          {
                             if (zz[4][zzindx] == 0) zz[4][zzindx] = temp_zzindx;
                             as_quit=1;
                          }
                 } while (!as_quit);
                 rest(100);
                 clear_keybuf();
                 clear(screen);
              }
         }
for (c = 0; c < zz[4][zzindx] + 1; c++)   /* show current seq shapes */
   if (( zz[5+c][zzindx] < 512) && (zz[5+c][zzindx] > 0))
      blit(memory_bitmap[ zz[5+c][zzindx] ], screen, 0, 0, c*20, 80, 20, 20);

for (c=0; c < 16; c++)   /* draw 16x4*/
   for (x=0; x < 4; x++)
     if (zz[4][c + (x * 16)] != 0)
        if ((zz[0][c + (x * 16)] < 512) && (zz[0][c + (x * 16)] > 0 ))
           blit(memory_bitmap[zz[0][c + (x * 16)]], screen, 0, 0, c*20, x*20, 20, 20);
     update_animation();
   } while ((!key[KEY_ESC]) && (!(mouse_b & 2)))  ;
       return zzindx;
       rest(200);
   }

void bitmap_menu(void)
{
   extern BITMAP *memory_bitmap[512];
   extern int zz[20][64]; /* to show current seq */
   extern int bmp_index; /* current bitmap selection */
   int c, x, y, b1_color;
   int zzindx = 0;    /* current animation seq */

   int btmgry=999, se1gry=999;
   char msg[80];
   show_mouse(NULL);
   clear(screen);
   clear_keybuf; /* to prevent selecting on entry */

   do
      {
         textout(screen, font, " Bitmap and Pallete Top Menu ", 40, 174, 246);
         btmgry = (bottom_menu(3));   /* call the menu handler */
         if ( (btmgry == -1) && (mouse_b & 2) && (mouse_y < 160))
            btmgry = 999; /* eat b2 exit if in upper screen */
         if (btmgry != 999) clear(screen);


         if (btmgry == 0) {
            zzindx = animation(zzindx);
            if (mouse_b & 2) while (mouse_b & 2); /* wait for release */
            clear_keybuf; /* to prevent selecting */
            }


         if (btmgry == 1)
            {
               select_bitmap(0);
               while (mouse_b & 2);
            }
         if (btmgry == 3)
            {
               edit_pallete(b1_color);
               clear (screen);
               draw_current_image(memory_bitmap[bmp_index],bmp_index);
               draw_color_selection_pallete();
               rest(500);
            }
         if (btmgry == 5) load(0,0,0,0,1);
         if (btmgry == 6) save(0,0,0,0,1);

         if (btmgry == 4) /* fx1 sub sub menu  */
            {
               clear(screen);
               clear_keybuf;
               se1gry = 999;
               rest(200); /* to prevent selecting on entry */
               draw_current_image(memory_bitmap[bmp_index],bmp_index);
               do
                  {
                     textout(screen, font, " Special Effects 1 Menu ", 40, 174, 246);
                     se1gry = (bottom_menu(4));   /* call the menu handler */
                     if (se1gry == 0) bm_flip_y_axis(bmp_index);
                     if (se1gry == 1) bm_flip_x_axis(bmp_index);
                     if (se1gry == 2) bm_scroll_up(bmp_index);
                     if (se1gry == 3) bm_scroll_down(bmp_index);
                     if (se1gry == 4) bm_scroll_left(bmp_index);
                     if (se1gry == 5) bm_scroll_right(bmp_index);
                   } while (se1gry != -1);  /* quit the effects 1 menu  */
               rest(500);
               clear_keybuf();
            }
         if (btmgry != 999) clear(screen);



         /* draw begins here  */

         draw_color_selection_pallete(); /* initial setup */
         draw_current_image(memory_bitmap[bmp_index],bmp_index);
         if ((mouse_y < 160) && (mouse_x > 160)) /* mouse on large bmp */
            {
               x = ((mouse_x-160)/8);
               y = (mouse_y/8);
               sprintf(msg,"x %-2d ",x);
               textout(screen, font, msg, 246, 164, 255);
               sprintf(msg,"y %-2d ",y);
               textout(screen, font, msg, 286, 164, 255);
               c = getpixel(memory_bitmap[bmp_index], x, y);
               sprintf(msg,"col %-2d ",c);
               textout(screen, font, msg, 180, 164, 255);
               rectfill(screen, 160, 164, 179, 171, c);

            }
         else rectfill(screen, 160, 164, 319, 171, 0);
         if ((mouse_x < 64) && (mouse_y >89)  && (mouse_y < 154)) /* mouse on colors */
            {
               c = ((mouse_x / 4) + (((mouse_y - 90) / 4) * 16));
               sprintf(msg,"   color =%-4d", c);
               textout(screen, font, msg, 0, 155, c);
               rectfill(screen, 110, 154, 155, 162, c);
   
            }
         else rectfill(screen, 0, 154, 155, 162, 0); /* erase if not on color menu */
   
         sprintf(msg,"b1 color =%-4d",b1_color);
         textout(screen, font, msg, 0, 163, 255);
         rectfill(screen, 110, 163, 150, 171, b1_color);
   
        for (c = 0; c < 8; c++)   /* show current seq shapes */
           {
               if  (zz[4][zzindx]  >  c - 1)  /* is shape in seq? */
                blit(memory_bitmap[zz[ 5+c][zzindx]],screen,0,0,c*20,20,20,20);
               if ((zz[4][zzindx]) > (c + 7))
                  blit(memory_bitmap[zz[13+c][zzindx]],screen,0,0,c*20,40,20,20);
           }
           /* show current animimation seq */
         if ((zz[0][zzindx] > 0) && (zz[0][zzindx] < 511))
            blit(memory_bitmap[zz[0][zzindx]],screen, 0, 0, 0, 0, 20, 20);
         sprintf(msg,"animation seq %-2d",zzindx);
         textout(screen, font, msg, 30, 6, 255);
   
         /* show the current bitmap and number */
         sprintf(msg,"current bmp %-2d  ",(bmp_index));
         textout(screen, font, msg, 10, 70, 255);
         blit(memory_bitmap[bmp_index],screen, 0, 0, 130, 64, 20, 20);
       
         show_mouse(screen);  rest(5);
   
         if (mouse_b & 1)
            {

               if ((mouse_x < 64) && (mouse_y >89)  && (mouse_y < 154)) b1_color=(((mouse_x) / 4) + (((mouse_y - 90) / 4) * 16) ) ;
               if ((mouse_y < 160) && (mouse_x > 160))  /* put pixel */
                  {
                     x = ((mouse_x - 160) / 8);
                     y = (mouse_y /8);
                     show_mouse(NULL);
                     putpixel(memory_bitmap[bmp_index],x,y,b1_color);
                     draw_current_image(memory_bitmap[bmp_index],bmp_index);
                     show_mouse(screen);
                  }
               if ( (mouse_y > 19) && (mouse_y < 60) && (mouse_x < 160) ) /*  select bitmap */
                  {
                     c = (((mouse_y / 20) - 1) * 8) + (mouse_x / 20); /* pointer */
                     if (c <= zz[4][zzindx]) /* check that its in the seq */
                        bmp_index = zz[5 + (((mouse_y / 20) - 1) * 8) + (mouse_x / 20)][zzindx];
                     draw_current_image(memory_bitmap[bmp_index],bmp_index);
      
                  }

            }
         if (mouse_b & 2)
            {

               if ((mouse_y < 160) && (mouse_x > 160))  /* get b1 color */
                   {
                      x = ((mouse_x - 160) / 8);
                      y = (mouse_y /8);
                      b1_color=getpixel(memory_bitmap[bmp_index], x, y);
                   }
       
            }
         update_animation();
      } while (btmgry != -1);  /* quit the bitmap menu  */
   while ((mouse_b & 2) || (mouse_b & 1));

   clear_keybuf();
}



