#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <allegro.h>

extern int l[100][100];
extern int mov_ob[20][20];

int is_right_solid(int solid_x, int solid_y)
{
         int a, b, c, d;
         int xx = (solid_x / 20) + 1;
         int yy = (solid_y / 20);
         int cc = (solid_y / 20) + 1;
         a = solid_y % 20;
          for (d = 0; d<20; d++)
            if (mov_ob[d][0]) /* if active */
               if (solid_y > mov_ob[d][3] - 18)
                  if (solid_y < mov_ob[d][5] - 2)
                     if (solid_x < mov_ob[d][2] - 8)
                        if (solid_x > mov_ob[d][2] - 18)
                           return 32+d;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][cc];
                 if ((c > 7 ) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17)) /* dual compare with ||  */
             {
                 b = l[xx][yy];
                 c = l[xx][cc];
                 if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }


         return 0;
}
 int is_left_solid(int solid_x, int solid_y)
{


         int a, b, c, d;
         int xx = (solid_x / 20);
         int yy = (solid_y / 20);
         int cc = (solid_y / 20)+1;
         a = solid_y % 20;
          for (d = 0; d<20; d++)
            if (mov_ob[d][0]) /* if active */
               if (solid_y > mov_ob[d][3] - 18)
                  if (solid_y < mov_ob[d][5] - 2)
                     if (solid_x < mov_ob[d][4] + 2)
                        if (solid_x > mov_ob[d][4] - 8)
                           return 32+d;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][cc];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17))/* dual compare with ||  */
             {
                b = l[xx][yy];
                c = l[xx][cc];
                if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }

         return 0;
}
int is_down_solid(int solid_x, int solid_y)
{

         int a, b, c, d;
         int yy = (solid_y / 20)+1;
         int cc = (solid_x / 20);
         int xx = (solid_x / 20)+1;
         a = solid_x % 20;


         for (d = 0; d<20; d++)  /* check for mov first */
            if (mov_ob[d][0])    /* if active */
               if (solid_x > mov_ob[d][2]-18)
                  if (solid_x < mov_ob[d][4]-2)
                     if (solid_y > mov_ob[d][3] - 25)
                        if (solid_y < mov_ob[d][3] - 10)
                            return d+32;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[cc][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a <17)) /* dual compare with ||  */
             {
                 b = l[xx][yy];
                 c = l[cc][yy];
                 if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }

         return 0;
}

int is_up_solid(int solid_x, int solid_y)
{

         int a, b, c, d;
         int yy = (solid_y-2)/20;
         int cc = (solid_x / 20);
         int xx = (solid_x / 20)+1;
         a = solid_x % 20;
         if (a > 16)  /* next block only */
             {
                 c = l[xx][yy];

                 if ((c > 15) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[cc][yy];

                 if ((c > 15) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17))/* dual compare with ||  */
             {
                 b = l[cc][yy];
                 c = l[xx][yy];
                 if ( ((b > 15) && (b < 256)) || ((c > 15) && (c < 256)) ) return 1;
             }
         for (d = 0; d<20; d++)
            if (mov_ob[d][0]) /* if active */
               if (solid_x > mov_ob[d][2] - 18)
                  if (solid_x < mov_ob[d][4] - 2)
                     if (solid_y < mov_ob[d][5] + 2)
                        if (solid_y > mov_ob[d][5] - 10)
                           return 2;




         return 0;
}
int is_up_solid_nosemi(int solid_x, int solid_y)
{

         int a, b, c, d;
         int yy = (solid_y-2)/20;
         int cc = (solid_x / 20);
         int xx = (solid_x / 20)+1;
         a = solid_x % 20;
         if (a > 16)  /* next block only */
             {
                 c = l[xx][yy];

                 if ((c > 7) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[cc][yy];

                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a < 17))/* dual compare with ||  */
             {
                 b = l[cc][yy];
                 c = l[xx][yy];
                 if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }
         for (d = 0; d<20; d++)
            if (mov_ob[d][0]) /* if active */
               if (solid_x > mov_ob[d][2] - 18)
                  if (solid_x < mov_ob[d][4] - 2)
                     if (solid_y < mov_ob[d][5] + 2)
                        if (solid_y > mov_ob[d][5] - 10)
                           return 2;




         return 0;
}


int is_down_solid_block_only(int solid_x, int solid_y)
{

         int a, b, c, d;
         int yy = (solid_y / 20)+1;
         int cc = (solid_x / 20);
         int xx = (solid_x / 20)+1;
         a = solid_x % 20;

         if (a > 16)  /* next block only */
             {
                 c = l[xx][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if (a < 3)    /* this block only */
             {
                 c = l[cc][yy];
                 if ((c > 7) && (c < 256)) return 1;
             }
         if ((a > 2) && (a <17)) /* dual compare with ||  */
             {
                 b = l[xx][yy];
                 c = l[cc][yy];
                 if ( ((b > 7) && (b < 256)) || ((c > 7) && (c < 256)) ) return 1;
             }

         return 0;
}

